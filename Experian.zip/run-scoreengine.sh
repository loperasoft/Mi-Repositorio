source ./submit.conf

spark2-submit --py-files $Local_Deploy_path/Deploy/ScoresEngine/libs/oxygenScoresEngine.zip,$Local_Deploy_path/Deploy/ScoresEngine/libs/scores.zip --jars $Local_Deploy_path/Deploy/lib/spark-avro_2.11-4.0.0.jar --files $Local_Deploy_path/Deploy/ScoresEngine/conf/log4j.properties,$Local_Deploy_path/Deploy/ScoresEngine/conf/app.conf,$Local_Deploy_path/Deploy/ScoresEngine/conf/scoresBundle.json,$Local_Deploy_path/Deploy/ScoresEngine/models/* --archives /projects/pro_sla_co_ebp_daily/encrypted/scoresvirualenv/myenv-jorge.zip#myenv-jorge \
--conf spark.yarn.appMasterEnv.PYSPARK_PYTHON=./myenv-jorge/myenv-jorge/bin/python \
--conf spark.driver.memory=35g \
--conf spark.yarn.maxAppAttempts=1 \
--conf "spark.dynamicAllocation.enabled=true" \
--master yarn \
--deploy-mode cluster \
--queue $queue_name \
--driver-cores 1 \
--num-executors 1 \
--executor-memory 8g \
--executor-cores 4 \
$Local_Deploy_path/Deploy/ScoresEngine/main.py --appConfig app.conf --scoresBundle scoresBundle.json
