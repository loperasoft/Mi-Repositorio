package TestMotorCaracteristicas;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Collections;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;



//import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
//import org.apache.spark.sql.avro.*;
import org.apache.spark.sql.SparkSession;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import co.com.experian.omnia.motorcrts.core.insumos.Consulta;
import co.com.experian.omnia.motorcrts.core.insumos.Cuenta;
import co.com.experian.omnia.motorcrts.core.insumos.Persona;
import co.com.experian.omnia.motorcrts.core.insumos.ReporteSuper;
import co.com.experian.omnia.motorcrts.core.parametros.Portafolio;
import co.com.experian.omnia.motorcrts.entrada.TransformadorEntradaXPM;
import co.com.experian.omnia.motorcrts.entrada.cobol.LectorRutinaCobol;
import co.com.experian.omnia.motorcrts.orquestador.*;


public class testEscribirArchivoVerificacion {

	interface FillPerson {

		public Persona executeAdapter(Integer index);

	}
	
	private static Map<String, String> salarios = new HashMap<String, String>();
	
	private static List<Persona> PersonaListaC = new ArrayList<Persona>();

    private static Map<Long,Persona> PersonaLista = new HashMap<Long, Persona>();

	
	
	public static void main(String[] args) {
		
		//"H"  "file:///test-ids/*" "C:/tmp/fullBusinessAttribs.json"
		//"H"  "file:///Users/c66357a/Documents/QueryXPM/XPM/14606923/14606923.json" "C:/tmp/fullBusinessAttribs.json"		
		//"C"  "C:/tmp/ICGMOT30IDSeasu.txt.SAL"
		//"C"  "C:/tmp/ICGMOT30IDS.txt.SAL.SI-NUMCTA"
		//"C"  "C:/tmp/ICGMOT30IDS.txt.SAL"
		//"C"  "C:/tmp/ICGMOT30IDS.txt.SAL.202004"
		//"C"  "C:/tmp/ICGMOT30IDS.txt.SAL.BITMAP"
		//"C"  "C:/tmp/ICGMOT30IDS.txt.SAL.BITMAP.201912"
		//"C"  "C:/tmp/ICGMOT30IDS.txt.SAL.BITMAP.TIPOBL.FORPAG"
		//"C"  "C:/tmp/ICGMOT50000IDS.txt.SAL.20200520"
		//"C"  "C:/tmp/ICGMOT50000IDS.TXT.SAL.20200602"
		//"C"  "C:/tmp/ICGMOT50000IDS.TXT.SAL.20200612"
		//"C"  "C:/tmp/ICGMOT50000IDSN.TXT.SAL"
		//"C"  "C:/tmp/ICGMOT50000IDSN_15072020.TXT.SAL"
		//"C"  "C:/tmp/ICGMOT50000IDSN_22072020.TXT.SAL"
		//"C"  "C:/tmp/ICGMOT50000IDSJ_22072020.TXT.SAL"
		
        if(args[0].startsWith("H") && args.length != 3 )
        {           
          	System.out.println("Debe ingresar la fuente del archivo (C= Cobol, H = Haddop), La Ruta y/o Nombre del Archivo a Procesar y Nombre del Archivo Bundle (Path incluido)!");
           	System.exit(0);                       
        }

        if(args[0].startsWith("C") && args.length != 2)
        {
            	System.out.println("Debe ingresar la fuente del archivo (C= Cobol, H = Haddop) y La Ruta y/o Nombre del Archivo a Procesar!");
            	System.exit(0);
        }	
        	
        salarios.put("2020", "877803");
        salarios.put("2019", "828116");
        salarios.put("2018", "781242");
        salarios.put("2017", "737717");
        salarios.put("2016", "689455");
        salarios.put("2015", "644350");
        salarios.put("2014", "616000");
        salarios.put("2013", "589500");
        salarios.put("2012", "566700");
        salarios.put("2011", "535600");
        salarios.put("2010", "515000");
        salarios.put("2009", "496900");
        salarios.put("2008", "461500");
        
        SparkSession spark = null;
        
        if(args[0].startsWith("C")) //Cobol
        {
        	EscribirArchivoVerificacion(spark, args[0], args[1], "");
        }
        else //Spark
        {
        	spark = SparkSession			  
  				  .builder()
  				  .master("local[3]")
  			      .appName("test Escribir Archivo Verificacion")			      
  			      .getOrCreate();        	
	    	        	
        	EscribirArchivoVerificacion(spark, args[0], args[1], args[2]);
        	
        	spark.stop();
        	
        }		
	}
	
		
	private static void EscribirArchivoVerificacion(SparkSession spark, String strFuente, String strArchivo, String strBundle) {

		Dataset<Row> dsArchivo = null;
		//List<Persona> Personas = new ArrayList<Persona>();
		
		try
		{
			
	    	/*Configuration configuration = new Configuration();
	    	FileSystem fileSystem = FileSystem.get(configuration);
        	
        	//Path srcPath = new Path("hdfs://nameservice1//projects/dev_sla_co_ebp/encrypted/XPM-Migration/release40_200520Icmchq50K201911EdfMirReplicaPin/");
        	Path srcPath = new Path(strArchivo);
	    	Path destPath = new Path("/home/c66357a/json/");
	    	fileSystem.copyToLocalFile(srcPath, destPath);*/			
	    	
			
			//System.out.println("Inside  try block of EscribirArchivoVerificacion "+strFuente.startsWith("C"));
			if(strFuente.startsWith("C"))
			{			  
				LectorRutinaCobol rutinaCobol = new LectorRutinaCobol();
				PersonaListaC = rutinaCobol.leerArchivo(strArchivo);
				for(Persona person: PersonaListaC){					
					//String sha1 = org.apache.commons.codec.digest.DigestUtils. .md2Hex( person.getId().toString() );//.sha1Hex					
					PersonaLista.put((long) person.hashCode(), person);
				}
			}
			else
			{
				
				if(strArchivo.endsWith(".avro"))
				{
					dsArchivo = spark.read().format("avro").load(strArchivo);
				}
				else
				{					
					dsArchivo = spark.read().json(strArchivo); //.option("multiline", "true").
					//dsArchivo.filter("_corrupt_record != null").count();

				}				
				
				//Obtiene el archivo Json de Bundles Caracteristicas y lo transforma a un objeto Json
				//System.out.println("Before calling JSOPARSER");
		        JsonParser parser = new JsonParser();
		        FileReader fr = new FileReader(strBundle);
		        JsonElement datos = parser.parse(fr);		        

				// Instancia el Orquestador 				
				OxygenAttributesEngine objOrquestador = OxygenAttributesEngine.getAttributesEngine();		        
		        
		        //Configura los Bundles de caractersiticas
				//System.out.println("objOrquestador.configure");
		        objOrquestador.configure(datos.toString(), salarios);				
		        
				//Obtiene una listas de Personas
		        Personas(dsArchivo);//Personas =								
				
			}
			
		    //sort por Id tipo Id
			
			System.out.println("Cantidad de Personas: " + PersonaLista.size());
			//PersonaLista.sort(Comparator.comparing(Persona::getId));      
			
			//System.out.println("Inicia impreson de persona");
		    // Configuracion HDFS
	    	/*Configuration configuration = new Configuration();
	    	FileSystem fileSystem = FileSystem.get(configuration);
        	//FSDataInputStream inputStream = fileSystem.open(srcPath);        	        	
	    	
	    	Path destPath = new Path("hdfs://nameservice1/user/c66357a/Haddop.csv");
	    	FSDataOutputStream fs = fileSystem.create(destPath, true);*/
	    	
		   
	    	//Configuracion LocalSystem
		    FileWriter writer = null;
		    StringBuilder stringBuffer = new StringBuilder();
		    
		    if(strFuente.startsWith("C"))
			{
		    	writer = new FileWriter("C:/Users/c66357a/Documents/Test Motor Caracteristicas/Cobol_test_id.txt");		    	
		    	//fs = fileSystem.create(new Path("hdfs://nameservice1/projects/dev_sla_co_ebp/encrypted/20200313Release30K/Cobol.csv"));		    	
			}
		    else
		    {
		    	writer = new FileWriter("C:/Users/c66357a/Documents/Test Motor Caracteristicas/Hadoop.txt");
		    	//writer = new FileWriter("/home/c66357a/csv/Hadoop.csv", true);
		    	//fs = fileSystem.create(new Path("hdfs://nameservice1/projects/dev_sla_co_ebp/encrypted/20200313Release30K/Hadoop.csv"));
		    	
		    }			
			
		    String campos = "Hash;tipoid;id;ciudadExpedicionDocumento;estadoVida;fechaExpedicionDocumento;fechaConsulta";//Datos Persona
		    //Datos Cuenta
		    campos += ";fechaActualizacion;codigoSuscriptor;portafolio;tipocuenta;numeroCuenta;garante;tipoObligacion;tipoGarantia;estado;cuotas;fechaApertura;fechaCancelacion;fechaVencimiento";
		    campos += ";nit;novedad;calificacion;bloqueo;reclamo;adjetivo1;adjetivo2;adjetivo3;fechaAdjetivo1;fechaAdjetivo2;fechaAdjetivo3;origenCredito;situacionTitular;estadoObligacion";
		    campos += ";formaPago;estadoSuscriptor";
		    campos += ";saldo_0;saldo_1;saldo_2;saldo_3;saldo_4;saldo_5;saldo_6;saldo_7;saldo_8;saldo_9;saldo_10;saldo_11;saldo_12";
		    campos += ";saldomora_0;saldomora_1;saldomora_2;saldomora_3;saldomora_4;saldomora_5;saldomora_6;saldomora_7;saldomora_8;saldomora_9;saldomora_10;saldomora_11;saldomora_12";
		    campos += ";cuota_0;cuota_1;cuota_2;cuota_3;cuota_4;cuota_5;cuota_6;cuota_7;cuota_8;cuota_9;cuota_10;cuota_11;cuota_12";
		    campos += ";cupo_0;cupo_1;cupo_2;cupo_3;cupo_4;cupo_5;cupo_6;cupo_7;cupo_8;cupo_9;cupo_10;cupo_11;cupo_12";		    
		    campos += ";mora_0;mora_1;mora_2;mora_3;mora_4;mora_5;mora_6;mora_7;mora_8;mora_9;mora_10;mora_11;mora_12;mora_13;mora_14;mora_15;mora_16;mora_17;mora_18;mora_19;mora_20;mora_21;mora_22;mora_23;mora_24";
		    campos += ";mora_25;mora_26;mora_27;mora_28;mora_29;mora_30;mora_31;mora_32;mora_33;mora_34;mora_35;mora_36;mora_37;mora_38;mora_39;mora_40;mora_41;mora_42;mora_43;mora_44;mora_45;mora_46;mora_47;mora_48";
		    campos += ";EsTEC;PeriodicidadPago;actividadEconomica;Genero;Edad;Nacionalidad;Estrato";
		    //Data Consultas
		    campos += ";fecha;codigoSuscriptorConsulta;nitSuscriptorConsulta;estadoSuscriptorConsulta";
		    //Data reportesSuper
		    campos += ";fechaReportesSuper;calificacionReportesSuper;portafolioSuper;trimestre;portafolioCalculado;suscriptorReportesSuper;nitSuscriptor";
		    campos += "\n";
	      
		    stringBuffer.append(campos);
		    //int vacios = 0;	      
		    String stringPersona = "";
		    String stringCuenta = "";
		    String stringConsultas = "";
		    String stringReportes = "";
		    String strCalificacion = "";
		    String FechaExpedicionDocumento = "";		    
		    Double valor = 0D;
		    String port = "";
		    Portafolio portafolio = new Portafolio();
		    
		    for (Entry<Long, Persona> XPM: PersonaLista.entrySet())		    
		    {                        
		    	Persona persona = XPM.getValue();
		    	Long lHash = XPM.getKey();		    	
		    	
		    	//System.out.println("Leyendo persona: " + persona.getId() + " Hash: " + lHash);
		    	
		    	if(persona.getId() != null ){
		          
		    	  /*if(persona.getId() == 1007752612L)//1007752612
		    	  {
		    		System.out.println("Leyendo persona: " + persona.getId() + " Hash: " + lHash);
		    	  }*/
		    	  
		          for(Cuenta cuenta : persona.getCuentas())
		          {
			         stringPersona += lHash.toString();
			         stringPersona += ";" + (strFuente.startsWith("H") ? cuenta.getTipoId(): cuenta.getTipoIdTec());
			         stringPersona += ";" + (strFuente.startsWith("H") ? cuenta.getNumeroId(): persona.getId());
			         stringPersona += ";" + persona.getDemografico().getCiudadExpedicionDocumento();
			         stringPersona += ";" + persona.getDemografico().getEstadoVida();
			          
			         FechaExpedicionDocumento = persona.getDemografico().getFechaExpedicionDocumento() != null ? persona.getDemografico().getFechaExpedicionDocumento().substring(0, 6): null;
			         stringPersona += ";" + FechaExpedicionDocumento;
			         stringPersona += ";" + persona.getFechaConsulta();
		        	  
		        	 port = portafolio.getPortafolio(cuenta);
					 cuenta.addPortafolio(port);				 					 					 
					 
					 //if(strFuente.startsWith("H"))
						 stringCuenta += ";" + cuenta.getFechaActualizacion();
					 /*else
						 stringCuenta += ";" + 
								 ((cuenta.getFechaActualizacion().equals("000000") == true
								 	&& (cuenta.getNovedad().equals("6") || cuenta.getNovedad().equals("9")))
								 	? cuenta.getNovedad() : cuenta.getFechaActualizacion());*/
					 
					 stringCuenta += ";" + cuenta.getCodigoSuscriptor();
					 stringCuenta += ";" + cuenta.getPortafolios().get(0);					 
		             stringCuenta += ";" + cuenta.getTipoCuenta();
		             stringCuenta += ";" + cuenta.getNumeroCuenta();
		             stringCuenta += ";" + cuenta.getGarante();
		             stringCuenta += ";" + cuenta.getTipoObligacion();
		             stringCuenta += ";" + cuenta.getTipoGarantia();
		             stringCuenta += ";" + cuenta.getEstado();
		             stringCuenta += ";" + cuenta.getCuotas();
		             stringCuenta += ";" + cuenta.getFechaApertura();
		             stringCuenta += ";" + cuenta.getFechaCancelacion();		             
		             stringCuenta += ";" + cuenta.getFechaVencimiento();
		             stringCuenta += ";" + cuenta.getNIT();		             
		             stringCuenta += ";" + cuenta.getNovedad();
		             
		             if(strFuente.startsWith("H"))
		             {
		            	 if(cuenta.getCalificacion()!= null)
		            	 {
			                 switch (cuenta.getCalificacion()) 
			                 {
			                     case "A": strCalificacion = "1";
			                               break;
			                     case "B": strCalificacion = "2";
			                              break;
			                     case "C": strCalificacion = "3";
			                              break;
			                     case "D": strCalificacion = "4";
			                              break;
			                     case "E": strCalificacion = "5";
			                              break;
			                     case "AA": strCalificacion = "6";
			                              break;
			                     case "BB": strCalificacion = "7";
			                              break;
			                     case "CC": strCalificacion = "8";
	                             		  break;		                              
			                     case "K": strCalificacion = "9";
	                             		   break;
			                     default: strCalificacion = "0";
			                              break;
			                 }
		            	 }
		                 else
		                 {
		                	 strCalificacion = "0";
		                 } 
		            	 
		            	 stringCuenta += ";"+strCalificacion;
		             }
		             else
		             {
		            	 stringCuenta += ";"+cuenta.getCalificacion();		            	 
		             }		             
		             
		             stringCuenta += ";"+cuenta.getBloqueo();
		             stringCuenta += ";"+cuenta.getReclamo();
		             stringCuenta += ";"+cuenta.getAdjetivo1();
		             stringCuenta += ";"+cuenta.getAdjetivo2();
		             stringCuenta += ";"+cuenta.getAdjetivo3();
		             stringCuenta += ";"+cuenta.getFechaAdjetivo1();
		             stringCuenta += ";"+cuenta.getFechaAdjetivo2();
		             stringCuenta += ";"+cuenta.getFechaAdjetivo3();		             
		             stringCuenta += ";"+cuenta.getOrigenCredito();
		             stringCuenta += ";"+cuenta.getSituacionTitular();
		             stringCuenta += ";"+cuenta.getEstadoObligacion();
		             stringCuenta += ";"+cuenta.getFormaPago();
		             stringCuenta += ";"+cuenta.getEstadoSuscriptor();
		             
		             //if(cuenta.getNumeroCuenta().equals("004513080278585140")) //000000000455420115
		            //	 System.out.println(cuenta.getVectorSaldo().toString());

	            	 Collections.reverse(cuenta.getVectorSaldo());		             
		             
		             for(int i = 0; i <= 12; i++)
		             {
		            	 if(cuenta.getVectorSaldo().size() > i)
		            	 {
		            		 valor = cuenta.getVectorSaldo().get(i);
		            	 	 stringCuenta += ";"+(valor!=null?valor:"");
		            	 }
		            	 else
		            		 stringCuenta += ";"+"";		            	 
		             }		             
		             
		        	 Collections.reverse(cuenta.getVectorSaldoMora());
		        	 
			         for(int i = 0; i <= 12; i++)
			         {
			           if(cuenta.getVectorSaldoMora().size() > i)
			           {
			         	 valor = cuenta.getVectorSaldoMora().get(i);
			          	 stringCuenta += ";"+(valor!=null?valor:"");
			           }
			           else
			         	 stringCuenta += ";"+"";		            	 
			         }			        	 
		             
		        	 Collections.reverse(cuenta.getVectorCuota());			        	 
 
			         for(int i = 0; i <= 12; i++)
			         {
			           if(cuenta.getVectorCuota().size() > i)
			           {
			         	 valor = cuenta.getVectorCuota().get(i);
			          	 stringCuenta += ";"+(valor!=null?valor:"");
			           }
			           else
			         	 stringCuenta += ";"+"";		            	 
			         }			        	 
		             
		            Collections.reverse(cuenta.getVectorCupo());		             
		            	 
			        for(int i = 0; i <= 12; i++)
			        {
			          if(cuenta.getVectorCupo().size() > i)
			          {
			         	 valor = cuenta.getVectorCupo().get(i);
			          	 stringCuenta += ";"+(valor!=null?valor:"");
			          }
			          else
			         	 stringCuenta += ";"+"";		            	 
			        }		             
			        
			        //if(strFuente.startsWith("C"))
			        	Collections.reverse(cuenta.getVectorMorosidad());
			        
		            //if(cuenta.getNumeroCuenta().equals("000377816086865023")) //"005291980007311640"
		            //	 System.out.println(cuenta.getVectorMorosidad().toString());

			        for(int i = 0; i <= 47; i++)
			        {
			          if(cuenta.getVectorMorosidad().size() > i)
			          {
			         	 valor = cuenta.getVectorMorosidad().get(i);
			          	 stringCuenta += ";"+(valor!=null?valor:"");
			          }
			          else
			         	 stringCuenta += ";"+"";		            	 
			        }		             

		            stringCuenta += ";;"+ cuenta.getEsTEC();
		            stringCuenta += ";" + cuenta.getPeriodicidadPago();
		            stringCuenta += ";" + persona.getDemografico().getActividadEconomica();
		            stringCuenta += ";" + persona.getDemografico().getGenero();
		            stringCuenta += ";" + persona.getDemografico().getEdad();
		            stringCuenta += ";" + persona.getDemografico().getNacionalidad();
		            stringCuenta += ";" + persona.getDemografico().getEstrato();
		            
		            stringCuenta = stringPersona + stringCuenta;
		            stringBuffer.append(stringCuenta+"\n");		            
		            stringPersona = "";
		            stringCuenta = "";
		          }
		          
		          for(Consulta consulta : persona.getConsultas())
		          {		        	  
				      stringPersona += lHash.toString();
			          stringPersona += ";" + consulta.getTipoId(); //(strFuente.startsWith("H") ? consulta.getTipoId(): persona.getTipoId());
				      stringPersona += ";" + (strFuente.startsWith("H") ? consulta.getNumeroId(): persona.getId());

				      stringPersona += ";" + persona.getDemografico().getCiudadExpedicionDocumento();
				      stringPersona += ";" + persona.getDemografico().getEstadoVida();				          
				      FechaExpedicionDocumento = persona.getDemografico().getFechaExpedicionDocumento() != null ? persona.getDemografico().getFechaExpedicionDocumento().substring(0, 6): null;
				      stringPersona += ";" + FechaExpedicionDocumento;
				      stringPersona += ";" + persona.getFechaConsulta();
				      
				      stringConsultas += ";" + persona.getDemografico().getActividadEconomica();
				      stringConsultas += ";" + persona.getDemografico().getGenero();
				      stringConsultas += ";" + persona.getDemografico().getEdad();
				      stringConsultas += ";" + persona.getDemografico().getNacionalidad();
				      stringConsultas += ";" + persona.getDemografico().getEstrato();
		        	  stringConsultas += ";" + consulta.getFecha().toString() + consulta.getDia().toString();
		        	  stringConsultas += ";" + consulta.getCodigoSuscriptor();
		        	  stringConsultas += ";" + consulta.getNitSuscriptor();
		        	  stringConsultas += ";" + consulta.getEstadoSuscriptor();
		        	  
		        	  //if(consulta.getNitSuscriptor().equals("890903938"))
		        	//	  System.out.println(consulta.getNitSuscriptor().toString());
		        		  
		        	  									  
		        	  stringConsultas = stringPersona +  ";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;" + stringConsultas;
			          stringBuffer.append(stringConsultas + "\n");
			          stringPersona = "";
			          stringConsultas = "";		        	  
		          }
		          
		          for(ReporteSuper reporte : persona.getReportesSuper())
		          {		        	  
				      stringPersona += lHash.toString();
				      stringPersona += ";" + persona.getTipoId();
				      stringPersona += ";" + persona.getId();
				      stringPersona += ";" + persona.getDemografico().getCiudadExpedicionDocumento();
				      stringPersona += ";" + persona.getDemografico().getEstadoVida();				          
				      FechaExpedicionDocumento = persona.getDemografico().getFechaExpedicionDocumento() != null ? persona.getDemografico().getFechaExpedicionDocumento().substring(0, 6): null;
				      stringPersona += ";" + FechaExpedicionDocumento;
				      stringPersona += ";" + persona.getFechaConsulta();
				      
				      stringReportes += ";" + persona.getDemografico().getActividadEconomica();
				      stringReportes += ";" + persona.getDemografico().getGenero();
				      stringReportes += ";" + persona.getDemografico().getEdad();
				      stringReportes += ";" + persona.getDemografico().getNacionalidad();
				      stringReportes += ";" + persona.getDemografico().getEstrato();
				      stringReportes += ";;;;";
				      stringReportes += ";" + reporte.getFecha();
		        	  stringReportes += ";" + reporte.getCalificacion();
		        	  stringReportes += ";" + reporte.getPortafolioSuper();
		        	  stringReportes += ";" + reporte.getTrimestre();
		        	  stringReportes += ";" + reporte.getPortafolioCalculado();
		        	  stringReportes += ";" + reporte.getSuscriptor();
		        	  stringReportes += ";" + reporte.getNitSuscriptor();
		        	  
		        	  stringReportes = stringPersona + ";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;" +stringReportes;
			          stringBuffer.append(stringReportes + "\n");
			          stringPersona = "";
			          stringReportes = "";		        	  
		          }

		          stringPersona = "";
		       }else {
		          //vacios++;
		        }
		    }	      
		      
		    writer.append(stringBuffer.toString());
		    writer.close();
		    
		    /*fs.write(stringBuffer.toString().getBytes(), 0, stringBuffer.toString().getBytes().length);		    
            fs.hflush();
            fs.close();*/
            //stringBuffer.delete(0, stringBuffer.length());		    
		    
	      //System.out.println("vacios:"+vacios);
	    } catch (Exception e) {
	      e.printStackTrace();
	      System.out.println(e);
	    }
	    
	}
	
	
	private static void Personas(Dataset<Row> jsonData)
	{		
		//System.out.println("Antes de volcar data List<String> Data" + jsonData.count());
		
		//List<Persona> PersonaLista = new ArrayList<Persona>();
		//JsonParser parser = new JsonParser();
				
		jsonData.toJSON().foreach(XPM ->
		{				
			//System.out.println("Antes de interar List<String> Data" + Data);
			
	        //FileReader fr = new FileReader(strBundle);
	        //JsonObject datosXPM = parser.parse(XPM).getAsJsonObject();		
	        JsonObject datosXPM = new JsonParser().parse(XPM.toString()).getAsJsonObject();
			//XPM.to
	        Long intHash = datosXPM.get("xpmHash").getAsLong();
	        
	        /*if (datosXPM.has("bestIdentifications"))
	        {
				JsonArray identifications = datosXPM.getAsJsonArray("bestIdentifications");
				JsonObject identification = (JsonObject) identifications.get(0);
				if (identification.has("personIdNumber")) {
					Long numId = Long.valueOf(identification.get("personIdNumber").getAsString());
		
					if(numId.equals(1007752612L))
					{
						System.out.println(XPM.toString());
					}
				}
	        }*/
				
			FillPerson fillPerson = (indice) -> {
				try {						
						//logger.info("convertir json de entrada en un objeto Persona con el adaptador SL");
						//System.out.println(XPM.toString());
						TransformadorEntradaXPM transformadorEntradaXPM = TransformadorEntradaXPM.getTransformadorEntradaXPM(salarios);
						return transformadorEntradaXPM.procesar(XPM.toString());
						
					} catch (Exception e) {
								e.printStackTrace();
								System.out.println(e);
								return null;
					}						
			};		
				
			Persona persona = fillPerson.executeAdapter(0);			
					
			if(persona != null)
			{				
				PersonaLista.put((long) intHash, persona );
				
				/*if(persona.getId().equals(1007752612L))
				{
					System.out.println("Agrego persona: " + persona.getId());					
				}*/
				
			}
				
		});
	    
		//return PersonaLista;		
	}
}