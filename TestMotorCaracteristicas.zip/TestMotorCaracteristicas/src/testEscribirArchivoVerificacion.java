// $example on:schema_merging$
//import java.io.Serializable;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
// $example off:schema_merging$
//import java.util.Properties;
//import org.apache.hadoop.hdfs.*;

// $example on:basic_parquet_example$
//import org.apache.spark.api.java.function.MapFunction;

//import org.apache.spark.sql.Encoder;
//import org.apache.spark.sql.Encoders;
// $example on:schema_merging$
// $example on:json_dataset$
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;


//import org.apache.spark.sql.avro.*;
// $example off:json_dataset$
// $example off:schema_merging$
// $example off:basic_parquet_example$
import org.apache.spark.sql.SparkSession;


public class testEscribirArchivoVerificacion {

	public static void main(String[] args) {
		
        if(args.length != 2){
            System.out.println("Por favor ingresar La Ruta y Nombre del Archivo a Procesar!");
            System.exit(0);
        }
				
		SparkSession spark = SparkSession			  
				  .builder()
			      .appName("test Escribir Archivo Verificacion")			      
			      .getOrCreate();
        
        
		EscribirArchivoVerificacion(spark, args[0], args[1]);
		
		spark.stop();
	}
	
	//
	private static void EscribirArchivoVerificacion(SparkSession spark, String strRuta, String strArchivo) {

		Dataset<Row> dfArchivo;
		
		try {

	     if(strRuta.startsWith("hdfs://"))
	     {
	    	 dfArchivo = spark.read().format("avro").load(strRuta + strArchivo);
	    	 dfArchivo.select("id", "tipoid").sort("id", "tipoid").write().format("avro").save(strRuta + "Personas.avro");
	     }
	     else
	     {
	    	 dfArchivo = spark.read().format("json").load(strRuta + strArchivo);
	    	 dfArchivo.select("id", "tipoid").sort("id", "tipoid").write().format("json").save(strRuta + "Personas.json");
	     }
	     
	     
	     
	    	
	    	
	      /*LectorRutinaCobol rutinaCobol = new LectorRutinaCobol();
	      List<Persona> personas = rutinaCobol.leerArchivo("D:/bases_acierta_master/dat1905_9090662.SAL");
	      //List<Persona> personas = rutinaCobol.leerArchivo("D:/prueba_data/datval824425_201812.SAL_insumos_act_14122018");
	      
	      FileWriter writer = new FileWriter("D:/bases_acierta_master/salida_cuentas_nuevo2.csv");
	      StringBuilder stringBuffer = new StringBuilder();
	      
	      Portafolio portafolio = new Portafolio();      

	      for (Persona persona : personas) {                        
	        for (Cuenta cuenta : persona.getCuentas()) {
	          String port = portafolio.getPortafolio(cuenta);
	          cuenta.addPortafolio(port);                       
	        }        
	      }*/
	      
	      
	      /*String campos = "id;tipoid;fecha;tipocuenta;cuenta;portafolio;novedad;origen_credito";
	      campos += ";cuota_0;cuota_1;cuota_2;cuota_3;cuota_4;cuota_5;cuota_6;cuota_7;cuota_8;cuota_9;cuota_10;cuota_11;cuota_12";
	      campos += ";cupo_0;cupo_1;cupo_2;cupo_3;cupo_4;cupo_5;cupo_6;cupo_7;cupo_8;cupo_9;cupo_10;cupo_11;cupo_12";
	      campos += ";saldo_0;saldo_1;saldo_2;saldo_3;saldo_4;saldo_5;saldo_6;saldo_7;saldo_8;saldo_9;saldo_10;saldo_11;saldo_12";
	      campos += ";saldomora_0;saldomora_1;saldomora_2;saldomora_3;saldomora_4;saldomora_5;saldomora_6;saldomora_7;saldomora_8;saldomora_9;saldomora_10;saldomora_11;saldomora_12";
	      campos += ";mora_0;mora_1;mora_2;mora_3;mora_4;mora_5;mora_6;mora_7;mora_8;mora_9;mora_10;mora_11;mora_12;mora_13;mora_14;mora_15;mora_16;mora_17;mora_18;mora_19;mora_20;mora_21;mora_22;mora_23;mora_24;mora_25;mora_26;mora_27;mora_28;mora_29;mora_30;mora_31;mora_32;mora_33;mora_34;mora_35;mora_36;mora_37;mora_38;mora_39;mora_40;mora_41;mora_42;mora_43;mora_44;mora_45;mora_46;mora_47;mora_48";
	      campos += "\n";
	      
	      stringBuffer.append(campos);
	      int vacios = 0;
	      
	      String stringPersona = "";
	      String stringCuenta = "";
	      //System.out.println("Personas:"+personas.size());
	      for (Persona persona : personas) {                        
	        if(persona.getId()!=null ){
	          stringPersona += persona.getId();
	          stringPersona += ";"+persona.getTipoId();
	          stringPersona += ";"+persona.getFecha();
	          for(Cuenta cuenta : persona.getCuentas()){
	            stringCuenta += ";"+cuenta.getTipoCuenta();
	            stringCuenta += ";"+cuenta.getNumeroCuenta();
	            stringCuenta += ";"+cuenta.getPortafolios().get(0);
	            stringCuenta += ";"+cuenta.getNovedad();
	            stringCuenta += ";"+cuenta.getOrigenCredito();
	            
	            for(Double valor:cuenta.getVectorCuota()){
	              stringCuenta += ";"+(valor!=null?valor:"");
	            }
	            for(Double valor:cuenta.getVectorCupo()){
	              stringCuenta += ";"+(valor!=null?valor:"");
	            }
	            for(Double valor:cuenta.getVectorSaldo()){
	              stringCuenta += ";"+(valor!=null?valor:"");
	            }
	            for(Double valor:cuenta.getVectorSaldoMora()){
	              stringCuenta += ";"+(valor!=null?valor:"");
	            }
	            for(Double valor:cuenta.getVectorMorosidad()){
	              stringCuenta += ";"+(valor!=null?valor:"");
	            }
	            stringCuenta = stringPersona+stringCuenta;                        
//	            System.out.println(stringCuenta);
	            stringBuffer.append(stringCuenta+"\n");
	            stringCuenta = "";
	          }          
	          stringPersona = "";
	        }else {
	          vacios++;
	        }
	      }
	      
		  //sord por Id tipo Id 
		  
	      
	      writer.append(stringBuffer.toString());
	      writer.close();
	      System.out.println("vacios:"+vacios);*/
	    } catch (Exception e) {
	      e.printStackTrace();
	      System.out.println(e);
	    }
	    
	  }
}
