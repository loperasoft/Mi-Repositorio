import collections


def nested_dict():
    """ Creates an arbitrarily deep dictionary.

    E.g. given x = { "a" : { "b": 10 } }, nesting x you can access to "b" value just writing: x["a.b"].

    :return: nested dictionary.
    """
    return collections.defaultdict(nested_dict)


def default_to_regular(d):
    """ Converts a nested dict into regular dictionary.

    :param d: nested dictionary.
    :return: regular dictionary.
    """
    if isinstance(d, collections.defaultdict):
        d = {k: default_to_regular(v) for k, v in d.items()}
    return d
