#!/usr/bin/env python
# -*- coding: utf-8 -*-
import json
import traceback


class inputAdapter(object):
    """
    Input adapter
    """

    def readXpm(self, xpm):
        """
        Converts XMP string object into a readable json object.

        :param xpm: Individual XPM
        :return: XPM as json object
        """
        try:
            # Load XPM as a json object
            xpm_json = json.loads(xpm)
        except Exception, error:
            # On error set xmp_json as an empty string
            xpm_json = None

            tb = traceback.format_exc()
            self.log.error("Error: {}, {}".format(error, tb))

        return xpm_json

    @staticmethod
    def getXpmAttributesData(xpm_json, score_attributes_list):
        """Return the attributes data to calculate a given score by evaluating attributes expressions.

        :param xpm_json: XPM json object
        :param score_attributes_list: Attributes names and paths dictionary
        :return: xpm attributes data for computing the given score
        """
        scoreAttributesData = {}
        if score_attributes_list:
            for attribute in score_attributes_list:
                attributeName = attribute.get("name")  # type: str
                xpmAttributeExpr = attribute.get("xpmAttributeExpr")
                attributeFormat = attribute.get("attributeFormat")
                # noinspection PyBroadException
                try:
                    expr = xpmAttributeExpr.format(xpm="xpm_json", name=attributeName)
                    extractedAttributeValue = eval(expr)  # type: list
                    if extractedAttributeValue:
                        [attributeValue] = extractedAttributeValue[-1:]
                        scoreAttributesData[attribute.get("name")] = attributeFormat(attributeValue)
                    else:
                        scoreAttributesData[attribute.get("name")] = attributeFormat(-1.0)
                except Exception:
                    scoreAttributesData[attribute.get("name")] = attributeFormat(-1.0)
            return scoreAttributesData
        else:
            return None

    def checkConsistency(self, xpm_json):
        """Check XPM consistency according to required sections.

        :param xpm_json: XPM json object
        :return: True or False depending on xpm consistency
        """
        # Check for needed sections
        for checkSectionExpr in self.scoresCheckSections:
            # noinspection PyBroadException
            try:
                expr = checkSectionExpr.format(xpm="xpm_json")
                consistencyCheck = eval(expr)
                if not bool(consistencyCheck):
                    return False
            except Exception:
                return False
        return True
