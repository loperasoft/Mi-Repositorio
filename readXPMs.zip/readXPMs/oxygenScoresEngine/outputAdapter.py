#!/usr/bin/env python
# -*- coding: utf-8 -*-
import traceback


class outputAdapter(object):
    """
    Output adapter
    """

    def polishScoreValue(self, raw_score_value, score_output_xpm):
        """Polish score returned dictionary.

        :param raw_score_value: resulting score dictionary
        :param score_output_xpm: score field to xpm field mapping dictionary
        :return: Adjusted score output to the xpm fields
        """
        polishScore = {}
        try:
            for outputFieldsProperties in score_output_xpm:
                scoreFieldName = outputFieldsProperties.get("scoreFieldName")
                xpmFieldName = outputFieldsProperties.get("xpmFieldName")
                if scoreFieldName and xpmFieldName:
                    formatScoreValue = self.formatOutputValue(
                        raw_score_value[scoreFieldName], outputFieldsProperties.get("xpmFieldFormat")
                    )
                    polishScore.update({xpmFieldName: formatScoreValue})
                else:
                    return raw_score_value
            return polishScore
        except Exception as error:
            tb = traceback.format_exc()
            self.log.error("!!! Error {}, {}".format(error, tb))
            return raw_score_value

    @staticmethod
    def formatOutputValue(value, xpm_field_format):
        """Formats an output score field value.

        :type value: list or float or int or str
        :param value: Score output field value
        :param xpm_field_format: Xpm field format (float, str, int, etc).
        """
        try:
            if xpm_field_format:
                formats = xpm_field_format.split(":")
                formatType1, formatType2 = (eval(formats[0]), None) \
                    if len(formats) == 1 else (eval(formats[0]), eval(formats[1]))
                if formatType1 == list:
                    if type(value) == list:
                        return [formatType2(val) for val in value]
                elif formatType2 is None:
                    return formatType1(value)
                else:
                    return value
            else:
                return value
        except NameError or ValueError or TypeError:
            return value

    def xpmOutFormatter(self, score_outputs, score_input_data):
        """Format resulting score outputs into the xpm schema

        :param score_outputs: Scores resulting outputs list
        :param score_input_data: Scores attributes list
        :return: Formatted score outputs
        """
        idType = score_input_data.get("TIPOID", None)
        idNumber = score_input_data.get("NUMID", None)
        if idType and idNumber:
            try:
                formatOutputSchema = self.scoresOutputSchema.format(
                    idTypeFieldName=self.scoresOutputIdTypeField,
                    idNumberFieldName=self.scoresOutputIdNumberField,
                    scoresFieldName= self.scoresSubSectionFieldName,
                    idType=int(idType),
                    idNumber=str(int(idNumber)),
                    scores=score_outputs
                )
                return eval(
                    "".join(["{", formatOutputSchema, "}"])
                )
            except SyntaxError or TypeError or NameError or ValueError:
                return {
                    'personIdType': int(idType),
                    'personIdNumber': str(int(idNumber)),
                    'scores': score_outputs
                }
        else:
            return {}

    def updateXpm(self, scores_outputs_xpm, xpm_json):
        """Update de Input Xpm with the output information

        :param scores_outputs_xpm: calculated scores section.
        :param xpm_json: XPM json object
        :return: updated XPM json object
        """
        if scores_outputs_xpm.get(self.scoresSubSectionFieldName):
            foundMatch = False
            if xpm_json.get(self.scoresMainSectionFieldName):
                for i in range(len(xpm_json[self.scoresMainSectionFieldName])):
                    inputBureauScore = xpm_json.get(self.scoresMainSectionFieldName)[i]
                    inputIdNumberField = inputBureauScore.get(self.scoresOutputIdNumberField)
                    inputIdTypeField = inputBureauScore.get(self.scoresOutputIdTypeField)

                    # Check if scores are already calculated
                    if inputIdNumberField == scores_outputs_xpm.get(self.scoresOutputIdNumberField) and \
                            inputIdTypeField == scores_outputs_xpm.get(self.scoresOutputIdTypeField):
                        # Append the calculated scores
                        xpm_json[self.scoresMainSectionFieldName][i][self.scoresSubSectionFieldName] += (
                            scores_outputs_xpm.get(self.scoresSubSectionFieldName)
                        )
                        foundMatch = True
                        break
                if not foundMatch:
                    xpm_json[self.scoresMainSectionFieldName].append(scores_outputs_xpm)
            else:
                xpm_json.update({self.scoresMainSectionFieldName: [scores_outputs_xpm]})
        return xpm_json
