#!/usr/bin/env python
# -*- coding: utf-8 -*-
""" Orchestrator Module.

Orchestrator reads the incoming XPM information and calculates, if possible, the scores values for each individual
mapped into the XPM.
"""
import logging
import traceback
import sys
import importlib
import json
from logging import Logger

from typing import List, Any

from oxygenScoresEngine.inputAdapter import inputAdapter
from oxygenScoresEngine.outputAdapter import outputAdapter
from copy import deepcopy


class Orchestrator(inputAdapter, outputAdapter):
    """Orchestrator main class.
    """
    # Logging configuration
    log = logging.getLogger('scoresEngine')  # type: Logger
    _handler = logging.StreamHandler(sys.stdout)
    # Logging format e.g. 2020-02-07 10:43:31,749 - scoresEngine - INFO: ...
    _handler.setFormatter(logging.Formatter("%(asctime)s - %(name)s - %(levelname)s : %(message)s"))
    log.addHandler(_handler)

    def __init__(self, scores_bundle, app_config):
        """ Init class function.

        Initialize configuration parameters including spark current session and input and output adapters.

        :param scores_bundle: Bundle with the scores information (instances, score name, etc)
        :param app_config: Configuration object with the app information (storage format, xpm paths, etc)
        :raise ValueError: when scores bundle or app configuration are not valid or empty.
        """
        # Initialize input and output adapters
        inputAdapter.__init__(self)
        outputAdapter.__init__(self)

        # Obtain app configuration and scores information
        if not scores_bundle or not app_config:
            raise ValueError("Scores Bundle or app configuration is empty !!!")
        else:
            # Get pySpark logging level. Default: Error.
            self.sparkLogLevel = app_config.get("pySpark", "logLevel") \
                if app_config.has_section("pySpark") and app_config.has_option("pySpark", "logLevel") else "ERROR"
            # Validate XPM path configuration.
            if app_config.has_section("application"):
                # Get App name. Default: 'scoresEngine'
                self.appName = app_config.get("application", "appName") \
                    if app_config.has_option("application", "appName") else "scoresEngine"
                # Get incoming data storage format. Default: 'text'
                self.storageFormat = app_config.get("application", "storageFormat") \
                    if app_config.has_option("application", "storageFormat") else "text"
                # Get source, target a SMLMV paths.
                self.sourceXpm = app_config.get("application", "sourceXpm") if app_config.has_option(
                    "application", "sourceXpm") else None
                self.targetXpm = app_config.get("application", "targetXpm") if app_config.has_option(
                    "application", "targetXpm") else None
                self.smlmvPath = app_config.get("application", "smlmvPath") if app_config.has_option(
                    "application", "smlmvPath") else None
            else:
                raise ValueError("App configuration has not 'application' field !!!")
            if scores_bundle.get("scores") and scores_bundle.get("scoresAttributes"):
                # Attributes Json section
                self.scoresAttributes = scores_bundle.get("scoresAttributes")
                # Scores Json section
                self.scoresBundle = scores_bundle.get("scores")
            else:
                raise ValueError("Scores Bundle has not 'scores' field or 'scoresAttributes' field !!!")
            if scores_bundle.get("scoresOutputSchema"):
                # Loads scores section schema
                self.scoresOutputSchema = scores_bundle.get("scoresOutputSchema")
                # Load scores main section field name. Default: bureauModels
                self.scoresMainSectionFieldName = scores_bundle.get("scoresMainSectionFieldName", "bureauModels")
                # Load scores section field name into the main scores section. Default: scores
                self.scoresSubSectionFieldName = scores_bundle.get("scoresSubSectionFieldName", "scores")
                # Load scores id number field name. Default: personIdNumber
                self.scoresOutputIdNumberField = scores_bundle.get("scoresOutputIdNumberField", "personIdNumber")
                # Load scores id type field name. Default: personIdType
                self.scoresOutputIdTypeField = scores_bundle.get("scoresOutputIdTypeField", "personIdType")
                # Load required checking expressions
                self.scoresCheckSections = scores_bundle.get("scoresCheckSections", [])
            else:
                raise ValueError("Scores Bundle has not 'scoresOutputSchema' field !!!")

        self.log.setLevel(self.sparkLogLevel)

        # If paths do not exist into the configuration file, raise a ValueError
        if not self.sourceXpm or not self.targetXpm or not self.smlmvPath:
            raise ValueError("Invalid or empty xpm fields !!!")

        # Initialize variable to store score instances
        self.scoreModels = {}
        self.attributesExprList = []
        self.currentSmlmv = 0

        # Load attributes configuration
        self.getScoreAttributes()

        self.log.info("Scores Bundle loaded.")

    def readSmlmvCsv(self, smlmv_data_frame):
        """Read SMLMV csv file and extract the current or last updated smlmv.

        :param smlmv_data_frame: smlmv data frame read from csv file.
        :return: Current or last updated smlmv.
        """
        try:
            try:
                smlmvSortedData = smlmv_data_frame.orderBy(["code/text"], ascending=[False])
                return float(smlmvSortedData.select("name").collect()[0]["name"])
            except KeyError:
                return smlmv_data_frame.max().max()
        except Exception, error:
            tb = traceback.format_exc()
            self.log.error("!!! Error Reading SMLMV csv file. {}, {}".format(error, tb))
            return 0.0

    def getScoreAttributes(self):
        """Create a key (attribute name) - value (attribute path) dictionary from the input configuration.
        """
        for attributes in self.scoresAttributes:
            if attributes.get("attributeStatus", False) and attributes.get("attributeName") and attributes.get(
                    "xpmAttributeExpr"):
                for attributeName in attributes.get("attributeName"):
                    self.attributesExprList.append(
                        {'name': attributeName, 'xpmAttributeExpr': attributes.get("xpmAttributeExpr"),
                         'attributeFormat': eval(attributes.get("attributeFormat"))}
                    )

    def createScoresModelsInstances(self):
        """Load scores models instances.

        WARNING: Scores Bundle should contain an 'scoreModule', 'scoreInstance' and a unique 'scoreId' fields.
        """
        for scoreConfig in self.scoresBundle:
            # Validate score module field
            if scoreConfig.get("scoreModule"):
                try:
                    # Import module
                    scoreModule = importlib.import_module(scoreConfig.get("scoreModule"))
                    # Validate score instance field
                    if scoreConfig.get("scoreInstance"):
                        # Get score class from module field
                        scoreClass = getattr(scoreModule, scoreConfig.get("scoreInstance"))  # type: any
                        # Validate score Id and add score to the score models dictionary
                        if not self.scoreModels.get(scoreConfig.get("scoreId")) and scoreConfig.get("scoreId") >= 0:
                            if scoreConfig.get("scoreStatus", False):
                                self.scoreModels[scoreConfig.get("scoreId")] = {
                                    "scoreClass": scoreClass(),
                                    "scoreOutputXpm": scoreConfig.get("scoreOutputXPM"),
                                }
                            else:
                                self.log.info("Score: {} is not active !!!".format(scoreConfig.get("name")))
                        else:
                            self.log.error("Score: {} has not a valid ID !!!".format(scoreConfig.get("name")))
                    else:
                        self.log.error("Score: {} has an invalid or empty 'scoreInstance' field".format(
                            scoreConfig.get("name"))
                        )
                except Exception, error:
                    tb = traceback.format_exc()
                    self.log.error("!!! Error: {}, {}".format(error, tb))
            else:
                self.log.error("Score: {} has an invalid or empty 'scoreModule' field".format(
                    scoreConfig.get("name"))
                )
        if self.scoreModels:
            self.log.info("Scores Instances created. {}".format([key for key, value in self.scoreModels.items()]))
        else:
            raise ImportError("Invalid or empty scores instances !!!")

    def computeScores(self, xpm):
        """Compute each instanced score for a single individual.

        :param xpm: individual xpm
        :return: computed scores
        """
        scoresOutputs = []
        xpmJson = self.readXpm(xpm)
        xpmOut = deepcopy(xpm)

        if xpmJson:
            try:
                # Check xpm consistency
                xpmConsistency = self.checkConsistency(xpmJson)
                # Obtain all attributes values
                scoreInputData = self.getXpmAttributesData(xpmJson, self.attributesExprList)
                scoreInputData.update({"VLR_SMLMV_CARACT": self.currentSmlmv})
                scoresOutputsXpm = self.xpmOutFormatter(scoresOutputs, scoreInputData)
                if xpmConsistency:
                    # Calculate each Score
                    for scoreId, scoreProperties in self.scoreModels.items():
                        try:
                            if scoreInputData:
                                # Call score class
                                rawScoreValue = scoreProperties.get("scoreClass")(scoreInputData)
                                # Polish score output according to XPM score format
                                polishScore = self.polishScoreValue(rawScoreValue, scoreProperties.get("scoreOutputXpm"))
                                scoresOutputs.append(polishScore)
                        except Exception, error:
                            tb = traceback.format_exc()
                            self.log.error("!!! Calculation Error: {}, {}".format(error, tb))

                # Update score outputs
                scoresOutputsXpm.update({self.scoresSubSectionFieldName: scoresOutputs})
                updatedXpm = self.updateXpm(scoresOutputsXpm, xpmJson)

                xpmOut = json.dumps(updatedXpm)

            except Exception, error:
                tb = traceback.format_exc()
                self.log.error("!!! Enrich Error: {}, {}".format(error, tb))

        return xpmOut

    def convertToTSV(self, xpm):
        """Convert XPM json structure to TSV format

        :param xpm: Current Xpm.
        :return: converted xpm to TSV format
        """
        try:
            xpmJson = json.loads(xpm)
            pin = xpmJson.get('pin', '')
            return "".join([str(pin), '\t', xpm])
        except Exception, error:
            tb = traceback.format_exc()
            self.log.error("!!! Error: {}, {}".format(error, tb))
            xpmJson = xpm
            pin = xpmJson.get('pin', '')
            return "".join([str(pin), '\t', json.dumps(xpm)])

    def enrichCobol(self, xpms):
        """Run scores calculation and save the resulting XPM.

        :return: Enriched XPM
        """
        outputXpm = map(
            lambda xpm: json.loads(self.computeScores(xpm)), xpms
        )
        return outputXpm

    def enrich(self, xpms):
        """Run scores calculation and save the resulting XPM.

        :return: Enriched XPM
        """
        outputXpm = xpms.map(
            lambda xpm: self.computeScores(xpm)
        )
        return outputXpm


if __name__ == "__main__":
    pass
