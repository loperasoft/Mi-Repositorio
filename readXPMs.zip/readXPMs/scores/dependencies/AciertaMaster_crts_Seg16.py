import numpy as np
import traceback


def main(data,vars_woe):

    #%%
    #### Calculo Crts ####
    try:
        co01end071ro = data['CO01END071RO_AMAS'] if data['CO01END071RO_AMAS']!=-999 else np.nan
        co01end093ro = data['CO01END093RO_AMAS'] if data['CO01END093RO_AMAS']!=-999 else np.nan
        co01end030ro = data['CO01END030RO_AMAS'] if data['CO01END030RO_AMAS']!=-999 else np.nan
        co02end015cb = data['CO02END015CB_AMAS'] if data['CO02END015CB_AMAS']!=-999 else np.nan
        co01end015ro = data['CO01END015RO_AMAS'] if data['CO01END015RO_AMAS']!=-999 else np.nan
        co02end035cb = data['CO02END035CB_AMAS'] if data['CO02END035CB_AMAS']!=-999 else np.nan
        co01exp006ro = data['CO01EXP006RO_AMAS'] if data['CO01EXP006RO_AMAS']!=-999 else np.nan
        co01exp004ro = data['CO01EXP004RO_AMAS'] if data['CO01EXP004RO_AMAS']!=-999 else np.nan
        co02end001cb = data['CO02END001CB_AMAS'] if data['CO02END001CB_AMAS']!=-999 else np.nan
        co01end088ro = data['CO01END088RO_AMAS'] if data['CO01END088RO_AMAS']!=-999 else np.nan
        co01mor062in = data['CO01MOR062IN_AMAS'] if data['CO01MOR062IN_AMAS']!=-999 else np.nan
        co01end012in = data['CO01END012IN_AMAS'] if data['CO01END012IN_AMAS']!=-999 else np.nan
        co01exp001ro = data['CO01EXP001RO_AMAS'] if data['CO01EXP001RO_AMAS']!=-999 else np.nan
        co01mor076ro = data['CO01MOR076RO_AMAS'] if data['CO01MOR076RO_AMAS']!=-999 else np.nan
        co01mor008in = data['CO01MOR008IN_AMAS'] if data['CO01MOR008IN_AMAS']!=-999 else np.nan
        co01mor002ro = data['CO01MOR002RO_AMAS'] if data['CO01MOR002RO_AMAS']!=-999 else np.nan
        co01end003ot = data['CO01END003OT_AMAS'] if data['CO01END003OT_AMAS']!=-999 else np.nan
        co02end024in = data['CO02END024IN_AMAS'] if data['CO02END024IN_AMAS']!=-999 else np.nan
        co01mor068ro = data['CO01MOR068RO_AMAS'] if data['CO01MOR068RO_AMAS']!=-999 else np.nan
        co02end044ro = data['CO02END044RO_AMAS'] if data['CO02END044RO_AMAS']!=-999 else np.nan
        co01mor016in = data['CO01MOR016IN_AMAS'] if data['CO01MOR016IN_AMAS']!=-999 else np.nan
    
        coa1mor995cp = data['CO01MOR995CP_AMAS'] if data['CO01MOR995CP_AMAS']!=-999 else np.nan
        coa1exp001to = data['CO01EXP001TO_AMAS'] if data['CO01EXP001TO_AMAS']!=-999 else np.nan
        coa1num002cp = data['CO01NUM002CP_AMAS'] if data['CO01NUM002CP_AMAS']!=-999 else np.nan
    except Exception, error:
        tb = traceback.format_exc()
        # logger.error("!!! Error: {}, {}".format(error, tb))
        assert False, "!!! Error: {}, {}".format(error, tb)

    #%%
    #### Woe Cs ####
    coa1mor995cp_woe = float(np.where(np.isnan(coa1mor995cp),-0.0982,np.where(coa1mor995cp<=0,-0.2179,np.where(coa1mor995cp<=1,0.267,0.7024))))
    co02end015cb_woe = float(np.where(np.isnan(co02end015cb)|(co02end015cb<0),0.0377,np.where(co02end015cb<=1.13,0.3263,-0.4664)))
    co01mor076ro_woe = float(np.where(np.isnan(co01mor076ro)|(co01mor076ro<0)|(co01mor076ro==999),0.1089,np.where(co01mor076ro<=1,-0.9419,np.where(co01mor076ro<=5,-0.3132,0.1089))))
    co01mor008in_woe = float(np.where(np.isnan(co01mor008in)|(co01mor008in<0),-0.0069,np.where(co01mor008in<=0,0.2548,-0.8778)))
    co01end012in_woe = float(np.where(np.isnan(co01end012in)|(co01end012in<0),-0.0281,np.where(co01end012in<=0.05,0.2547,np.where(co01end012in<=0.28,-0.4568,-0.863))))
    co01end071ro_woe = float(np.where(np.isnan(co01end071ro)|(co01end071ro<0),0.0437,np.where(co01end071ro<=28.01,0.7137,np.where(co01end071ro<=91.25,0.0437,np.where(co01end071ro<=97.79,-0.2472,np.where(co01end071ro<=101.94,-0.3323,-0.5794))))))
    co01end015ro_woe = float(np.where(np.isnan(co01end015ro)|(co01end015ro<0),-0.0466,np.where(co01end015ro<=0.03,-0.5016,np.where(co01end015ro<=1.43,-0.0466,np.where(co01end015ro<=3.66,0.407,0.7127)))))
    co02end035cb_woe = float(np.where(np.isnan(co02end035cb)|(co02end035cb==-1)|(co02end035cb==-2)|(co02end035cb==-3)|(co02end035cb==-4)|(co02end035cb==-5)|(co02end035cb==-11)|(co02end035cb==-88)|(co02end035cb==-99),0.0078,np.where(co02end035cb<=-40.91,0.3489,np.where(co02end035cb<=-5.77,0.2555,np.where(co02end035cb<=69.48,0.0078,-0.3479)))))
    co01end030ro_woe = float(np.where(np.isnan(co01end030ro)|(co01end030ro<0),-0.0025,np.where(co01end030ro<=0.09,-0.4119,np.where(co01end030ro<=0.95,-0.1194,np.where(co01end030ro<=1.33,-0.0025,np.where(co01end030ro<=2.86,0.2262,0.5269))))))
    coa1num002cp_woe = float(np.where(np.isnan(coa1num002cp)|(coa1num002cp<0),-0.0982,np.where(coa1num002cp<=1,0.03,np.where(coa1num002cp<=7,0.1942,0.8044))))
    co01mor002ro_woe = float(np.where(np.isnan(co01mor002ro)|(co01mor002ro<0),0.0456,np.where(co01mor002ro<=0,0.0456,-0.7641)))
    coa1exp001to_woe = float(np.where(np.isnan(coa1exp001to)|(coa1exp001to<0),0.041,np.where(coa1exp001to<=12.5714285714286,-0.4892,np.where(coa1exp001to<=27.4285714285714,-0.153,np.where(coa1exp001to<=29.4444444444444,0.041,0.1323)))))
    co01exp006ro_woe = float(np.where(np.isnan(co01exp006ro)|(co01exp006ro<0),-0.041,np.where(co01exp006ro<=9,-0.1768,np.where(co01exp006ro<=28,-0.041,np.where(co01exp006ro<=42,0.1985,0.6266)))))
    co01end003ot_woe = float(np.where(np.isnan(co01end003ot)|(co01end003ot<0),0.0475,np.where(co01end003ot<=0.16,0.1182,np.where(co01end003ot<=0.55,-0.302,-0.4747))))
    co01exp001ro_woe = float(np.where(np.isnan(co01exp001ro)|(co01exp001ro<0),-0.0062,np.where(co01exp001ro<=18,-0.2411,np.where(co01exp001ro<=50,-0.0062,np.where(co01exp001ro<=81,0.2563,0.3486)))))
    co02end001cb_woe = float(np.where(np.isnan(co02end001cb)|(co02end001cb==-1)|(co02end001cb==-2)|(co02end001cb==-3)|(co02end001cb==-4)|(co02end001cb==-5)|(co02end001cb==-11)|(co02end001cb==-88)|(co02end001cb==-99),-0.0454,np.where(co02end001cb<=0.33,-0.2618,np.where(co02end001cb<=33.53,-0.0454,np.where(co02end001cb<=67.65,0.1431,0.3912)))))
    co01exp004ro_woe = float(np.where(np.isnan(co01exp004ro)|(co01exp004ro<0)|(co01exp004ro==999),-0.0453,np.where(co01exp004ro<=19,-0.0453,np.where(co01exp004ro<=34,0.0973,0.5963))))
    co02end024in_woe = float(np.where(np.isnan(co02end024in)|(co02end024in==-1)|(co02end024in==-2)|(co02end024in==-3)|(co02end024in==-4)|(co02end024in==-5)|(co02end024in==-11)|(co02end024in==-88)|(co02end024in==-99),0.005,np.where(co02end024in<=-47.22,0.4088,np.where(co02end024in<=-11.97,0.1818,np.where(co02end024in<=-8.35,0.005,-0.1415)))))
    co01mor068ro_woe = float(np.where(np.isnan(co01mor068ro)|(co01mor068ro<0),-0.0693,np.where(co01mor068ro<=0,-0.0079,0.3289)))
    co02end044ro_woe = float(np.where(np.isnan(co02end044ro)|(co02end044ro==-1)|(co02end044ro==-2)|(co02end044ro==-3)|(co02end044ro==-4)|(co02end044ro==-5)|(co02end044ro==-11)|(co02end044ro==-88)|(co02end044ro==-99),0.0121,np.where(co02end044ro<=-29.46,0.416,-0.0729)))
    co01end088ro_woe = float(np.where(np.isnan(co01end088ro)|(co01end088ro<0),-0.0148,np.where(co01end088ro<=21.85,0.718,np.where(co01end088ro<=81.56,0.1916,np.where(co01end088ro<=88.32,-0.1701,np.where(co01end088ro<=98.69,-0.3297,-0.5756))))))
    co01end093ro_woe = float(np.where(np.isnan(co01end093ro)|(co01end093ro<0),0.0012,np.where(co01end093ro<=3.38,-0.4718,np.where(co01end093ro<=36.7,-0.1034,np.where(co01end093ro<=47.45,0.1999,np.where(co01end093ro<=71.5,0.4431,0.8442))))))
    co01mor062in_woe = float(np.where(np.isnan(co01mor062in)|(co01mor062in<0),-0.0723,np.where(co01mor062in<=0,0.2921,np.where(co01mor062in<=1,-0.1427,-0.4593))))
    co01mor016in_woe = float(np.where(np.isnan(co01mor016in)|(co01mor016in<0),-0.0216,np.where(co01mor016in<=0,0.1139,-0.5404)))

    #%% salida
    out=[eval(i) for i in vars_woe]

    #%%
    return out
