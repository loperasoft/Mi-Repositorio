import numpy as np
import traceback


def main(data,vars_woe):
    #%%
    #### Calculo Crts ####
    try:
        co01mor071ro = data['CO01MOR071RO_AMAS'] if data['CO01MOR071RO_AMAS']!=-999 else np.nan
        co01end071ro = data['CO01END071RO_AMAS'] if data['CO01END071RO_AMAS']!=-999 else np.nan
        co01exp006in = data['CO01EXP006IN_AMAS'] if data['CO01EXP006IN_AMAS']!=-999 else np.nan
        co01mor009in = data['CO01MOR009IN_AMAS'] if data['CO01MOR009IN_AMAS']!=-999 else np.nan
        co02exp007to = data['CO02EXP007TO'] if data['CO02EXP007TO']!=-999 else np.nan
        co02end034in = data['CO02END034IN_AMAS'] if data['CO02END034IN_AMAS']!=-999 else np.nan
        co01acp041in = data['CO01ACP041IN_AMAS'] if data['CO01ACP041IN_AMAS']!=-999 else np.nan
        co00dem003   = data['CO00DEM003'] if data['CO00DEM003']!=-999 else np.nan
        co02exp006to = data['CO02EXP006TO'] if data['CO02EXP006TO']!=-999 else np.nan
        co01mor033cc = data['CO01MOR033CC_AMAS'] if data['CO01MOR033CC_AMAS']!=-999 else np.nan
        co01exp009ah = data['CO01EXP009AH'] if data['CO01EXP009AH']!=-999 else np.nan
        co01mor075ro = data['CO01MOR075RO_AMAS'] if data['CO01MOR075RO_AMAS']!=-999 else np.nan
        co01num005in = data['CO01NUM005IN_AMAS'] if data['CO01NUM005IN_AMAS']!=-999 else np.nan
        co02num019to = data['CO02NUM019TO'] if data['CO02NUM019TO']!=-999 else np.nan
        co01acp042in = data['CO01ACP042IN_AMAS'] if data['CO01ACP042IN_AMAS']!=-999 else np.nan
        co01end030ro = data['CO01END030RO_AMAS'] if data['CO01END030RO_AMAS']!=-999 else np.nan
        co02end019cb = data['CO02END019CB_AMAS'] if data['CO02END019CB_AMAS']!=-999 else np.nan
        co02num057cb = data['CO02NUM057CB_AMAS'] if data['CO02NUM057CB_AMAS']!=-999 else np.nan
        co01acp015in = data['CO01ACP015IN_AMAS'] if data['CO01ACP015IN_AMAS']!=-999 else np.nan
        co01exp005ro = data['CO01EXP005RO_AMAS'] if data['CO01EXP005RO_AMAS']!=-999 else np.nan
        co01exp013cc = data['CO01EXP013CC_AMAS'] if data['CO01EXP013CC_AMAS']!=-999 else np.nan
        co01mor009cc = data['CO01MOR009CC_AMAS'] if data['CO01MOR009CC_AMAS']!=-999 else np.nan
        co02exp009in = data['CO02EXP009IN_AMAS'] if data['CO02EXP009IN_AMAS']!=-999 else np.nan
    
        coa1exp001to = data['CO01EXP001TO_AMAS'] if data['CO01EXP001TO_AMAS']!=-999 else np.nan
        coa1exp003fi = data['CO01EXP003FI_AMAS'] if data['CO01EXP003FI_AMAS']!=-999 else np.nan
        coa1mor001to = data['CO01MOR001TO_AMAS'] if data['CO01MOR001TO_AMAS']!=-999 else np.nan
        coa1mor006to = data['CO01MOR006TO'] if data['CO01MOR006TO']!=-999 else np.nan
    except Exception, error:
        tb = traceback.format_exc()
        # logger.error("!!! Error: {}, {}".format(error, tb))
        assert False, "!!! Error: {}, {}".format(error, tb)
    #%%
    #### Woe Cs ####
    co01mor071ro_woe = float(np.where(np.isnan(co01mor071ro)|(co01mor071ro<0),-0.5132,np.where(co01mor071ro<=0,0.445,-1.0016)))
    co01end071ro_woe = float(np.where(np.isnan(co01end071ro)|(co01end071ro<0),-0.4308,np.where(co01end071ro<=35.39,0.6394,np.where(co01end071ro<=49.28,0.3168,np.where(co01end071ro<=64.08,-0.0491,-0.7841)))))
    co01mor009in_woe = float(np.where(np.isnan(co01mor009in)|(co01mor009in<0),-0.178,np.where(co01mor009in<=0,0.2305,np.where(co01mor009in<=1,-0.4687,-0.9826))))
    co01exp006in_woe = float(np.where(np.isnan(co01exp006in)|(co01exp006in<0),-0.04,np.where(co01exp006in<=4,-0.3006,np.where(co01exp006in<=17,-0.0952,np.where(co01exp006in<=21,0.1947,np.where(co01exp006in<=29,0.2651,0.3821))))))
    co02exp007to_woe = float(np.where(np.isnan(co02exp007to)|(co02exp007to<0),0.0905,np.where(co02exp007to<=16.67,0.2105,np.where(co02exp007to<=25,0.0905,np.where(co02exp007to<=40,-0.2821,-0.6913)))))
    co02end034in_woe = float(np.where(np.isnan(co02end034in)|(co02end034in==-1)|(co02end034in==-2)|(co02end034in==-3)|(co02end034in==-4)|(co02end034in==-5)|(co02end034in==-11)|(co02end034in==-88)|(co02end034in==-99),-0.0778,np.where(co02end034in<=-51.26,0.3589,np.where(co02end034in<=-3.03,0.2099,np.where(co02end034in<=33.38,0.0398,-0.2122)))))
    co01acp041in_woe = float(np.where(np.isnan(co01acp041in)|(co01acp041in<0),-0.2242,np.where(co01acp041in<=0,-0.2242,np.where(co01acp041in<=3,-0.0051,np.where(co01acp041in<=9,0.2914,0.5988)))))
    co00dem003_woe   = float(np.where(np.isnan(co00dem003)|(co00dem003<0),-0.7159,np.where(co00dem003<=30,-0.7159,np.where(co00dem003<=53,-0.0527,np.where(co00dem003<=56,0.3377,np.where(co00dem003<=61,0.4446,0.5324))))))
    coa1exp001to_woe = float(np.where(np.isnan(coa1exp001to)|(coa1exp001to<0),-0.0302,np.where(coa1exp001to<=40.4545454545455,-0.8399,np.where(coa1exp001to<=96.7368421052632,-0.0302,np.where(coa1exp001to<=103,0.3689,0.4303)))))
    co02exp006to_woe = float(np.where(np.isnan(co02exp006to)|(co02exp006to<0),-0.7952,np.where(co02exp006to<=14,-0.7952,np.where(co02exp006to<=71,-0.0451,np.where(co02exp006to<=78,0.3468,np.where(co02exp006to<=98,0.5123,0.6861))))))
    co01mor033cc_woe = float(np.where(np.isnan(co01mor033cc)|(co01mor033cc<0),-0.059,np.where(co01mor033cc<=1,-0.059,np.where(co01mor033cc<=2,0.1631,0.3797))))
    co01exp009ah_woe = float(np.where(np.isnan(co01exp009ah)|(co01exp009ah<0),0.0775,np.where(co01exp009ah<=0,0.119,-0.2418)))
    co01mor075ro_woe = float(np.where(np.isnan(co01mor075ro)|(co01mor075ro<0)|(co01mor075ro==999),0.0881,np.where(co01mor075ro<=24,-0.3417,-0.2926)))
    co01num005in_woe = float(np.where(np.isnan(co01num005in)|(co01num005in<0),-0.2095,np.where(co01num005in<=1,-0.2639,np.where(co01num005in<=7,-0.026,np.where(co01num005in<=9,0.163,np.where(co01num005in<=19,0.2873,0.752))))))
    co02num019to_woe = float(np.where(np.isnan(co02num019to)|(co02num019to<0)|(co02num019to<=0),0.1287,-1.0693))
    co01acp042in_woe = float(np.where(np.isnan(co01acp042in)|(co01acp042in<0),0.0093,np.where(co01acp042in<=0,0.1666,-0.0738)))
    co01end030ro_woe = float(np.where(np.isnan(co01end030ro)|(co01end030ro<0),-0.4834,np.where(co01end030ro<=1.16,-0.7947,np.where(co01end030ro<=4.76,0.1601,np.where(co01end030ro<=8.19,0.6987,np.where(co01end030ro<=11.9,1.0095,1.257))))))
    co02end019cb_woe = float(np.where(np.isnan(co02end019cb)|(co02end019cb<0),-0.6811,np.where(co02end019cb<=0,0.1962,-0.2521)))
    co02num057cb_woe = float(np.where(np.isnan(co02num057cb)|(co02num057cb<0)|(co02num057cb<=0),0.1287,-1.0693))
    coa1exp003fi_woe = float(np.where(np.isnan(coa1exp003fi)|(coa1exp003fi<0),-0.1162,np.where(coa1exp003fi<=31,0.1279,np.where(coa1exp003fi<=52,-0.1162,-0.6246))))
    coa1mor001to_woe = float(np.where(np.isnan(coa1mor001to)|(coa1mor001to<0)|(coa1mor001to<=0),0.0995,-0.652))
    co01acp015in_woe = float(np.where(np.isnan(co01acp015in)|(co01acp015in<0),-0.2461,np.where(co01acp015in<=0,-0.2461,np.where(co01acp015in<=1,-0.0078,np.where(co01acp015in<=3,0.0862,np.where(co01acp015in<=9,0.1796,0.6157))))))
    co01exp005ro_woe = float(np.where(np.isnan(co01exp005ro)|(co01exp005ro<0)|(co01exp005ro==999),-0.4133,np.where(co01exp005ro<=36,0.4656,np.where(co01exp005ro<=61,0.2636,np.where(co01exp005ro<=71,0.0707,np.where(co01exp005ro<=120,-0.0377,-0.1705))))))
    co01exp013cc_woe = float(np.where(np.isnan(co01exp013cc)|(co01exp013cc<0),-0.021,np.where(co01exp013cc<=0,-0.3924,0.3891)))
    co01mor009cc_woe = float(np.where(np.isnan(co01mor009cc)|(co01mor009cc<0),-0.0524,np.where(co01mor009cc<=1,0.1501,-0.8534)))
    co02exp009in_woe = float(np.where(np.isnan(co02exp009in)|(co02exp009in<0),0.0316,np.where(co02exp009in<=75,0.274,-0.1141)))
    coa1mor006to_woe = float(np.where(np.isnan(coa1mor006to)|(coa1mor006to<0)|(coa1mor006to<=0),0.0995,-0.652))

    #%% salida
    out=[eval(i) for i in vars_woe]
    
    #%%
    return out
