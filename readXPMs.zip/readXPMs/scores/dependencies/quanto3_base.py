import copy
import math


class Quanto3Base(object):
    """
    Quanto 3 Score class base.
    """
    # Constant variables initialization
    # NOTEC population variables
    ESNODO01 = (177, 42, 182, 48, 175, 74, 159, 162, 163, 165, 181,
                133, 169, 168, 170, 143)

    ESNODO02 = (131, 130, 180, 69, 119, 121, 122, 141, 142, 134,
                128, 118, 153, 179, 18)

    ESNODO03 = (109, 135, 147, 158, 148, 39, 125, 111, 138)

    ESNODO04 = (145, 151, 126, 11, 25, 154, 137, 123, 172,
                115, 149, 152, 7, 13)

    ESNODO05 = (122, 129, 564, 514, 580, 438, 436, 59, 899, 581, 585, 582, 101,
                586, 374, 492, 183, 487, 123, 565, 587, 220, 583, 513, 940, 44, 222, 563, 437,
                95, 717, 798, 517, 807, 392, 455, 799, 741, 971, 435, 642, 491, 817, 885, 813,
                454, 410, 490, 209, 643, 404, 221, 286, 714, 51, 134, 808, 366, 886, 819, 373,
                893, 796, 375, 800, 35, 963, 285, 955, 516, 953, 180, 161, 419, 420, 816, 814,
                646, 274, 416, 367, 888, 199, 146, 417, 155, 157, 710, 815, 973, 887, 185, 201,
                820, 827, 656, 972, 645, 515, 322, 399, 829, 835, 938, 406, 647, 325, 818, 944,
                335, 488, 415, 409, 678, 407, 234, 662)

    ESNODO06 = (659, 531, 53, 534, 391, 709, 411, 136, 884, 675, 600, 494, 429,
                102, 211, 212, 433, 831, 826, 162, 428, 418, 677, 239, 103, 253, 676, 493,
                661, 669, 368, 658, 242, 401, 472, 962, 370, 535, 235, 69, 655, 939, 825,
                611, 797, 822, 889, 832, 92, 660, 830, 601, 809, 679, 687, 318, 393, 644, 397,
                456, 606, 186, 605, 895, 205, 966, 489, 229, 408, 537, 894, 369, 900, 898, 288,
                931, 277, 210, 945, 834, 780,
                427, 821, 496, 77, 833, 743, 497, 111, 823, 184, 607, 145, 715, 781, 168, 612,
                498, 680, 896, 897, 670,
                683, 828, 473, 744, 324, 688,
                405, 128, 400, 775, 230, 402, 326, 954, 536, 403, 836, 148, 338, 682)

    ESNODO07 = (584, 795, 671, 708, 602, 218, 151, 495, 187, 964, 240, 742, 231,
                681, 76, 275, 341, 214, 255, 58, 142, 533, 657, 130, 474, 167, 538, 532, 89, 654,
                745, 929, 774, 323, 297, 782, 824, 934, 347, 746, 718, 946, 901, 55, 398, 933,
                248, 932, 345, 339, 22, 689, 246)

    ESNODO08 = (965, 716, 518, 539, 126, 348, 610, 434, 118, 967, 930, 776, 249,
                342, 179, 327, 267, 279, 719, 333, 219, 85, 64, 91, 336, 88, 216, 40, 258)

    ESNODO09 = (40, 64, 74, 82, 94)

    ESNODO10 = (36, 70, 86, 95)

    ESNODO11 = (21, 33, 49, 50, 52, 65, 68, 71, 75, 76, 78, 83, 92, 100, 101)

    ESNODO12 = (46, 53, 69, 79, 87, 93)

    ESNODO13 = (7, 27, 45, 77)

    ESNODO14 = (147, 215, 158, 216, 179, 180, 240, 181, 244, 178, 194, 203, 309, 256)

    ESNODO15 = (137, 197, 205, 246, 193, 199, 198, 245, 206, 243, 196, 202, 286, 302, 257, 200)

    ESNODO16 = (282, 250, 272, 187, 310, 255, 304, 251)

    ESNODO17 = (283, 289, 305, 285)

    ESNODO18 = (263, 275, 249, 259)

    ESNODO19 = (3353, 3349, 3390, 3341, 3028, 3029, 3388, 3044)

    ESNODO20 = (3389, 3354, 3036, 3035, 3091, 3380, 3043, 3041)

    ESNODO21 = (3345, 3381, 3346, 3001, 3084, 3090, 3092, 3190, 3191, 3199,
                3060, 3085, 3087, 3112, 3002, 3192, 3093, 3200, 3347, 2998, 3042, 3208,
                3351, 3039, 3355)

    ESNODO22 = (3088, 3182, 3201, 3257, 3216, 3223, 3183, 3287, 3089,
                3348, 3217, 3288, 3344, 3248, 2999, 3184)

    ESNODO23 = (3277, 3290, 3209, 3276, 3302)

    ESNODO24 = (3250, 3289, 3300)

    ESNODO25 = (3303, 3242, 3210, 3301, 3304, 2994, 3327)

    ESNODO26 = (3333, 3305, 3326, 3334)

    # TEC population variables
    ESNODO27 = (225, 267, 22, 195, 294, 197, 12, 283, 299)

    ESNODO28 = (230, 40, 58, 86, 314, 170, 354, 218, 105, 309, 295, 82, 325,
                165, 52, 92)

    ESNODO29 = (186, 352, 315, 187, 180, 302, 83, 231, 35, 87, 166, 164, 190,
                353, 93, 355, 162, 129, 182, 42, 344, 191, 9)

    ESNODO30 = (117, 189, 149, 57, 153, 169, 173, 27, 116, 154, 127, 15)

    ESNODO31 = (835, 144, 764, 765, 151, 142, 149, 834, 373, 664, 76, 145, 23, 80,
                802, 230, 665, 755, 74, 510, 754, 16, 824, 653)

    ESNODO32 = (744, 825, 72, 81, 77, 652, 738, 511, 677, 150, 409, 143, 217,
                148, 509, 43, 649, 153, 648, 410, 59, 228, 57)

    ESNODO33 = (161, 75, 33, 745, 55, 707, 374, 729, 32, 678, 218, 700, 697, 54,
                162, 166, 682, 733, 722, 715, 168, 717, 696, 730, 73, 683, 723, 28, 61, 21, 167,
                60, 411, 702, 699, 714, 34, 13, 22)

    ESNODO34 = (135, 160, 183, 141, 139, 34, 159, 145, 48, 165, 149, 166, 147,
                151, 138, 150, 152)

    ESNODO35 = (140, 10, 193, 185, 156, 186, 154, 182, 26, 194, 25, 35, 49, 999,
                28, 78, 200)

    ESNODO36 = (27, 180, 204, 191, 210, 211, 208, 45, 203, 23, 207, 192, 199, 15)

    ESNODO37 = (144, 148, 152, 128, 143, 77, 146, 147)

    ESNODO38 = (81, 155, 33, 48, 157, 37, 28, 58, 92, 17, 45, 103, 49, 41, 93,
                43, 36, 176, 129, 161, 151, 94, 39, 59, 76, 162)

    ESNODO39 = (154, 102, 95, 164, 156, 163, 177, 166, 172, 168, 175, 50)

    # TIPO5 population variables
    ESNODO40 = (78, 77, 22, 713, 714, 715, 716, 712, 12, 717, 76, 31, 32, 36,
                66, 67, 69, 70, 121, 167, 174)

    ESNODO41 = (213, 214, 313, 698, 30, 220, 73, 72, 169, 35, 71, 678, 697, 694,
                314, 679, 176, 223, 315, 334, 335, 695, 46, 1249)

    ESNODO42 = (44, 125, 126, 128, 168, 175, 219, 221, 127, 671, 123, 215,
                333, 26, 222, 210, 224)

    ESNODO43 = (79, 49, 82, 672, 18, 19, 20, 15)

    K_INTERVALO_DAQU3 = 0.3

    def initBase(self, data):
        self.data_o = copy.deepcopy(data)
        self.data = copy.deepcopy(data)

        # Variables q3
        self.q3_cuotatotal = 0.0
        self.q3_prcuotatotalro = 0.0
        self.q3_exposicion = 0.0
        self.q3_prexposicionro = 0.0
        self.q3_prexposicionin = 0.0
        self.q3_prexposicionve = 0.0
        self.q3_prexposicionhp = 0.0
        self.q3_prexposicionot = 0.0

        self.q3_financiero = 0.0
        self.q3_real = 0.0
        self.q3_telcos = 0.0
        self.q3_tiporel = ""
        self.q3_tiporeld01 = 0.0
        self.q3_tiporeld02 = 0.0
        self.q3_tiporeld03 = 0.0
        self.q3_tiporeld04 = 0.0

        # Variablesencontradas
        self.q3_ro = 0.0
        self.q3_hp = 0.0
        self.q3_cc = 0.0
        self.q3_ot = 0.0
        self.q3_co = 0.0
        self.q3_ah_ct = 0.0
        self.q3_codeudor = 0.0
        self.q3_extranjeria = 0.0
        self.q3_tipoid = 0.0
        self.q3_act_econ = 0.0
        self.q3_ahorr_ct = 0.0

        self.prestamos_daqu3 = 0
        self.poblacion_daqu3 = ""
        self.nodo_daqu3 = 0
        self.node_daqu3 = 0
        self.grupo_daqu3 = 0
        self.num_port_daqu3 = 0.0
        self.q3_scoren = 0.0
        self.vlr_smlmv_daqu3 = self.data['VLR_SMLMV_CARACT']
        self.score_daqu3 = 0
        self.score_ori_daqu3 = 0
        self.probabilidad_daqu3 = 0
        self.adverse_razon_daqu3 = [0, 0, 0, 0]

        self.ingreso_pesos_daqu3 = 0.0
        self.ingreso_pesos_n_daqu3 = 0
        self.ingreso_pesos_inf_daqu3 = 0.0
        self.ingreso_pesos_n_inf_daqu3 = 0
        self.ingreso_pesos_sup_daqu3 = 0.0
        self.ingreso_pesos_n_sup_daqu3 = 0
        self.ingreso_daqu3 = 0.0
        self.ingreso_n_daqu3 = 0.0
        self.ingreso_inf_daqu3 = 0.0
        self.ingreso_inf_n_daqu3 = 0.0
        self.ingreso_sup_daqu3 = 0.0
        self.ingreso_sup_n_daqu3 = 0.0
        self.q3_ingreso = 0.0

        self.score_card_daqu3 = 0
        self.con_exclusion_daqu3 = 0
        self.i_daqu3 = 0
        self.j_daqu3 = 0
        self.l_daqu3 = 0
        self.t_daqu3 = 0
        self.area_vali_daqu3 = ""
        self.nomb_vali_daqu3 = ""
        self.dummies_desplegar_daqu3 = ""
        self.q3_nodo = 0
        self.q3_rango_ant = 0

        if self.vlr_smlmv_daqu3 <= 0 or self.vlr_smlmv_daqu3 is None:
            self.con_exclusion_daqu3 = 1
            self.adverse_razon_daqu3[0] = 72
            self.ingreso_daqu3 = 0
            self.ingreso_n_daqu3 = 0
            self.ingreso_usapi = 0
            self.ingreso_n_usapi = 0

    def inicializa_variables(self):
        self.data = copy.deepcopy(self.data_o)

    def ver_exclusiones_daqu3(self):
        # Clientes fallecidos
        if self.con_exclusion_daqu3 == 0:
            if self.data["CO00DEM001"] == 1 or self.data["CO00DEM002"] == 1:
                self.con_exclusion_daqu3 = 1
                self.adverse_razon_daqu3[0] = 73
                self.ingreso_daqu3 = 0.03
                self.ingreso_n_daqu3 = 0.03
                # self.ingreso_usapi = 0.03
                # self.ingreso_n_usapi = 0.03

        # Clientes tipoid 2 o 3
        if self.con_exclusion_daqu3 == 0:
            if self.data["TIPOID"] != 1 and self.data["TIPOID"] != 4:
                self.con_exclusion_daqu3 = 1
                self.adverse_razon_daqu3[0] = 70
                self.ingreso_daqu3 = 0.0
                self.ingreso_n_daqu3 = 0.0
                # self.ingreso_usapi = 0.0
                # self.ingreso_n_usapi = 0.0

        # Clientes tipo 5
        if self.con_exclusion_daqu3 == 0:
            if self.data["CO01NUM001RO"] == -1 and self.data["CO01NUM001IN"] == -1 and \
                    self.data["CO01NUM001VE"] == -1 and self.data["CO01NUM001HP"] == -1 and \
                    self.data["CO01NUM001CC"] == -1 and self.data["CO01NUM001OT"] == -1 and \
                    self.data["CO01NUM001CO"] == -1 and self.data["CO01NUM001AH"] == -1 and \
                    self.data["CO01NUM001CT"] == -1:
                self.con_exclusion_daqu3 = 1
                self.adverse_razon_daqu3[0] = 71
                self.ingreso_daqu3 = 0.0
                self.ingreso_n_daqu3 = 0.0
                # self.ingreso_usapi = 0.0
                # self.ingreso_n_usapi = 0.0

        # Clientes tipo 1 sin desempeno
        if self.con_exclusion_daqu3 == 0:
            if (self.data["CO01NUM001AH"] > 0 or self.data["CO01NUM001CT"] > 0) and \
                    self.data["CO01NUM001RO"] == -1 and self.data["CO01NUM001IN"] == -1 and \
                    self.data["CO01NUM001VE"] == -1 and self.data["CO01NUM001HP"] == -1 and \
                    self.data["CO01NUM001CC"] == -1 and self.data["CO01NUM001OT"] == -1 and \
                    self.data["CO01NUM001CO"] == -1:
                self.con_exclusion_daqu3 = 1
                self.adverse_razon_daqu3[0] = 72
                self.ingreso_daqu3 = 0.0
                self.ingreso_n_daqu3 = 0.0
                # self.ingreso_usapi = 0.0
                # self.ingreso_n_usapi = 0.0

        # Clientes que son solo codeudores
        if self.con_exclusion_daqu3 == 0:
            if self.data["CO01NUM001RO"] == -1 and self.data["CO01NUM001IN"] == -1 and \
                    self.data["CO01NUM001VE"] == -1 and self.data["CO01NUM001HP"] == -1 and \
                    self.data["CO01NUM001CC"] == -1 and self.data["CO01NUM001OT"] == -1 and \
                    self.data["CO01NUM001CT"] == -1 and self.data["CO01NUM001AH"] == -1 and \
                    self.data["CO01NUM001CO"] != -1:  # <> "  -1"
                self.con_exclusion_daqu3 = 1
                self.adverse_razon_daqu3[0] = 74
                self.ingreso_daqu3 = 0.04
                self.ingreso_n_daqu3 = 0.04
                # self.ingreso_usapi = 0.04
                # self.ingreso_n_usapi = 0.04

        # Clientes tipo 1 codeudores
        if self.con_exclusion_daqu3 == 0:
            if self.data["CO01NUM001RO"] == -1 and self.data["CO01NUM001IN"] == -1 and \
                    self.data["CO01NUM001VE"] == -1 and self.data["CO01NUM001HP"] == -1 and \
                    self.data["CO01NUM001CC"] == -1 and self.data["CO01NUM001OT"] == -1 and \
                    (self.data["CO01NUM001CT"] != -1 or self.data["CO01NUM001CO"] != -1):  # <> "  -1"
                self.con_exclusion_daqu3 = 1
                self.adverse_razon_daqu3[0] = 75
                self.ingreso_daqu3 = 0.04
                self.ingreso_n_daqu3 = 0.04
                # self.ingreso_usapi = 0.04
                # self.ingreso_n_usapi = 0.04

        # Clientes con todo cerrado
        if self.con_exclusion_daqu3 == 0:
            if self.data["CO02NUM001TO"] > 0 and self.data["CO02NUM002TO"] <= 0:
                self.con_exclusion_daqu3 = 1
                self.adverse_razon_daqu3[0] = 76
                self.ingreso_daqu3 = 0.0
                self.ingreso_n_daqu3 = 0.0
                # self.ingreso_usapi = 0.0
                # self.ingreso_n_usapi = 0.0

        if self.con_exclusion_daqu3 == 1:
            if self.adverse_razon_daqu3[0] == 76:
                if self.data["COQ1EXP005TO"] == 1:
                    self.adverse_razon_daqu3[0] = 78
                    self.ingreso_daqu3 = 0.02
                    self.ingreso_n_daqu3 = 0.02
                    # self.ingreso_usapi = 0.02
                    # self.ingreso_n_usapi = 0.02
                else:
                    self.con_exclusion_daqu3 = 0

        if self.adverse_razon_daqu3[0] == 72:
            self.con_exclusion_daqu3 = 0
            self.poblacion_daqu3 = "TIPO5"
        elif self.con_exclusion_daqu3 == 0:
            if self.data["COQ1DEM001TO"] == 1:
                self.poblacion_daqu3 = "TEC"
            else:
                self.poblacion_daqu3 = "NOTEC"

    def cal_salida_pesos_daqu3(self):
        q3_ingreso_inf_c = self.q3_ingreso - self.q3_ingreso * self.K_INTERVALO_DAQU3
        q3_ingreso_sup_c = self.q3_ingreso + self.q3_ingreso * self.K_INTERVALO_DAQU3

        self.ingreso_n_daqu3 = self.q3_ingreso
        self.ingreso_inf_n_daqu3 = round(q3_ingreso_inf_c, 5)
        self.ingreso_sup_n_daqu3 = round(q3_ingreso_sup_c, 5)

        self.ingreso_pesos_n_daqu3 = math.floor((self.ingreso_n_daqu3 * self.data['VLR_SMLMV_CARACT']) / 1000.0)
        self.ingreso_pesos_n_inf_daqu3 = math.floor(
            self.ingreso_pesos_n_daqu3 - self.ingreso_pesos_n_daqu3 * self.K_INTERVALO_DAQU3
        )
        self.ingreso_pesos_n_sup_daqu3 = math.floor(
            self.ingreso_pesos_n_daqu3 + self.ingreso_pesos_n_daqu3 * self.K_INTERVALO_DAQU3
        )

        # valores de salarios minimos editados
        self.ingreso_daqu3 = self.ingreso_n_daqu3
        self.ingreso_inf_daqu3 = self.ingreso_inf_n_daqu3
        self.ingreso_sup_daqu3 = self.ingreso_sup_n_daqu3
        # valores en pesos editados
        self.ingreso_pesos_daqu3 = self.ingreso_pesos_n_daqu3
        self.ingreso_pesos_inf_daqu3 = self.ingreso_pesos_n_inf_daqu3
        self.ingreso_pesos_sup_daqu3 = self.ingreso_pesos_n_sup_daqu3

    def calcular_num_port_daqu3(self):
        self.prestamos_daqu3 = 0
        self.q3_ro = 0.0
        self.q3_hp = 0.0
        self.q3_cc = 0.0
        self.q3_ot = 0.0
        self.q3_co = 0.0
        self.q3_ah_ct = 0.0

        if self.data["CO01NUM002IN"] > 0 or self.data["CO01NUM002VE"] > 0:
            self.prestamos_daqu3 = 1.0

        if self.data["CO01NUM002RO"] > 0:
            self.q3_ro = 1.0

        if self.data["CO01NUM002HP"] > 0:
            self.q3_hp = 1.0

        if self.data["CO01NUM002CC"] > 0:
            self.q3_cc = 1.0

        if self.data["CO01NUM002OT"] > 0:
            self.q3_ot = 1.0

        if self.data["CO01NUM002CO"] > 0:
            self.q3_co = 1.0

        if self.data["CO01NUM002AH"] > 0 or self.data["CO01NUM002CT"] > 0:
            self.q3_ah_ct = 1.0

        self.num_port_daqu3 = (self.prestamos_daqu3 + self.q3_ro + self.q3_hp + self.q3_cc +
                               self.q3_ot + self.q3_co + self.q3_ah_ct)

    def calcular_nodos_daqu3(self):
        self.nodo_daqu3 = -1

        if self.poblacion_daqu3 == "NOTEC":
            if self.num_port_daqu3 < 1.5:
                self.nodo_daqu3 = 1
            elif 1.5 <= self.num_port_daqu3 < 2.5:
                self.nodo_daqu3 = 2
            elif 2.5 <= self.num_port_daqu3 < 3.5:
                if 0 <= self.data["CO00DEM003"] < 44.5:
                    self.nodo_daqu3 = 3
                else:
                    self.nodo_daqu3 = 4
            else:
                if 30.5 <= self.data["CO00DEM003"]:
                    self.nodo_daqu3 = 5
                else:
                    self.nodo_daqu3 = 4

        if self.poblacion_daqu3 == "TEC":
            if 3.5 <= self.num_port_daqu3:
                if 4.5 <= self.num_port_daqu3:
                    self.nodo_daqu3 = 4
                else:
                    if self.q3_ro == 1.0:
                        self.nodo_daqu3 = 3
                    else:
                        self.nodo_daqu3 = 2
            else:
                if 2.5 <= self.num_port_daqu3:
                    if 99.6999413900592 <= self.data["COQ1END012TC"]:
                        self.nodo_daqu3 = 2
                    else:
                        self.nodo_daqu3 = 2
                else:
                    self.nodo_daqu3 = 1

        if self.poblacion_daqu3 == "TIPO5":
            self.nodo_daqu3 = 0

    def calcular_node_daqu3(self):
        self.node_daqu3 = -1
        self.grupo_daqu3 = -1

        attributes = ["COQ1END005HP", "COQ1END002HP", "COQ1NUM002HP", "COQ1END006HP", "COQ1END008TC",
                      "COQ1END008IN", "COQ1END002IN", "COQ1END010IN", "COQ1END002TC", "COQ1END009TC",
                      "CO01END007IN", "CO01END081RO", "CO01END007RO", "CO01ACP007HP", "CO01END028HP",
                      "CO01END005RO", "COQ1END001TO", "CO01END026IN", "CO01END028IN", "CO01NUM005HP",
                      "CO01END026RO", "CO01ACP007RO", "CO01END028RO", "COQ1END010HP", "CO01END026HP",
                      "CO01EXP001HP", "CO02END002HP", "CO01ACP017HP", "CO02END009HP", "CO01END090HP",
                      "COQ1EXP001HP", "CO00DEM006", "CO00DEM012", "CO00DEM016", "CO02EXP001TO",
                      "CO02NUM002TO", "CO02NUM004TO", "CO00DEM026", "CO02NUM005TO", "CO01ACP007AH"]

        # POBLACION-DAQU3  OK
        if self.poblacion_daqu3 == "NOTEC":
            # Q3_ACTIVIDAD-ECONOMICA  *Es una caracteristica externa
            # Q3_PREXPOSICION         *SE CALCULA EN PERFORM
            # Q3_TIPOID               *SE ASIGNA DE TIPO-ID-CARACT
            # self.q3_act_econ             *Es una caracteristica externa
            q3_actividad_economica = self.data["COQ1DEM002TO"]
            self.q3_act_econ = q3_actividad_economica

            self.cuotatotal_daqu3()
            self.exposicion_daqu3()
            self.q3_tipoid = self.data["TIPOID"]

            for key in attributes:
                if self.data_o[key] < 0 or self.data_o[key] == 999:
                    self.data[key] = -1.0

            if self.q3_cuotatotal < 0 or self.q3_cuotatotal == 999:
                self.q3_cuotatotal = -1.0

            if self.q3_prexposicionhp < 0 or self.q3_prexposicionhp == 999:
                self.q3_prexposicionhp = -1.0

            if self.num_port_daqu3 < 0 or self.num_port_daqu3 == 999:
                self.num_port_daqu3 = -1.0

            if self.data_o["CO00DEM003"] < 18 or self.data_o["CO00DEM003"] == 999:
                self.data["CO00DEM003"] = -1.0

            if self.nodo_daqu3 == 1:
                self.notec_nodo_1()
            # FIN  NODO 1 **********************************************
            if self.nodo_daqu3 == 2:
                self.notec_nodo_2()
            # FIN NODO  2 **********************************************
            if self.nodo_daqu3 == 3:
                self.notec_nodo_3()
            # FIN NODO 3 ***********************************************
            if self.nodo_daqu3 == 4:
                self.notec_nodo_4()
            # FIN NODO 4 ****************************************
            if self.nodo_daqu3 == 5:
                self.notec_nodo_5()
            # FIN NODO 5 ****************************************

        if self.poblacion_daqu3 == "TEC":
            self.q3_tipoid = self.data["TIPOID"]
            self.calcular_num_port_daqu3()
            self.cuotatotal_daqu3()
            self.exposicion_daqu3()

            if self.q3_co == 1:
                self.q3_codeudor = 1.0
            else:
                self.q3_codeudor = 0.0

            if self.q3_tipoid == 4:
                self.q3_extranjeria = 1.0
            else:
                self.q3_extranjeria = 0.0

            for key in attributes:
                if self.data_o[key] < 0 or self.data_o[key] == 999:
                    self.data[key] = -1.0

            if self.q3_prexposicionve < 0 or self.q3_prexposicionve == 999:
                self.q3_prexposicionve = -1.0

            if self.q3_cuotatotal < 0 or self.q3_cuotatotal == 999:
                self.q3_cuotatotal = -1.0

            if self.num_port_daqu3 < 0 or self.num_port_daqu3 == 999:
                self.num_port_daqu3 = -1.0

            if self.q3_prexposicionhp < 0 or self.q3_prexposicionhp == 999:
                self.q3_prexposicionhp = -1.0

            if self.data_o["CO00DEM003"] < 18 or self.data_o["CO00DEM003"] == 999:
                self.data["CO00DEM003"] = -1.0

            if self.nodo_daqu3 == 1:
                self.tec_nodo_1()
            # FIN NODO 1 TEC ****************************************
            if self.nodo_daqu3 == 2:
                self.tec_nodo_2()
            # FIN NODO 2 TEC **********************************
            if self.nodo_daqu3 == 3:
                self.tec_nodo_3()
            # FIN NODO 3 TEC ***********************************
            if self.nodo_daqu3 == 4:
                self.tec_nodo_4()
            # FIN NODO 4 TEC ***********************************

        if self.poblacion_daqu3 == "TIPO5":
            self.q3_tipoid = self.data["TIPOID"]
            self.calcular_num_port_daqu3()

            if self.q3_tipoid == 4:
                self.q3_extranjeria = 1.0
            else:
                self.q3_extranjeria = 0.0

            if self.data_o["CO00DEM003"] < 18 or self.data_o["CO00DEM003"] == 999:
                self.data["CO00DEM003"] = -1.0

            if self.q3_co == 1:
                self.q3_codeudor = 1.0
            else:
                self.q3_codeudor = 0.0

            if self.q3_ah_ct == 1:
                self.q3_ahorr_ct = 1.0
            else:
                self.q3_ahorr_ct = 0.0

            self.poblacion_tipo_5()

    def notec_nodo_1(self):
        if 1365 <= self.data["COQ1END001TO"]:
            if 12750.25 <= self.data["COQ1END008IN"]:
                self.node_daqu3 = 7
            else:
                if 3931.5 <= self.data["COQ1END008TC"]:
                    self.node_daqu3 = 13
                else:
                    if 358 <= self.data["COQ1END002HP"]:
                        self.node_daqu3 = 25
                    else:
                        if 0 <= self.data["COQ1END006HP"] < 38692:
                            self.node_daqu3 = 48
                        else:
                            if 0 <= self.data["COQ1END002IN"] < 310:
                                self.node_daqu3 = 153
                            else:
                                self.node_daqu3 = 154
        else:
            if 2.5 <= self.data["CO00DEM026"]:
                if 0.495 <= self.q3_cuotatotal:
                    self.node_daqu3 = 11
                else:
                    if 3.5 <= self.data["CO00DEM026"]:
                        if 0 <= self.data["COQ1END002HP"] < 272.5:
                            self.node_daqu3 = 42
                        else:
                            if 0 <= self.data["CO01ACP007RO"] < 0.5:
                                self.node_daqu3 = 149
                            else:
                                if 3.5 <= self.data["CO01ACP007RO"]:
                                    self.node_daqu3 = 152
                                else:
                                    self.node_daqu3 = 151
                    else:
                        if 0 <= self.data["CO00DEM003"] < 27.5:
                            if 151.5 <= self.data["COQ1END002IN"]:
                                self.node_daqu3 = 142
                            else:
                                self.node_daqu3 = 141
                        else:
                            if 0 <= self.data["COQ1END008IN"] < 8725:
                                self.node_daqu3 = 143
                            else:
                                if self.data["COQ1NUM002HP"] >= 0:
                                    self.node_daqu3 = 145
                                else:
                                    if 64.5 <= self.data["CO00DEM003"]:
                                        self.node_daqu3 = 148
                                    else:
                                        self.node_daqu3 = 147
            else:
                if 0.365 <= self.q3_cuotatotal:
                    if 0.725 <= self.q3_cuotatotal:
                        if 3316.66666666666 <= self.data["COQ1END008IN"]:
                            self.node_daqu3 = 39
                        else:
                            if 0 <= self.data["COQ1END008TC"] < 816.666666666666:
                                self.node_daqu3 = 74
                            else:
                                if 0 <= self.data["COQ1END006HP"] < 46019.5:
                                    self.node_daqu3 = 135
                                else:
                                    if 57.5 <= self.data["CO00DEM003"]:
                                        self.node_daqu3 = 138
                                    else:
                                        self.node_daqu3 = 137
                    else:
                        self.node_daqu3 = 18
                else:
                    if 0 <= self.data["COQ1END001TO"] < 602.505:
                        if 0 <= self.q3_prexposicionhp < 0.5:
                            if 783.75 <= self.data["COQ1END008TC"]:
                                self.node_daqu3 = 158
                            else:
                                if 0 <= self.data["CO00DEM003"] < 27.5:
                                    self.node_daqu3 = 159
                                else:
                                    if 52.5 <= self.data["CO00DEM003"]:
                                        self.node_daqu3 = 162
                                    else:
                                        if 0 <= self.data["CO00DEM003"] < 32.5:
                                            self.node_daqu3 = 163
                                        else:
                                            if 0 <= self.data["CO00DEM003"] < 33.5:
                                                self.node_daqu3 = 165
                                            else:
                                                if 50.5 <= self.data["CO00DEM003"]:
                                                    self.node_daqu3 = 168
                                                else:
                                                    if 49.5 <= self.data["CO00DEM003"]:
                                                        self.node_daqu3 = 170
                                                    else:
                                                        self.node_daqu3 = 169
                        else:
                            if 5475 <= self.data["COQ1END008TC"]:
                                self.node_daqu3 = 172
                            else:
                                if 0 <= self.data["COQ1END002IN"] < 136.5:
                                    if 0 <= self.data["COQ1END002TC"] < 1:
                                        self.node_daqu3 = 181
                                    else:
                                        self.node_daqu3 = 182
                                else:
                                    if 0 <= self.data["COQ1END008TC"] < 2371.5:
                                        self.node_daqu3 = 175
                                    else:
                                        if 0 <= self.data["COQ1END002HP"] < 342:
                                            self.node_daqu3 = 177
                                        else:
                                            if self.data["CO01ACP007RO"] >= 0:
                                                self.node_daqu3 = 179
                                            else:
                                                self.node_daqu3 = 180
                    else:
                        if 0 <= self.data["CO00DEM003"] < 34.5:
                            if 3.5 <= self.data["CO01ACP007RO"]:
                                self.node_daqu3 = 128
                            else:
                                if 742.495 <= self.data["COQ1END001TO"]:
                                    self.node_daqu3 = 130
                                else:
                                    if self.data["CO00DEM026"] >= 0:
                                        self.node_daqu3 = 131
                                    else:
                                        if 0 <= self.data["CO00DEM003"] < 25.5:
                                            self.node_daqu3 = 133
                                        else:
                                            self.node_daqu3 = 134
                        else:
                            if 0.5 <= self.data["CO00DEM026"]:
                                self.node_daqu3 = 69
                            else:
                                if 0 <= self.data["CO01ACP007RO"] < 0.5:
                                    if self.data["COQ1NUM002HP"] >= 0:
                                        self.node_daqu3 = 123
                                    else:
                                        if 56.5 <= self.data["CO00DEM003"]:
                                            self.node_daqu3 = 126
                                        else:
                                            self.node_daqu3 = 125

                                else:
                                    if 0 <= self.data["CO00DEM003"] < 49.5:
                                        if 2.5 <= self.data["CO01ACP007RO"]:
                                            self.node_daqu3 = 111
                                        else:
                                            if self.q3_act_econ == 1 or self.q3_act_econ == 2 or self.q3_act_econ == 3:
                                                self.node_daqu3 = 115
                                            else:
                                                if 45.5 <= self.data["CO00DEM003"]:
                                                    self.node_daqu3 = 118
                                                else:
                                                    if 0 <= self.data["CO00DEM003"] < 35.5:
                                                        self.node_daqu3 = 119
                                                    else:
                                                        if 0 <= self.data["CO00DEM003"] < 36.5:
                                                            self.node_daqu3 = 121
                                                        else:
                                                            self.node_daqu3 = 122
                                    else:
                                        self.node_daqu3 = 109

    def notec_nodo_2(self):
        if 0 <= self.q3_cuotatotal < 0.525:
            if 883.5 <= self.data["COQ1END008TC"] < 2411:
                if 0 <= self.data["COQ1END002IN"] < 207.5:
                    if 107.5 <= self.data["COQ1END002IN"] < 151.5:
                        self.node_daqu3 = 51
                    elif 151.5 <= self.data["COQ1END002IN"]:
                        if 6308.33333333333 <= self.data["COQ1END008IN"] < 9300:
                            if 0 <= self.data["CO01ACP007RO"] < 1.5:
                                self.node_daqu3 = 454
                            elif 4.5 <= self.data["CO01ACP007RO"]:
                                self.node_daqu3 = 456
                            else:
                                self.node_daqu3 = 455
                        elif 9300 <= self.data["COQ1END008IN"]:
                            self.node_daqu3 = 157
                        else:
                            self.node_daqu3 = 155
                    else:
                        if 224.5 <= self.data["COQ1END002HP"] < 357.5:
                            if 2055 <= self.data["COQ1END008TC"] < 2197:
                                self.node_daqu3 = 437
                            elif 2197 <= self.data["COQ1END008TC"]:
                                self.node_daqu3 = 438
                            else:
                                self.node_daqu3 = 436
                        elif 357.5 <= self.data["COQ1END002HP"]:
                            self.node_daqu3 = 151
                        else:
                            if self.q3_act_econ == 0 or self.q3_act_econ == 1:
                                self.node_daqu3 = 433
                            elif self.q3_act_econ == 2 or self.q3_act_econ == 3 or \
                                    self.q3_act_econ == 4 or self.q3_act_econ == 5:
                                self.node_daqu3 = 434
                            else:
                                self.node_daqu3 = 435
                elif 207.5 <= self.data["COQ1END002IN"] < 1775.5:
                    if 9661.5 <= self.data["COQ1END008IN"] < 18180:
                        if 0 <= self.data["COQ1END001TO"] < 950:
                            self.node_daqu3 = 161
                        elif 950 <= self.data["COQ1END001TO"] < 1146.67:
                            self.node_daqu3 = 162
                        else:
                            if 0 <= self.data["CO00DEM003"] < 27.5:
                                self.node_daqu3 = 472
                            elif 47.5 <= self.data["CO00DEM003"]:
                                self.node_daqu3 = 474
                            else:
                                self.node_daqu3 = 473
                    elif 18180 <= self.data["COQ1END008IN"]:
                        self.node_daqu3 = 55
                    else:
                        self.node_daqu3 = 53
                else:
                    if 0 <= self.data["CO00DEM026"] < 2.5:
                        if self.q3_act_econ == 0 or self.q3_act_econ == 1 or self.q3_act_econ == 2 or \
                                self.q3_act_econ == 3 or self.q3_act_econ == 4 or self.q3_act_econ == 5:
                            self.node_daqu3 = 167
                        elif self.q3_act_econ == 6:
                            self.node_daqu3 = 168
                        else:
                            if 0 <= self.data["COQ1END002HP"] < 237.5:
                                self.node_daqu3 = 487
                            elif 381.5 <= self.data["COQ1END002HP"]:
                                self.node_daqu3 = 489
                            else:
                                self.node_daqu3 = 488
                    elif 3.5 <= self.data["CO00DEM026"]:
                        self.node_daqu3 = 58
                    else:
                        if 0 <= self.data["COQ1END002HP"] < 297.5:
                            if 0.6892 <= self.q3_prexposicionhp < 0.8073:
                                self.node_daqu3 = 491
                            elif 0.8073 <= self.q3_prexposicionhp:
                                self.node_daqu3 = 492
                            else:
                                self.node_daqu3 = 490
                        elif 297.5 <= self.data["COQ1END002HP"]:
                            if 0 <= self.data["COQ1END006HP"] < 27026.5:
                                self.node_daqu3 = 493
                            elif 53577.5 <= self.data["COQ1END006HP"]:
                                self.node_daqu3 = 495
                            else:
                                self.node_daqu3 = 494
                        else:
                            if 2.5 <= self.data["CO01ACP007RO"] < 3.5:
                                self.node_daqu3 = 497
                            elif 3.5 <= self.data["CO01ACP007RO"]:
                                self.node_daqu3 = 498
                            else:
                                self.node_daqu3 = 496
            elif 2411 <= self.data["COQ1END008TC"]:
                if 0 <= self.data["COQ1END002HP"] < 260.5:
                    if 0 <= self.data["CO01END090HP"] < 3.695:
                        self.node_daqu3 = 59
                    elif 4.355 <= self.data["CO01END090HP"]:
                        if 695 <= self.data["COQ1END001TO"] < 1250.005:
                            self.node_daqu3 = 183
                        elif 1250.005 <= self.data["COQ1END001TO"]:
                            self.node_daqu3 = 184
                        else:
                            if 0 <= self.data["CO01END028HP"] < 0.23:
                                self.node_daqu3 = 516
                            elif 0.23 <= self.data["CO01END028HP"] < 0.305:
                                self.node_daqu3 = 517
                            else:
                                self.node_daqu3 = 518
                    else:
                        if 0 <= self.data["COQ1END002HP"] < 27:
                            self.node_daqu3 = 179
                        elif 201.5 <= self.data["COQ1END002HP"]:
                            if 0 <= self.data["COQ1END010IN"] < 1672:
                                self.node_daqu3 = 513
                            elif 1672 <= self.data["COQ1END010IN"] < 11119:
                                self.node_daqu3 = 514
                            else:
                                self.node_daqu3 = 515
                        else:
                            self.node_daqu3 = 180
                elif 447.5 <= self.data["COQ1END002HP"]:
                    self.node_daqu3 = 22
                else:
                    if 0 <= self.data["COQ1END008TC"] < 2499.5:
                        if 0 <= self.data["CO00DEM026"] < 2.5:
                            self.node_daqu3 = 185
                        elif 3.5 <= self.data["CO00DEM026"]:
                            self.node_daqu3 = 187
                        else:
                            self.node_daqu3 = 186
                    elif 5697.5 <= self.data["COQ1END008TC"]:
                        self.node_daqu3 = 64
                    else:
                        if 0 <= self.data["CO00DEM026"] < 0.5:
                            if 0 <= self.data["COQ1END008IN"] < 4050:
                                self.node_daqu3 = 531
                            elif 12993.5 <= self.data["COQ1END008IN"]:
                                self.node_daqu3 = 533
                            else:
                                self.node_daqu3 = 532
                        elif 0.5 <= self.data["CO00DEM026"] < 2.5:
                            if 2999 <= self.data["COQ1END008TC"] < 3688:
                                self.node_daqu3 = 535
                            elif 3688 <= self.data["COQ1END008TC"]:
                                self.node_daqu3 = 536
                            else:
                                self.node_daqu3 = 534
                        else:
                            if 0 <= self.data["COQ1END008IN"] < 2801.5:
                                self.node_daqu3 = 537
                            elif 19923 <= self.data["COQ1END008IN"]:
                                self.node_daqu3 = 539
                            else:
                                self.node_daqu3 = 538
            else:
                if 0 <= self.data["COQ1END008IN"] < 526:
                    if 43.5 <= self.data["COQ1END002IN"] < 199.5:
                        if self.q3_act_econ == 0 or self.q3_act_econ == 1:
                            if 0 <= self.data["COQ1END010IN"] < 85.5:
                                self.node_daqu3 = 368
                            elif 85.5 <= self.data["COQ1END010IN"] < 127:
                                self.node_daqu3 = 369
                            else:
                                self.node_daqu3 = 370
                        elif self.q3_act_econ == 2 or self.q3_act_econ == 3 or \
                                self.q3_act_econ == 4 or self.q3_act_econ == 5:
                            self.node_daqu3 = 126
                        else:
                            if 89.5 <= self.data["COQ1END002IN"] < 97.5:
                                self.node_daqu3 = 374
                            elif 97.5 <= self.data["COQ1END002IN"]:
                                self.node_daqu3 = 375
                            else:
                                self.node_daqu3 = 373
                    elif 199.5 <= self.data["COQ1END002IN"]:
                        if 233.75 <= self.data["COQ1END008IN"] < 336:
                            self.node_daqu3 = 129
                        elif 336 <= self.data["COQ1END008IN"]:
                            self.node_daqu3 = 130
                        else:
                            self.node_daqu3 = 128
                    else:
                        if 0 <= self.data["COQ1END008TC"] < 280:
                            self.node_daqu3 = 122
                        elif 648 <= self.data["COQ1END008TC"]:
                            if 384.5 <= self.data["COQ1END010IN"]:
                                self.node_daqu3 = 367
                            else:
                                self.node_daqu3 = 366
                        else:
                            self.node_daqu3 = 123
                elif 3213.33333333333 <= self.data["COQ1END008IN"]:
                    if 0 <= self.q3_cuotatotal < 0.185:
                        if 0 <= self.data["COQ1END001TO"] < 155.83:
                            if 0 <= self.data["COQ1END008IN"] < 3845:
                                self.node_daqu3 = 406
                            elif 5690 <= self.data["COQ1END008IN"]:
                                self.node_daqu3 = 408
                            else:
                                self.node_daqu3 = 407
                        elif 155.83 <= self.data["COQ1END001TO"] < 1715.835:
                            if 0 <= self.data["COQ1END002IN"] < 95.5:
                                self.node_daqu3 = 409
                            elif 95.5 <= self.data["COQ1END002IN"] < 213:
                                self.node_daqu3 = 410
                            else:
                                self.node_daqu3 = 411
                        else:
                            self.node_daqu3 = 142
                    elif 0.345 <= self.q3_cuotatotal:
                        if 0 <= self.data["COQ1END002IN"] < 177.5:
                            self.node_daqu3 = 146
                        elif 177.5 <= self.data["COQ1END002IN"] < 351.5:
                            if 0 <= self.data["COQ1END010IN"] < 1166.5:
                                self.node_daqu3 = 427
                            elif 1166.5 <= self.data["COQ1END010IN"] < 6209:
                                self.node_daqu3 = 428
                            else:
                                self.node_daqu3 = 429
                        else:
                            self.node_daqu3 = 148
                    else:
                        if 7003 <= self.data["COQ1END008IN"] < 9783:
                            if 167.5 <= self.data["COQ1END002IN"] < 271.5:
                                self.node_daqu3 = 419
                            elif 271.5 <= self.data["COQ1END002IN"]:
                                self.node_daqu3 = 420
                            else:
                                self.node_daqu3 = 418
                        elif 9783 <= self.data["COQ1END008IN"]:
                            self.node_daqu3 = 145
                        else:
                            if 3128.5 <= self.data["COQ1END010IN"] < 3968.5:
                                self.node_daqu3 = 416
                            elif 3968.5 <= self.data["COQ1END010IN"]:
                                self.node_daqu3 = 417
                            else:
                                self.node_daqu3 = 415
                else:
                    if 0 <= self.data["CO01END090HP"] < 1.255:
                        self.node_daqu3 = 44
                    elif 1.255 <= self.data["CO01END090HP"] < 8.57:
                        if 0 <= self.data["CO01END028HP"] < 0.415:
                            self.node_daqu3 = 134
                        elif 0.415 <= self.data["CO01END028HP"]:
                            if 0 <= self.data["CO01END090HP"] < 2.055:
                                self.node_daqu3 = 391
                            elif 2.055 <= self.data["CO01END090HP"] < 2.875:
                                self.node_daqu3 = 392
                            else:
                                self.node_daqu3 = 393
                        else:
                            self.node_daqu3 = 136
                    else:
                        if 0 <= self.data["COQ1END001TO"] < 215.83:
                            if self.q3_act_econ == 0 or self.q3_act_econ == 1:
                                self.node_daqu3 = 397
                            elif self.q3_act_econ == 2 or self.q3_act_econ == 3 or self.q3_act_econ == 4:
                                self.node_daqu3 = 398
                            else:
                                self.node_daqu3 = 399
                        elif 1690.01 <= self.data["COQ1END001TO"]:
                            if 221.5 <= self.data["COQ1END002HP"] < 416.5:
                                self.node_daqu3 = 404
                            elif 416.5 <= self.data["COQ1END002HP"]:
                                self.node_daqu3 = 405
                            else:
                                self.node_daqu3 = 403
                        else:
                            if 0 <= self.data["CO01ACP007RO"] < 0.5:
                                self.node_daqu3 = 400
                            elif 1.5 <= self.data["CO01ACP007RO"]:
                                self.node_daqu3 = 402
                            else:
                                self.node_daqu3 = 401

        elif 0.525 <= self.q3_cuotatotal:
            if 0 <= self.data["COQ1END002IN"] < 245.5:
                if 0 <= self.data["COQ1END008TC"] < 991:
                    if 0.885 <= self.q3_cuotatotal < 1.54:
                        self.node_daqu3 = 69
                    elif 1.54 <= self.q3_cuotatotal:
                        if 0 <= self.data["COQ1END001TO"] < 970.835:
                            self.node_daqu3 = 205
                        elif 970.835 <= self.data["COQ1END001TO"] < 1607.5:
                            if 42.5 <= self.data["CO00DEM003"]:
                                self.node_daqu3 = 581
                            else:
                                self.node_daqu3 = 580
                        else:
                            if 98.5 <= self.data["COQ1END002IN"] < 151:
                                self.node_daqu3 = 583
                            elif 151 <= self.data["COQ1END002IN"]:
                                self.node_daqu3 = 584
                            else:
                                self.node_daqu3 = 582
                    else:
                        if 355.835 <= self.data["COQ1END001TO"] < 1318.33:
                            if 0 <= self.data["COQ1END002TC"] < 161.5:
                                self.node_daqu3 = 563
                            elif 168.5 <= self.data["COQ1END002TC"]:
                                self.node_daqu3 = 565
                            else:
                                self.node_daqu3 = 564
                        elif 1318.33 <= self.data["COQ1END001TO"]:
                            self.node_daqu3 = 201
                        else:
                            self.node_daqu3 = 199
                elif 2989 <= self.data["COQ1END008TC"]:
                    if 0.19 <= self.data["CO01END028HP"] < 0.52:
                        if 0 <= self.data["COQ1END009TC"] < 560:
                            self.node_daqu3 = 220
                        elif 560 <= self.data["COQ1END009TC"] < 1270.5:
                            self.node_daqu3 = 221
                        else:
                            self.node_daqu3 = 222
                    elif 0.52 <= self.data["CO01END028HP"]:
                        self.node_daqu3 = 76
                    else:
                        if 0 <= self.data["COQ1END009TC"] < 612.5:
                            if 0 <= self.data["COQ1END009TC"] < 14:
                                self.node_daqu3 = 610
                            elif 14 <= self.data["COQ1END009TC"] < 122.5:
                                self.node_daqu3 = 611
                            else:
                                self.node_daqu3 = 612
                        elif 612.5 <= self.data["COQ1END009TC"] < 2176:
                            self.node_daqu3 = 218
                        else:
                            self.node_daqu3 = 219
                else:
                    if 0 <= self.data["COQ1END002HP"] < 353.5:
                        if 0.685 <= self.q3_cuotatotal < 1.195:
                            self.node_daqu3 = 209
                        elif 1.195 <= self.q3_cuotatotal:
                            self.node_daqu3 = 210
                        else:
                            if 0 <= self.data["CO01END028HP"] < 0.445:
                                self.node_daqu3 = 585
                            elif 0.445 <= self.data["CO01END028HP"] < 0.555:
                                self.node_daqu3 = 586
                            else:
                                self.node_daqu3 = 587
                    elif 555.5 <= self.data["COQ1END002HP"]:
                        if 0 <= self.data["COQ1END001TO"] < 1939.165:
                            self.node_daqu3 = 214
                        elif 4335.01 <= self.data["COQ1END001TO"]:
                            self.node_daqu3 = 216
                        else:
                            if 1.135 <= self.q3_cuotatotal < 1.905:
                                self.node_daqu3 = 606
                            elif 1.905 <= self.q3_cuotatotal:
                                self.node_daqu3 = 607
                            else:
                                self.node_daqu3 = 605
                    else:
                        if 0 <= self.data["COQ1END002IN"] < 126.5:
                            self.node_daqu3 = 211
                        elif 195.5 <= self.data["COQ1END002IN"]:
                            if 0.735 <= self.q3_cuotatotal < 1.325:
                                self.node_daqu3 = 601
                            elif 1.325 <= self.q3_cuotatotal:
                                self.node_daqu3 = 602
                            else:
                                self.node_daqu3 = 600
                        else:
                            self.node_daqu3 = 212
            elif 245.5 <= self.data["COQ1END002IN"] < 4647:
                if 0 <= self.data["COQ1END008IN"] < 2213.80952380952:
                    if 0 <= self.data["CO01ACP007RO"] < 2.5:
                        self.node_daqu3 = 77
                    elif 2.5 <= self.data["CO01ACP007RO"]:
                        if 0 <= self.q3_cuotatotal < 0.595:
                            self.node_daqu3 = 229
                        elif 0.595 <= self.q3_cuotatotal < 1.045:
                            self.node_daqu3 = 230
                        else:
                            self.node_daqu3 = 231
                    else:
                        if 0 <= self.data["COQ1END008IN"] < 883.5:
                            if 0 <= self.data["COQ1END010IN"] < 628.5:
                                self.node_daqu3 = 642
                            elif 3763.5 <= self.data["COQ1END010IN"]:
                                self.node_daqu3 = 644
                            else:
                                self.node_daqu3 = 643
                        elif 2110.16666666666 <= self.data["COQ1END008IN"]:
                            self.node_daqu3 = 234
                        else:
                            if 994 <= self.data["COQ1END002IN"] < 2729:
                                self.node_daqu3 = 646
                            elif 2729 <= self.data["COQ1END002IN"]:
                                self.node_daqu3 = 647
                            else:
                                self.node_daqu3 = 645
                elif 6738 <= self.data["COQ1END008IN"]:
                    if 14997.75 <= self.data["COQ1END008IN"] < 24835:
                        if 529.5 <= self.data["COQ1END002IN"] < 1205.5:
                            self.node_daqu3 = 248
                        elif 1205.5 <= self.data["COQ1END002IN"]:
                            self.node_daqu3 = 249
                        else:
                            if 0 <= self.data["COQ1END008TC"] < 1078.5:
                                self.node_daqu3 = 687
                            elif 6550 <= self.data["COQ1END008TC"]:
                                self.node_daqu3 = 689
                            else:
                                self.node_daqu3 = 688
                    elif 24835 <= self.data["COQ1END008IN"]:
                        self.node_daqu3 = 85
                    else:
                        if 0 <= self.data["COQ1END008TC"] < 905.5:
                            if 322.5 <= self.data["COQ1END002IN"] < 542.5:
                                self.node_daqu3 = 679
                            elif 542.5 <= self.data["COQ1END002IN"]:
                                self.node_daqu3 = 680
                            else:
                                self.node_daqu3 = 678
                        elif 5405 <= self.data["COQ1END008TC"]:
                            self.node_daqu3 = 246
                        else:
                            if 0 <= self.data["CO00DEM003"] < 22.5:
                                self.node_daqu3 = 681
                            elif 52.5 <= self.data["CO00DEM003"]:
                                self.node_daqu3 = 683
                            else:
                                self.node_daqu3 = 682
                else:
                    if 0 <= self.data["COQ1END008IN"] < 3233.16666666666:
                        if 1.165 <= self.q3_cuotatotal < 2.035:
                            if 0 <= self.data["COQ1END002IN"] < 332:
                                self.node_daqu3 = 654
                            elif 332 <= self.data["COQ1END002IN"] < 645.5:
                                self.node_daqu3 = 655
                            else:
                                self.node_daqu3 = 656
                        elif 2.035 <= self.q3_cuotatotal:
                            if 0 <= self.data["COQ1END002IN"] < 653.5:
                                self.node_daqu3 = 657
                            elif 653.5 <= self.data["COQ1END002IN"] < 1032.5:
                                self.node_daqu3 = 658
                            else:
                                self.node_daqu3 = 659
                        else:
                            self.node_daqu3 = 235
                    elif 3233.16666666666 <= self.data["COQ1END008IN"] < 4320.75:
                        if 4209.5 <= self.data["COQ1END010IN"] < 22452:
                            self.node_daqu3 = 239
                        elif 22452 <= self.data["COQ1END010IN"]:
                            self.node_daqu3 = 240
                        else:
                            if 0 <= self.data["COQ1END002IN"] < 265.5:
                                self.node_daqu3 = 660
                            elif 265.5 <= self.data["COQ1END002IN"] < 706.5:
                                self.node_daqu3 = 661
                            else:
                                self.node_daqu3 = 662
                    else:
                        if 0 <= self.data["COQ1END002IN"] < 439.5:
                            if 3364.5 <= self.data["COQ1END010IN"] < 19411:
                                self.node_daqu3 = 670
                            elif 19411 <= self.data["COQ1END010IN"]:
                                self.node_daqu3 = 671
                            else:
                                self.node_daqu3 = 669
                        elif 439.5 <= self.data["COQ1END002IN"] < 988.5:
                            self.node_daqu3 = 242
                        else:
                            if 5656.5 <= self.data["COQ1END010IN"] < 10529.5:
                                self.node_daqu3 = 676
                            elif 10529.5 <= self.data["COQ1END010IN"]:
                                self.node_daqu3 = 677
                            else:
                                self.node_daqu3 = 675
            else:
                if 0 <= self.data["CO01ACP007RO"] < 2.5:
                    if 0 <= self.data["COQ1END008TC"] < 1901.5:
                        if 998.5 <= self.data["COQ1END008TC"] < 1373.75:
                            if 733 <= self.data["COQ1END002TC"] < 1840.5:
                                self.node_daqu3 = 709
                            elif 1840.5 <= self.data["COQ1END002TC"]:
                                self.node_daqu3 = 710
                            else:
                                self.node_daqu3 = 708
                        elif 1373.75 <= self.data["COQ1END008TC"]:
                            self.node_daqu3 = 255
                        else:
                            self.node_daqu3 = 253
                    elif 4893 <= self.data["COQ1END008TC"]:
                        self.node_daqu3 = 88
                    else:
                        if 0 <= self.data["COQ1END006HP"] < 7628:
                            if 0 <= self.data["COQ1END002HP"] < 208.5:
                                self.node_daqu3 = 714
                            elif 208.5 <= self.data["COQ1END002HP"] < 349.5:
                                self.node_daqu3 = 715
                            else:
                                self.node_daqu3 = 716
                        elif 64549 <= self.data["COQ1END006HP"]:
                            self.node_daqu3 = 258
                        else:
                            if 0 <= self.data["COQ1END002HP"] < 211:
                                self.node_daqu3 = 717
                            elif 692.5 <= self.data["COQ1END002HP"]:
                                self.node_daqu3 = 719
                            else:
                                self.node_daqu3 = 718
                elif 2.5 <= self.data["CO01ACP007RO"]:
                    if 0 <= self.q3_cuotatotal < 0.845:
                        self.node_daqu3 = 89
                    elif 1.845 <= self.q3_cuotatotal:
                        self.node_daqu3 = 91
                    else:
                        if 0 <= self.data["COQ1END008TC"] < 1997.5:
                            if 0 <= self.data["COQ1END006HP"] < 26239:
                                self.node_daqu3 = 741
                            elif 42925.5 <= self.data["COQ1END006HP"]:
                                self.node_daqu3 = 743
                            else:
                                self.node_daqu3 = 742
                        elif 3437.75 <= self.data["COQ1END008TC"]:
                            self.node_daqu3 = 267
                        else:
                            if 0 <= self.data["COQ1END002HP"] < 308.5:
                                self.node_daqu3 = 744
                            elif 350.5 <= self.data["COQ1END002HP"]:
                                self.node_daqu3 = 746
                            else:
                                self.node_daqu3 = 745
                else:
                    if 0 <= self.data["COQ1END001TO"] < 689.165:
                        self.node_daqu3 = 92
                    elif 689.165 <= self.data["COQ1END001TO"] < 8012.5:
                        if 0 <= self.data["COQ1END002HP"] < 437.5:
                            self.node_daqu3 = 274
                        elif 437.5 <= self.data["COQ1END002HP"]:
                            self.node_daqu3 = 275
                        else:
                            if 0 <= self.data["CO00DEM026"] < 0.5:
                                self.node_daqu3 = 774
                            elif 2.5 <= self.data["CO00DEM026"]:
                                self.node_daqu3 = 776
                            else:
                                self.node_daqu3 = 775
                    else:
                        if 0 <= self.q3_cuotatotal < 0.865:
                            self.node_daqu3 = 277
                        elif 17.285 <= self.q3_cuotatotal:
                            self.node_daqu3 = 279
                        else:
                            if 0 <= self.data["CO00DEM003"] < 21.5:
                                self.node_daqu3 = 780
                            elif 21.5 <= self.data["CO00DEM003"] < 24.5:
                                self.node_daqu3 = 781
                            else:
                                self.node_daqu3 = 782
        else:
            if 0 <= self.data["COQ1END001TO"] < 883.335:
                if 0 <= self.data["COQ1END002IN"] < 223.5:
                    if 0 <= self.data["COQ1END008IN"] < 3713.5:
                        self.node_daqu3 = 95
                    elif 3713.5 <= self.data["COQ1END008IN"] < 11675.5:
                        if 0 <= self.data["COQ1END001TO"] < 23.335:
                            if 2432.5 <= self.data["COQ1END010IN"] < 4814.5:
                                self.node_daqu3 = 796
                            elif 4814.5 <= self.data["COQ1END010IN"]:
                                self.node_daqu3 = 797
                            else:
                                self.node_daqu3 = 795
                        elif 494.17 <= self.data["COQ1END001TO"]:
                            self.node_daqu3 = 285
                        else:
                            if 156.5 <= self.data["COQ1END002IN"] < 190.5:
                                self.node_daqu3 = 799
                            elif 190.5 <= self.data["COQ1END002IN"]:
                                self.node_daqu3 = 800
                            else:
                                self.node_daqu3 = 798
                    else:
                        if 0 <= self.data["CO00DEM003"] < 24.5:
                            self.node_daqu3 = 286
                        elif 24.5 <= self.data["CO00DEM003"] < 27.5:
                            if 41.67 <= self.data["COQ1END001TO"] < 410:
                                self.node_daqu3 = 808
                            elif 410 <= self.data["COQ1END001TO"]:
                                self.node_daqu3 = 809
                            else:
                                self.node_daqu3 = 807
                        else:
                            self.node_daqu3 = 288
                elif 326.5 <= self.data["COQ1END002IN"]:
                    if 0 <= self.data["COQ1END008IN"] < 1581.5:
                        self.node_daqu3 = 101
                    elif 1581.5 <= self.data["COQ1END008IN"] < 8475:
                        self.node_daqu3 = 102
                    else:
                        self.node_daqu3 = 103
                else:
                    if 0 <= self.data["COQ1END008TC"] < 2410.5:
                        if 0 <= self.data["COQ1END008TC"] < 736.5:
                            if 0 <= self.data["CO01ACP007RO"] < 2.5:
                                self.node_daqu3 = 813
                            elif 2.5 <= self.data["CO01ACP007RO"] < 4.5:
                                self.node_daqu3 = 814
                            else:
                                self.node_daqu3 = 815
                        elif 736.5 <= self.data["COQ1END008TC"] < 991.5:
                            if 0 <= self.data["COQ1END002TC"] < 0.5:
                                self.node_daqu3 = 816
                            elif 0.5 <= self.data["COQ1END002TC"] < 438.5:
                                self.node_daqu3 = 817
                            else:
                                self.node_daqu3 = 818
                        else:
                            if 0 <= self.data["CO00DEM026"] < 2.5:
                                self.node_daqu3 = 819
                            elif 3.5 <= self.data["CO00DEM026"]:
                                self.node_daqu3 = 821
                            else:
                                self.node_daqu3 = 820
                    elif 3599 <= self.data["COQ1END008TC"]:
                        if 0 <= self.data["COQ1END008TC"] < 3649:
                            if 1.5 <= self.data["CO01ACP007RO"] < 2.5:
                                self.node_daqu3 = 832
                            elif 2.5 <= self.data["CO01ACP007RO"]:
                                self.node_daqu3 = 833
                            else:
                                self.node_daqu3 = 831
                        elif 3649 <= self.data["COQ1END008TC"] < 4719.5:
                            if 0.5 <= self.data["CO00DEM026"] < 2.5:
                                self.node_daqu3 = 835
                            elif 2.5 <= self.data["CO00DEM026"]:
                                self.node_daqu3 = 836
                            else:
                                self.node_daqu3 = 834
                        else:
                            self.node_daqu3 = 297
                    else:
                        if 0 <= self.data["CO01ACP007RO"] < 0.5:
                            if 0 <= self.data["CO00DEM026"] < 2.5:
                                self.node_daqu3 = 822
                            elif 3.5 <= self.data["CO00DEM026"]:
                                self.node_daqu3 = 824
                            else:
                                self.node_daqu3 = 823
                        elif 1.5 <= self.data["CO01ACP007RO"]:
                            if 18.5 <= self.data["COQ1END002TC"] < 227.5:
                                self.node_daqu3 = 829
                            elif 227.5 <= self.data["COQ1END002TC"]:
                                self.node_daqu3 = 830
                            else:
                                self.node_daqu3 = 828
                        else:
                            if 142.5 <= self.data["COQ1END001TO"] < 333.325:
                                self.node_daqu3 = 826
                            elif 333.325 <= self.data["COQ1END001TO"]:
                                self.node_daqu3 = 827
                            else:
                                self.node_daqu3 = 825
            elif 2398.33 <= self.data["COQ1END001TO"]:
                if 1617.5 <= self.data["COQ1END008TC"] < 5931.375:
                    if 0 <= self.data["COQ1END008IN"] < 6900:
                        if 0 <= self.data["CO00DEM026"] < 2.5:
                            if 0 <= self.data["CO01ACP007RO"] < 0.5:
                                self.node_daqu3 = 962
                            elif 0.5 <= self.data["CO01ACP007RO"] < 6.5:
                                self.node_daqu3 = 963
                            else:
                                self.node_daqu3 = 964
                        elif 2.5 <= self.data["CO00DEM026"] < 3.5:
                            if 0 <= self.data["COQ1END008TC"] < 1989:
                                self.node_daqu3 = 965
                            elif 3125 <= self.data["COQ1END008TC"]:
                                self.node_daqu3 = 967
                            else:
                                self.node_daqu3 = 966
                        else:
                            self.node_daqu3 = 345
                    elif 26500 <= self.data["COQ1END008IN"]:
                        self.node_daqu3 = 118
                    else:
                        if 0 <= self.data["COQ1END002HP"] < 377:
                            if 3344.165 <= self.data["COQ1END001TO"] < 5053.33:
                                self.node_daqu3 = 972
                            elif 5053.33 <= self.data["COQ1END001TO"]:
                                self.node_daqu3 = 973
                            else:
                                self.node_daqu3 = 971
                        elif 993.5 <= self.data["COQ1END002HP"]:
                            self.node_daqu3 = 348
                        else:
                            self.node_daqu3 = 347
                elif 5931.375 <= self.data["COQ1END008TC"]:
                    self.node_daqu3 = 40
                else:
                    if 0 <= self.data["COQ1END010IN"] < 4307:
                        if 2517.75 <= self.data["COQ1END008IN"] < 11500:
                            self.node_daqu3 = 335
                        elif 11500 <= self.data["COQ1END008IN"]:
                            self.node_daqu3 = 336
                        else:
                            if 0 <= self.data["COQ1END002IN"] < 529:
                                self.node_daqu3 = 938
                            elif 1422.5 <= self.data["COQ1END002IN"]:
                                self.node_daqu3 = 940
                            else:
                                self.node_daqu3 = 939
                    elif 14838.5 <= self.data["COQ1END010IN"]:
                        if 0 <= self.data["COQ1END008IN"] < 9855:
                            if 0 <= self.data["COQ1END002IN"] < 201.5:
                                self.node_daqu3 = 953
                            elif 1179 <= self.data["COQ1END002IN"]:
                                self.node_daqu3 = 955
                            else:
                                self.node_daqu3 = 954
                        elif 26845.6666666666 <= self.data["COQ1END008IN"]:
                            self.node_daqu3 = 342
                        else:
                            self.node_daqu3 = 341
                    else:
                        if 27879.5 <= self.data["COQ1END006HP"] < 57987.5:
                            self.node_daqu3 = 338
                        elif 57987.5 <= self.data["COQ1END006HP"]:
                            self.node_daqu3 = 339
                        else:
                            if 0 <= self.data["CO00DEM026"] < 2.5:
                                self.node_daqu3 = 944
                            elif 3.5 <= self.data["CO00DEM026"]:
                                self.node_daqu3 = 946
                            else:
                                self.node_daqu3 = 945
            else:
                if 0 <= self.data["CO00DEM003"] < 24.5:
                    self.node_daqu3 = 35
                elif 24.5 <= self.data["CO00DEM003"] < 45.5:
                    if 0 <= self.data["COQ1END008TC"] < 1499.5:
                        if 0 <= self.data["CO01ACP007RO"] < 0.5:
                            if 529.5 <= self.data["COQ1END002TC"] < 703.5:
                                self.node_daqu3 = 885
                            elif 703.5 <= self.data["COQ1END002TC"]:
                                self.node_daqu3 = 886
                            else:
                                self.node_daqu3 = 884
                        elif 0.5 <= self.data["CO01ACP007RO"]:
                            if 0 <= self.data["COQ1END008TC"] < 726:
                                self.node_daqu3 = 887
                            elif 726 <= self.data["COQ1END008TC"] < 964.5:
                                self.node_daqu3 = 888
                            else:
                                self.node_daqu3 = 889
                        else:
                            self.node_daqu3 = 318
                    elif 3297.5 <= self.data["COQ1END008TC"]:
                        if 0 <= self.data["COQ1END002HP"] < 269.5:
                            self.node_daqu3 = 322
                        elif 633.5 <= self.data["COQ1END002HP"]:
                            self.node_daqu3 = 324
                        else:
                            self.node_daqu3 = 323
                    else:
                        if 0 <= self.data["CO00DEM026"] < 2.5:
                            if 0 <= self.data["COQ1END008IN"] < 5519.5:
                                self.node_daqu3 = 893
                            elif 7913 <= self.data["COQ1END008IN"]:
                                self.node_daqu3 = 895
                            else:
                                self.node_daqu3 = 894
                        elif 3.5 <= self.data["CO00DEM026"]:
                            if 0 <= self.data["COQ1END002HP"] < 376:
                                self.node_daqu3 = 899
                            elif 376 <= self.data["COQ1END002HP"] < 1096:
                                self.node_daqu3 = 900
                            else:
                                self.node_daqu3 = 901
                        else:
                            if 0 <= self.data["CO01ACP007RO"] < 2.5:
                                self.node_daqu3 = 896
                            elif 2.5 <= self.data["CO01ACP007RO"] < 8.5:
                                self.node_daqu3 = 897
                            else:
                                self.node_daqu3 = 898
                else:
                    if 0.5 <= self.data["CO00DEM026"] < 2.5:
                        self.node_daqu3 = 111
                    elif 2.5 <= self.data["CO00DEM026"]:
                        if 0 <= self.data["COQ1END008TC"] < 1175:
                            if 0 <= self.data["COQ1END008IN"] < 3450:
                                self.node_daqu3 = 929
                            elif 3450 <= self.data["COQ1END008IN"]:
                                self.node_daqu3 = 930
                            else:
                                self.node_daqu3 = 931
                        elif 9638 <= self.data["COQ1END008TC"]:
                            self.node_daqu3 = 333
                        else:
                            if 0 <= self.data["COQ1END008IN"] < 754.5:
                                self.node_daqu3 = 932
                            elif 4986.75 <= self.data["COQ1END008IN"]:
                                self.node_daqu3 = 934
                            else:
                                self.node_daqu3 = 933
                    else:
                        if 0 <= self.data["COQ1END008TC"] < 725:
                            self.node_daqu3 = 325
                        elif 5975 <= self.data["COQ1END008TC"]:
                            self.node_daqu3 = 327
                        else:
                            self.node_daqu3 = 326

    def notec_nodo_3(self):
        if 0.375 <= self.q3_cuotatotal:
            if 3998 <= self.data["COQ1END008TC"]:
                self.node_daqu3 = 7
            else:
                if 0 <= self.data["COQ1END002IN"] < 183.5:
                    if 0.845 <= self.q3_cuotatotal:
                        if 3.5 <= self.data["CO01ACP007RO"]:
                            if 0 <= self.data["COQ1END008TC"] < 1159.5:
                                self.node_daqu3 = 100
                            else:
                                self.node_daqu3 = 101
                        else:
                            self.node_daqu3 = 50
                    else:
                        if 142.5 <= self.data["COQ1END002IN"]:
                            self.node_daqu3 = 49
                        else:
                            if 1986 <= self.data["COQ1END008TC"]:
                                self.node_daqu3 = 95
                            else:
                                self.node_daqu3 = 94
                else:
                    if 24325.5 <= self.data["COQ1END008IN"]:
                        self.node_daqu3 = 27
                    else:
                        if 0 <= self.data["COQ1END002HP"] < 345.5:
                            self.node_daqu3 = 52
                        else:
                            self.node_daqu3 = 53
        else:
            if 2990.5 <= self.data["COQ1END008TC"]:
                if 0 <= self.data["COQ1END002HP"] < 330.5:
                    if 3.98 <= self.data["CO01END090HP"]:
                        self.node_daqu3 = 21
                    else:
                        if 0 <= self.data["COQ1END008IN"] < 2712.5:
                            self.node_daqu3 = 40
                        else:
                            if 7959.5 <= self.data["COQ1END005HP"]:
                                self.node_daqu3 = 83
                            else:
                                self.node_daqu3 = 82
                else:
                    if 0 <= self.data["COQ1END008IN"] < 721.25:
                        if 731 <= self.data["COQ1END009TC"]:
                            self.node_daqu3 = 45
                        else:
                            if 0 <= self.data["COQ1END002IN"] < 207.5:
                                self.node_daqu3 = 86
                            else:
                                self.node_daqu3 = 87
                    else:
                        if 0 <= self.q3_cuotatotal < 0.045:
                            self.node_daqu3 = 46
                        else:
                            if 0 <= self.data["COQ1END008TC"] < 3191.5:

                                self.node_daqu3 = 92
                            else:
                                self.node_daqu3 = 93
            else:
                if self.q3_cuotatotal >= 0:
                    if 0 <= self.data["COQ1END008IN"] < 4328.25:
                        if 143.5 <= self.data["COQ1END002IN"]:
                            self.node_daqu3 = 33
                        else:
                            if 2302.485 <= self.data["COQ1END001TO"]:
                                self.node_daqu3 = 65
                            else:
                                self.node_daqu3 = 64
                    else:
                        if 997.5 <= self.data["COQ1END008TC"]:
                            if 0 <= self.data["COQ1END002HP"] < 347:
                                self.node_daqu3 = 70
                            else:
                                self.node_daqu3 = 71
                        else:
                            if 2.5 <= self.data["CO01ACP007RO"]:
                                self.node_daqu3 = 69
                            else:
                                self.node_daqu3 = 68
                else:
                    if 17418 <= self.data["COQ1END008IN"]:
                        if 0 <= self.data["CO00DEM003"] < 27.5:
                            if 0 <= self.data["COQ1END002IN"] < 1617:
                                self.node_daqu3 = 76
                            else:
                                self.node_daqu3 = 77

                        else:
                            if 0 <= self.data["COQ1END008IN"] < 19997.5:
                                self.node_daqu3 = 78
                            else:
                                self.node_daqu3 = 79
                    else:
                        if 108.5 <= self.data["COQ1END002IN"]:
                            if 542.5 <= self.data["COQ1END002HP"]:
                                self.node_daqu3 = 75
                            else:
                                self.node_daqu3 = 74
                        else:
                            self.node_daqu3 = 36

    def notec_nodo_4(self):
        if 0.965 <= self.q3_cuotatotal:
            if 0 <= self.q3_cuotatotal < 1.325:
                if 3262.25 <= self.data["COQ1END008TC"]:
                    self.node_daqu3 = 255
                else:
                    if 0 <= self.data["COQ1END008IN"] < 7925.5:

                        self.node_daqu3 = 256
                    else:
                        self.node_daqu3 = 257
            else:
                if 6534 <= self.data["COQ1END008TC"]:
                    self.node_daqu3 = 259
                else:
                    if self.data["CO01ACP007RO"] >= 0:
                        if 145976 <= self.data["COQ1END010IN"]:
                            self.node_daqu3 = 263
                        else:
                            if 7622.5 <= self.data["COQ1END010IN"]:
                                if 38796.5 <= self.data["COQ1END008IN"]:
                                    self.node_daqu3 = 285
                                else:
                                    if 0 <= self.data["COQ1END001TO"] < 691.665:

                                        self.node_daqu3 = 286
                                    else:
                                        if 6423 <= self.data["COQ1END009TC"]:
                                            self.node_daqu3 = 289
                                        else:
                                            if 0 <= self.data["COQ1END001TO"] < 789.995:

                                                self.node_daqu3 = 302
                                            else:
                                                if 71357.5 <= self.data["COQ1END006HP"]:
                                                    self.node_daqu3 = 305
                                                else:
                                                    self.node_daqu3 = 304
                            else:
                                if 0 <= self.data["CO01ACP007RO"] < 0.5:

                                    self.node_daqu3 = 272
                                else:
                                    if 1.635 <= self.data["CO01END028HP"]:
                                        self.node_daqu3 = 275
                                    else:
                                        if 0 <= self.q3_cuotatotal < 2:

                                            self.node_daqu3 = 282
                                        else:
                                            self.node_daqu3 = 283
                    else:
                        if 0 <= self.data["COQ1END008IN"] < 7680.83333333333:

                            self.node_daqu3 = 309
                        else:
                            self.node_daqu3 = 310
        else:
            if 3530.5 <= self.data["COQ1END008TC"]:
                if 0 <= self.data["COQ1END002IN"] < 354.5:
                    self.node_daqu3 = 246
                else:
                    if 17975 <= self.data["COQ1END008TC"]:
                        self.node_daqu3 = 249
                    else:
                        if 0 <= self.data["CO00DEM026"] < 3.5:
                            self.node_daqu3 = 250
                        else:
                            self.node_daqu3 = 251
            else:
                if 0 <= self.q3_prexposicionhp < 0.55845:
                    if 0 <= self.data["COQ1END002IN"] < 235.5:
                        if self.q3_act_econ in (1, 2, 3, 4, 5, 6):
                            self.node_daqu3 = 137
                        else:
                            if 149.5 <= self.data["COQ1END002IN"]:
                                if 370.835 <= self.data["COQ1END001TO"]:
                                    self.node_daqu3 = 181
                                else:
                                    self.node_daqu3 = 180

                            else:
                                if 0 <= self.data["COQ1END008TC"] < 1567.5:

                                    self.node_daqu3 = 147
                                else:
                                    if 0 <= self.data["CO00DEM026"] < 3.5:

                                        self.node_daqu3 = 158
                                    else:
                                        if 0 <= self.data["COQ1END002IN"] < 35.5:

                                            self.node_daqu3 = 178
                                        else:
                                            self.node_daqu3 = 179
                    else:
                        if 1025 <= self.data["COQ1END008IN"]:
                            if 0 <= self.data["COQ1END002IN"] < 529:
                                if 0 <= self.data["COQ1END008TC"] < 1316.66666666666:

                                    self.node_daqu3 = 203
                                else:
                                    if 1.5 <= self.data["COQ1NUM002HP"]:
                                        self.node_daqu3 = 206
                                    else:
                                        self.node_daqu3 = 205
                            else:
                                self.node_daqu3 = 202
                        else:
                            if 1429.5 <= self.data["COQ1END008TC"]:
                                if 0 <= self.data["CO01ACP007RO"] < 2.5:

                                    self.node_daqu3 = 199
                                else:
                                    self.node_daqu3 = 200
                            else:
                                if 3.5 <= self.data["CO00DEM026"]:
                                    self.node_daqu3 = 187
                                else:
                                    if 0 <= self.data["COQ1END001TO"] < 559.165:

                                        if self.data["COQ1NUM002HP"] >= 0:
                                            self.node_daqu3 = 193
                                        else:
                                            self.node_daqu3 = 194

                                    else:
                                        if 0 <= self.q3_cuotatotal < 0.685:
                                            if 2.5 <= self.data["CO00DEM026"]:
                                                self.node_daqu3 = 198
                                            else:
                                                self.node_daqu3 = 197

                                        else:
                                            self.node_daqu3 = 196
                else:
                    if 0 <= self.data["COQ1END008IN"] < 11144:
                        if 634.5 <= self.data["COQ1END002IN"]:
                            self.node_daqu3 = 216
                        else:
                            self.node_daqu3 = 215
                    else:
                        if 662.5 <= self.data["COQ1END001TO"]:
                            if 516 <= self.data["COQ1END002IN"]:
                                self.node_daqu3 = 243
                            else:
                                if 46889.5 <= self.data["COQ1END006HP"]:
                                    self.node_daqu3 = 245
                                else:
                                    self.node_daqu3 = 244
                        else:
                            self.node_daqu3 = 240

    def notec_nodo_5(self):
        if 0 <= self.q3_cuotatotal < 1.685:
            if 0 <= self.data["COQ1END008TC"] < 1594.5:
                if 0 <= self.data["COQ1END002IN"] < 366.5:
                    if 0 <= self.data["CO01END090HP"] < 0.81:
                        self.node_daqu3 = 3028
                    else:
                        self.node_daqu3 = 3029
                elif 366.5 <= self.data["COQ1END002IN"] < 679:
                    self.node_daqu3 = 3001
                elif 679 <= self.data["COQ1END002IN"] < 874:
                    self.node_daqu3 = 3002
                else:
                    if 0.365 <= self.data["CO01END028HP"]:
                        self.node_daqu3 = 3036
                    else:
                        self.node_daqu3 = 3035
            elif 3309 <= self.data["COQ1END008TC"] < 5708.5:
                self.node_daqu3 = 2998
            elif 5708.5 <= self.data["COQ1END008TC"]:
                self.node_daqu3 = 2999
            else:
                if 0 <= self.data["COQ1END002IN"] < 293.5:
                    if self.q3_act_econ == 1:
                        self.node_daqu3 = 3041
                    elif self.q3_act_econ in (2, 3, 4, 5):
                        self.node_daqu3 = 3042
                    elif self.q3_act_econ == 6:
                        self.node_daqu3 = 3043
                    else:
                        self.node_daqu3 = 3044
                elif 293.5 <= self.data["COQ1END002IN"] < 593.5:
                    if 383 <= self.data["COQ1END002HP"]:
                        self.node_daqu3 = 3060
                    else:
                        if 499 <= self.data["COQ1END002IN"]:
                            self.node_daqu3 = 3085
                        else:
                            self.node_daqu3 = 3084
                elif 593.5 <= self.data["COQ1END002IN"]:
                    self.node_daqu3 = 3039
                else:
                    if 2.5 <= self.data["CO00DEM026"] < 3.5:
                        self.node_daqu3 = 3087
                    elif 3.5 <= self.data["CO00DEM026"] < 4.5:
                        self.node_daqu3 = 3088
                    elif 4.5 <= self.data["CO00DEM026"]:
                        self.node_daqu3 = 3089
                    else:
                        if 0 <= self.q3_cuotatotal < 0.215:
                            self.node_daqu3 = 3090
                        elif 0.695 <= self.q3_cuotatotal < 1.165:
                            self.node_daqu3 = 3092
                        elif 1.165 <= self.q3_cuotatotal:
                            self.node_daqu3 = 3093
                        else:
                            self.node_daqu3 = 3091
        elif 1.685 <= self.q3_cuotatotal < 61.425:
            if 0 <= self.data["COQ1END008TC"] < 2808.5:
                if 0 <= self.data["COQ1END002IN"] < 250.5:
                    self.node_daqu3 = 3112
                elif 250.5 <= self.data["COQ1END002IN"] < 796:
                    if 2.895 <= self.q3_cuotatotal < 3.69:
                        self.node_daqu3 = 3182
                    elif 3.69 <= self.q3_cuotatotal < 5.92:
                        self.node_daqu3 = 3183
                    elif 5.92 <= self.q3_cuotatotal:
                        self.node_daqu3 = 3184
                    else:
                        if 0 <= self.data["CO01END090HP"] < 1.585:
                            self.node_daqu3 = 3190
                        elif 1.585 <= self.data["CO01END090HP"] < 8.62:
                            self.node_daqu3 = 3191
                        elif 8.62 <= self.data["CO01END090HP"]:
                            self.node_daqu3 = 3192
                        else:
                            if 0 <= self.q3_cuotatotal < 1.875:
                                self.node_daqu3 = 3199
                            elif 1.875 <= self.q3_cuotatotal < 2.745:
                                self.node_daqu3 = 3200
                            elif 2.745 <= self.q3_cuotatotal:
                                self.node_daqu3 = 3201
                            else:
                                self.node_daqu3 = 3202
                elif 796 <= self.data["COQ1END002IN"]:
                    if 0 <= self.data["COQ1END008IN"] < 17024.6818181818:
                        self.node_daqu3 = 3208
                    elif 17024.6818181818 <= self.data["COQ1END008IN"]:
                        self.node_daqu3 = 3209
                    else:
                        self.node_daqu3 = 3210
                else:
                    if 0.68 <= self.data["CO01END028HP"]:
                        self.node_daqu3 = 3217
                    else:
                        self.node_daqu3 = 3216
            elif 9065 <= self.data["COQ1END008TC"] < 14420:
                if 0 <= self.q3_cuotatotal < 2.645:
                    self.node_daqu3 = 3302
                elif 8.325 <= self.q3_cuotatotal < 9.86:
                    self.node_daqu3 = 3304
                elif 9.86 <= self.q3_cuotatotal:
                    self.node_daqu3 = 3305
                else:
                    self.node_daqu3 = 3303
            elif 14420 <= self.data["COQ1END008TC"]:
                if 0 <= self.data["CO00DEM026"] < 6:
                    if 0 <= self.q3_cuotatotal < 18.39:
                        self.node_daqu3 = 3333
                    elif 18.39 <= self.q3_cuotatotal:
                        self.node_daqu3 = 3334
                    else:
                        self.node_daqu3 = 3335
                elif 6 <= self.data["CO00DEM026"]:
                    self.node_daqu3 = 3326
                else:
                    self.node_daqu3 = 3327
            else:
                if 0 <= self.data["COQ1END010IN"] < 8427:
                    self.node_daqu3 = 3223
                else:
                    if 78300.5 <= self.data["COQ1END006HP"]:
                        self.node_daqu3 = 3242
                    else:
                        if 1.5 <= self.data["CO01ACP007RO"] < 14.5:
                            if 6.765 <= self.q3_cuotatotal:
                                if 0 <= self.data["COQ1END008IN"] < 33750:
                                    self.node_daqu3 = 3300
                                else:
                                    self.node_daqu3 = 3301
                            else:
                                if 0 <= self.q3_cuotatotal < 2.455:

                                    self.node_daqu3 = 3257
                                else:
                                    if 0 <= self.data["COQ1END002TC"] < 1521:
                                        if 0 <= self.data["COQ1END002IN"] < 297:
                                            self.node_daqu3 = 3287
                                        elif 297 <= self.data["COQ1END002IN"] < 1380.5:
                                            self.node_daqu3 = 3288
                                        elif 1380.5 <= self.data["COQ1END002IN"]:
                                            self.node_daqu3 = 3289
                                        else:
                                            self.node_daqu3 = 3290
                                    elif 1521 <= self.data["COQ1END002TC"]:
                                        self.node_daqu3 = 3276
                                    else:
                                        self.node_daqu3 = 3277

                        elif 14.5 <= self.data["CO01ACP007RO"]:
                            self.node_daqu3 = 3250
                        else:
                            self.node_daqu3 = 3248
        elif 61.425 <= self.q3_cuotatotal:
            self.node_daqu3 = 2994
        else:
            if 0 <= self.data["COQ1END008IN"] < 3400.33333333333:

                self.node_daqu3 = 3341
            elif 17768 <= self.data["COQ1END008IN"] < 40155:
                if 2018.25 <= self.data["COQ1END008TC"] < 3623:
                    self.node_daqu3 = 3346
                elif 3623 <= self.data["COQ1END008TC"] < 8148.75:
                    self.node_daqu3 = 3347
                elif 8148.75 <= self.data["COQ1END008TC"]:
                    self.node_daqu3 = 3348
                else:
                    self.node_daqu3 = 3345
            elif 40155 <= self.data["COQ1END008IN"]:
                self.node_daqu3 = 3344
            else:
                if 0 <= self.data["COQ1END008TC"] < 977.5:

                    self.node_daqu3 = 3349
                elif 4542.5 <= self.data["COQ1END008TC"]:
                    self.node_daqu3 = 3351
                else:
                    if 104 <= self.data["COQ1END002HP"] < 358.5:
                        self.node_daqu3 = 3353
                    elif 358.5 <= self.data["COQ1END002HP"] < 974:
                        self.node_daqu3 = 3354
                    elif 974 <= self.data["COQ1END002HP"]:
                        self.node_daqu3 = 3355
                    else:
                        if 0 <= self.data["COQ1NUM002HP"] < 3:

                            self.node_daqu3 = 3380
                        elif 3 <= self.data["COQ1NUM002HP"]:
                            self.node_daqu3 = 3381
                        else:
                            if 0 <= self.data["CO01ACP007RO"] < 4.5:
                                self.node_daqu3 = 3388
                            elif 4.5 <= self.data["CO01ACP007RO"]:
                                self.node_daqu3 = 3389
                            else:
                                self.node_daqu3 = 3390

    def tec_nodo_1(self):
        if 1137.495 <= self.data["COQ1END001TO"]:
            if self.data["COQ1END001TO"] < 2246.665:
                if 0 <= self.data["CO01END028HP"] < 1.065:
                    self.node_daqu3 = 12
                else:
                    if 10.625 <= self.data["CO01END007RO"]:
                        self.node_daqu3 = 27
                    else:
                        if 0 <= self.data["CO01END007IN"] < 9.18:
                            self.node_daqu3 = 52
                        else:
                            if 1.38 <= self.data["CO01END028RO"]:
                                self.node_daqu3 = 105
                            else:
                                if self.data["COQ1EXP001HP"] >= 0:
                                    if 113.145 <= self.data["CO01END026HP"]:
                                        self.node_daqu3 = 164
                                    else:
                                        if 0.69 <= self.data["CO01END026RO"]:
                                            self.node_daqu3 = 166
                                        else:
                                            self.node_daqu3 = 165
                                else:
                                    self.node_daqu3 = 162
            else:
                if 39.38 <= self.data["CO01END007RO"]:
                    self.node_daqu3 = 15
                else:
                    if 6.805 <= self.q3_cuotatotal:
                        if 0 <= self.data["CO01END007IN"] < 21.905:

                            self.node_daqu3 = 58
                        else:
                            if 0 <= self.data["CO01END028RO"] < 1.925:

                                self.node_daqu3 = 116
                            else:
                                self.node_daqu3 = 117
                    else:
                        if 1.85 <= self.data["CO01END028RO"]:
                            self.node_daqu3 = 57
                        else:
                            if 11788.32 <= self.data["COQ1END001TO"]:
                                self.node_daqu3 = 127
                            else:
                                if 2.695 <= self.q3_cuotatotal:
                                    self.node_daqu3 = 129
                                else:
                                    if 1.595 <= self.data["CO01END028HP"]:
                                        self.node_daqu3 = 149
                                    else:
                                        if 137.5 <= self.data["CO01EXP001HP"]:
                                            self.node_daqu3 = 154
                                        else:
                                            self.node_daqu3 = 153
        else:
            if 2.5 <= self.data["CO00DEM026"]:
                if 0 <= self.data["CO01END028IN"] < 0.565:
                    if 3.595 <= self.data["CO01END007RO"]:
                        if 186.67 <= self.data["COQ1END001TO"]:
                            if 0 <= self.data["CO01ACP007RO"] < 1.5:
                                self.node_daqu3 = 86
                            else:
                                self.node_daqu3 = 87
                        else:
                            self.node_daqu3 = 42
                    else:
                        if 0.275 <= self.data["CO01END028IN"]:
                            if 4.5 <= self.data["CO02NUM002TO"]:
                                self.node_daqu3 = 83
                            else:
                                self.node_daqu3 = 82
                        else:
                            self.node_daqu3 = 40
                else:
                    if 0 <= self.data["COQ1END010HP"] < 56069:
                        self.node_daqu3 = 22
                    else:
                        if 2.5 <= self.data["CO02NUM002TO"]:
                            if 3.5 <= self.data["CO00DEM026"]:
                                self.node_daqu3 = 169
                            else:
                                if 0 <= self.data["CO01END007RO"] < 1.745:
                                    self.node_daqu3 = 170
                                else:
                                    if 13.53 <= self.data["CO01END007RO"]:
                                        self.node_daqu3 = 173
                                    else:
                                        if 0 <= self.data["COQ1END001TO"] < 697.5:
                                            if 0 <= self.data["CO01ACP007RO"] < 5.5:
                                                if 0 <= self.q3_prexposicionve < 0.21225:
                                                    if 0 <= self.data["CO01END007RO"] < 3.36:
                                                        self.node_daqu3 = 186
                                                    else:
                                                        self.node_daqu3 = 187
                                                else:
                                                    self.node_daqu3 = 182
                                            else:
                                                self.node_daqu3 = 180
                                        else:
                                            if 0.815 <= self.q3_cuotatotal:
                                                self.node_daqu3 = 189
                                            else:
                                                if 0 <= self.data["CO01END007RO"] < 3.625:
                                                    self.node_daqu3 = 190
                                                else:
                                                    self.node_daqu3 = 191
                        else:
                            if 0 <= self.data["COQ1END001TO"] < 309.165:

                                self.node_daqu3 = 92
                            else:
                                self.node_daqu3 = 93
            else:
                if 8.485 <= self.data["CO01END007RO"]:
                    self.node_daqu3 = 9
                else:
                    if 0 <= self.q3_cuotatotal < 0.475:
                        if 0 <= self.data["CO01END028IN"] < 0.235:
                            self.node_daqu3 = 195
                        else:
                            if 0 <= self.data["CO02NUM002TO"] < 1.5:

                                self.node_daqu3 = 197
                            else:
                                if 2.805 <= self.data["CO01END026IN"]:
                                    self.node_daqu3 = 218
                                else:
                                    if 0 <= self.data["CO02END002HP"] < 1.75:

                                        self.node_daqu3 = 225
                                    else:
                                        if 0 <= self.data["COQ1END001TO"] < 841.67:

                                            self.node_daqu3 = 230
                                        else:
                                            self.node_daqu3 = 231
                    else:
                        if 0.525 <= self.data["CO01END028IN"]:
                            self.node_daqu3 = 35
                        else:
                            if 0 <= self.data["COQ1END001TO"] < 794.17:
                                if self.data["COQ1END010HP"] >= 0:
                                    self.node_daqu3 = 267
                                else:
                                    if self.data["CO01ACP007RO"] >= 0:
                                        if 0 <= self.data["CO01END028IN"] < 0.315:

                                            self.node_daqu3 = 299
                                        else:
                                            if 2.295 <= self.data["CO01END026RO"]:
                                                self.node_daqu3 = 302
                                            else:
                                                if 0 <= self.data["CO01END007IN"] < 14.61:

                                                    self.node_daqu3 = 309
                                                else:
                                                    if 38.5 <= self.data["CO00DEM003"]:
                                                        self.node_daqu3 = 315
                                                    else:
                                                        self.node_daqu3 = 314
                                    else:
                                        if 0 <= self.data["COQ1END001TO"] < 32.5:

                                            self.node_daqu3 = 283
                                        else:
                                            if 0 <= self.data["CO01END028IN"] < 0.295:

                                                self.node_daqu3 = 294
                                            else:
                                                self.node_daqu3 = 295
                            else:
                                if 2.5 <= self.data["CO02NUM002TO"]:
                                    if 0 <= self.data["CO00DEM003"] < 36.5:
                                        if 0 <= self.data["CO00DEM026"] < 0.5:

                                            self.node_daqu3 = 344
                                        else:
                                            if 3.5 <= self.data["CO02NUM002TO"]:
                                                self.node_daqu3 = 353
                                            else:
                                                self.node_daqu3 = 352
                                    else:
                                        if 0 <= self.q3_cuotatotal < 0.605:

                                            self.node_daqu3 = 354
                                        else:
                                            self.node_daqu3 = 355
                                else:
                                    self.node_daqu3 = 325

    def tec_nodo_2(self):
        if 5.67 <= self.data["CO01END007RO"] < 16.315:
            if 0 <= self.data["CO01END007IN"] < 19.415:
                if 0 <= self.data["COQ1END001TO"] < 671.665:
                    self.node_daqu3 = 23
                elif 671.665 <= self.data["COQ1END001TO"] < 4173.33:
                    if 0.375 <= self.data["CO01END028IN"] < 0.775:
                        self.node_daqu3 = 72
                    elif 0.775 <= self.data["CO01END028IN"]:
                        self.node_daqu3 = 73
                    else:
                        if 0 <= self.data["CO01END026IN"] < 7.635:
                            self.node_daqu3 = 664
                        else:
                            self.node_daqu3 = 665
                else:
                    if 0 <= self.data["CO01END028IN"] < 0.46:
                        self.node_daqu3 = 74
                    elif 1.295 <= self.data["CO01END028IN"]:
                        self.node_daqu3 = 76
                    else:
                        self.node_daqu3 = 75
            elif 35.32 <= self.data["CO01END007IN"]:
                if 0 <= self.data["CO01END028IN"] < 0.545:
                    self.node_daqu3 = 729
                else:
                    self.node_daqu3 = 730
            else:
                if 0 <= self.data["COQ1END001TO"] < 938.335:
                    if 0 <= self.data["CO00DEM026"] < 1.5:
                        self.node_daqu3 = 77
                    elif 3.5 <= self.data["CO00DEM026"]:
                        if 0 <= self.data["CO01END007RO"] < 6.51:

                            self.node_daqu3 = 677
                        else:
                            self.node_daqu3 = 678
                    else:
                        if 0.555 <= self.data["CO01END028RO"] < 1.21:
                            self.node_daqu3 = 217
                        elif 1.21 <= self.data["CO01END028RO"]:
                            self.node_daqu3 = 218
                        else:
                            if 0 <= self.data["CO01END005RO"] < 0.145:

                                self.node_daqu3 = 509
                            elif 0.895 <= self.data["CO01END005RO"]:
                                self.node_daqu3 = 511
                            else:
                                self.node_daqu3 = 510
                elif 8615 <= self.data["COQ1END001TO"]:
                    self.node_daqu3 = 28
                else:
                    if 0 <= self.data["CO01END090HP"] < 3.6:
                        self.node_daqu3 = 80
                    elif 3.6 <= self.data["CO01END090HP"] < 30.89:
                        self.node_daqu3 = 81
                    else:
                        if 0 <= self.data["CO01END005RO"] < 1.565:

                            self.node_daqu3 = 228
                        elif 4.55 <= self.data["CO01END005RO"]:
                            self.node_daqu3 = 230
                        else:
                            if 3371.67 <= self.data["COQ1END001TO"]:
                                self.node_daqu3 = 683
                            else:
                                self.node_daqu3 = 682
        elif 16.315 <= self.data["CO01END007RO"]:
            if 0 <= self.data["CO01END007RO"] < 19.285:
                if 0 <= self.data["CO01END007IN"] < 8.945:
                    self.node_daqu3 = 32
                elif 85.74 <= self.data["CO01END007IN"]:
                    self.node_daqu3 = 34
                else:
                    self.node_daqu3 = 33
            elif 93.37 <= self.data["CO01END007RO"]:
                self.node_daqu3 = 13
            else:
                if 10.66 <= self.data["CO01END005RO"]:
                    self.node_daqu3 = 696
                else:
                    if 0 <= self.data["COQ1END001TO"] < 2.5:
                        self.node_daqu3 = 697
                    elif 9960.835 <= self.data["COQ1END001TO"]:
                        self.node_daqu3 = 699
                    else:
                        if 0 <= self.data["CO01END028IN"] < 0.355:

                            self.node_daqu3 = 700
                        elif 2.005 <= self.data["CO01END028IN"]:
                            self.node_daqu3 = 702
                        else:
                            if 0 <= self.data["CO01END007RO"] < 22.405:
                                self.node_daqu3 = 707
                            else:
                                if 118.3 <= self.data["CO01END007IN"]:
                                    self.node_daqu3 = 714
                                else:
                                    if 1.045 <= self.data["CO01END026RO"] < 11.07:
                                        if 7.615 <= self.q3_cuotatotal:
                                            self.node_daqu3 = 723
                                        else:
                                            self.node_daqu3 = 722

                                    elif 11.07 <= self.data["CO01END026RO"]:
                                        self.node_daqu3 = 717
                                    else:
                                        self.node_daqu3 = 715
        else:
            if 0 <= self.data["CO01END007IN"] < 12.815:
                if 0 <= self.data["CO01END028IN"] < 0.355:
                    if 0 <= self.data["COQ1END001TO"] < 537.5:
                        if 0 <= self.data["CO01EXP001HP"] < 204:
                            self.node_daqu3 = 764
                        else:
                            self.node_daqu3 = 765

                    elif 2131.67 <= self.data["COQ1END001TO"]:
                        self.node_daqu3 = 43
                    else:
                        if 36712.5 <= self.data["COQ1END010HP"]:
                            self.node_daqu3 = 835
                        else:
                            self.node_daqu3 = 834
                elif 0.355 <= self.data["CO01END028IN"] < 5.585:
                    if 0 <= self.data["CO01EXP001HP"] < 110.5:
                        self.node_daqu3 = 802
                    else:
                        if 0 <= self.data["COQ1END001TO"] < 954.995:

                            self.node_daqu3 = 824
                        else:
                            self.node_daqu3 = 825
                else:
                    self.node_daqu3 = 16
            elif 28.285 <= self.data["CO01END007IN"]:
                if 58.145 <= self.data["CO01END007IN"] < 404.935:
                    self.node_daqu3 = 21
                elif 404.935 <= self.data["CO01END007IN"]:
                    self.node_daqu3 = 22
                else:
                    if 0.37045 <= self.q3_prexposicionve < 0.4951:
                        self.node_daqu3 = 60
                    elif 0.4951 <= self.q3_prexposicionve:
                        self.node_daqu3 = 61
                    else:
                        self.node_daqu3 = 59
            else:
                if 0 <= self.data["COQ1END001TO"] < 1229.165:
                    if 0 <= self.data["CO01EXP001HP"] < 48.5:
                        if 3.85 <= self.data["CO02END002HP"] < 5.955:
                            self.node_daqu3 = 143
                        elif 5.955 <= self.data["CO02END002HP"]:
                            self.node_daqu3 = 144
                        else:
                            self.node_daqu3 = 142
                    elif 162.5 <= self.data["CO01EXP001HP"]:
                        if 0 <= self.q3_cuotatotal < 1.055:

                            self.node_daqu3 = 148
                        elif 1.055 <= self.q3_cuotatotal < 1.855:
                            self.node_daqu3 = 149
                        else:
                            self.node_daqu3 = 150
                    else:
                        if 0 <= self.data["CO01END028IN"] < 0.345:

                            self.node_daqu3 = 145
                        elif 0.625 <= self.data["CO01END028IN"]:
                            if 4.335 <= self.data["CO01END007RO"]:
                                self.node_daqu3 = 649
                            else:
                                self.node_daqu3 = 648
                        else:
                            if 0 <= self.data["CO01END007RO"] < 1.83:

                                self.node_daqu3 = 373
                            elif 1.83 <= self.data["CO01END007RO"] < 2:
                                self.node_daqu3 = 374
                            else:
                                if 0 <= self.data["CO02NUM002TO"] < 3.5:
                                    if 0 <= self.data["CO01END028RO"] < 0.085:
                                        self.node_daqu3 = 738
                                    else:
                                        if 0.44 <= self.data["CO01END028RO"]:
                                            self.node_daqu3 = 755
                                        else:
                                            self.node_daqu3 = 754
                                elif 6.5 <= self.data["CO02NUM002TO"]:
                                    self.node_daqu3 = 733
                                else:
                                    if 0.3817 <= self.q3_prexposicionve:
                                        self.node_daqu3 = 745
                                    else:
                                        self.node_daqu3 = 744
                elif 1229.165 <= self.data["COQ1END001TO"] < 2555.835:
                    if 0 <= self.q3_prexposicionve < 0.26705:
                        if 0 <= self.data["CO01END028HP"] < 1.465:
                            self.node_daqu3 = 151
                        elif 1.745 <= self.data["CO01END028HP"]:
                            self.node_daqu3 = 153
                        else:
                            if 0.695 <= self.data["CO01END005RO"]:
                                self.node_daqu3 = 653
                            else:
                                self.node_daqu3 = 652
                    elif 0.91185 <= self.q3_prexposicionve:
                        self.node_daqu3 = 55
                    else:
                        self.node_daqu3 = 54
                else:
                    if 0 <= self.q3_prexposicionve < 0.17135:
                        if 2.5 <= self.data["CO00DEM026"] < 3.5:
                            self.node_daqu3 = 161
                        elif 3.5 <= self.data["CO00DEM026"]:
                            self.node_daqu3 = 162
                        else:
                            if 162315 <= self.data["COQ1END010HP"] < 268701.5:
                                self.node_daqu3 = 410
                            elif 268701.5 <= self.data["COQ1END010HP"]:
                                self.node_daqu3 = 411
                            else:
                                self.node_daqu3 = 409
                    elif 0.17135 <= self.q3_prexposicionve < 0.3741:
                        self.node_daqu3 = 57
                    else:
                        if 0 <= self.q3_cuotatotal < 2.8:
                            self.node_daqu3 = 166
                        elif 2.8 <= self.q3_cuotatotal < 4.19:
                            self.node_daqu3 = 167
                        else:
                            self.node_daqu3 = 168

    def tec_nodo_3(self):
        if 18.615 <= self.data["CO01END007RO"]:
            if 0 <= self.data["COQ1END001TO"] < 1384.165:
                if 10.5 <= self.data["CO02NUM002TO"]:
                    if 0 <= self.data["CO01END028IN"] < 0.665:
                        self.node_daqu3 = 26
                    else:
                        self.node_daqu3 = 27
                else:
                    if 44.255 <= self.data["CO01END007RO"]:
                        self.node_daqu3 = 25
                    else:
                        if 0.695 <= self.data["CO01END028IN"]:
                            self.node_daqu3 = 49
                        else:
                            self.node_daqu3 = 48
            else:
                if 200.94 <= self.data["CO01END007RO"]:
                    self.node_daqu3 = 15
                else:
                    if 1.595 <= self.q3_cuotatotal:
                        if 260.785 <= self.data["CO01END007IN"]:
                            self.node_daqu3 = 199
                        else:
                            if 0 <= self.q3_cuotatotal < 2.235:
                                self.node_daqu3 = 200
                            else:
                                if 2.685 <= self.data["CO01END028HP"]:
                                    self.node_daqu3 = 203
                                else:
                                    if 0 <= self.data["CO02END009HP"] < 1.565:
                                        self.node_daqu3 = 204
                                    else:
                                        if 24.795 <= self.q3_cuotatotal:
                                            self.node_daqu3 = 207
                                        else:
                                            if 1397.5 <= self.data["COQ1END001TO"]:
                                                if 0 <= self.data["CO00DEM026"] < 4.5:
                                                    self.node_daqu3 = 210
                                                else:
                                                    self.node_daqu3 = 211
                                            else:
                                                self.node_daqu3 = 208
                    else:
                        self.node_daqu3 = 28
        else:
            if 53.365 <= self.data["CO01END007IN"]:
                if 0 <= self.data["COQ1END001TO"] < 1918.33:
                    self.node_daqu3 = 10
                else:
                    if 87.975 <= self.data["CO01END007IN"]:
                        self.node_daqu3 = 23
                    else:
                        if 0.0794 <= self.q3_prexposicionve:
                            self.node_daqu3 = 45
                        else:
                            self.node_daqu3 = 999
            else:
                if 0 <= self.data["COQ1END001TO"] < 861.665:
                    if 8.5 <= self.data["CO02NUM002TO"]:
                        if 0 <= self.data["CO01END028IN"] < 0.525:

                            self.node_daqu3 = 34
                        else:
                            self.node_daqu3 = 35
                    else:
                        if 0 <= self.data["CO02END009HP"] < 0.965:
                            self.node_daqu3 = 135
                        else:
                            if 4.5 <= self.data["CO00DEM026"]:
                                self.node_daqu3 = 138
                            else:
                                if 1.085 <= self.data["CO01END028IN"]:
                                    self.node_daqu3 = 140
                                else:
                                    self.node_daqu3 = 139
                else:
                    if 0.1237 <= self.q3_prexposicionve:
                        if 0 <= self.data["COQ1END001TO"] < 3042.505:
                            if 0 <= self.data["CO01END007RO"] < 8.6:
                                self.node_daqu3 = 193
                            else:
                                self.node_daqu3 = 194
                        else:
                            if 0 <= self.data["CO01END007IN"] < 29.685:
                                self.node_daqu3 = 78
                            else:
                                if 0.99 <= self.data["CO01END028RO"]:
                                    self.node_daqu3 = 192
                                else:
                                    self.node_daqu3 = 191
                    else:
                        if 0 <= self.data["CO01END007IN"] < 13.24:
                            if 6.085 <= self.data["CO01END007RO"]:
                                if 0 <= self.data["CO01END028IN"] < 0.395:
                                    self.node_daqu3 = 165
                                else:
                                    self.node_daqu3 = 166
                            else:
                                if 62.16 <= self.data["CO01END026HP"]:
                                    self.node_daqu3 = 160
                                else:
                                    self.node_daqu3 = 159
                        else:
                            if 0 <= self.data["COQ1END001TO"] < 2488.33:
                                if 0 <= self.data["COQ1EXP001HP"] < 36.5:
                                    self.node_daqu3 = 141
                                else:
                                    if 10.685 <= self.data["CO01END007RO"]:
                                        if 49.5 <= self.data["CO00DEM003"]:
                                            self.node_daqu3 = 152
                                        else:
                                            self.node_daqu3 = 151
                                    else:
                                        if 0 <= self.data["CO01END028IN"] < 0.435:
                                            self.node_daqu3 = 145
                                        else:
                                            if 0 <= self.data["CO00DEM003"] < 31.5:
                                                self.node_daqu3 = 147
                                            else:
                                                if 0.735 <= self.data["CO01END028IN"]:
                                                    self.node_daqu3 = 150
                                                else:
                                                    self.node_daqu3 = 149
                            else:
                                if 6.76 <= self.q3_cuotatotal:
                                    self.node_daqu3 = 154
                                else:
                                    if 3.5 <= self.data["CO00DEM026"]:
                                        self.node_daqu3 = 156
                                    else:
                                        if 11393.33 <= self.data["COQ1END001TO"]:
                                            self.node_daqu3 = 180
                                        else:
                                            if 10.5 <= self.data["CO02NUM002TO"]:
                                                self.node_daqu3 = 182
                                            else:
                                                if 0 <= self.data["COQ1END010HP"] < 188376:
                                                    self.node_daqu3 = 183
                                                else:
                                                    if 12.32 <= self.data["CO01END007RO"]:
                                                        self.node_daqu3 = 186
                                                    else:
                                                        self.node_daqu3 = 185

    def tec_nodo_4(self):
        if 4.275 <= self.q3_cuotatotal:
            if 26.3 <= self.data["CO01END007RO"]:
                if 0 <= self.q3_cuotatotal < 4.465:
                    if 0 <= self.data["CO01END007RO"] < 36.92:
                        self.node_daqu3 = 28
                    else:
                        if 0.585 <= self.data["CO01END028IN"]:
                            self.node_daqu3 = 59
                        else:
                            self.node_daqu3 = 58
                else:
                    if 0 <= self.data["CO01END005RO"] < 21.955:
                        if 1462377.5 <= self.data["COQ1END010HP"]:
                            self.node_daqu3 = 168
                        else:
                            if 0 <= self.data["CO02END009HP"] < 1.245:

                                self.node_daqu3 = 172
                            else:
                                if 5.39 <= self.data["CO01END028HP"]:
                                    self.node_daqu3 = 175
                                else:
                                    if 0 <= self.q3_cuotatotal < 4.645:

                                        self.node_daqu3 = 176
                                    else:
                                        self.node_daqu3 = 177
                    else:
                        self.node_daqu3 = 166
            else:
                if 0 <= self.data["CO01END007IN"] < 58.125:
                    if 0.2087 <= self.q3_prexposicionve:
                        if 0 <= self.data["CO02END009HP"] < 1.41:
                            self.node_daqu3 = 50
                        else:
                            if 0.82 <= self.data["CO01END005RO"]:
                                self.node_daqu3 = 103
                            else:
                                self.node_daqu3 = 102
                    else:
                        if 15.025 <= self.data["CO01END007RO"]:
                            self.node_daqu3 = 49
                        else:
                            self.node_daqu3 = 48
                else:
                    if 113.48 <= self.data["CO01END007IN"]:
                        if 3.76 <= self.data["CO02END002HP"]:
                            self.node_daqu3 = 164
                        else:
                            self.node_daqu3 = 163
                    else:
                        if 0 <= self.data["CO01END028IN"] < 9.92:

                            self.node_daqu3 = 161
                        else:
                            self.node_daqu3 = 162
        else:
            if 16.485 <= self.data["CO01END007RO"]:
                if 0 <= self.data["COQ1END001TO"] < 3477.5:
                    if 0 <= self.data["CO01END028IN"] < 0.615:
                        if 108.225 <= self.data["CO01END007RO"]:
                            self.node_daqu3 = 41
                        else:
                            if 0.425 <= self.data["CO01END028RO"]:
                                self.node_daqu3 = 81
                            else:
                                if 0 <= self.data["CO01END007IN"] < 12.44:
                                    if 1766.675 <= self.data["COQ1END001TO"]:
                                        self.node_daqu3 = 144
                                    else:
                                        self.node_daqu3 = 143
                                else:
                                    if 52.78 <= self.data["CO01END007IN"]:
                                        self.node_daqu3 = 146
                                    else:
                                        if 0 <= self.data["CO01END026IN"] < 4.785:

                                            self.node_daqu3 = 147
                                        else:
                                            self.node_daqu3 = 148
                    else:
                        if 45.115 <= self.data["CO01END007RO"]:
                            self.node_daqu3 = 43
                        else:
                            if 77.09 <= self.data["CO01END007IN"]:
                                self.node_daqu3 = 151
                            else:
                                if 0 <= self.data["CO02END002HP"] < 2.115:
                                    self.node_daqu3 = 152
                                else:
                                    if 0 <= self.data["CO02END002HP"] < 5.525:
                                        self.node_daqu3 = 154
                                    else:
                                        self.node_daqu3 = 155
                else:
                    if 0 <= self.data["CO01END007IN"] < 50.445:
                        if 40.83 <= self.data["CO01END007RO"]:
                            self.node_daqu3 = 45
                        else:
                            if 0 <= self.data["CO01ACP017HP"] < 43.5:
                                self.node_daqu3 = 156
                            else:
                                self.node_daqu3 = 157
                    else:
                        if 0 <= self.data["COQ1END010HP"] < 212167:
                            if 0 <= self.data["CO01END028RO"] < 0.225:
                                self.node_daqu3 = 92
                            else:
                                self.node_daqu3 = 93
                        else:
                            if 7381.67 <= self.data["COQ1END001TO"]:
                                self.node_daqu3 = 95
                            else:
                                self.node_daqu3 = 94
            else:
                if 6104.175 <= self.data["COQ1END001TO"]:
                    if 0 <= self.data["CO01END026IN"] < 12.34:
                        if 8.565 <= self.data["CO01END007IN"]:
                            self.node_daqu3 = 37
                        else:
                            self.node_daqu3 = 36
                    else:
                        if 1.125 <= self.data["CO01END028IN"]:
                            self.node_daqu3 = 39
                        else:
                            if 0.58685 <= self.q3_prexposicionhp:
                                self.node_daqu3 = 77
                            else:
                                self.node_daqu3 = 76
                else:
                    if 64.59 <= self.data["CO01END007IN"]:
                        self.node_daqu3 = 17
                    else:
                        if 13.5 <= self.data["CO02NUM002TO"]:
                            self.node_daqu3 = 33
                        else:
                            if 0.85645 <= self.q3_prexposicionve:
                                self.node_daqu3 = 129
                            else:
                                self.node_daqu3 = 128

    def poblacion_tipo_5(self):
        if 0 <= self.data["CO00DEM006"] < 0.5:
            if 21.5 <= self.data["CO00DEM003"] < 60.5:
                if 0 <= self.q3_ahorr_ct < 0.5:
                    if 0 <= self.data["CO01ACP007AH"] < 1.5:
                        self.node_daqu3 = 44
                    elif 2.5 <= self.data["CO01ACP007AH"]:
                        self.node_daqu3 = 46
                    else:
                        if 0 <= self.data["CO00DEM003"] < 22.5:
                            self.node_daqu3 = 121
                        elif 41.5 <= self.data["CO00DEM003"]:
                            self.node_daqu3 = 123
                        else:
                            if 0 <= self.data["CO00DEM003"] < 23.5:
                                self.node_daqu3 = 313
                            elif 23.5 <= self.data["CO00DEM003"] < 24.5:
                                self.node_daqu3 = 314
                            else:
                                self.node_daqu3 = 315
                else:
                    if 0 <= self.data["CO02EXP001TO"] < 2.5:
                        if 40.5 <= self.data["CO00DEM003"] < 48.5:
                            self.node_daqu3 = 125
                        elif 48.5 <= self.data["CO00DEM003"]:
                            self.node_daqu3 = 126
                        else:
                            self.node_daqu3 = 124
                    elif 140.5 <= self.data["CO02EXP001TO"]:
                        self.node_daqu3 = 49
                    else:
                        if 0 <= self.data["CO01ACP007AH"] < 0.5:
                            self.node_daqu3 = 127
                        elif 0.5 <= self.data["CO01ACP007AH"] < 1.5:
                            self.node_daqu3 = 128
                        else:
                            if 0 <= self.data["CO02NUM004TO"] < 0.5:
                                self.node_daqu3 = 333
                            elif 0.5 <= self.data["CO02NUM004TO"] < 2.5:
                                self.node_daqu3 = 334
                            else:
                                self.node_daqu3 = 335
            elif 60.5 <= self.data["CO00DEM003"]:
                if 70.5 <= self.data["CO00DEM003"] < 73.5:
                    self.node_daqu3 = 19
                elif 73.5 <= self.data["CO00DEM003"]:
                    self.node_daqu3 = 20
                else:
                    self.node_daqu3 = 18
            else:
                if 0.5 <= self.q3_extranjeria:
                    self.node_daqu3 = 15
                else:
                    if 0.5 <= self.data["CO02EXP001TO"]:
                        self.node_daqu3 = 672
                    else:
                        self.node_daqu3 = 671
        elif 0.5 <= self.data["CO00DEM006"]:
            if 0 <= self.data["CO02EXP001TO"] < 0.5:
                if 0 <= self.data["CO01ACP007AH"] < 1.5:
                    if 48.5 <= self.data["CO00DEM003"]:
                        self.node_daqu3 = 679
                    else:
                        self.node_daqu3 = 678
                elif 1.5 <= self.data["CO01ACP007AH"]:
                    self.node_daqu3 = 22
                else:
                    if 0 <= self.data["CO00DEM003"] < 25.5:
                        if 0 <= self.data["CO00DEM003"] < 22.5:
                            self.node_daqu3 = 167
                        elif 22.5 <= self.data["CO00DEM003"] < 24.5:
                            self.node_daqu3 = 168
                        else:
                            self.node_daqu3 = 169

                    elif 25.5 <= self.data["CO00DEM003"] < 32.5:
                        self.node_daqu3 = 66
                    else:
                        self.node_daqu3 = 67
            elif 0.5 <= self.data["CO02EXP001TO"] < 27.5:
                if 0 <= self.data["CO01ACP007AH"] < 1.5:
                    if 0 <= self.data["CO02NUM004TO"] < 0.5:
                        if 0 <= self.data["CO00DEM003"] < 22.5:
                            self.node_daqu3 = 174
                        elif 35.5 <= self.data["CO00DEM003"]:
                            self.node_daqu3 = 176
                        else:
                            self.node_daqu3 = 175

                    elif 0.5 <= self.data["CO02NUM004TO"]:
                        self.node_daqu3 = 69
                    else:
                        self.node_daqu3 = 70
                elif 1.5 <= self.data["CO01ACP007AH"] < 3.5:
                    if 0 <= self.data["CO02NUM004TO"] < 0.5:
                        self.node_daqu3 = 71
                    elif 0.5 <= self.data["CO02NUM004TO"]:
                        self.node_daqu3 = 72
                    else:
                        self.node_daqu3 = 73
                else:
                    self.node_daqu3 = 26
            else:
                if 0 <= self.data["CO02EXP001TO"] < 40.5:
                    if 36.5 <= self.data["CO02EXP001TO"] < 39.5:
                        self.node_daqu3 = 77
                    elif 39.5 <= self.data["CO02EXP001TO"]:
                        self.node_daqu3 = 78
                    else:
                        self.node_daqu3 = 76
                elif 114.5 <= self.data["CO02EXP001TO"]:
                    if 0 <= self.data["CO00DEM003"] < 30.5:
                        self.node_daqu3 = 82
                    elif 53.5 <= self.data["CO00DEM003"]:
                        if 0 <= self.data["CO02NUM002TO"] < 0.5:
                            self.node_daqu3 = 222
                        elif 1.5 <= self.data["CO02NUM002TO"]:
                            self.node_daqu3 = 224
                        else:
                            self.node_daqu3 = 223
                    else:
                        if 0 <= self.data["CO02NUM004TO"] < 0.5:

                            self.node_daqu3 = 219
                        elif 0.5 <= self.data["CO02NUM004TO"]:
                            self.node_daqu3 = 220
                        else:
                            self.node_daqu3 = 221
                else:
                    if 0 <= self.data["CO00DEM003"] < 25.5:
                        self.node_daqu3 = 79
                    elif 25.5 <= self.data["CO00DEM003"] < 31.5:
                        if 0 <= self.data["CO02NUM004TO"] < 0.5:

                            self.node_daqu3 = 210
                        elif 0.5 <= self.data["CO02NUM004TO"] < 1.5:
                            if 0 <= self.data["CO02NUM002TO"] < 1.5:
                                self.node_daqu3 = 694
                            else:
                                self.node_daqu3 = 695
                        else:
                            if 0 <= self.data["CO02NUM002TO"] < 0.5:
                                self.node_daqu3 = 697
                            else:
                                self.node_daqu3 = 698
                    else:
                        if 39.5 <= self.data["CO00DEM003"] < 56.5:
                            self.node_daqu3 = 214
                        elif 56.5 <= self.data["CO00DEM003"]:
                            self.node_daqu3 = 215
                        else:
                            self.node_daqu3 = 213
        else:
            if 0 <= self.data["CO02EXP001TO"] < 0.5:
                if 23.5 <= self.data["CO00DEM003"] < 24.5:
                    self.node_daqu3 = 31
                elif 24.5 <= self.data["CO00DEM003"]:
                    self.node_daqu3 = 32
                else:
                    self.node_daqu3 = 30
            elif 0.5 <= self.data["CO02EXP001TO"] < 18.5:
                self.node_daqu3 = 12
            else:
                if 0.5 <= self.data["CO01ACP007AH"] < 1.5:
                    self.node_daqu3 = 36
                elif 1.5 <= self.data["CO01ACP007AH"]:
                    if 35.5 <= self.data["CO02EXP001TO"]:
                        if 43.5 <= self.data["CO02EXP001TO"] < 47.5:
                            self.node_daqu3 = 716
                        elif 47.5 <= self.data["CO02EXP001TO"]:
                            self.node_daqu3 = 717
                        else:
                            self.node_daqu3 = 715
                    else:
                        if 0 <= self.data["CO02EXP001TO"] < 23.5:
                            self.node_daqu3 = 712
                        elif 23.5 <= self.data["CO02EXP001TO"] < 26.5:
                            self.node_daqu3 = 713
                        else:
                            self.node_daqu3 = 714
                else:
                    self.node_daqu3 = 35

    def calcular_grupos_daqu3(self):
        """
        Obtain the evaluated individual group. ( "TEC", "NOTEC", "TIPO5")

        :return: None type Object. It loads results on self variables of the
        Quanto 3 Base Instance.
        """
        self.grupo_daqu3 = -1.0
        if self.poblacion_daqu3 == "NOTEC":
            if self.nodo_daqu3 == 1:
                if self.node_daqu3 in self.ESNODO01:
                    self.grupo_daqu3 = 1.0
                if self.node_daqu3 in self.ESNODO02:
                    self.grupo_daqu3 = 2.0
                if self.node_daqu3 in self.ESNODO03:
                    self.grupo_daqu3 = 3.0
                if self.node_daqu3 in self.ESNODO04:
                    self.grupo_daqu3 = 4.0

            elif self.nodo_daqu3 == 2:
                if self.node_daqu3 in self.ESNODO05:
                    self.grupo_daqu3 = 1.0
                if self.node_daqu3 in self.ESNODO06:
                    self.grupo_daqu3 = 2.0
                if self.node_daqu3 in self.ESNODO07:
                    self.grupo_daqu3 = 3.0
                if self.node_daqu3 in self.ESNODO08:
                    self.grupo_daqu3 = 4.0

            elif self.nodo_daqu3 == 3:
                if self.node_daqu3 in self.ESNODO09:
                    self.grupo_daqu3 = 1.0
                if self.node_daqu3 in self.ESNODO10:
                    self.grupo_daqu3 = 2.0
                if self.node_daqu3 in self.ESNODO11:
                    self.grupo_daqu3 = 3.0
                if self.node_daqu3 in self.ESNODO12:
                    self.grupo_daqu3 = 4.0
                if self.node_daqu3 in self.ESNODO13:
                    self.grupo_daqu3 = 5.0

            elif self.nodo_daqu3 == 4:
                if self.node_daqu3 in self.ESNODO14:
                    self.grupo_daqu3 = 1.0
                if self.node_daqu3 in self.ESNODO15:
                    self.grupo_daqu3 = 2.0
                if self.node_daqu3 in self.ESNODO16:
                    self.grupo_daqu3 = 3.0
                if self.node_daqu3 in self.ESNODO17:
                    self.grupo_daqu3 = 4.0
                if self.node_daqu3 in self.ESNODO18:
                    self.grupo_daqu3 = 5.0

            elif self.nodo_daqu3 == 5:
                if self.node_daqu3 in self.ESNODO19:
                    self.grupo_daqu3 = 1.0
                if self.node_daqu3 in self.ESNODO20:
                    self.grupo_daqu3 = 2.0
                if self.node_daqu3 in self.ESNODO21:
                    self.grupo_daqu3 = 3.0
                if self.node_daqu3 in self.ESNODO22:
                    self.grupo_daqu3 = 4.0
                if self.node_daqu3 in self.ESNODO23:
                    self.grupo_daqu3 = 5.0
                if self.node_daqu3 in self.ESNODO24:
                    self.grupo_daqu3 = 6.0
                if self.node_daqu3 in self.ESNODO25:
                    self.grupo_daqu3 = 7.0
                if self.node_daqu3 in self.ESNODO26:
                    self.grupo_daqu3 = 8.0

                if self.grupo_daqu3 in (1, 2):
                    self.grupo_daqu3 = 1.0
                elif self.grupo_daqu3 == 3:
                    self.grupo_daqu3 = 2.0
                elif self.grupo_daqu3 == 4:
                    self.grupo_daqu3 = 3.0
                elif self.grupo_daqu3 in (5, 6):
                    self.grupo_daqu3 = 4.0
                elif self.grupo_daqu3 == 7:
                    self.grupo_daqu3 = 5.0
                elif self.grupo_daqu3 == 8:
                    self.grupo_daqu3 = 6.0

        if self.poblacion_daqu3 == "TEC":
            if self.nodo_daqu3 == 1:
                if self.node_daqu3 in self.ESNODO27:
                    self.grupo_daqu3 = 1.0
                if self.node_daqu3 in self.ESNODO28:
                    self.grupo_daqu3 = 2.0
                if self.node_daqu3 in self.ESNODO29:
                    self.grupo_daqu3 = 3.0
                if self.node_daqu3 in self.ESNODO30:
                    self.grupo_daqu3 = 4.0

            if self.nodo_daqu3 == 2:
                if self.node_daqu3 in self.ESNODO31:
                    self.grupo_daqu3 = 1.0
                if self.node_daqu3 in self.ESNODO32:
                    self.grupo_daqu3 = 2.0
                if self.node_daqu3 in self.ESNODO33:
                    self.grupo_daqu3 = 3.0

            if self.nodo_daqu3 == 3:
                if self.node_daqu3 in self.ESNODO34:
                    self.grupo_daqu3 = 1.0
                if self.node_daqu3 in self.ESNODO35:
                    self.grupo_daqu3 = 2.0
                if self.node_daqu3 in self.ESNODO36:
                    self.grupo_daqu3 = 3.0

            if self.nodo_daqu3 == 4:
                if self.node_daqu3 in self.ESNODO37:
                    self.grupo_daqu3 = 1.0
                if self.node_daqu3 in self.ESNODO38:
                    self.grupo_daqu3 = 2.0
                if self.node_daqu3 in self.ESNODO39:
                    self.grupo_daqu3 = 3.0

        if self.poblacion_daqu3 == "TIPO5":
            if self.nodo_daqu3 == 0:
                if self.node_daqu3 in self.ESNODO40:
                    self.grupo_daqu3 = 1.0
                if self.node_daqu3 in self.ESNODO41:
                    self.grupo_daqu3 = 2.0
                if self.node_daqu3 in self.ESNODO42:
                    self.grupo_daqu3 = 3.0
                if self.node_daqu3 in self.ESNODO43:
                    self.grupo_daqu3 = 4.0

    def cuotatotal_daqu3(self):
        """
        Computes the set of quota based hybrid characteristics.

        Attributes:

        ""CO01END005XX" : Total up to date products quota of the XX portfolio.

        :return: None type Object. It loads results on self variables of the
        Quanto 3 Base Instance.
        """
        CO01END005ROV = self.data["CO01END005RO"] * (not self.data["CO01END005RO"] < 0)
        CO01END005INV = self.data["CO01END005IN"] * (not self.data["CO01END005IN"] < 0)
        CO01END005VEV = self.data["CO01END005VE"] * (not self.data["CO01END005VE"] < 0)
        CO01END005HPV = self.data["CO01END005HP"] * (not self.data["CO01END005HP"] < 0)
        CO01END005OTV = self.data["CO01END005OT"] * (not self.data["CO01END005OT"] < 0)

        if CO01END005ROV or CO01END005INV or CO01END005VEV or CO01END005HPV or CO01END005OTV:
            self.q3_cuotatotal = CO01END005ROV + CO01END005INV + CO01END005VEV + CO01END005HPV + CO01END005OTV
            if self.q3_cuotatotal > 0:
                self.q3_prcuotatotalro = round(CO01END005ROV / self.q3_cuotatotal, 4)  # Check cobol ROUND
            else:
                self.q3_prcuotatotalro = -1.0
        else:
            self.q3_cuotatotal = -1.0
            self.q3_prcuotatotalro = -1.0

    def exposicion_daqu3(self):
        """
        Obtains Exposition Computations.

        Attributes:

        "CO01END007RO" : Total up to date products quota.
        "CO01END001XX" : Total up to date products balance of the XX portfolio.

        :return: None type Object. It loads results on self variables of the
        Quanto 3 Base Instance.
        """
        CO01END007ROV = self.data["CO01END007RO"] * (self.data["CO01END007RO"] >= 0)
        CO01END001INV = self.data["CO01END001IN"] * (self.data["CO01END001IN"] >= 0)
        CO01END001VEV = self.data["CO01END001VE"] * (self.data["CO01END001VE"] >= 0)
        CO01END001HPV = self.data["CO01END001HP"] * (self.data["CO01END001HP"] >= 0)
        CO01END001OTV = self.data["CO01END001OT"] * (self.data["CO01END001OT"] >= 0)

        if CO01END007ROV or CO01END001INV or CO01END001VEV or CO01END001HPV or CO01END001OTV:
            self.q3_exposicion = CO01END007ROV + CO01END001INV + CO01END001VEV + CO01END001HPV + CO01END001OTV
        else:
            self.q3_exposicion = -1.0

        if self.q3_exposicion > 0:
            self.q3_prexposicionro = round(CO01END007ROV / self.q3_exposicion, 4)  # Cobol ROUNDED revisar
            self.q3_prexposicionin = round(CO01END001INV / self.q3_exposicion, 4)  # Cobol ROUNDED revisar
            self.q3_prexposicionve = round(CO01END001VEV / self.q3_exposicion, 4)  # Cobol ROUNDED revisar
            self.q3_prexposicionhp = round(CO01END001HPV / self.q3_exposicion, 4)  # Cobol ROUNDED revisar
            self.q3_prexposicionot = round(CO01END001OTV / self.q3_exposicion, 4)  # Cobol ROUNDED revisar
        elif self.q3_exposicion < 0:
            self.q3_prexposicionro = -1.0
            self.q3_prexposicionin = -1.0
            self.q3_prexposicionve = -1.0
            self.q3_prexposicionhp = -1.0
            self.q3_prexposicionot = -1.0
            self.q3_prexposicionot = -1.0
        else:
            self.q3_prexposicionro = 0.0
            self.q3_prexposicionin = 0.0
            self.q3_prexposicionve = 0.0
            self.q3_prexposicionhp = 0.0
            self.q3_prexposicionot = 0.0

    def sectores_daqu3(self):
        """
        Computes the set of financial based hybrid characteristics.

        Attributes:

        "CO01NUM001XX" : Total number of products of the XX portfolio.

        :return: None type Object. It loads results on self variables of the
        Quanto 3 Base Instance.
        """
        self.q3_financiero = 1.0 * (
                self.data["CO01NUM001RO"] > 0 or self.data["CO01NUM001IN"] > 0 or
                self.data["CO01NUM001VE"] > 0 or self.data["CO01NUM001HP"] > 0
        )
        self.q3_real = 1.0 * (self.data["CO01NUM001OT"] > 0)
        self.q3_telcos = 1.0 * (self.data["CO01NUM001CC"] > 0)

        self.q3_tiporeld01 = 1 * (self.q3_financiero and not self.q3_real and not self.q3_telcos)
        self.q3_tiporeld02 = 1 * (self.q3_financiero and self.q3_real and not self.q3_telcos)
        self.q3_tiporeld03 = 1 * (self.q3_financiero and self.q3_real and self.q3_telcos)
        self.q3_tiporeld04 = 1 * (self.q3_financiero and not self.q3_real and self.q3_telcos)

    def qtotab_daqu3(self):
        """
        Obtain the total number of open products of an individual.

        Attributes:

        "CO01NUM002XX" : Total number of open products of the XX portfolio.

        :return: Total number of open products.
        """
        co01num002cc_a = self.data_o["CO01NUM002CC"] * (self.data_o["CO01NUM002CC"] >= 0)
        co01num002ro_a = self.data_o["CO01NUM002RO"] * (self.data_o["CO01NUM002RO"] >= 0)
        co01num002in_a = self.data_o["CO01NUM002IN"] * (self.data_o["CO01NUM002IN"] >= 0)
        co01num002ot_a = self.data_o["CO01NUM002OT"] * (self.data_o["CO01NUM002OT"] >= 0)
        co01num002ve_a = self.data_o["CO01NUM002VE"] * (self.data_o["CO01NUM002VE"] >= 0)
        co01num002hp_a = self.data_o["CO01NUM002HP"] * (self.data_o["CO01NUM002HP"] >= 0)

        return co01num002cc_a + co01num002ro_a + co01num002in_a + co01num002ot_a + co01num002ve_a + co01num002hp_a

    def qtot_daqu3(self):
        """
        Obtain the total number of products of an individual.

        Attributes:

        "CO01NUM001XX" : Total number of products of the XX portfolio.

        :return: Total number of products.
        """
        co01num001cc_a = self.data_o["CO01NUM001CC"] * (self.data_o["CO01NUM001CC"] >= 0)
        co01num001ro_a = self.data_o["CO01NUM001RO"] * (self.data_o["CO01NUM001RO"] >= 0)
        co01num001in_a = self.data_o["CO01NUM001IN"] * (self.data_o["CO01NUM001IN"] >= 0)
        co01num001ot_a = self.data_o["CO01NUM001OT"] * (self.data_o["CO01NUM001OT"] >= 0)
        co01num001ve_a = self.data_o["CO01NUM001VE"] * (self.data_o["CO01NUM001VE"] >= 0)
        co01num001hp_a = self.data_o["CO01NUM001HP"] * (self.data_o["CO01NUM001HP"] >= 0)

        return co01num001cc_a + co01num001ro_a + co01num001in_a + co01num001ot_a + co01num001ve_a + co01num001hp_a

    def calcula_maximo_cupo_tot(self):
        """
        Obtain the maximum credit fee betweem the HP ( mortgage credits ),
        IN ( credits facility ), MC ( Micro-credits ) and TC ( Credit Cards )
        portfolios.

        Attributes:

        "COQ1END003XX" : Maximum product quota of the XX portfolio.

        :return: Maximum products quota.
        """
        return max(
            self.data_o["COQ1END003HP"],
            self.data_o["COQ1END003IN"],
            self.data_o["COQ1END003MC"],
            self.data_o["COQ1END003TC"]
        )

    def calcula_suma_cuota_tot(self):
        """
        Computes the maximum open products up to date quota.

        Attributes:

        "COQ1END002XX" : Maximum up to date open products quota of the XX portfolio.

        :return: Maximum quota.
        """
        return (
            self.data["COQ1END002IN"] + self.data["COQ1END002HP"] +
            self.data["COQ1END002MC"] + self.data["COQ1END002TC"]
        )

    def calcula_cast_scodaqu3(self):
        """
        Obtain the number of punished and recovered products from
        RO ( revolving credits ), IN ( credits facility ), OT
        ( Other Credits ), VE ( vehicle credits ), CC ( communication
        duties ) and HP ( mortgage credits ) portfolios.

        Attributes:

        "CO01NUM018XX" : Number of punished products of the XX portfolio.
        "CO01NUM019XX" : Number of recovered products of the XX portfolio.

        :return: Number of punished and recovered products.
        """
        q3_cast = (
                self.data["CO01NUM018RO"] * (self.data["CO01NUM018RO"] > 0) +
                self.data["CO01NUM019RO"] * (self.data["CO01NUM019RO"] > 0) +
                self.data["CO01NUM018IN"] * (self.data["CO01NUM018IN"] > 0) +
                self.data["CO01NUM019IN"] * (self.data["CO01NUM019IN"] > 0) +
                self.data["CO01NUM018OT"] * (self.data["CO01NUM018OT"] > 0) +
                self.data["CO01NUM019OT"] * (self.data["CO01NUM019OT"] > 0) +
                self.data["CO01NUM018VE"] * (self.data["CO01NUM018VE"] > 0) +
                self.data["CO01NUM019VE"] * (self.data["CO01NUM019VE"] > 0) +
                self.data["CO01NUM018CC"] * (self.data["CO01NUM018CC"] > 0) +
                self.data["CO01NUM019CC"] * (self.data["CO01NUM019CC"] > 0) +
                self.data["CO01NUM018HP"] * (self.data["CO01NUM018HP"] > 0) +
                self.data["CO01NUM019HP"] * (self.data["CO01NUM019HP"] > 0)
        )

        return q3_cast

    def calcula_cast_ro(self):
        """
        Obtain the number of punished and recovered products from RO (
        revolving credits ) portfolio.

        Attributes:

        "CO01NUM018RO" : Number of punished products of the RO portfolio.
        "CO01NUM019RO" : Number of recovered products of the RO portfolio.

        :return: Number of punished and recovered RO products.
        """

        q3_cast_ro = (
                self.data["CO01NUM018RO"] * (not self.data["CO01NUM018RO"] < 0) +
                self.data["CO01NUM019RO"] * (not self.data["CO01NUM019RO"] < 0)
        )

        return q3_cast_ro
