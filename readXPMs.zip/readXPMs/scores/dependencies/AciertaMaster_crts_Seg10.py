import numpy as np
import traceback


def main(data,vars_woe):
    #%%
    #### Calculo Crts ####
    try:
        co00dem003   = data['CO00DEM003'] if data['CO00DEM003']!=-999 else np.nan
        co02end015cb = data['CO02END015CB_AMAS'] if data['CO02END015CB_AMAS']!=-999 else np.nan
        co01exp004ro = data['CO01EXP004RO_AMAS'] if data['CO01EXP004RO_AMAS']!=-999 else np.nan
        co02end034cb = data['CO02END034CB_AMAS'] if data['CO02END034CB_AMAS']!=-999 else np.nan
        co01end010ro = data['CO01END010RO_AMAS'] if data['CO01END010RO_AMAS']!=-999 else np.nan
        co02num043cb = data['CO02NUM043CB_AMAS'] if data['CO02NUM043CB_AMAS']!=-999 else np.nan
        co01mor076in = data['CO01MOR076IN_AMAS'] if data['CO01MOR076IN_AMAS']!=-999 else np.nan
        co02end028cb = data['CO02END028CB_AMAS'] if data['CO02END028CB_AMAS']!=-999 else np.nan
        co01mor034in = data['CO01MOR034IN_AMAS'] if data['CO01MOR034IN_AMAS']!=-999 else np.nan
        co01end004ro = data['CO01END004RO_AMAS'] if data['CO01END004RO_AMAS']!=-999 else np.nan
        co01mor002in = data['CO01MOR002IN_AMAS'] if data['CO01MOR002IN_AMAS']!=-999 else np.nan
        co01end087ro = data['CO01END087RO_AMAS'] if data['CO01END087RO_AMAS']!=-999 else np.nan
        co01end022ro = data['CO01END022RO_AMAS'] if data['CO01END022RO_AMAS']!=-999 else np.nan
        co01end066in = data['CO01END066IN_AMAS'] if data['CO01END066IN_AMAS']!=-999 else np.nan
        co01exp001ro = data['CO01EXP001RO_AMAS'] if data['CO01EXP001RO_AMAS']!=-999 else np.nan
        co02exp011to = data['CO02EXP011TO'] if data['CO02EXP011TO']!=-999 else np.nan
        co01mor009ve = data['CO01MOR009VE_AMAS'] if data['CO01MOR009VE_AMAS']!=-999 else np.nan
        co01end012in = data['CO01END012IN_AMAS'] if data['CO01END012IN_AMAS']!=-999 else np.nan
        co01end022ve = data['CO01END022VE_AMAS'] if data['CO01END022VE_AMAS']!=-999 else np.nan
    
        coa1exp001to = data['CO01EXP001TO_AMAS'] if data['CO01EXP001TO_AMAS']!=-999 else np.nan
        coa1num002cp = data['CO01NUM002CP_AMAS'] if data['CO01NUM002CP_AMAS']!=-999 else np.nan
    except Exception, error:
        tb = traceback.format_exc()
        # logger.error("!!! Error: {}, {}".format(error, tb))
        assert False, "!!! Error: {}, {}".format(error, tb)

    #%%
    #### Woe Cs ####
    co01mor076in_woe = float(np.where(np.isnan(co01mor076in)|(co01mor076in<0)|(co01mor076in==999),0.2409,np.where(co01mor076in<=2,-1.311,np.where(co01mor076in<=8,-0.7442,0.2409))))
    co02end028cb_woe = float(np.where(np.isnan(co02end028cb)|(co02end028cb==-1)|(co02end028cb==-2)|(co02end028cb==-3)|(co02end028cb==-4)|(co02end028cb==-5)|(co02end028cb==-11)|(co02end028cb==-88)|(co02end028cb==-99),0.21,np.where(co02end028cb<=-100,0.4787,np.where(co02end028cb<=4.55,0.21,np.where(co02end028cb<=36.11,-0.5484,-1.0327)))))
    co01mor034in_woe = float(np.where(np.isnan(co01mor034in)|(co01mor034in<0),0.0427,np.where(co01mor034in<=0,0.48,np.where(co01mor034in<=1,-0.3707,-1.2332))))
    co01end004ro_woe = float(np.where(np.isnan(co01end004ro)|(co01end004ro<0),0.1044,np.where(co01end004ro<=0.03,0.4403,np.where(co01end004ro<=0.28,-0.2871,np.where(co01end004ro<=1.12,-0.8347,-0.9691)))))
    co01mor002in_woe = float(np.where(np.isnan(co01mor002in)|(co01mor002in<0),0.078,np.where(co01mor002in<=0,0.078,-1.1197)))
    co02end015cb_woe = float(np.where(np.isnan(co02end015cb)|(co02end015cb<0),0.0539,np.where(co02end015cb<=0.13,0.6341,np.where(co02end015cb<=1.13,0.3056,np.where(co02end015cb<=3.51,-0.2433,-0.6308)))))
    co00dem003_woe   = float(np.where(np.isnan(co00dem003)|(co00dem003<0),-0.3632,np.where(co00dem003<=29,-0.3632,np.where(co00dem003<=52,-0.0962,np.where(co00dem003<=55,0.2172,np.where(co00dem003<=59,0.4155,0.5111))))))
    co02end034cb_woe = float(np.where(np.isnan(co02end034cb)|(co02end034cb==-1)|(co02end034cb==-2)|(co02end034cb==-3)|(co02end034cb==-4)|(co02end034cb==-5)|(co02end034cb==-11)|(co02end034cb==-88)|(co02end034cb==-99),0.0235,np.where(co02end034cb<=-37.29,0.3612,np.where(co02end034cb<=13.95,0.2123,np.where(co02end034cb<=34.68,0.0235,np.where(co02end034cb<=119,-0.2784,-0.7408))))))
    co01end087ro_woe = float(np.where(np.isnan(co01end087ro)|(co01end087ro<0),0.0647,np.where(co01end087ro<=32.23,0.6515,np.where(co01end087ro<=72.81,0.2216,np.where(co01end087ro<=84.95,-0.1537,np.where(co01end087ro<=99.32,-0.359,-0.6278))))))
    co01end022ro_woe = float(np.where(np.isnan(co01end022ro)|(co01end022ro<0),0.0662,np.where(co01end022ro<=0.02,0.4754,np.where(co01end022ro<=0.05,0.0662,np.where(co01end022ro<=0.17,-0.3006,-0.5523)))))
    co01end010ro_woe = float(np.where(np.isnan(co01end010ro)|(co01end010ro<0),-0.0523,np.where(co01end010ro<=0.24,-0.326,np.where(co01end010ro<=1.78,-0.0523,np.where(co01end010ro<=4.52,0.1295,np.where(co01end010ro<=7.87,0.3543,0.5128))))))
    co01end066in_woe = float(np.where(np.isnan(co01end066in)|(co01end066in<0),0.0127,np.where(co01end066in<=0.18,0.166,np.where(co01end066in<=1.11,0.0127,-0.2061))))
    coa1num002cp_woe = float(np.where(np.isnan(coa1num002cp)|(coa1num002cp<0),-0.0878,np.where(coa1num002cp<=4,-0.0878,np.where(coa1num002cp<=6,0.1574,np.where(coa1num002cp<=12,0.279,0.575)))))
    co01exp001ro_woe = float(np.where(np.isnan(co01exp001ro)|(co01exp001ro<0),-0.0302,np.where(co01exp001ro<=54,-0.2673,np.where(co01exp001ro<=124,-0.0302,np.where(co01exp001ro<=250,0.08,0.2303)))))
    co02exp011to_woe = float(np.where(np.isnan(co02exp011to)|(co02exp011to<0),0.0598,np.where(co02exp011to<=33.33,0.3132,np.where(co02exp011to<=75,0.0598,-0.2354))))
    co01mor009ve_woe = float(np.where(np.isnan(co01mor009ve)|(co01mor009ve<0),-0.0136,np.where(co01mor009ve<=0,0.2916,-0.4577)))
    co01exp004ro_woe = float(np.where(np.isnan(co01exp004ro)|(co01exp004ro<0)|(co01exp004ro==999),-0.064,np.where(co01exp004ro<=39,-0.064,np.where(co01exp004ro<=53,0.0509,np.where(co01exp004ro<=81,0.2117,0.3865)))))
    coa1exp001to_woe = float(np.where(np.isnan(coa1exp001to)|(coa1exp001to<0),-0.0416,np.where(coa1exp001to<=40.5087719298246,-0.3727,np.where(coa1exp001to<=94.3888888888889,-0.0416,np.where(coa1exp001to<=100.857142857143,0.1657,0.3547)))))
    co02num043cb_woe = float(np.where(np.isnan(co02num043cb)|(co02num043cb<0),-0.0475,np.where(co02num043cb<=35.29,-0.4366,np.where(co02num043cb<=78.95,-0.0475,0.367))))
    co01end012in_woe = float(np.where(np.isnan(co01end012in)|(co01end012in<0),0.0581,np.where(co01end012in<=0.03,0.4387,np.where(co01end012in<=0.42,-0.4139,-0.9353))))
    co01end022ve_woe = float(np.where(np.isnan(co01end022ve)|(co01end022ve<0),-0.0091,np.where(co01end022ve<=0.05,0.4196,-0.682)))

    #%% salida
    out=[eval(i) for i in vars_woe]

    #%%
    return out
