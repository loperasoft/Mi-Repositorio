import numpy as np
import traceback


def main(data,vars_woe):

    #%%
    #### Calculo Crts ####
    try:
        co01end071ro = data['CO01END071RO_AMAS'] if data['CO01END071RO_AMAS']!=-999 else np.nan
        co00dem003   = data['CO00DEM003'] if data['CO00DEM003']!=-999 else np.nan
        co01mor009cc = data['CO01MOR009CC_AMAS'] if data['CO01MOR009CC_AMAS']!=-999 else np.nan
        co01mor009ro = data['CO01MOR009RO_AMAS'] if data['CO01MOR009RO_AMAS']!=-999 else np.nan
        co01acp042in = data['CO01ACP042IN_AMAS'] if data['CO01ACP042IN_AMAS']!=-999 else np.nan
        co02end015cb = data['CO02END015CB_AMAS'] if data['CO02END015CB_AMAS']!=-999 else np.nan
        co01end093in = data['CO01END093IN_AMAS'] if data['CO01END093IN_AMAS']!=-999 else np.nan
        co02end003in = data['CO02END003IN_AMAS'] if data['CO02END003IN_AMAS']!=-999 else np.nan
        co01end018in = data['CO01END018IN_AMAS'] if data['CO01END018IN_AMAS']!=-999 else np.nan
        co01mor067in = data['CO01MOR067IN_AMAS'] if data['CO01MOR067IN_AMAS']!=-999 else np.nan
        co02num072cb = data['CO02NUM072CB_AMAS'] if data['CO02NUM072CB_AMAS']!=-999 else np.nan
        co02end034cb = data['CO02END034CB_AMAS'] if data['CO02END034CB_AMAS']!=-999 else np.nan
        co01end088ro = data['CO01END088RO_AMAS'] if data['CO01END088RO_AMAS']!=-999 else np.nan
        co01end010ro = data['CO01END010RO_AMAS'] if data['CO01END010RO_AMAS']!=-999 else np.nan
        co02exp010to = np.floor(data['CO02EXP010TO']) if data['CO02EXP010TO']!=-999 else np.nan
        co01exp003ah = data['CO01EXP003AH_AMAS'] if data['CO01EXP003AH_AMAS']!=-999 else np.nan
        co01acp006ah = data['CO01ACP006AH'] if data['CO01ACP006AH']!=-999 else np.nan
        co01mor061cc = data['CO01MOR061CC_AMAS'] if data['CO01MOR061CC_AMAS']!=-999 else np.nan
        co02end001cb = data['CO02END001CB_AMAS'] if data['CO02END001CB_AMAS']!=-999 else np.nan
        co02num043cb = data['CO02NUM043CB_AMAS'] if data['CO02NUM043CB_AMAS']!=-999 else np.nan
        co02exp005to = data['CO02EXP005TO'] if data['CO02EXP005TO']!=-999 else np.nan
    
        coa1mor001to = data['CO01MOR001TO_AMAS'] if data['CO01MOR001TO_AMAS']!=-999 else np.nan
        coa1mor006to = data['CO01MOR006TO'] if data['CO01MOR006TO']!=-999 else np.nan
        coa1exp002fi = data['CO01EXP002FI_AMAS'] if data['CO01EXP002FI_AMAS']!=-999 else np.nan
        coa1end001fi = data['CO01END001FI_AMAS'] if data['CO01END001FI_AMAS']!=-999 else np.nan
    except Exception, error:
        tb = traceback.format_exc()
        # logger.error("!!! Error: {}, {}".format(error, tb))
        assert False, "!!! Error: {}, {}".format(error, tb)
	
    #%%
    #### Woe Cs ####
    co01end071ro_woe = float(np.where(np.isnan(co01end071ro)|(co01end071ro<0),-0.1479,np.where(co01end071ro<=33.33,0.621,np.where(co01end071ro<=42.33,0.3546,np.where(co01end071ro<=57.05,0.0988,-0.5208)))))
    coa1mor001to_woe = float(np.where(np.isnan(coa1mor001to),0.1321,np.where(coa1mor001to<=0,0.1321,-0.6779)))
    co00dem003_woe   = float(np.where(np.isnan(co00dem003)|(co00dem003<0),-0.4307,np.where(co00dem003<=25,-0.4307,np.where(co00dem003<=47,0.0225,np.where(co00dem003<=54,0.1772,0.3712)))))
    co02end003in_woe = float(np.where(np.isnan(co02end003in)|(co02end001cb==-99)|(co02end001cb==-88)|(co02end001cb==-11)|(co02end001cb==-5)|(co02end001cb==-4)|(co02end001cb==-3)|(co02end001cb==-2)|(co02end003in==-1),0.0417,np.where(co02end003in<=11.45,-0.2134,np.where(co02end003in<=21.51,0.0417,np.where(co02end003in<=46.51,0.1231,0.3945)))))
    co01end018in_woe = float(np.where(np.isnan(co01end018in)|(co01end018in<0),-0.0198,np.where(co01end018in<=0.11,0.2721,-0.0198)))
    co01mor067in_woe = float(np.where(np.isnan(co01mor067in)|(co01mor067in<0),-0.0129,np.where(co01mor067in<=0,0.0903,-0.7872)))
    co02num072cb_woe = float(np.where(np.isnan(co02num072cb)|(co02num072cb<0),-0.0323,np.where(co02num072cb<=0,-0.1263,np.where(co02num072cb<=50,0.0027,0.2264))))
    co02end034cb_woe = float(np.where(np.isnan(co02end034cb)|(co02end034cb==-1)|(co02end034cb==-2)|(co02end034cb==-3)|(co02end034cb==-4)|(co02end034cb==-5)|(co02end034cb==-11)|(co02end034cb==-88)|(co02end034cb==-99),-0.1978,np.where(co02end034cb<=-53.25,0.3494,np.where(co02end034cb<=2.33,0.1317,np.where(co02end034cb<=46.93,-0.0407,-0.1978)))))
    co01end088ro_woe = float(np.where(np.isnan(co01end088ro)|(co01end088ro<0),-0.1848,np.where(co01end088ro<=32.46,0.5392,np.where(co01end088ro<=44.51,0.2438,np.where(co01end088ro<=64.41,-0.0647,-0.5576)))))
    co01end010ro_woe = float(np.where(np.isnan(co01end010ro)|(co01end010ro<0),-0.1826,np.where(co01end010ro<=0.47,-0.6898,np.where(co01end010ro<=3.02,0.0775,np.where(co01end010ro<=6.6,0.7351,1.2075)))))
    co02end015cb_woe = float(np.where(np.isnan(co02end015cb)|(co02end015cb<0),-0.0227,np.where(co02end015cb<=0,0.1026,-0.6948)))
    co02exp010to_woe = float(np.where(np.isnan(co02exp010to)|(co02exp010to<0),-0.0836,np.where(co02exp010to<=33,0.3531,np.where(co02exp010to<=76,0.1921,np.where(co02exp010to<=87,-0.0836,-0.2123)))))
    coa1exp002fi_woe = float(np.where(np.isnan(coa1exp002fi),0.1052,np.where(coa1exp002fi<=37,-0.1358,0.1052)))
    co01mor009cc_woe = float(np.where(np.isnan(co01mor009cc)|(co01mor009cc<0),-0.0085,np.where(co01mor009cc<=0,0.2178,np.where(co01mor009cc<=3,-0.4392,-0.6548))))
    co01exp003ah_woe = float(np.where(np.isnan(co01exp003ah)|(co01exp003ah<0),0.1333,np.where(co01exp003ah<=14,-0.3834,np.where(co01exp003ah<=79,-0.1205,np.where(co01exp003ah<=157,0.1333,0.4477)))))
    co01acp006ah_woe = float(np.where(np.isnan(co01acp006ah)|(co01acp006ah<0),0.0655,np.where(co01acp006ah<=0,0.2088,np.where(co01acp006ah<=1,-0.1441,-0.3249))))
    coa1mor006to_woe = float(np.where(np.isnan(coa1mor006to),0.1321,np.where(coa1mor006to<=0,0.1321,-0.6779)))
    co01mor061cc_woe = float(np.where(np.isnan(co01mor061cc)|(co01mor061cc<0),-0.0556,np.where(co01mor061cc<=0,-0.2012,np.where(co01mor061cc<=1,0.2313,0.5657))))
    co02end001cb_woe = float(np.where(np.isnan(co02end001cb)|(co02end001cb==-1),0.1049,np.where(co02end001cb<=43.24,-0.1126,np.where(co02end001cb<=73.45,0.1049,0.4762))))
    coa1end001fi_woe = float(np.where(np.isnan(coa1end001fi),0.0809,np.where(coa1end001fi<=0,-0.4336,np.where(coa1end001fi<=11788,0.0809,np.where(coa1end001fi<=24153,0.245,0.4664)))))
    co01acp042in_woe = float(np.where(np.isnan(co01acp042in)|(co01acp042in<0),0.0311,np.where(co01acp042in<=0,0.3398,-0.3046)))
    co02num043cb_woe = float(np.where(np.isnan(co02num043cb),0.049,np.where(co02num043cb<=62.5,-0.0663,np.where(co02num043cb<=67.74,0.049,np.where(co02num043cb<=75.86,0.1783,0.3319)))))
    co01mor009ro_woe = float(np.where(np.isnan(co01mor009ro)|(co01mor009ro<0),-0.1446,np.where(co01mor009ro<=0,0.204,-0.5522)))
    co01end093in_woe = float(np.where(np.isnan(co01end093in)|(co01end093in<0),0.1048,np.where(co01end093in<=1.3,-0.2831,np.where(co01end093in<=22.04,-0.168,np.where(co01end093in<=39.74,0.1048,0.3915)))))
    co02exp005to_woe = float(np.where(np.isnan(co02exp005to)|(co02exp005to<0)|(co02exp005to==999),-0.0491,np.where(co02exp005to<=5,0.2503,np.where(co02exp005to<=13,0.0378,-0.0491))))

    #%% salida
    out=[eval(i) for i in vars_woe]

    #%%
    return out
