import numpy as np
import traceback


def main(data,vars_woe):

    #%%
    #### Calculo Crts ####
    try:
        co00dem003   = data['CO00DEM003'] if data['CO00DEM003']!=-999 else np.nan
        co01acp005ro = data['CO01ACP005RO_AMAS'] if data['CO01ACP005RO_AMAS']!=-999 else np.nan
        co01acp008ro = data['CO01ACP008RO_AMAS'] if data['CO01ACP008RO_AMAS']!=-999 else np.nan
        co01acp014ro = data['CO01ACP014RO_AMAS'] if data['CO01ACP014RO_AMAS']!=-999 else np.nan
        co01exp002ah = data['CO01EXP002AH'] if data['CO01EXP002AH']!=-999 else np.nan
        co01mor047ro = data['CO01MOR047RO_AMAS'] if data['CO01MOR047RO_AMAS']!=-999 else np.nan
        co01mor053in = data['CO01MOR053IN_AMAS'] if data['CO01MOR053IN_AMAS']!=-999 else np.nan
        co01mor056in = data['CO01MOR056IN_AMAS'] if data['CO01MOR056IN_AMAS']!=-999 else np.nan
        co01mor062in = data['CO01MOR062IN_AMAS'] if data['CO01MOR062IN_AMAS']!=-999 else np.nan
        co01mor067in = data['CO01MOR067IN_AMAS'] if data['CO01MOR067IN_AMAS']!=-999 else np.nan
        co01mor067ro = data['CO01MOR067RO_AMAS'] if data['CO01MOR067RO_AMAS']!=-999 else np.nan
        co01mor071cc = data['CO01MOR071CC_AMAS'] if data['CO01MOR071CC_AMAS']!=-999 else np.nan
        co01mor072ro = data['CO01MOR072RO_AMAS'] if data['CO01MOR072RO_AMAS']!=-999 else np.nan
        co01mor074ro = data['CO01MOR074RO_AMAS'] if data['CO01MOR074RO_AMAS']!=-999 else np.nan
        co02num029to = data['CO02NUM029TO'] if data['CO02NUM029TO']!=-999 else np.nan
    
        coa1num002cp = data['CO01NUM002CP_AMAS'] if data['CO01NUM002CP_AMAS']!=-999 else np.nan
    except Exception, error:
        tb = traceback.format_exc()
        # logger.error("!!! Error: {}, {}".format(error, tb))
        assert False, "!!! Error: {}, {}".format(error, tb)
    #%%
    #### Woe Cs ####
    co00dem003_woe   = float(np.where(np.isnan(co00dem003)|(co00dem003<0),-0.5055,np.where(co00dem003<=25,-0.5055,np.where(co00dem003<=51,-0.1201,np.where(co00dem003<=53,0.1077,np.where(co00dem003<=57,0.3658,0.9602))))))
    co01mor062in_woe = float(np.where(np.isnan(co01mor062in)|(co01mor062in<0),-0.1825,np.where(co01mor062in<=0,0.4939,-0.4973)))
    co01mor074ro_woe = float(np.where(np.isnan(co01mor074ro)|(co01mor074ro<0),-0.0618,np.where(co01mor074ro<=0,0.5653,-0.3426)))
    co01mor053in_woe = float(np.where(np.isnan(co01mor053in)|(co01mor053in<0),-0.1636,np.where(co01mor053in<=0,0.417,-0.5472)))
    co02num029to_woe = float(np.where(np.isnan(co02num029to)|(co02num029to<0),-0.0948,np.where(co02num029to<=1,-0.5333,np.where(co02num029to<=10,-0.0948,np.where(co02num029to<=12,0.258,0.5772)))))
    co01mor067in_woe = float(np.where(np.isnan(co01mor067in)|(co01mor067in<0),-0.1823,np.where(co01mor067in<=0,0.4942,-0.4973)))
    co01mor072ro_woe = float(np.where(np.isnan(co01mor072ro)|(co01mor072ro<0),-0.0601,np.where(co01mor072ro<=0,0.4635,-0.4876)))
    co01acp008ro_woe = float(np.where(np.isnan(co01acp008ro)|(co01acp008ro<0),-0.0152,np.where(co01acp008ro<=0,-0.2782,np.where(co01acp008ro<=1,-0.0152,np.where(co01acp008ro<=2,0.1924,0.4396)))))
    coa1num002cp_woe = float(np.where(np.isnan(coa1num002cp)|(coa1num002cp<0),-0.0332,np.where(coa1num002cp<=1,-0.3338,np.where(coa1num002cp<=4,-0.0332,np.where(coa1num002cp<=9,0.4831,0.8977)))))
    co01mor056in_woe = float(np.where(np.isnan(co01mor056in)|(co01mor056in<0),-0.1766,np.where(co01mor056in<=0,0.4174,-0.5782)))
    co01mor071cc_woe = float(np.where(np.isnan(co01mor071cc)|(co01mor071cc<0),-0.0342,np.where(co01mor071cc<=0,0.3965,-0.3615)))
    co01mor067ro_woe = float(np.where(np.isnan(co01mor067ro)|(co01mor067ro<0),-0.0608,np.where(co01mor067ro<=0,0.5741,-0.361)))
    co01exp002ah_woe = float(np.where(np.isnan(co01exp002ah)|(co01exp002ah<0)|(co01exp002ah==999),0.0685,np.where(co01exp002ah<=5,-0.4126,np.where(co01exp002ah<=46,-0.1545,np.where(co01exp002ah<=95,0.0685,np.where(co01exp002ah<=126,0.2563,0.494))))))
    co01acp014ro_woe = float(np.where(np.isnan(co01acp014ro)|(co01acp014ro<0),-0.096,np.where(co01acp014ro<=0,-0.096,np.where(co01acp014ro<=1,0.2257,0.6421))))
    co01mor047ro_woe = float(np.where(np.isnan(co01mor047ro)|(co01mor047ro<0),-0.0406,np.where(co01mor047ro<=0,-0.0406,0.6995)))
    co01acp005ro_woe = float(np.where(np.isnan(co01acp005ro)|(co01acp005ro<0),-0.0195,np.where(co01acp005ro<=0,0.1398,-0.1847)))

    #%% salida
    out=[eval(i) for i in vars_woe]

    #%%
    return out
