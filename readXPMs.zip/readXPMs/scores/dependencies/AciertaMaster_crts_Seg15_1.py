import numpy as np
import math
import traceback


def main(data,vars_woe):

    #%%
    #### Calculo Crts ####
    try:
        co01end093ro = data['CO01END093RO_AMAS'] if data['CO01END093RO_AMAS']!=-999 else np.nan
        co02end024cb = data['CO02END024CB_AMAS'] if data['CO02END024CB_AMAS']!=-999 else np.nan
        co02num036to = data['CO02NUM036TO'] if data['CO02NUM036TO']!=-999 else np.nan
        co00dem003   = data['CO00DEM003'] if data['CO00DEM003']!=-999 else np.nan
        co01end010ro = data['CO01END010RO_AMAS'] if data['CO01END010RO_AMAS']!=-999 else np.nan
        co01end071ro = data['CO01END071RO_AMAS'] if data['CO01END071RO_AMAS']!=-999 else np.nan
        co01end093in = data['CO01END093IN_AMAS'] if data['CO01END093IN_AMAS']!=-999 else np.nan
        co02num043cb = data['CO02NUM043CB_AMAS'] if data['CO02NUM043CB_AMAS']!=-999 else np.nan
        co02num072cb = data['CO02NUM072CB_AMAS'] if data['CO02NUM072CB_AMAS']!=-999 else np.nan
        co02num029to = data['CO02NUM029TO'] if data['CO02NUM029TO']!=-999 else np.nan
        co01end076ro = data['CO01END076RO_AMAS'] if data['CO01END076RO_AMAS']!=-999 else np.nan
        co01end039ro = data['CO01END039RO_AMAS'] if data['CO01END039RO_AMAS']!=-999 else np.nan
        co01exp002in = data['CO01EXP002IN_AMAS'] if data['CO01EXP002IN_AMAS']!=-999 else np.nan
        co01exp004ah = data['CO01EXP004AH'] if data['CO01EXP004AH']!=-999 else np.nan
        co01mor069in = data['CO01MOR069IN_AMAS'] if data['CO01MOR069IN_AMAS']!=-999 else np.nan
        co02end001ot = math.trunc(data['CO02END001OT_AMAS']) if data['CO02END001OT_AMAS']!=-999 else np.nan
        co02end006cb = data['CO02END006CB_AMAS'] if data['CO02END006CB_AMAS']!=-999 else np.nan
        co02exp004to = data['CO02EXP004TO'] if data['CO02EXP004TO']!=-999 else np.nan
        coa1exp003fi = data['CO01EXP003FI_AMAS'] if data['CO01EXP003FI_AMAS']!=-999 else np.nan
        coa1mor995cp = data['CO01MOR995CP_AMAS'] if data['CO01MOR995CP_AMAS']!=-999 else np.nan
    except Exception, error:
        tb = traceback.format_exc()
        # logger.error("!!! Error: {}, {}".format(error, tb))
        assert False, "!!! Error: {}, {}".format(error, tb)
    
    #%%
    #### Woe Cs ####
    co00dem003_woe   = float(np.where(np.isnan(co00dem003)|(co00dem003<0),-0.029,np.where(co00dem003<=50,-0.029,0.3122)))
    co01end010ro_woe = float(np.where(np.isnan(co01end010ro)|(co01end010ro<0),0.0436,np.where(co01end010ro<=0.08,-0.7526,np.where(co01end010ro<=0.27,-0.273,np.where(co01end010ro<=0.82,0.0436,0.5405)))))
    co01end039ro_woe = float(np.where(np.isnan(co01end039ro)|(co01end039ro<0),-0.0155,np.where(co01end039ro<=0.17,-0.4544,np.where(co01end039ro<=1.55,0.1547,0.5532))))
    co01end071ro_woe = float(np.where(np.isnan(co01end071ro)|(co01end071ro==-1)|(co01end071ro==-2)|(co01end071ro==-3)|(co01end071ro==-4)|(co01end071ro==-5)|(co01end071ro==-88)|(co01end071ro==-99),0.0596,np.where(co01end071ro<=38.24,0.595,np.where(co01end071ro<=80.38,0.0596,-0.5675))))
    co01end076ro_woe = float(np.where(np.isnan(co01end076ro)|(co01end076ro==-1)|(co01end076ro==-2)|(co01end076ro==-3)|(co01end076ro==-4)|(co01end076ro==-5)|(co01end076ro==-88)|(co01end076ro==-99),0.06,np.where(co01end076ro<=38.39,0.591,np.where(co01end076ro<=81.58,0.06,-0.5675))))
    co01end093in_woe = float(np.where(np.isnan(co01end093in)|(co01end093in<0),-0.0441,np.where(co01end093in<=0,-0.2842,np.where(co01end093in<=18.9,-0.0441,np.where(co01end093in<=31.69,0.3932,0.6395)))))
    co01end093ro_woe = float(np.where(np.isnan(co01end093ro)|(co01end093ro<0),0.0432,np.where(co01end093ro<=16.83,-0.5313,np.where(co01end093ro<=42.4,-0.2099,0.3895))))
    co01exp002in_woe = float(np.where(np.isnan(co01exp002in)|(co01exp002in<0)|(co01exp002in==999),-0.0554,np.where(co01exp002in<=0,-0.3959,np.where(co01exp002in<=3,-0.1953,np.where(co01exp002in<=4,0.1089,0.3154)))))
    co01exp004ah_woe = float(np.where(np.isnan(co01exp004ah)|(co01exp004ah<0)|(co01exp004ah==999),0.0306,np.where(co01exp004ah<=3,-0.4474,np.where(co01exp004ah<=16,-0.1364,np.where(co01exp004ah<=25,0.0306,np.where(co01exp004ah<=69,0.23,0.3501))))))
    co01mor069in_woe = float(np.where(np.isnan(co01mor069in)|(co01mor069in<0),-0.065,np.where(co01mor069in<=0,0.4577,-0.065)))
    co02end001ot_woe = float(np.where(np.isnan(co02end001ot)|(co02end001ot==-1)|(co02end001ot==-2)|(co02end001ot==-3)|(co02end001ot==-4)|(co02end001ot==-5)|(co02end001ot==-88)|(co02end001ot==-99),0.0224,np.where(co02end001ot<=15,-0.3635,0.0869)))
    co02end006cb_woe = float(np.where(np.isnan(co02end006cb)|(co02end006cb<0),0.1352,np.where(co02end006cb<=21.68,-0.1252,np.where(co02end006cb<=48.08,0.1352,0.4986))))
    co02end024cb_woe = float(np.where(np.isnan(co02end024cb)|(co02end024cb==-1)|(co02end024cb==-2)|(co02end024cb==-3)|(co02end024cb==-4)|(co02end024cb==-5)|(co02end024cb==-11)|(co02end024cb==-88)|(co02end024cb==-99),-0.2775,np.where(co02end024cb<=-51.18,0.5871,np.where(co02end024cb<=-30,0.2822,np.where(co02end024cb<=0,0.058,-0.1471)))))
    co02exp004to_woe = float(np.where(np.isnan(co02exp004to)|(co02exp004to<0),-0.1069,np.where(co02exp004to<=0,-0.3317,np.where(co02exp004to<=3,-0.1069,np.where(co02exp004to<=4,0.1646,0.3355)))))
    co02num029to_woe = float(np.where(np.isnan(co02num029to)|(co02num029to<0),-0.06,np.where(co02num029to<=0,-0.2154,np.where(co02num029to<=3,-0.06,np.where(co02num029to<=5,0.1866,0.3898)))))
    co02num036to_woe = float(np.where(np.isnan(co02num036to)|(co02num036to<0),0.052,np.where(co02num036to<=0,-0.1134,0.2909)))
    co02num043cb_woe = float(np.where(np.isnan(co02num043cb)|(co02num043cb<0),-0.0062,np.where(co02num043cb<=20,-0.2203,np.where(co02num043cb<=53.85,-0.0062,np.where(co02num043cb<=66.67,0.3125,0.5491)))))
    co02num072cb_woe = float(np.where(np.isnan(co02num072cb)|(co02num072cb<0),0.052,np.where(co02num072cb<=50,-0.1095,0.3895)))
    coa1exp003fi_woe = float(np.where(np.isnan(coa1exp003fi)|(coa1exp003fi<0),-0.1676,np.where(coa1exp003fi<=3,-0.1676,np.where(coa1exp003fi<=4,0.1488,np.where(coa1exp003fi<=7,0.3184,0.3662)))))
    coa1mor995cp_woe = float(np.where(np.isnan(coa1mor995cp)|(coa1mor995cp<0),-0.09,np.where(coa1mor995cp<=0,-0.09,0.3029)))

    #%% salida
    out=[eval(i) for i in vars_woe]

    #%%
    return out