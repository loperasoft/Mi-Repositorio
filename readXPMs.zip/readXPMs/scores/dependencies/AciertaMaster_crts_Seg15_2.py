import numpy as np
import traceback


def main(data,vars_woe):

    #%%
    #### Calculo Crts ####
    try:
        co00dem003   = data['CO00DEM003'] if data['CO00DEM003']!=-999 else np.nan
        co02num029to = data['CO02NUM029TO'] if data['CO02NUM029TO']!=-999 else np.nan
        co01mor009cc = data['CO01MOR009CC_AMAS'] if data['CO01MOR009CC_AMAS']!=-999 else np.nan
        co01mor009in = data['CO01MOR009IN_AMAS'] if data['CO01MOR009IN_AMAS']!=-999 else np.nan
        co01mor033cc = data['CO01MOR033CC_AMAS'] if data['CO01MOR033CC_AMAS']!=-999 else np.nan
        co02exp007to = data['CO02EXP007TO'] if data['CO02EXP007TO']!=-999 else np.nan
        co01acp041ot = data['CO01ACP041OT_AMAS'] if data['CO01ACP041OT_AMAS']!=-999 else np.nan
        co01mor069ot = data['CO01MOR069OT_AMAS'] if data['CO01MOR069OT_AMAS']!=-999 else np.nan
        co01end089ro = data['CO01END089RO_AMAS'] if data['CO01END089RO_AMAS']!=-999 else np.nan
        co01exp008ah = data['CO01EXP008AH'] if data['CO01EXP008AH']!=-999 else np.nan
        co01mor053cc = data['CO01MOR053CC_AMAS'] if data['CO01MOR053CC_AMAS']!=-999 else np.nan
        co01mor055ot = data['CO01MOR055OT_AMAS'] if data['CO01MOR055OT_AMAS']!=-999 else np.nan
        co02end016cb = data['CO02END016CB_AMAS'] if data['CO02END016CB_AMAS']!=-999 else np.nan
        co01acp017cc = data['CO01ACP017CC_AMAS'] if data['CO01ACP017CC_AMAS']!=-999 else np.nan
        co01end090cc = data['CO01END090CC_AMAS'] if data['CO01END090CC_AMAS']!=-999 else np.nan
        co01exp002cc = data['CO01EXP002CC_AMAS'] if data['CO01EXP002CC_AMAS']!=-999 else np.nan
        co01exp013ah = data['CO01EXP013AH'] if data['CO01EXP013AH']!=-999 else np.nan
        co01num004ah = data['CO01NUM004AH'] if data['CO01NUM004AH']!=-999 else np.nan
        co02acp002to = data['CO02ACP002TO'] if data['CO02ACP002TO']!=-999 else np.nan
    
        coa1exp001fi = data['CO01EXP001FI_AMAS'] if data['CO01EXP001FI_AMAS']!=-999 else np.nan
        coa1num600to = data['CO01NUM600TO_AMAS'] if data['CO01NUM600TO_AMAS']!=-999 else np.nan
        coa1exp002re = data['CO01EXP002RE_AMAS'] if data['CO01EXP002RE_AMAS']!=-999 else np.nan
        coa1mor005to = data['CO01MOR005TO_AMAS'] if data['CO01MOR005TO_AMAS']!=-999 else np.nan
    except Exception, error:
        tb = traceback.format_exc()
        # logger.error("!!! Error: {}, {}".format(error, tb))
        assert False, "!!! Error: {}, {}".format(error, tb)

    #%%
    #### Woe Cs ####
    co00dem003_woe   = float(np.where(np.isnan(co00dem003)|(co00dem003<0),0.0391,np.where(co00dem003<=20,-0.2646,np.where(co00dem003<=37,-0.0559,np.where(co00dem003<=43,0.0391,np.where(co00dem003<=51,0.1648,0.4785))))))
    co01end089ro_woe = float(np.where(np.isnan(co01end089ro)|(co01end089ro==-1)|(co01end089ro==-2)|(co01end089ro==-3)|(co01end089ro==-4)|(co01end089ro==-5)|(co01end089ro==-88)|(co01end089ro==-99),-0.0322,np.where(co01end089ro<=60,0.3809,-0.0322)))
    co01exp008ah_woe = float(np.where(np.isnan(co01exp008ah)|(co01exp008ah<0),-0.0239,np.where(co01exp008ah<=0,0.218,-0.1766)))
    co01mor053cc_woe = float(np.where(np.isnan(co01mor053cc)|(co01mor053cc<0),-0.0472,np.where(co01mor053cc<=1,0.2611,-0.2434)))
    co01mor055ot_woe = float(np.where(np.isnan(co01mor055ot)|(co01mor055ot<0),-0.0314,np.where(co01mor055ot<=0,0.3715,-0.2864)))
    co02end016cb_woe = float(np.where(np.isnan(co02end016cb)|(co02end016cb<0),0.0244,np.where(co02end016cb<=0,0.0244,-0.3956)))
    co02num029to_woe = float(np.where(np.isnan(co02num029to),-0.055,np.where(co02num029to<=0,-0.4256,np.where(co02num029to<=2,-0.055,np.where(co02num029to<=3,0.1126,np.where(co02num029to<=4,0.2407,0.3194))))))
    coa1exp001fi_woe = float(np.where(np.isnan(coa1exp001fi)|(coa1exp001fi<0),-0.0086,np.where(coa1exp001fi<=5,-0.1923,0.1902)))
    coa1exp002re_woe = float(np.where(np.isnan(coa1exp002re)|(coa1exp002re<0),0.0011,np.where(coa1exp002re<=11,-0.3477,0.0751)))
    coa1mor005to_woe = float(np.where(np.isnan(coa1mor005to),0.0681,np.where(coa1mor005to<=0,0.0681,-0.5912)))
    co01acp017cc_woe = float(np.where(np.isnan(co01acp017cc)|(co01acp017cc<0)|(co01acp017cc==999),-0.0961,np.where(co01acp017cc<=68,0.3787,-0.0961)))
    co01acp041ot_woe = float(np.where(np.isnan(co01acp041ot)|(co01acp041ot<0),-0.0293,np.where(co01acp041ot<=0,-0.0958,0.3337)))
    co01end090cc_woe = float(np.where(np.isnan(co01end090cc)|(co01end090cc<0),0.045,np.where(co01end090cc<=90,-0.2136,-0.1204)))
    co01exp002cc_woe = float(np.where(np.isnan(co01exp002cc)|(co01exp002cc<0)|(co01exp002cc==999),5e-04,np.where(co01exp002cc<=1,-0.4074,0.0743)))
    co01exp013ah_woe = float(np.where(np.isnan(co01exp013ah)|(co01exp013ah<0),-0.0419,np.where(co01exp013ah<=0,-0.0419,0.249)))
    co01mor009cc_woe = float(np.where(np.isnan(co01mor009cc)|(co01mor009cc<0),0.0111,np.where(co01mor009cc<=1,0.0381,-0.2272)))
    co01mor009in_woe = float(np.where(np.isnan(co01mor009in)|(co01mor009in<0),1e-04,np.where(co01mor009in<=0,0.2401,-0.7293)))
    co01mor033cc_woe = float(np.where(np.isnan(co01mor033cc)|(co01mor033cc<0),0.0067,np.where(co01mor033cc<=0,-0.1788,0.1206)))
    co01mor069ot_woe = float(np.where(np.isnan(co01mor069ot)|(co01mor069ot<0),-0.032,np.where(co01mor069ot<=0,0.3564,-0.2663)))
    co01num004ah_woe = float(np.where(np.isnan(co01num004ah)|(co01num004ah<0),-0.0157,np.where(co01num004ah<=0,0.0956,-0.0632)))
    co02acp002to_woe = float(np.where(np.isnan(co02acp002to)|(co02acp002to<0)|(co02acp002to==999),-0.2945,np.where(co02acp002to<=0,0.3344,np.where(co02acp002to<=3,0.2303,np.where(co02acp002to<=13,0.1393,-0.0225)))))
    co02exp007to_woe = float(np.where(np.isnan(co02exp007to)|(co02exp007to<0),0.0702,np.where(co02exp007to<=0,0.2032,np.where(co02exp007to<=50,0.0702,-0.335))))
    coa1num600to_woe = float(np.where(np.isnan(coa1num600to),0.0123,np.where(coa1num600to<=2,0.0123,-0.1804)))

    #%% salida
    out=[eval(i) for i in vars_woe]

    #%%
    return out
