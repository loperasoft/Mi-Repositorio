import numpy as np
import traceback


def main(data,vars_woe):
    #%%
    #### Calculo Crts ####
    try:
        co01acp005hp = data['CO01ACP005HP_AMAS'] if data['CO01ACP005HP_AMAS']!=-999 else np.nan
        co01acp015ro = data['CO01ACP015RO_AMAS'] if data['CO01ACP015RO_AMAS']!=-999 else np.nan
        co01end006in = data['CO01END006IN_AMAS'] if data['CO01END006IN_AMAS']!=-999 else np.nan
        co01end015ro = data['CO01END015RO_AMAS'] if data['CO01END015RO_AMAS']!=-999 else np.nan
        co01end081ro = data['CO01END081RO_AMAS'] if data['CO01END081RO_AMAS']!=-999 else np.nan
        co01end082ro = data['CO01END082RO_AMAS'] if data['CO01END082RO_AMAS']!=-999 else np.nan
        co01end084ro = data['CO01END084RO_AMAS'] if data['CO01END084RO_AMAS']!=-999 else np.nan
        co01end085ro = data['CO01END085RO_AMAS'] if data['CO01END085RO_AMAS']!=-999 else np.nan
        co01end093in = data['CO01END093IN_AMAS'] if data['CO01END093IN_AMAS']!=-999 else np.nan
        co01exp004ro = data['CO01EXP004RO_AMAS'] if data['CO01EXP004RO_AMAS']!=-999 else np.nan
        co01exp006ro = data['CO01EXP006RO_AMAS'] if data['CO01EXP006RO_AMAS']!=-999 else np.nan
        co02exp006to = data['CO02EXP006TO'] if data['CO02EXP006TO']!=-999 else np.nan
        co01mor009ro = data['CO01MOR009RO_AMAS'] if data['CO01MOR009RO_AMAS']!=-999 else np.nan
        co01mor053in = data['CO01MOR053IN_AMAS'] if data['CO01MOR053IN_AMAS']!=-999 else np.nan
        co01mor054ro = data['CO01MOR054RO_AMAS'] if data['CO01MOR054RO_AMAS']!=-999 else np.nan
        co01mor068cc = data['CO01MOR068CC_AMAS'] if data['CO01MOR068CC_AMAS']!=-999 else np.nan
        co01mor087ro = np.floor(data['CO01MOR087RO_AMAS']) if data['CO01MOR087RO_AMAS']!=-999 else np.nan
        co02end015cb = data['CO02END015CB_AMAS'] if data['CO02END015CB_AMAS']!=-999 else np.nan
        co02end024cb = data['CO02END024CB_AMAS'] if data['CO02END024CB_AMAS']!=-999 else np.nan
        co02end026cb = data['CO02END026CB_AMAS'] if data['CO02END026CB_AMAS']!=-999 else np.nan
        co02end035cb = data['CO02END035CB_AMAS'] if data['CO02END035CB_AMAS']!=-999 else np.nan
        co02num019to = data['CO02NUM019TO'] if data['CO02NUM019TO']!=-999 else np.nan
        co02num036to = data['CO02NUM036TO'] if data['CO02NUM036TO']!=-999 else np.nan
        co02num043ro = np.floor(data['CO02NUM043RO_AMAS']) if data['CO02NUM043RO_AMAS']!=-999 else np.nan
        co01acp016cc = data['CO01ACP016CC_AMAS'] if data['CO01ACP016CC_AMAS']!=-999 else np.nan
        co02end040ro = data['CO02END040RO_AMAS'] if data['CO02END040RO_AMAS']!=-999 else np.nan
        co02num042in = np.floor(data['CO02NUM042IN_AMAS']) if data['CO02NUM042IN_AMAS']!=-999 else np.nan
        co01end093ro = data['CO01END093RO_AMAS'] if data['CO01END093RO_AMAS']!=-999 else np.nan
        co01exp010ah = data['CO01EXP010AH'] if data['CO01EXP010AH']!=-999 else np.nan
        co01exp011ct = data['CO01EXP011CT'] if data['CO01EXP011CT']!=-999 else np.nan
    
        coa1end001cc = data['CO01END001CC_AMAS'] if data['CO01END001CC_AMAS']!=-999 else np.nan
        coa1exp002fi = data['CO01EXP002FI_AMAS'] if data['CO01EXP002FI_AMAS']!=-999 else np.nan
        coa1exp002to = data['CO01EXP002TO'] if data['CO01EXP002TO']!=-999 else np.nan
    except Exception, error:
        tb = traceback.format_exc()
        # logger.error("!!! Error: {}, {}".format(error, tb))
        assert False, "!!! Error: {}, {}".format(error, tb)
    #%%
    #### Woe Cs ####
    co01acp005hp_woe = float(np.where(np.isnan(co01acp005hp)|(co01acp005hp<0),-0.0845,np.where(co01acp005hp<=0,0.318,-0.0845)))
    co01acp015ro_woe = float(np.where(np.isnan(co01acp015ro)|(co01acp015ro<0),-0.3009,np.where(co01acp015ro<=1,-0.0439,np.where(co01acp015ro<=2,0.1811,np.where(co01acp015ro<=3,0.2477,0.4093)))))
    co01end006in_woe = float(np.where(np.isnan(co01end006in)|(co01end006in<0),-0.0148,np.where(co01end006in<=0.11,0.2068,-0.0148)))
    co01end015ro_woe = float(np.where(np.isnan(co01end015ro)|(co01end015ro<0),-0.1536,np.where(co01end015ro<=0.06,-0.6567,np.where(co01end015ro<=2.14,-0.1536,np.where(co01end015ro<=3.01,0.2842,np.where(co01end015ro<=6.2,0.5463,0.8462))))))
    co01end081ro_woe = float(np.where(np.isnan(co01end081ro)|(co01end081ro<0),-0.164,np.where(co01end081ro<=0,-0.164,np.where(co01end081ro<=1,0.2318,np.where(co01end081ro<=2,0.4731,0.6232)))))
    co01end082ro_woe = float(np.where(np.isnan(co01end082ro)|(co01end082ro<0),-0.0864,np.where(co01end082ro<=0,-0.0864,np.where(co01end082ro<=1,0.2397,0.3895))))
    co01end084ro_woe = float(np.where(np.isnan(co01end084ro)|(co01end084ro<0),-0.0565,np.where(co01end084ro<=0,0.2235,np.where(co01end084ro<=2,-0.0565,np.where(co01end084ro<=3,-0.1341,-0.2441)))))
    co01end085ro_woe = float(np.where(np.isnan(co01end085ro)|(co01end085ro<0),0.1737,np.where(co01end085ro<=0,0.1737,np.where(co01end085ro<=1,-0.2345,-0.5756))))
    co01end093in_woe = float(np.where(np.isnan(co01end093in)|(co01end093in<0),-0.0574,np.where(co01end093in<=1.04,-0.1978,np.where(co01end093in<=24.11,-0.0574,np.where(co01end093in<=31.13,0.1252,np.where(co01end093in<=48.98,0.2716,0.3951))))))
    co01exp004ro_woe = float(np.where(np.isnan(co01exp004ro)|(co01exp004ro<0)|(co01exp004ro==999),-0.1882,np.where(co01exp004ro<=1,-0.1882,np.where(co01exp004ro<=15,-0.1122,np.where(co01exp004ro<=21,-0.0154,np.where(co01exp004ro<=75,0.0961,0.3751))))))
    co01exp006ro_woe = float(np.where(np.isnan(co01exp006ro)|(co01exp006ro<0),-0.5833,np.where(co01exp006ro<=12,-0.5833,np.where(co01exp006ro<=70,-0.0632,np.where(co01exp006ro<=85,0.2414,np.where(co01exp006ro<=97,0.4179,0.7285))))))
    co01mor009ro_woe = float(np.where(np.isnan(co01mor009ro),-0.1147,np.where(co01mor009ro<=0,0.1894,np.where(co01mor009ro<=1,-0.1147,np.where(co01mor009ro<=2,-0.2616,-0.501)))))
    co01mor053in_woe = float(np.where(np.isnan(co01mor053in)|(co01mor053in<0),-0.2212,np.where(co01mor053in<=0,0.1437,-0.4956)))
    co01mor054ro_woe = float(np.where(np.isnan(co01mor054ro),-0.0608,np.where(co01mor054ro<=0,-0.602,np.where(co01mor054ro<=1,-0.0608,0.2082))))
    co01mor068cc_woe = float(np.where(np.isnan(co01mor068cc)|(co01mor068cc<0),-0.1128,np.where(co01mor068cc<=0,-0.1128,np.where(co01mor068cc<=1,0.1567,0.2942))))
    co01mor087ro_woe = float(np.where(np.isnan(co01mor087ro)|(co01mor087ro<0),0.0933,np.where(co01mor087ro<=0,0.0933,-0.6045)))
    co02end015cb_woe = float(np.where(np.isnan(co02end015cb)|(co02end015cb<0),0.0974,np.where(co02end015cb<=0.25,0.0974,-0.6238)))
    co02end024cb_woe = float(np.where(np.isnan(co02end024cb)|(co02end024cb==-1)|(co02end024cb==-2)|(co02end024cb==-3)|(co02end024cb==-4)|(co02end024cb==-5)|(co02end024cb==-11)|(co02end024cb==-88)|(co02end024cb==-99),0.0839,np.where(co02end024cb<=-21.04,0.3241,np.where(co02end024cb<=3.09,0.0839,np.where(co02end024cb<=32.62,-0.1706,-0.3396)))))
    co02end026cb_woe = float(np.where(np.isnan(co02end026cb)|(co02end026cb==-1)|(co02end026cb==-2)|(co02end026cb==-3)|(co02end026cb==-4)|(co02end026cb==-5)|(co02end026cb==-11)|(co02end026cb==-88)|(co02end026cb==-99),-0.1878,np.where(co02end026cb<=-37.86,0.4399,np.where(co02end026cb<=16.51,0.1235,np.where(co02end026cb<=37.89,-0.1878,np.where(co02end026cb<=93.03,-0.2738,-0.4255))))))
    co02end035cb_woe = float(np.where(np.isnan(co02end035cb)|(co02end035cb==-1)|(co02end035cb==-2)|(co02end035cb==-3)|(co02end035cb==-4)|(co02end035cb==-5)|(co02end035cb==-11)|(co02end035cb==-88)|(co02end035cb==-99),-0.193,np.where(co02end035cb<=-1.44,0.2346,np.where(co02end035cb<=16.39,0.1231,np.where(co02end035cb<=61.29,-0.0458,np.where(co02end035cb<=123.08,-0.2823,-0.4348))))))
    co02exp006to_woe = float(np.where(np.isnan(co02exp006to)|(co02exp006to<0),-0.6395,np.where(co02exp006to<=18,-0.6395,np.where(co02exp006to<=56,-0.0956,np.where(co02exp006to<=77,0.272,0.5444)))))
    co02num019to_woe = float(np.where(np.isnan(co02num019to),0.0596,np.where(co02num019to<=0,0.0596,-0.5562)))
    co02num036to_woe = float(np.where(np.isnan(co02num036to)|(co02num036to<0),-0.1247,np.where(co02num036to<=0,-0.2855,np.where(co02num036to<=1,0.1595,0.2143))))
    co02num043ro_woe = float(np.where(np.isnan(co02num043ro),0.0332,np.where(co02num043ro<=31,-0.3571,np.where(co02num043ro<=66,0.0332,np.where(co02num043ro<=75,0.3897,0.5682)))))
    coa1end001cc_woe = float(np.where(np.isnan(coa1end001cc)|(coa1end001cc<0),-0.0579,np.where(coa1end001cc<=0,0.2264,np.where(coa1end001cc<=29,0.1244,np.where(coa1end001cc<=42,0.0309,-0.0579)))))
    coa1exp002fi_woe = float(np.where(np.isnan(coa1exp002fi),-0.0977,np.where(coa1exp002fi<=64,-0.4278,np.where(coa1exp002fi<=187,-0.0977,np.where(coa1exp002fi<=275,0.1638,0.4728)))))
    coa1exp002to_woe = float(np.where(np.isnan(coa1exp002to),-0.0888,np.where(coa1exp002to<=83,-0.4935,np.where(coa1exp002to<=207,-0.0888,np.where(coa1exp002to<=258,0.135,np.where(coa1exp002to<=313,0.243,0.4602))))))
    co01acp016cc_woe = float(np.where(np.isnan(co01acp016cc)|(co01acp016cc<0),-0.1369,np.where(co01acp016cc<=0,-0.1369,np.where(co01acp016cc<=1,0.0912,np.where(co01acp016cc<=2,0.1535,0.2434)))))
    co02end040ro_woe = float(np.where(np.isnan(co02end040ro)|(co02end040ro==-1)|(co02end040ro==-2)|(co02end040ro==-3)|(co02end040ro==-4)|(co02end040ro==-5)|(co02end040ro==-11)|(co02end040ro==-88)|(co02end040ro==-99),0.0923,np.where(co02end040ro<=-26.39,0.4159,np.where(co02end040ro<=-6.9,0.0923,-0.1041))))
    co02num042in_woe = float(np.where(np.isnan(co02num042in)|(co02num042in<0),-0.189,np.where(co02num042in<=20,0.1225,np.where(co02num042in<=33,0.0064,np.where(co02num042in<=50,-0.095,-0.3178)))))
    co01end093ro_woe = float(np.where(np.isnan(co01end093ro)|(co01end093ro<0),-0.0702,np.where(co01end093ro<=5.65,-0.5161,np.where(co01end093ro<=38.92,-0.0702,np.where(co01end093ro<=45.84,0.3046,np.where(co01end093ro<=56.02,0.4703,0.603))))))
    co01exp010ah_woe = float(np.where(np.isnan(co01exp010ah)|(co01exp010ah<0),0.111,np.where(co01exp010ah<=0,0.111,np.where(co01exp010ah<=1,-0.1204,-0.3096))))
    co01exp011ct_woe = float(np.where(np.isnan(co01exp011ct)|(co01exp011ct<0),0.0252,np.where(co01exp011ct<=0,0.298,-0.24)))

    #%% salida
    out=[eval(i) for i in vars_woe]

    #%%
    return out
