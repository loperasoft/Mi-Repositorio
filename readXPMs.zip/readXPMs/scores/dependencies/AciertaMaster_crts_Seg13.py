import numpy as np
import traceback


def main(data,vars_woe):

    #%%
    #### Calculo Crts ####
    try:
        co02end015cb = data['CO02END015CB_AMAS'] if data['CO02END015CB_AMAS']!=-999 else np.nan
        co01mor009cc = data['CO01MOR009CC_AMAS'] if data['CO01MOR009CC_AMAS']!=-999 else np.nan
        co01end010ro = data['CO01END010RO_AMAS'] if data['CO01END010RO_AMAS']!=-999 else np.nan
        co02exp006to = data['CO02EXP006TO'] if data['CO02EXP006TO']!=-999 else np.nan
        co01exp002ah = data['CO01EXP002AH'] if data['CO01EXP002AH']!=-999 else np.nan
        co01end073ro = data['CO01END073RO_AMAS'] if data['CO01END073RO_AMAS']!=-999 else np.nan
        co02end001in = data['CO02END001IN_AMAS'] if data['CO02END001IN_AMAS']!=-999 else np.nan
        co01end086ro = data['CO01END086RO_AMAS'] if data['CO01END086RO_AMAS']!=-999 else np.nan
        co01end089ro = data['CO01END089RO_AMAS'] if data['CO01END089RO_AMAS']!=-999 else np.nan
        co02num003to = data['CO02NUM003TO'] if data['CO02NUM003TO']!=-999 else np.nan
        co01exp004cc = data['CO01EXP004CC_AMAS'] if data['CO01EXP004CC_AMAS']!=-999 else np.nan
        co02end008cb = data['CO02END008CB_AMAS'] if data['CO02END008CB_AMAS']!=-999 else np.nan
        co02end033ro = data['CO02END033RO_AMAS'] if data['CO02END033RO_AMAS']!=-999 else np.nan
        co01acp003ro = data['CO01ACP003RO_AMAS'] if data['CO01ACP003RO_AMAS']!=-999 else np.nan
        co01end059ro = data['CO01END059RO_AMAS'] if data['CO01END059RO_AMAS']!=-999 else np.nan
        co01end077ro = data['CO01END077RO_AMAS'] if data['CO01END077RO_AMAS']!=-999 else np.nan
        co01exp002ro = data['CO01EXP002RO_AMAS'] if data['CO01EXP002RO_AMAS']!=-999 else np.nan
        co02num042cb = data['CO02NUM042CB_AMAS'] if data['CO02NUM042CB_AMAS']!=-999 else np.nan
    
        coa1num600to = data['CO01NUM600TO_AMAS'] if data['CO01NUM600TO_AMAS']!=-999 else np.nan
    except Exception, error:
        tb = traceback.format_exc()
        # logger.error("!!! Error: {}, {}".format(error, tb))
        assert False, "!!! Error: {}, {}".format(error, tb)

    #%%
    #### Woe Cs ####
    co02end015cb_woe = float(np.where(np.isnan(co02end015cb)|(co02end015cb<0),-0.5419,np.where(co02end015cb<=0,0.0657,-0.5419)))
    co01end086ro_woe = float(np.where(np.isnan(co01end086ro)|(co01end086ro<0),0.1296,np.where(co01end086ro<=33.42,0.8341,np.where(co01end086ro<=91.55,0.1296,np.where(co01end086ro<=95.74,-0.215,-0.462)))))
    co01end089ro_woe = float(np.where(np.isnan(co01end089ro),-0.1912,np.where(co01end089ro<=26.86,0.9899,np.where(co01end089ro<=82.92,0.2302,np.where(co01end089ro<=87.64,-0.1912,-0.4643)))))
    co02exp006to_woe = float(np.where(np.isnan(co02exp006to)|(co02exp006to<0),-0.388,np.where(co02exp006to<=7,-0.388,np.where(co02exp006to<=14,-0.1567,np.where(co02exp006to<=20,0.0331,0.2657)))))
    co02num003to_woe = float(np.where(np.isnan(co02num003to)|(co02num003to<0),-0.1951,np.where(co02num003to<=7,0.0464,-0.1951)))
    co01end010ro_woe = float(np.where(np.isnan(co01end010ro)|(co01end010ro<0),-0.3609,np.where(co01end010ro<=0.03,-0.3609,np.where(co01end010ro<=1.15,-0.0347,np.where(co01end010ro<=1.76,0.3274,0.6578)))))
    co01exp004cc_woe = float(np.where(np.isnan(co01exp004cc)|(co01exp004cc<0)|(co01exp004cc==999),-0.0673,np.where(co01exp004cc<=1,-0.0673,np.where(co01exp004cc<=37,0.0231,0.3816))))
    co02end008cb_woe = float(np.where(np.isnan(co02end008cb)|(co02end008cb<0),-0.0246,np.where(co02end008cb<=2.98,0.2657,-0.0246)))
    co02end033ro_woe = float(np.where(np.isnan(co02end033ro)|(co02end033ro==-1)|(co02end033ro==-2)|(co02end033ro==-3)|(co02end033ro==-4)|(co02end033ro==-5)|(co02end033ro==-11)|(co02end033ro==-88)|(co02end033ro==-99),0.0336,np.where(co02end033ro<=-62.5,0.2897,np.where(co02end033ro<=127.27,0.0336,-0.2485))))
    co01end073ro_woe = float(np.where(np.isnan(co01end073ro)|(co01end073ro<0),-0.2794,np.where(co01end073ro<=45.44,0.5507,np.where(co01end073ro<=97.06,0.0207,-0.2794))))
    co01acp003ro_woe = float(np.where(np.isnan(co01acp003ro),0.03,np.where(co01acp003ro<=0,0.1984,np.where(co01acp003ro<=1,0.03,-0.1339))))
    co01end059ro_woe = float(np.where(np.isnan(co01end059ro)|(co01end059ro<0),-0.1929,np.where(co01end059ro<=0.14,-0.1929,np.where(co01end059ro<=1.78,0.0882,0.2504))))
    co01end077ro_woe = float(np.where(np.isnan(co01end077ro)|(co01end077ro<0),-0.2979,np.where(co01end077ro<=43.32,0.6305,np.where(co01end077ro<=85.15,0.1965,np.where(co01end077ro<=93.14,-0.1223,-0.2979)))))
    co01exp002ah_woe = float(np.where(np.isnan(co01exp002ah)|(co01exp002ah<0)|(co01exp002ah==999),-0.189,np.where(co01exp002ah<=8,-0.189,np.where(co01exp002ah<=23,-0.0259,np.where(co01exp002ah<=51,0.1237,0.2702)))))
    co02end001in_woe = float(np.where(np.isnan(co02end001in)|(co02end001in==-1)|(co02end001in==-2)|(co02end001in==-3)|(co02end001in==-4)|(co02end001in==-5)|(co02end001in==-11)|(co02end001in==-88)|(co02end001in==-99),0.0642,np.where(co02end001in<=16.37,-0.2291,np.where(co02end001in<=46.53,0.0864,0.4445))))
    co02num042cb_woe = float(np.where(np.isnan(co02num042cb),0.1291,np.where(co02num042cb<=33.33,0.4801,np.where(co02num042cb<=66.67,0.1291,-0.1182))))
    coa1num600to_woe = float(np.where(np.isnan(coa1num600to),0.0235,np.where(coa1num600to<=1,-0.2336,0.0235)))
    co01mor009cc_woe = float(np.where(np.isnan(co01mor009cc)|(co01mor009cc<0),-0.0733,np.where(co01mor009cc<=0,0.093,-0.2443)))
    co01exp002ro_woe = float(np.where(np.isnan(co01exp002ro),-0.0508,np.where(co01exp002ro<=0,-0.2478,np.where(co01exp002ro<=10,-0.0508,np.where(co01exp002ro<=13,0.0717,0.242)))))

    #%% salida
    out=[eval(i) for i in vars_woe]

    #%%
    return out
