import numpy as np
import traceback


def main(data,vars_woe):

    #%%
    #### Calculo Crts ####
    try:
        co02end035cb = data['CO02END035CB_AMAS'] if data['CO02END035CB_AMAS']!=-999 else np.nan#CO02END035RO_AMAS
        co01exp004ro = data['CO01EXP004RO_AMAS'] if data['CO01EXP004RO_AMAS']!=-999 else np.nan
        co02exp006to = data['CO02EXP006TO'] if data['CO02EXP006TO']!=-999 else np.nan
        co02end024cb = data['CO02END024CB_AMAS'] if data['CO02END024CB_AMAS']!=-999 else np.nan# CO02END024RO_AMAS
        co02end015cb = data['CO02END015CB_AMAS'] if data['CO02END015CB_AMAS']!=-999 else np.nan
        co01end093ro = data['CO01END093RO_AMAS'] if data['CO01END093RO_AMAS']!=-999 else np.nan
        co02num043cb = data['CO02NUM043CB_AMAS'] if data['CO02NUM043CB_AMAS']!=-999 else np.nan
        co01acp005ah = data['CO01ACP005AH'] if data['CO01ACP005AH']!=-999 else np.nan
        co01acp041ot = data['CO01ACP041OT_AMAS'] if data['CO01ACP041OT_AMAS']!=-999 else np.nan
        co01end025ro = data['CO01END025RO_AMAS'] if data['CO01END025RO_AMAS']!=-999 else np.nan
        co01end073ro = data['CO01END073RO_AMAS'] if data['CO01END073RO_AMAS']!=-999 else np.nan
        co01end076ro = data['CO01END076RO_AMAS'] if data['CO01END076RO_AMAS']!=-999 else np.nan
        co01mor048cc = data['CO01MOR048CC_AMAS'] if data['CO01MOR048CC_AMAS']!=-999 else np.nan
        co01mor061in = data['CO01MOR061IN_AMAS'] if data['CO01MOR061IN_AMAS']!=-999 else np.nan
        co01mor069cc = data['CO01MOR069CC_AMAS'] if data['CO01MOR069CC_AMAS']!=-999 else np.nan
        co01mor069ot = data['CO01MOR069OT_AMAS'] if data['CO01MOR069OT_AMAS']!=-999 else np.nan
        co02end001in = data['CO02END001IN_AMAS'] if data['CO02END001IN_AMAS']!=-999 else np.nan
        co02end002ot = data['CO02END002OT_AMAS'] if data['CO02END002OT_AMAS']!=-999 else np.nan
        co02end006ro = data['CO02END006RO_AMAS'] if data['CO02END006RO_AMAS']!=-999 else np.nan#CO02END006RO_AMAS CO02END006IN_AMAS
        co02end033cb = data['CO02END033CB_AMAS'] if data['CO02END033CB_AMAS']!=-999 else np.nan#CO02END033CB_AMAS CO02END033IN_AMAS
        co02exp013cc = data['CO02EXP013CC_AMAS'] if data['CO02EXP013CC_AMAS']!=-999 else np.nan
        co02num043ro = np.floor(data['CO02NUM043RO_AMAS']) if data['CO02NUM043RO_AMAS']!=-999 else np.nan
        co02exp010to = np.floor(data['CO02EXP010TO']) if data['CO02EXP010TO']!=-999 else np.nan
    
        coa1exp001fi = data['CO01EXP001FI_AMAS'] if data['CO01EXP001FI_AMAS']!=-999 else np.nan
    except Exception, error:
        tb = traceback.format_exc()
        # logger.error("!!! Error: {}, {}".format(error, tb))
        assert False, "!!! Error: {}, {}".format(error, tb)

    #%%
    #### Woe Cs ####
    co01end076ro_woe = float(np.where(np.isnan(co01end076ro)|(co01end076ro<0),-0.0386,np.where(co01end076ro<=20.43,0.8274,np.where(co01end076ro<=80.39,0.276,np.where(co01end076ro<=94.21,-0.1605,np.where(co01end076ro<=99.72,-0.4648,-0.6086))))))
    co02end035cb_woe = float(np.where(np.isnan(co02end035cb)|(co02end035cb==-1)|(co02end035cb==-2)|(co02end035cb==-3)|(co02end035cb==-4)|(co02end035cb==-5)|(co02end035cb==-11)|(co02end035cb==-88)|(co02end035cb==-99),-0.0818,np.where(co02end035cb<=-51.52,0.408,np.where(co02end035cb<=25.57,0.182,np.where(co02end035cb<=51.43,0.0098,np.where(co02end035cb<=132.14,-0.0818,-0.2804))))))
    co02end033cb_woe = float(np.where(np.isnan(co02end033cb)|(co02end033cb==-1)|(co02end033cb==-2)|(co02end033cb==-3)|(co02end033cb==-4)|(co02end033cb==-5)|(co02end033cb==-11)|(co02end033cb==-88)|(co02end033cb==-99),-0.0604,np.where(co02end033cb<=-32.5,0.3308,np.where(co02end033cb<=14.49,0.096,np.where(co02end033cb<=74.81,-0.0604,-0.3069)))))
    co01mor069cc_woe = float(np.where(np.isnan(co01mor069cc)|(co01mor069cc<0),-0.1533,np.where(co01mor069cc<=0,0.2401,-0.2473)))
    co02exp010to_woe = float(np.where(np.isnan(co02exp010to)|(co02exp010to<0),0.0317,np.where(co02exp010to<=33,0.3873,np.where(co02exp010to<=75,0.2681,np.where(co02exp010to<=88,0.0317,-0.213)))))
    co01exp004ro_woe = float(np.where(np.isnan(co01exp004ro)|(co01exp004ro<0)|(co01exp004ro==999),-0.0405,np.where(co01exp004ro<=1,-0.2241,np.where(co01exp004ro<=9,-0.0405,np.where(co01exp004ro<=28,0.1216,0.3941)))))
    co02exp006to_woe = float(np.where(np.isnan(co02exp006to)|(co02exp006to<0),-0.0905,np.where(co02exp006to<=8,-0.505,np.where(co02exp006to<=27,-0.0905,np.where(co02exp006to<=41,0.24,0.4591)))))
    co02num043cb_woe = float(np.where(np.isnan(co02num043cb),-0.0297,np.where(co02num043cb<=14.29,-0.2443,np.where(co02num043cb<=50,-0.0297,np.where(co02num043cb<=68.18,0.2212,0.4774)))))
    co01acp005ah_woe = float(np.where(np.isnan(co01acp005ah)|(co01acp005ah<0),-0.065,np.where(co01acp005ah<=0,0.2127,np.where(co01acp005ah<=1,-0.1294,-0.3377))))
    coa1exp001fi_woe = float(np.where(np.isnan(coa1exp001fi)|(coa1exp001fi<0),-0.0879,np.where(coa1exp001fi<=5,-0.3995,np.where(coa1exp001fi<=25,0.0492,0.246))))
    co02end001in_woe = float(np.where(np.isnan(co02end001in)|(co02end001in==-1)|(co02end001in==-2)|(co02end001in==-3)|(co02end001in==-4)|(co02end001in==-5)|(co02end001in==-11)|(co02end001in==-88)|(co02end001in==-99),0.049,np.where(co02end001in<=3.73,-0.2521,np.where(co02end001in<=39.74,-0.0822,np.where(co02end001in<=69.81,0.049,0.4293)))))
    co01end073ro_woe = float(np.where(np.isnan(co01end073ro)|(co01end073ro<0),-0.0875,np.where(co01end073ro<=32.04,0.5991,np.where(co01end073ro<=72.1,0.2175,np.where(co01end073ro<=95.15,-0.0875,-0.3214)))))
    co02end024cb_woe = float(np.where(np.isnan(co02end024cb)|(co02end024cb==-1)|(co02end024cb==-2)|(co02end024cb==-3)|(co02end024cb==-4)|(co02end024cb==-5)|(co02end024cb==-11)|(co02end024cb==-88)|(co02end024cb==-99),0.0453,np.where(co02end024cb<=-39.12,0.4259,np.where(co02end024cb<=0,0.0453,-0.1931))))
    co01acp041ot_woe = float(np.where(np.isnan(co01acp041ot)|(co01acp041ot<0),-0.0452,np.where(co01acp041ot<=0,0.018,0.2717)))
    co01end025ro_woe = float(np.where(np.isnan(co01end025ro)|(co01end025ro<0),-0.0651,np.where(co01end025ro<=0.15,-0.5586,np.where(co01end025ro<=1.25,-0.0651,np.where(co01end025ro<=1.98,0.2832,np.where(co01end025ro<=3.72,0.5007,0.7203))))))
    co02end015cb_woe = float(np.where(np.isnan(co02end015cb)|(co02end015cb<0),0.0569,np.where(co02end015cb<=0,0.0569,-0.5912)))
    co02exp013cc_woe = float(np.where(np.isnan(co02exp013cc)|(co02exp013cc<0),0.0178,np.where(co02exp013cc<=0,-0.1004,0.4491)))
    co02num043ro_woe = float(np.where(np.isnan(co02num043ro)|(co02num043ro<0),-0.0625,np.where(co02num043ro<=14,-0.0625,np.where(co02num043ro<=33,0.0376,np.where(co02num043ro<=50,0.2244,0.4286)))))
    co01mor048cc_woe = float(np.where(np.isnan(co01mor048cc)|(co01mor048cc<0),-0.0951,np.where(co01mor048cc<=0,0.0861,-0.3567)))
    co01mor061in_woe = float(np.where(np.isnan(co01mor061in)|(co01mor061in<0),-0.0678,np.where(co01mor061in<=0,0.0338,0.2967)))
    co01mor069ot_woe = float(np.where(np.isnan(co01mor069ot)|(co01mor069ot<0),-0.0409,np.where(co01mor069ot<=0,0.1953,-0.182)))
    co02end002ot_woe = float(np.where(np.isnan(co02end002ot)|(co02end002ot==-1)|(co02end002ot==-2)|(co02end002ot==-3)|(co02end002ot==-4)|(co02end002ot==-5)|(co02end002ot==-11)|(co02end002ot==-88)|(co02end002ot==-99),0.0259,np.where(co02end002ot<=23,-0.2187,0.1131)))
    co02end006ro_woe = float(np.where(np.isnan(co02end006ro)|(co02end006ro<0),0.0237,np.where(co02end006ro<=18.41,-0.0935,np.where(co02end006ro<=30.52,0.0237,0.3369))))
    co01end093ro_woe = float(np.where(np.isnan(co01end093ro)|(co01end093ro<0),-0.0759,np.where(co01end093ro<=5.98,-0.5115,np.where(co01end093ro<=38.56,-0.0759,np.where(co01end093ro<=68.5,0.3649,0.7504)))))

    #%% salida
    out=[eval(i) for i in vars_woe]

    #%%
    return out
