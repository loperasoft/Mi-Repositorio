import numpy as np
from numpy.lib.recfunctions import append_fields
from datetime import datetime as dt
import sys
import math
from collections import Counter
import warnings

def segmentador_fin(data):

    if data['CO01END001TO_AMAS']==-999:   # Inactivo
        if data['CO01EXP001FI_AMAS'] >= 18 and np.isfinite(data['CO01EXP001FI_AMAS']):
            segmento = 6
        elif data['CO02END015CB_AMAS'] > 1 or data['CO02END015CB_AMAS'] < 0 or data['CO02END015CB_AMAS']==-999:
            segmento = 15.2
        else:
            segmento = 15.1
    else:         #No inactivo
        if data['CO01EXP001FI_AMAS'] < 14.8167 or data['CO01EXP001FI_AMAS']==-999:
            if data['CO02MOR046TO'] < 0.5 or data['CO02MOR046TO']==-999:
                if data['CO01END001RO_AMAS']>=96.5 and data['CO01END001RO_AMAS']==-999:
                    segmento = 13
                elif data['CO01END001RO_AMAS'] < 96.5 or data['CO01END001RO_AMAS']==-999:
                    segmento = 7.9
            else:
                segmento = 16
        elif data['CO01EXP001FI_AMAS'] < 36.2053:
            if data['CO01MOR006FI_AMAS'] < 0.5 or data['CO01MOR006FI_AMAS']:
                if data['CO01END001RO_AMAS']>= 83.5 and data['CO01END001RO_AMAS']==-999:
                    segmento = 7.9
                elif data['CO01END001RO_AMAS'] < 83.5 or np.isnan(data['CO01END001RO_AMAS']):
                    segmento = 3
            else:
                segmento = 16
        elif data['CO01EXP001FI_AMAS'] >= 36.2053:
            if data['CO01MOR005TO_AMAS'] < 0.5 or data['CO01MOR005TO_AMAS']==-999:
                if data['CO01END001RO_AMAS'] >= 71.5 and data['CO01END001RO_AMAS']==-999:
                    segmento = 2
                elif data['CO01END001RO_AMAS'] < 71.5 or data['CO01END001RO_AMAS']:
                    segmento = 1
            elif data['CO01MOR005TO_AMAS'] >= 0.5:
                segmento = 10
    
    return segmento

def score_seg_0(exc):
    switcher = {
        70: '0',
        71: '0',
        72: '0',
        73: '3',
        74: '4',
        75: '1',
    }
    return switcher.get(exc, 0)