# coding=utf-8
# Cargar librerias y funciones custom
from scores.dependencies.AciertaMaster_Funciones import segmentador_fin, score_seg_0
import scores.dependencies.AciertaMaster_crts_Seg01 as seg01
import scores.dependencies.AciertaMaster_crts_Seg02 as seg02
import scores.dependencies.AciertaMaster_crts_Seg03 as seg03
import scores.dependencies.AciertaMaster_crts_Seg06 as seg06
import scores.dependencies.AciertaMaster_crts_Seg07_09 as seg07_09
import scores.dependencies.AciertaMaster_crts_Seg10 as seg10
import scores.dependencies.AciertaMaster_crts_Seg13 as seg13
import scores.dependencies.AciertaMaster_crts_Seg15_1 as seg15_1
import scores.dependencies.AciertaMaster_crts_Seg15_2 as seg15_2
import scores.dependencies.AciertaMaster_crts_Seg16 as seg16
import traceback
import numpy as np
import copy
import time
try:
    import sklearn
except Exception:
    pass


# Ignorar la warning que no representa riesgo
#warnings.filterwarnings("ignore", r'All-NaN (slice|axis) encountered')

def get_score(data, model_name, sub_model,_models):
    variables_predictoras = []
    #  Lectura archivo y formacion lista
    #start_time = dt.now()
    if data.get('TIPOID') in (2, 3):
        exclusion = 70
    elif (data['CO02NUM136MX'] == 0) & (data['CO01NUM002CT_AMAS'] == 0) & (data['CO01NUM002CO_AMAS'] == 0):#OJO CON CO01NUM002CB_AMAS
        exclusion = 71
    elif (data['CO02NUM136MX'] == 0) & (data['CO01NUM002CT_AMAS'] > 0) & (data['CO01NUM002CO_AMAS'] == 0):
        exclusion = 72
    elif (data['CO00DEM001'] == 1) | (data['CO00DEM002'] == 1):
        exclusion = 73
    elif (data['CO02NUM136MX'] == 0) & (data['CO01NUM002CO_AMAS'] > 0):
        exclusion = 74
    elif (data['CO01MOR134TO'] > 0) & (data['CO01MOR135TO'] == 0) & (data['CO01NUM001TO_AMAS'] >= 2):#SE CAMBIO OJO
        exclusion = 75
    else:
        exclusion = 99

    # Segmentacion
    if exclusion == 99:
        segmento = segmentador_fin(data)
    else:
        segmento = 0

    if ('segmento' not in locals()) or (segmento not in [0, 1, 2, 3, 6, 7.9, 10, 13, 15.1, 15.2, 16]):
        exclusion = 92  # Devolver exclusion 92 Mala segmentacion
        score = '0'
    elif segmento == 0:
        score = score_seg_0(exclusion)
    else:
        nombres = []
        #logger.info('Scores dictionary received AciertaMaster')
        #logger.info('Calculating hybrid attributes AciertaMaster')
        #logger.info('Preparing predictor variables')
        if segmento == 1:
            vars_seg01 = ["co01mor071ro", "co01end071ro", "co01exp006in", "co01mor009in", "co02exp007to", "co02end034in",
                          "co01acp041in",
                          "co00dem003", "coa1exp001to", "co02exp006to", "co01mor033cc", "co01exp009ah", "co01mor075ro",
                          "co01num005in", "co02num019to",
                          "co01acp042in", "co01end030ro", "co02end019cb", "co02num057cb", "coa1exp003fi", "coa1mor001to",
                          "co01acp015in", "co01exp005ro",
                          "co01exp013cc", "co01mor009cc", "co02exp009in", "coa1mor006to"]
            nombres = [s + '_woe' for s in vars_seg01]
            variables_predictoras = seg01.main(data, nombres)
        elif segmento == 2:
            vars_seg02 = ["co01acp005hp", "co01acp015ro", "co01end006in", "co01end015ro", "co01end081ro", "co01end082ro",
                          "co01end084ro",
                          "co01end085ro", "co01end093in", "co01exp004ro", "co01exp006ro", "co01mor009ro", "co01mor053in",
                          "co01mor054ro", "co01mor068cc",
                          "co01mor087ro", "co02end015cb", "co02end024cb", "co02end026cb", "co02end035cb", "co02exp006to",
                          "co02num019to", "co02num036to",
                          "co02num043ro", "coa1end001cc", "coa1exp002fi", "coa1exp002to", "co01acp016cc", "co02end040ro",
                          "co02num042in", "co01end093ro",
                          "co01exp010ah", "co01exp011ct"]
            nombres = [s + '_woe' for s in vars_seg02]
            variables_predictoras = seg02.main(data,nombres)
        elif segmento == 3:
            vars_seg03 = ["co01end071ro", "coa1mor001to", "co00dem003", "co02end003in", "co01end018in", "co01mor067in",
                          "co02num072cb",
                          "co02end034cb", "co01end088ro", "co01end010ro", "co02end015cb", "co02exp010to", "coa1exp002fi",
                          "co01mor009cc", "co01exp003ah",
                          "co01acp006ah", "coa1mor006to", "co01mor061cc", "co02end001cb", "coa1end001fi", "co01acp042in",
                          "co02num043cb", "co01mor009ro",
                          "co01end093in", "co02exp005to"]
            nombres = [s + '_woe' for s in vars_seg03]
            variables_predictoras = seg03.main(data,nombres)
        elif segmento == 6:
            vars_seg06 = ["co00dem003", "co01mor062in", "co01mor074ro", "co01mor053in", "co02num029to", "co01mor067in",
                          "co01mor072ro",
                          "co01acp008ro", "coa1num002cp", "co01mor056in", "co01mor071cc", "co01mor067ro", "co01exp002ah",
                          "co01acp014ro", "co01mor047ro",
                          "co01acp005ro"]
            nombres = [s + '_woe' for s in vars_seg06]
            variables_predictoras = seg06.main(data,nombres)
        elif segmento == 7.9:
            vars_seg07_09 = ["co01end076ro", "co02end035cb", "co02end033cb", "co01mor069cc", "co02exp010to", "co01exp004ro",
                             "co02exp006to",
                             "co02num043cb", "co01acp005ah", "coa1exp001fi", "co02end001in", "co01end073ro", "co02end024cb",
                             "co01acp041ot", "co01end025ro",
                             "co02end015cb", "co02exp013cc", "co02num043ro", "co01mor048cc", "co01mor061in", "co01mor069ot",
                             "co02end002ot", "co02end006ro",
                             "co01end093ro"]
            nombres = [s + '_woe' for s in vars_seg07_09]
            variables_predictoras = seg07_09.main(data,nombres)
        elif segmento == 10:
            vars_seg10 = ["co01mor076in", "co02end028cb", "co01mor034in", "co01end004ro", "co01mor002in", "co02end015cb",
                          "co00dem003",
                          "co02end034cb", "co01end087ro", "co01end022ro", "co01end010ro", "co01end066in", "coa1num002cp",
                          "co01exp001ro", "co02exp011to",
                          "co01mor009ve", "co01exp004ro", "coa1exp001to", "co02num043cb", "co01end012in", "co01end022ve"]
            nombres = [s + '_woe' for s in vars_seg10]
            variables_predictoras = seg10.main(data,nombres)
        elif segmento == 13:
            vars_seg13 = ["co02end015cb", "co01end086ro", "co01end089ro", "co02exp006to", "co02num003to", "co01end010ro",
                          "co01exp004cc",
                          "co02end008cb", "co02end033ro", "co01end073ro", "co01acp003ro", "co01end059ro", "co01end077ro",
                          "co01exp002ah", "co01exp002ro",
                          "co02end001in", "co02num042cb", "coa1num600to", "co01mor009cc"]
            nombres = [s + '_woe' for s in vars_seg13]
            variables_predictoras = seg13.main(data, nombres)
        if segmento == 15.1:
            vars_seg15_1 = ["co00dem003", "co01end010ro", "co01end039ro", "co01end071ro", "co01end076ro", "co01end093in",
                            "co01end093ro",
                            "co01exp002in", "co01exp004ah", "co01mor069in", "co02end001ot", "co02end006cb", "co02end024cb",
                            "co02exp004to", "co02num029to",
                            "co02num036to", "co02num043cb", "co02num072cb", "coa1exp003fi", "coa1mor995cp"]
            nombres = [s + '_woe' for s in vars_seg15_1]
            variables_predictoras = seg15_1.main(data, nombres)
        elif segmento == 15.2:
            vars_seg15_2 = ["co00dem003", "co01end089ro", "co01exp008ah", "co01mor053cc", "co01mor055ot", "co02end016cb",
                            "co02num029to",
                            "coa1exp001fi", "coa1exp002re", "coa1mor005to", "co01acp017cc", "co01acp041ot", "co01end090cc",
                            "co01exp002cc", "co01exp013ah",
                            "co01mor009cc", "co01mor009in", "co01mor033cc", "co01mor069ot", "co01num004ah", "co02acp002to",
                            "co02exp007to", "coa1num600to"]
            nombres = [s + '_woe' for s in vars_seg15_2]
            variables_predictoras = seg15_2.main(data, nombres)
        elif segmento == 16:
            vars_seg16 = ["coa1mor995cp", "co02end015cb", "co01mor076ro", "co01mor008in", "co01end012in", "co01end071ro",
                          "co01end015ro",
                          "co02end035cb", "co01end030ro", "coa1num002cp", "co01mor002ro", "coa1exp001to", "co01exp006ro",
                          "co01end003ot", "co01exp001ro",
                          "co02end001cb", "co01exp004ro", "co02end024in", "co01mor068ro", "co02end044ro", "co01end088ro",
                          "co01end093ro", "co01mor062in",
                          "co01mor016in"]
            nombres = [s + '_woe' for s in vars_seg16]
            variables_predictoras = seg16.main(data, nombres)

    mensaje = {'segmento': segmento, 'variables': variables_predictoras}
    try:
        #logger.info('Calculating scores based in the models')
        score = calculate_score(model_name, sub_model, mensaje,_models)
        if segmento == 1:
            score = int(round(0.527928144252845 * float(score) + 457.931754161832))
        elif segmento == 2:
            score = int(round(0.495476047043189 * float(score) + 315.147825442153))
        elif segmento == 3:
            score = int(round(0.46653068 * float(score) + 423.868543))
        elif segmento == 6:
            score = int(round(0.5440769 * float(score) + 316.6142782))
        elif segmento == 7.9:
            score = int(round(0.4978935 * float(score) + 355.8246329))
        elif segmento == 10:
            score = int(round(0.49547605 * float(score) + 315.1478254))
        elif segmento == 13:
            score = int(round(0.40975036 * float(score) + 340.9458596))
        elif segmento == 15.1:
            score = int(round(0.40763491 * float(score) + 317.0196692))
        elif segmento == 15.2:
            score = int(round(0.7387294 * float(score) + 134.7747553))
        elif segmento == 16:
            score = int(round(0.50816529 * float(score) + 244.2294867))
        else:
            score = -1

        score = str(score)
    except Exception, error:
        tb = traceback.format_exc()
        # logger.error("!!! Error: {}, {}".format(error, tb))
        assert False, "!!! Error: {}, {}".format(error, tb)
        # Probar que el modelo haya devuelto un score valido
    try:
        #logger.info('Validating the model has returned a valid score')
        if float(score) < 0:
            exclusion = 93  # Devolver exlusion 93 No retorna Score Valido
            score = '0'
        elif float(score) < 150 and float(score) not in (0, 1, 3, 4):  # Cota inferior
            score = '150'
        elif float(score) > 999:  # Cota superior
            score = '999'
    except ValueError, error:
        tb = traceback.format_exc()
        # logger.error("!!! Error: {}, {}".format(error, tb))
        exclusion = 93  # Devolver exlusion 93 No retorna Score Valido
        score = '0'
        assert False, "!!! Error: {}, {}".format(error, tb)
    #print('Tiempo R: ' + str(dt.now() - python_time) + ' segundos')

    ##############################################################

    # Generacion salida y escritura en archivo
    #logger.info('Score AciertaMaster calculated succesfully')
    salida = {'TIPOID': data.get('TIPOID'),'scoreCode':'V9','scoreName':'667','scoreValue': str(int(score)), 'scoreSegment': str(float(segmento)), 'exclusionCode': [str(int(exclusion))],'scoreDate':int(round(time.time() * 1000)),'relation':'0','tradeHolderIndicator':'0'}

    #print('Tiempo: ' + str(dt.now() - start_time) + ' segundos')
    return salida

def calculate_score(model_name, sub_model, data,_models):
    """Calculates the score based on the given model and data.

    Parameters
    ----------
    model_name : str
        The name of the model being used.
    sub_model : str
        The name of the sub-model being used.
    data : dict
        A dictionary containing the required data for the score.

    Returns
    -------
    str
        a string containing the resulting score.

    """
    segment = data['segmento']
    vec = data['variables']
    vec = np.asarray(vec).reshape(1, -1)
    segment = "{}".format(segment)
    if segment != "0":
        model = copy.deepcopy(_models[segment])
        result = model.predict_proba(vec)
        result = int(round(result[0, 1] * 1000))
    else:
        result = 0

    return str(result)
