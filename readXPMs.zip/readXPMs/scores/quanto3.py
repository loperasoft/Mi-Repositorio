from scores.dependencies.quanto3_base import Quanto3Base
import time


class Quanto3(Quanto3Base):
    """
    Quanto 3 Score main class. Predicts the income of an individual based
    on its financial information stored by the financial bureau.
    """
    def __init__(self):
        Quanto3Base.__init__(self)

    def __call__(self, data):
        """
        Calculate the respective score card according to the obtained
        individual segmentation.
        """
        self.initBase(data)
        self.ver_exclusiones_daqu3()
        if self.con_exclusion_daqu3 == 0:
            self.ver_score_card_daqu3()

        result = {
            "TIPOID": data.get('TIPOID'),
            "exclusionCode": self.adverse_razon_daqu3,
            "scoreCode": "O4",
            "scoreName": "Quanto3",
            "scoreSegment": self.score_card_daqu3,
            "scoreDate": int(round(time.time() * 1000)),
            "relation": "0",
            "tradeHolderIndicator": "0",
            "incomeSMLMV": self.ingreso_daqu3,
            "lowerIncomeSMLMV": self.ingreso_inf_daqu3,
            "upperIncomeSMLMV": self.ingreso_sup_daqu3,
            "incomeCOP": self.ingreso_pesos_daqu3,
            "lowerIncomeCOP": self.ingreso_pesos_inf_daqu3,
            "upperIncomeCOP": self.ingreso_pesos_sup_daqu3
        }

        return result

    def ver_score_card_daqu3(self):
        """
        Run the respective score card according to the obtained values
        for the nodos, nodes, and grupos variables.
        """
        self.adverse_razon_daqu3[0] = 79
        self.calcular_num_port_daqu3()
        self.calcular_nodos_daqu3()
        self.calcular_node_daqu3()
        self.calcular_grupos_daqu3()

        if self.poblacion_daqu3 == "NOTEC":
            if self.nodo_daqu3 == 1:
                if self.grupo_daqu3 == 1:
                    self.score_card01_daqu3()
                elif self.grupo_daqu3 == 2:
                    self.score_card02_daqu3()
                elif self.grupo_daqu3 == 3:
                    self.score_card03_daqu3()
                elif self.grupo_daqu3 == 4:
                    self.score_card04_daqu3()

            elif self.nodo_daqu3 == 2:
                if self.grupo_daqu3 == 1:
                    self.score_card05_daqu3()
                elif self.grupo_daqu3 == 2:
                    self.score_card06_daqu3()
                elif self.grupo_daqu3 == 3:
                    self.score_card07_daqu3()
                elif self.grupo_daqu3 == 4:
                    self.score_card08_daqu3()

            elif self.nodo_daqu3 == 3:
                if self.grupo_daqu3 == 1:
                    self.score_card09_daqu3()
                elif self.grupo_daqu3 == 2:
                    self.score_card10_daqu3()
                elif self.grupo_daqu3 == 3:
                    self.score_card11_daqu3()
                elif self.grupo_daqu3 == 4:
                    self.score_card12_daqu3()
                elif self.grupo_daqu3 == 5:
                    self.score_card13_daqu3()

            elif self.nodo_daqu3 == 4:
                if self.grupo_daqu3 == 1:
                    self.score_card14_daqu3()
                elif self.grupo_daqu3 == 2:
                    self.score_card15_daqu3()
                elif self.grupo_daqu3 == 3:
                    self.score_card16_daqu3()
                elif self.grupo_daqu3 == 4:
                    self.score_card17_daqu3()
                elif self.grupo_daqu3 == 5:
                    self.score_card18_daqu3()

            elif self.nodo_daqu3 == 5:
                if self.grupo_daqu3 == 1:
                    self.score_card19_daqu3()
                elif self.grupo_daqu3 == 2:
                    self.score_card20_daqu3()
                elif self.grupo_daqu3 == 3:
                    self.score_card21_daqu3()
                elif self.grupo_daqu3 == 4:
                    self.score_card22_daqu3()
                elif self.grupo_daqu3 == 5:
                    self.score_card23_daqu3()
                elif self.grupo_daqu3 == 6:
                    self.score_card24_daqu3()

        if self.poblacion_daqu3 == "TEC":
            if self.nodo_daqu3 == 1:
                if self.grupo_daqu3 == 1:
                    self.score_card25_daqu3()
                elif self.grupo_daqu3 == 2:
                    self.score_card26_daqu3()
                elif self.grupo_daqu3 == 3:
                    self.score_card27_daqu3()
                elif self.grupo_daqu3 == 4:
                    self.score_card28_daqu3()

            elif self.nodo_daqu3 == 2:
                if self.grupo_daqu3 == 1:
                    self.score_card29_daqu3()
                elif self.grupo_daqu3 == 2:
                    self.score_card30_daqu3()
                elif self.grupo_daqu3 == 3:
                    self.score_card31_daqu3()

            elif self.nodo_daqu3 == 3:
                if self.grupo_daqu3 == 1:
                    self.score_card32_daqu3()
                elif self.grupo_daqu3 == 2:
                    self.score_card33_daqu3()
                elif self.grupo_daqu3 == 3:
                    self.score_card34_daqu3()

            elif self.nodo_daqu3 == 4:
                if self.grupo_daqu3 == 1:
                    self.score_card35_daqu3()
                elif self.grupo_daqu3 == 2:
                    self.score_card36_daqu3()
                elif self.grupo_daqu3 == 3:
                    self.score_card37_daqu3()

        if self.poblacion_daqu3 == "TIPO5":
            if self.grupo_daqu3 == 1:
                self.score_card38_daqu3()
            elif self.grupo_daqu3 == 2:
                self.score_card39_daqu3()
            elif self.grupo_daqu3 == 3:
                self.score_card40_daqu3()
            elif self.grupo_daqu3 == 4:
                self.score_card41_daqu3()

    def score_card01_daqu3(self):
        """
        Computes Score Card 01
        """
        self.inicializa_variables()
        self.score_card_daqu3 = 1
        self.adverse_razon_daqu3[0] = 99

        # Scpecial Attributes
        attributes = ["CO00DEM006", "CO01END028IN", "CO01END036IN", "CO01END041IN", "CO01END056IN",
                      "CO01NUM005RO", "CO02END002CB", "CO02END003IN", "CO02END005CB", "CO02END007IN",
                      "CO02END012CB", "CO02END014CB", "CO02NUM004TO", "CO02NUM037TO", "CO02NUM037TO",
                      "CO02NUM038TO", "COQ1END001TO", "COQ1END002IN", "COQ1END006IN", "COQ1END014TC",
                      "COQ1EXP002TC", "COQ1END010IN"]

        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        self.sectores_daqu3()
        if self.q3_telcos == 999:
            self.q3_telcos = -1

        self.cuotatotal_daqu3()
        if self.q3_cuotatotal == 999:
            self.q3_cuotatotal = -1.0

        if self.q3_prcuotatotalro == 999:
            self.q3_prcuotatotalro = -1.0

        Q3_QTOT = self.qtot_daqu3()
        Q3_QTOTAB = self.qtotab_daqu3()
        if Q3_QTOT > 0:
            Q3_PROQTOTAB = round(Q3_QTOTAB / Q3_QTOT, 4)  # ROUNDED
        else:
            Q3_PROQTOTAB = -1.0

        if Q3_PROQTOTAB == 999:
            Q3_PROQTOTAB = -1.0

        # Acotaciones
        if self.data["CO00DEM006"] > 1:      self.data["CO00DEM006"] = 1
        if self.q3_telcos > 1:          self.q3_telcos = 1
        if self.data["CO01END028IN"] > 0.29:  self.data["CO01END028IN"] = 0.29
        if self.data["CO01END036IN"] > 0.26:  self.data["CO01END036IN"] = 0.26
        if self.data["CO01END041IN"] > 4.18:  self.data["CO01END041IN"] = 4.18
        if self.data["CO01END056IN"] > 0.26:  self.data["CO01END056IN"] = 0.26
        if self.data["CO01NUM005RO"] > 2:     self.data["CO01NUM005RO"] = 2
        if self.data["CO02END002CB"] > 34.54: self.data["CO02END002CB"] = 34.54
        if self.data["CO02END003IN"] > 35.85: self.data["CO02END003IN"] = 35.85
        if self.data["CO02END005CB"] > 45.6:  self.data["CO02END005CB"] = 45.6
        if self.data["CO02END007IN"] > 19.35: self.data["CO02END007IN"] = 19.35
        if self.data["CO02END012CB"] > 123.76: self.data["CO02END012CB"] = 123.76
        if self.data["CO02END014CB"] > 114.76: self.data["CO02END014CB"] = 114.76
        if self.data["CO02NUM004TO"] > 1:  self.data["CO02NUM004TO"] = 1
        if self.data["CO02NUM037TO"] > 1: self.data["CO02NUM037TO"] = 1
        if self.data["CO02NUM037TO"] > 1: self.data["CO02NUM037TO"] = 1
        if self.data["CO02NUM038TO"] > 1: self.data["CO02NUM038TO"] = 1
        if self.q3_cuotatotal > 0.3: self.q3_cuotatotal = 0.3
        if self.data["COQ1END001TO"] > 528.33: self.data["COQ1END001TO"] = 528.33
        if self.data["COQ1END002IN"] > 153: self.data["COQ1END002IN"] = 153
        if self.data["COQ1END006IN"] > 3504: self.data["COQ1END006IN"] = 3504
        if self.data["COQ1END014TC"] > 2200: self.data["COQ1END014TC"] = 2200
        if self.data["COQ1EXP002TC"] > 53: self.data["COQ1EXP002TC"] = 53
        if self.q3_prcuotatotalro > 1:  self.q3_prcuotatotalro = 1.0
        if Q3_PROQTOTAB > 1: Q3_PROQTOTAB = 1.0
        if self.data["COQ1END010IN"] > 4892.5: self.data["COQ1END010IN"] = 4892.5

        # binarias: Creacion
        if 0.16 < self.data["CO01END028IN"] <= 0.28:
            Q3_S01_CO01END028IN_3 = 1
        else:
            Q3_S01_CO01END028IN_3 = 0

        if 0.28 < self.data["CO01END028IN"] <= 0.29:
            Q3_S01_CO01END028IN_4 = 1
        else:
            Q3_S01_CO01END028IN_4 = 0

        if 0 <= self.data["CO01END036IN"] <= 0.16:
            Q3_S01_CO01END036IN_2 = 1
        else:
            Q3_S01_CO01END036IN_2 = 0

        if 0 <= self.data["CO01END041IN"] <= 1.99:
            Q3_S01_CO01END041IN_2 = 1
        else:
            Q3_S01_CO01END041IN_2 = 0

        if 0 <= self.data["CO01END056IN"] <= 0.21:
            Q3_S01_CO01END056IN_2 = 1
        else:
            Q3_S01_CO01END056IN_2 = 0

        if 1 < self.data["CO01NUM005RO"] <= 2:
            Q3_S01_CO01NUM005RO_4 = 1
        else:
            Q3_S01_CO01NUM005RO_4 = 0

        if 33.59 < self.data["CO02END002CB"] <= 34.54:
            Q3_S01_CO02END002CB_5 = 1
        else:
            Q3_S01_CO02END002CB_5 = 0

        if self.data["CO02END003IN"] == 999 or self.data["CO02END003IN"] < 0:
            Q3_S01_CO02END003IN_1 = 1
        else:
            Q3_S01_CO02END003IN_1 = 0

        if 17.38 < self.data["CO02END005CB"] <= 45.6:
            Q3_S01_CO02END005CB_3 = 1
        else:
            Q3_S01_CO02END005CB_3 = 0

        if 0 <= self.data["CO02END007IN"] <= 7.27:
            Q3_S01_CO02END007IN_2 = 1
        else:
            Q3_S01_CO02END007IN_2 = 0

        if self.data["CO02END012CB"] < 0:
            Q3_S01_CO02END012CB_1 = 1
        else:
            Q3_S01_CO02END012CB_1 = 0

        if self.data["CO02END014CB"] == 999 or self.data["CO02END014CB"] < 0:
            Q3_S01_CO02END014CB_1 = 1
        else:
            Q3_S01_CO02END014CB_1 = 0

        if 0 < self.data["CO02NUM004TO"] <= 1:
            Q3_S01_CO02NUM004TO_3 = 1
        else:
            Q3_S01_CO02NUM004TO_3 = 0

        if 0 <= self.data["CO02NUM037TO"] <= 0:
            Q3_S01_CO02NUM037TO_2 = 1
        else:
            Q3_S01_CO02NUM037TO_2 = 0

        if 0 < self.data["CO02NUM037TO"] <= 1:
            Q3_S01_CO02NUM037TO_3 = 1
        else:
            Q3_S01_CO02NUM037TO_3 = 0

        if self.data["CO02NUM038TO"] < 0:
            Q3_S01_CO02NUM038TO_1 = 1
        else:
            Q3_S01_CO02NUM038TO_1 = 0

        if self.q3_cuotatotal < 0:
            Q3_S01_CUOTATOTAL_1 = 1
        else:
            Q3_S01_CUOTATOTAL_1 = 0

        if 450 < self.data["COQ1END001TO"] <= 528.33:
            Q3_S01_COQ1END001TO_5 = 1
        else:
            Q3_S01_COQ1END001TO_5 = 0

        if 108 < self.data["COQ1END002IN"] <= 135:
            Q3_S01_COQ1END002IN_4 = 1
        else:
            Q3_S01_COQ1END002IN_4 = 0

        if 135 < self.data["COQ1END002IN"] <= 153:
            Q3_S01_COQ1END002IN_5 = 1
        else:
            Q3_S01_COQ1END002IN_5 = 0

        if 3032.4 < self.data["COQ1END006IN"] <= 3504:
            Q3_S01_COQ1END006IN_5 = 1
        else:
            Q3_S01_COQ1END006IN_5 = 0

        if 2029 < self.data["COQ1END014TC"] <= 2200:
            Q3_S01_COQ1END014TC_3 = 1
        else:
            Q3_S01_COQ1END014TC_3 = 0

        if self.data["COQ1EXP002TC"] < 0:
            Q3_S01_COQ1EXP002TC_1 = 1
        else:
            Q3_S01_COQ1EXP002TC_1 = 0

        if 0 < self.q3_prcuotatotalro <= 1:
            Q3_S01_PRCUOTATOTALRO_3 = 1
        else:
            Q3_S01_PRCUOTATOTALRO_3 = 0

        if 0 <= Q3_PROQTOTAB <= 0:
            Q3_S01_PROQTOTAB_2 = 1
        else:
            Q3_S01_PROQTOTAB_2 = 0

        if 412 < self.data["COQ1END010IN"] <= 3344.75:
            Q3_S01_COQ1END010IN_3 = 1
        else:
            Q3_S01_COQ1END010IN_3 = 0

        # Categoricas: Creacion
        Q3_S01_CO00DEM006VS_C = 0.0
        if self.data["CO00DEM006"] < 0:
            Q3_S01_CO00DEM006VS_C = 0.0
        elif self.data["CO00DEM006"] == 0:
            Q3_S01_CO00DEM006VS_C = 1.0
        elif self.data["CO00DEM006"] == 1:
            Q3_S01_CO00DEM006VS_C = 2.0

        Q3_S01_TELCOS_C = 0.0
        if self.q3_telcos < 0:
            Q3_S01_TELCOS_C = 0.0
        elif self.q3_telcos == 0:
            Q3_S01_TELCOS_C = 1.0
        elif self.q3_telcos == 1:
            Q3_S01_TELCOS_C = 2.0

        if self.data["CO01NUM002CC"] > 0:
            Q3_S01_TELECOM = 1
        else:
            Q3_S01_TELECOM = 0

        Q3_S01_EXPONENTE = (0.21265 +
                            Q3_S01_TELECOM * 0.05513 +
                            Q3_S01_CO00DEM006VS_C * -0.02506 +
                            Q3_S01_TELCOS_C * 0.04869 +
                            Q3_S01_CO01END028IN_3 * 0.09101 +
                            Q3_S01_CO01END028IN_4 * 0.18616 +
                            Q3_S01_CO01END036IN_2 * 0.02364 +
                            Q3_S01_CO01END041IN_2 * -0.03409 +
                            Q3_S01_CO01END056IN_2 * -0.02626 +
                            Q3_S01_CO01NUM005RO_4 * 0.04546 +
                            Q3_S01_CO02END002CB_5 * 0.02658 +
                            Q3_S01_CO02END003IN_1 * 0.01213 +
                            Q3_S01_CO02END005CB_3 * 0.0308 +
                            Q3_S01_CO02END007IN_2 * -0.01627 +
                            Q3_S01_CO02END012CB_1 * 0.03584 +
                            Q3_S01_CO02END014CB_1 * 0.02553 +
                            Q3_S01_CO02NUM004TO_3 * 0.05053 +
                            Q3_S01_CO02NUM037TO_2 * 0.0329 +
                            Q3_S01_CO02NUM037TO_3 * -0.02223 +
                            Q3_S01_CO02NUM038TO_1 * 0.02307 +
                            Q3_S01_CUOTATOTAL_1 * -0.06556 +
                            Q3_S01_COQ1END001TO_5 * 0.06832 +
                            Q3_S01_COQ1END002IN_4 * 0.03417 +
                            Q3_S01_COQ1END002IN_5 * 0.06434 +
                            Q3_S01_COQ1END006IN_5 * -0.03364 +
                            Q3_S01_COQ1END014TC_3 * 0.03812 +
                            Q3_S01_COQ1EXP002TC_1 * -0.02383 +
                            Q3_S01_PRCUOTATOTALRO_3 * 0.05233 +
                            Q3_S01_PROQTOTAB_2 * 0.05851 +
                            Q3_S01_COQ1END010IN_3 * 0.01055)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S01_EXPONENTE, 2)  # ROUNDED
        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card02_daqu3(self):
        """
        Computes Score Card 02
        """
        # SCORE-CARD PARA : .NOTEC. and NODO = 1 and GRUPO = 2
        self.inicializa_variables()
        self.score_card_daqu3 = 2
        self.adverse_razon_daqu3[0] = 99

        # CARACTERISTICAS HIBRIDAS
        # FINANCIERO
        self.sectores_daqu3()

        # CARACTERISTICAS PERSONALIZADAS QUANTO 3
        # PROCESO DE EVALUACION DE ALGUNAS VARIABLES
        attributes = ["COQ1END001TO", "COQ1NUM002TC", "CO02EXP001TO", "CO02NUM002TO", "CO01ACP007CO",
                      "CO01ACP017IN", "CO01ACP017RO", "CO01END023CC", "CO01END026IN", "CO01END028IN",
                      "CO01MOR001CC", "CO01NUM001CC", "CO01NUM001RO", "CO01NUM005AH", "CO02END006CB",
                      "CO02END008IN", "CO02END010IN", "CO02END011CB", "CO02NUM043AH", "COQ1END001TO",
                      "COQ1NUM002TC"]
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        if self.q3_financiero == 999:
            self.q3_financiero = -1.0

        # Dimensioning
        if self.data["CO02EXP001TO"] > 201:
            self.data["CO02EXP001TO"] = 201

        if self.data["CO02NUM002TO"] > 3:
            self.data["CO02NUM002TO"] = 3

        if self.q3_financiero > 1:
            self.q3_financiero = 1

        if self.data["CO01ACP007CO"] > 1:
            self.data["CO01ACP007CO"] = 1

        if self.data["CO01ACP017IN"] > 78:
            self.data["CO01ACP017IN"] = 78

        if self.data["CO01ACP017RO"] > 42:
            self.data["CO01ACP017RO"] = 42

        if self.data["CO01END023CC"] > 0.04:
            self.data["CO01END023CC"] = 0.04

        if self.data["CO01END026IN"] > 2.58699999999983:
            self.data["CO01END026IN"] = 2.58699999999983

        if self.data["CO01END028IN"] > 0.41:
            self.data["CO01END028IN"] = 0.41

        if self.data["CO01MOR001CC"] > 1:
            self.data["CO01MOR001CC"] = 1

        if self.data["CO01NUM001CC"] > 3:
            self.data["CO01NUM001CC"] = 3

        if self.data["CO01NUM001RO"] > 2:
            self.data["CO01NUM001RO"] = 2

        if self.data["CO01NUM005AH"] > 2:
            self.data["CO01NUM005AH"] = 2

        if self.data["CO02END006CB"] > 18.4769999999998:
            self.data["CO02END006CB"] = 18.4769999999998

        if self.data["CO02END008IN"] > 19.08:
            self.data["CO02END008IN"] = 19.08

        if self.data["CO02END010IN"] > 17.9569999999998:
            self.data["CO02END010IN"] = 17.9569999999998

        if self.data["CO02END011CB"] > 13.18:
            self.data["CO02END011CB"] = 13.18

        if self.data["CO02NUM043AH"] > 100:
            self.data["CO02NUM043AH"] = 100

        if self.data["COQ1END001TO"] > 680:
            self.data["COQ1END001TO"] = 680

        if self.data["COQ1NUM002TC"] > 3:
            self.data["COQ1NUM002TC"] = 3

        # Binary Attributes
        if self.data["CO01ACP007CO"] == 0:
            Q3_S02_CO01ACP007CO_2 = 1
        else:
            Q3_S02_CO01ACP007CO_2 = 0

        if self.data["CO01ACP017IN"] < 0:
            Q3_S02_CO01ACP017IN_1 = 1
        else:
            Q3_S02_CO01ACP017IN_1 = 0

        if 27 < self.data["CO01ACP017RO"] <= 42:
            Q3_S02_CO01ACP017RO_3 = 1
        else:
            Q3_S02_CO01ACP017RO_3 = 0

        if 0.03 < self.data["CO01END023CC"] <= 0.04:
            Q3_S02_CO01END023CC_3 = 1
        else:
            Q3_S02_CO01END023CC_3 = 0

        if 1.61 < self.data["CO01END026IN"] <= 2.58699999999983:
            Q3_S02_CO01END026IN_3 = 1
        else:
            Q3_S02_CO01END026IN_3 = 0

        if 0.34 < self.data["CO01END028IN"] <= 0.41:
            Q3_S02_CO01END028IN_3 = 1
        else:
            Q3_S02_CO01END028IN_3 = 0

        if 0 <= self.data["CO01MOR001CC"] <= 0:
            Q3_S02_CO01MOR001CC_2 = 1
        else:
            Q3_S02_CO01MOR001CC_2 = 0

        if 0 <= self.data["CO01NUM001CC"] <= 1:
            Q3_S02_CO01NUM001CC_2 = 1
        else:
            Q3_S02_CO01NUM001CC_2 = 0

        if 1 < self.data["CO01NUM001CC"] <= 2:
            Q3_S02_CO01NUM001CC_3 = 1
        else:
            Q3_S02_CO01NUM001CC_3 = 0

        if 1 < self.data["CO01NUM001RO"] <= 2:
            Q3_S02_CO01NUM001RO_3 = 1
        else:
            Q3_S02_CO01NUM001RO_3 = 0

        if 0 <= self.data["CO01NUM005AH"] <= 0:
            Q3_S02_CO01NUM005AH_2 = 1
        else:
            Q3_S02_CO01NUM005AH_2 = 0

        if 0 < self.data["CO01NUM005AH"] <= 1:
            Q3_S02_CO01NUM005AH_3 = 1
        else:
            Q3_S02_CO01NUM005AH_3 = 0

        if 10.16 < self.data["CO02END006CB"] <= 18.4769999999998:
            Q3_S02_CO02END006CB_3 = 1
        else:
            Q3_S02_CO02END006CB_3 = 0

        if 0 <= self.data["CO02END008IN"] <= 17.84:
            Q3_S02_CO02END008IN_2 = 1
        else:
            Q3_S02_CO02END008IN_2 = 0

        if 0 <= self.data["CO02END010IN"] <= 16.15:
            Q3_S02_CO02END010IN_2 = 1
        else:
            Q3_S02_CO02END010IN_2 = 0

        if 16.15 < self.data["CO02END010IN"] <= 17.9569999999998:
            Q3_S02_CO02END010IN_3 = 1
        else:
            Q3_S02_CO02END010IN_3 = 0

        if 0 <= self.data["CO02END011CB"] <= 12.95:
            Q3_S02_CO02END011CB_2 = 1
        else:
            Q3_S02_CO02END011CB_2 = 0

        if 50 < self.data["CO02NUM043AH"] <= 100:
            Q3_S02_CO02NUM043AH_4 = 1
        else:
            Q3_S02_CO02NUM043AH_4 = 0

        if 0 <= self.data["COQ1END001TO"] <= 336.67:
            Q3_S02_COQ1END001TO_2 = 1
        else:
            Q3_S02_COQ1END001TO_2 = 0

        if 336.67 < self.data["COQ1END001TO"] <= 680:
            Q3_S02_COQ1END001TO_3 = 1
        else:
            Q3_S02_COQ1END001TO_3 = 0

        if 0 <= self.data["COQ1NUM002TC"] <= 2:
            Q3_S02_COQ1NUM002TC_2 = 1
        else:
            Q3_S02_COQ1NUM002TC_2 = 0

        if 2 < self.data["COQ1NUM002TC"] <= 3:
            Q3_S02_COQ1NUM002TC_3 = 1
        else:
            Q3_S02_COQ1NUM002TC_3 = 0

        # Binary Attributes

        Q3_S02_FINANCIERO_C = 0.0
        if self.q3_financiero < 0:
            Q3_S02_FINANCIERO_C = 0.0
        elif self.q3_financiero == 0:
            Q3_S02_FINANCIERO_C = 1.0
        elif self.q3_financiero == 1:
            Q3_S02_FINANCIERO_C = 2.0

        Q3_MAXIMO_CUPO_TOT = self.calcula_maximo_cupo_tot()

        if Q3_MAXIMO_CUPO_TOT < 0:
            Q3_MAXIMO_CUPO_TOT = -2

        if Q3_MAXIMO_CUPO_TOT == self.data["COQ1END003HP"]:
            Q3_S02_MAXCUPO_HP = 1
        else:
            Q3_S02_MAXCUPO_HP = 0

        if Q3_MAXIMO_CUPO_TOT == self.data["COQ1END003IN"]:
            Q3_S02_MAXCUPO_IN = 1
        else:
            Q3_S02_MAXCUPO_IN = 0

        if self.data["CO01NUM002RO"] > 0:
            Q3_S02_TDC = 1
        else:
            Q3_S02_TDC = 0

        if self.data["CO01NUM002HP"] > 0:
            Q3_S02_HIPOTECARIO = 1
        else:
            Q3_S02_HIPOTECARIO = 0

        if self.data["CO01NUM002CC"] > 0:  # ERROR
            Q3_S02_TELECOM = 1
        else:
            Q3_S02_TELECOM = 0

        Q3_S02_EXPONENTE = (0.2871 +
                            Q3_S02_MAXCUPO_HP * 0.08734 +
                            Q3_S02_MAXCUPO_IN * 0.06412 +
                            Q3_S02_TDC * 0.08196 +
                            Q3_S02_HIPOTECARIO * -0.06579 +
                            Q3_S02_TELECOM * 0.13893 +
                            self.data["CO02EXP001TO"] * 0.00043657 +
                            self.data["CO02NUM002TO"] * 0.01461 +
                            Q3_S02_FINANCIERO_C * 0.03665 +
                            Q3_S02_CO01ACP007CO_2 * 0.02216 +
                            Q3_S02_CO01ACP017IN_1 * -0.01256 +
                            Q3_S02_CO01ACP017RO_3 * -0.03034 +
                            Q3_S02_CO01END023CC_3 * 0.12139 +
                            Q3_S02_CO01END026IN_3 * 0.11276 +
                            Q3_S02_CO01END028IN_3 * 0.22781 +
                            Q3_S02_CO01MOR001CC_2 * -0.2304 +
                            Q3_S02_CO01NUM001CC_2 * 0.02924 +
                            Q3_S02_CO01NUM001CC_3 * 0.05047 +
                            Q3_S02_CO01NUM001RO_3 * 0.03289 +
                            Q3_S02_CO01NUM005AH_2 * 0.04111 +
                            Q3_S02_CO01NUM005AH_3 * 0.01022 +
                            Q3_S02_CO02END006CB_3 * -0.02523 +
                            Q3_S02_CO02END008IN_2 * -0.04042 +
                            Q3_S02_CO02END010IN_2 * -0.03516 +
                            Q3_S02_CO02END010IN_3 * -0.01915 +
                            Q3_S02_CO02END011CB_2 * -0.0379 +
                            Q3_S02_CO02NUM043AH_4 * -0.02298 +
                            Q3_S02_COQ1END001TO_2 * -0.11772 +
                            Q3_S02_COQ1END001TO_3 * -0.01459 +
                            Q3_S02_COQ1NUM002TC_2 * -0.01893 +
                            Q3_S02_COQ1NUM002TC_3 * 0.0651)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S02_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card03_daqu3(self):
        """
        Computes Score Card 03
        """
        # NOTEC NODO = 1 and GRUPO = 3
        self.inicializa_variables()
        self.score_card_daqu3 = 3
        self.adverse_razon_daqu3[0] = 99

        # CARACTERISTICAS HIBRIDAS
        self.cuotatotal_daqu3()

        attributes = ["COQ1NUM002TC", "COQ1END014TC", "CO02END006CB", "CO01NUM005RO", "CO01END025RO",
                      "CO01NUM001RO", "CO01MOR001CC", "CO01END009RO", "CO01END029RO", "CO01ACP017RO",
                      "CO01END028IN", "CO02NUM002TO", "CO02EXP001TO"]

        # VALORES ESPECIALES
        for key in attributes:
            if self.data_o[key] == 999:  # CO01END029RO ERROR
                self.data[key] = -1.0

        if self.q3_cuotatotal == 999:
            self.q3_cuotatotal = -1.0

        # Dimensioning
        if self.data["COQ1NUM002TC"] > 4:
            self.data["COQ1NUM002TC"] = 4

        if self.data["COQ1END014TC"] > 2561:
            self.data["COQ1END014TC"] = 2561

        if self.data["CO02END006CB"] > 20.1409999999999:
            self.data["CO02END006CB"] = 20.1409999999999

        if self.q3_cuotatotal > 0.26:
            self.q3_cuotatotal = 0.26

        if self.data["CO01NUM005RO"] > 3:
            self.data["CO01NUM005RO"] = 3

        if self.data["CO01END025RO"] > 2.11:
            self.data["CO01END025RO"] = 2.11

        if self.data["CO01NUM001RO"] > 4:
            self.data["CO01NUM001RO"] = 4

        if self.data["CO01MOR001CC"] > 1:
            self.data["CO01MOR001CC"] = 1

        if self.data["CO01END009RO"] > 2.34:
            self.data["CO01END009RO"] = 2.34

        if self.data["CO01END029RO"] > 3.47:
            self.data["CO01END029RO"] = 3.47

        if self.data["CO01ACP017RO"] > 87:
            self.data["CO01ACP017RO"] = 87

        if self.data["CO01END028IN"] > 0.64:
            self.data["CO01END028IN"] = 0.64

        if self.data["CO02NUM002TO"] > 3:
            self.data["CO02NUM002TO"] = 3

        if self.data["CO02EXP001TO"] > 280:
            self.data["CO02EXP001TO"] = 280

        # Binary Attributes
        if 2 < self.data["COQ1NUM002TC"] <= 4:
            Q3_S03_COQ1NUM002TC_4 = 1
        else:
            Q3_S03_COQ1NUM002TC_4 = 0

        if self.data["COQ1END014TC"] < 0:
            Q3_S03_COQ1END014TC_1 = 1
        else:
            Q3_S03_COQ1END014TC_1 = 0

        if self.data["CO02END006CB"] < 0:
            Q3_S03_CO02END006CB_1 = 1
        else:
            Q3_S03_CO02END006CB_1 = 0

        if 0.24 < self.q3_cuotatotal <= 0.26:
            Q3_S03_CUOTATOTAL_3 = 1
        else:
            Q3_S03_CUOTATOTAL_3 = 0

        if 1 < self.data["CO01NUM005RO"] <= 2:
            Q3_S03_CO01NUM005RO_4 = 1
        else:
            Q3_S03_CO01NUM005RO_4 = 0

        if 1.46 < self.data["CO01END025RO"] <= 2.11:
            Q3_S03_CO01END025RO_3 = 1
        else:
            Q3_S03_CO01END025RO_3 = 0

        if 3 < self.data["CO01NUM001RO"] <= 4:
            Q3_S03_CO01NUM001RO_4 = 1
        else:
            Q3_S03_CO01NUM001RO_4 = 0

        if 0 < self.data["CO01MOR001CC"] <= 1:
            Q3_S03_CO01MOR001CC_3 = 1
        else:
            Q3_S03_CO01MOR001CC_3 = 0

        if self.data["CO01END009RO"] < 0:
            Q3_S03_CO01END009RO_1 = 1
        else:
            Q3_S03_CO01END009RO_1 = 0

        if 2 < self.data["CO01NUM005RO"] <= 3:
            Q3_S03_CO01NUM005RO_5 = 1
        else:
            Q3_S03_CO01NUM005RO_5 = 0

        if 3.33 < self.data["CO01END029RO"] <= 3.47:
            Q3_S03_CO01END029RO_3 = 1
        else:
            Q3_S03_CO01END029RO_3 = 0

        if 74 < self.data["CO01ACP017RO"] <= 87:
            Q3_S03_CO01ACP017RO_3 = 1
        else:
            Q3_S03_CO01ACP017RO_3 = 0

        if 0.31 < self.data["CO01END028IN"] <= 0.64:
            Q3_S03_CO01END028IN_3 = 1
        else:
            Q3_S03_CO01END028IN_3 = 0

        # Binary Attributes
        Q3_MAXIMO_CUPO_TOT = self.calcula_maximo_cupo_tot()

        if Q3_MAXIMO_CUPO_TOT < 0:
            Q3_MAXIMO_CUPO_TOT = -2

        if Q3_MAXIMO_CUPO_TOT == self.data["COQ1END003IN"]:
            Q3_S03_MAXCUPO_IN = 1
        else:
            Q3_S03_MAXCUPO_IN = 0

        Q3_S03_EXPONENTE = (0.30519 +
                            Q3_S03_MAXCUPO_IN * 0.12307 +
                            self.data["CO02EXP001TO"] * 0.00074772 +
                            self.data["CO02NUM002TO"] * 0.03458 +
                            Q3_S03_CO01END028IN_3 * 0.2942 +
                            Q3_S03_CO01ACP017RO_3 * 0.12116 +
                            Q3_S03_CO01END029RO_3 * 0.07461 +
                            Q3_S03_CO01NUM005RO_5 * 0.08476 +
                            Q3_S03_CO01END009RO_1 * -0.06333 +
                            Q3_S03_CO01MOR001CC_3 * 0.13782 +
                            Q3_S03_CO01NUM001RO_4 * 0.05614 +
                            Q3_S03_CO01END025RO_3 * 0.04886 +
                            Q3_S03_CO01NUM005RO_4 * 0.02762 +
                            Q3_S03_CUOTATOTAL_3 * 0.06481 +
                            Q3_S03_CO02END006CB_1 * 0.06362 +
                            Q3_S03_COQ1END014TC_1 * 0.04738 +
                            Q3_S03_COQ1NUM002TC_4 * 0.03604)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S03_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1
        self.cal_salida_pesos_daqu3()

    def score_card04_daqu3(self):
        """
        Computes Score Card 04
        """
        # NOTEC NODO = 1 and GRUPO = 4
        self.inicializa_variables()
        self.score_card_daqu3 = 4
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO01END092RO", "COQ1END003TC", "CO01MOR001RO", "CO01ACP017RO", "COQ1END020TC",
                      "COQ1END003IN", "CO01NUM005RO", "CO02END006CB", "CO01MOR001CC", "CO02NUM018TO",
                      "CO02NUM002TO", "CO02NUM001TO", "CO02EXP001TO"]

        # VALORES ESPECIALES
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        if self.q3_cuotatotal == 999:
            self.q3_cuotatotal = -1.0

        # Dimensioning
        COQ1END003IN_A = self.data["COQ1END003IN"]

        if self.data["CO01END092RO"] > 40.8:
            self.data["CO01END092RO"] = 40.8

        if self.data["COQ1END003TC"] > 4600:
            self.data["COQ1END003TC"] = 4600

        if self.data["CO01MOR001RO"] > 3:
            self.data["CO01MOR001RO"] = 3

        if self.q3_cuotatotal > 1.84:
            self.q3_cuotatotal = 1.84

        if self.data["CO01ACP017RO"] > 114:
            self.data["CO01ACP017RO"] = 114

        if self.data["COQ1END020TC"] > 0.99:
            self.data["COQ1END020TC"] = 0.99

        if self.data["COQ1END003IN"] > 15000:
            self.data["COQ1END003IN"] = 15000

        if self.data["CO01NUM005RO"] > 4:
            self.data["CO01NUM005RO"] = 4

        if self.data["CO02END006CB"] > 100:
            self.data["CO02END006CB"] = 100

        if self.q3_cuotatotal > 1.84:
            self.q3_cuotatotal = 1.84

        if self.data["CO01MOR001CC"] > 1:
            self.data["CO01MOR001CC"] = 1

        if self.data["CO02NUM018TO"] > 1:
            self.data["CO02NUM018TO"] = 1

        if self.data["CO02NUM002TO"] > 3:
            self.data["CO02NUM002TO"] = 3

        if self.data["CO02NUM001TO"] > 17:
            self.data["CO02NUM001TO"] = 17

        if self.data["CO02EXP001TO"] > 289:
            self.data["CO02EXP001TO"] = 289

        # Binary Attributes
        if 40.551 < self.data["CO01END092RO"] <= 40.8:
            Q3_S04_CO01END092RO_3 = 1
        else:
            Q3_S04_CO01END092RO_3 = 0

        if 3570 < self.data["COQ1END003TC"] <= 4600:
            Q3_S04_COQ1END003TC_4 = 1
        else:
            Q3_S04_COQ1END003TC_4 = 0

        if 1 < self.data["CO01MOR001RO"] <= 3:
            Q3_S04_CO01MOR001RO_3 = 1
        else:
            Q3_S04_CO01MOR001RO_3 = 0

        if 0.8 < self.q3_cuotatotal <= 1.34:
            Q3_S04_CUOTATOTAL_4 = 1
        else:
            Q3_S04_CUOTATOTAL_4 = 0

        if 70 < self.data["CO01ACP017RO"] <= 114:
            Q3_S04_CO01ACP017RO_3 = 1
        else:
            Q3_S04_CO01ACP017RO_3 = 0

        if 0 <= self.data["COQ1END020TC"] <= 0.2055:
            Q3_S04_COQ1END020TC_2 = 1
        else:
            Q3_S04_COQ1END020TC_2 = 0

        if 14997 < self.data["COQ1END003IN"] <= 15000:
            Q3_S04_COQ1END003IN_4 = 1
        else:
            Q3_S04_COQ1END003IN_4 = 0

        if 3 < self.data["CO01NUM005RO"] <= 4:
            Q3_S04_CO01NUM005RO_5 = 1
        else:
            Q3_S04_CO01NUM005RO_5 = 0

        if self.data["CO02END006CB"] < 0:
            Q3_S04_CO02END006CB_1 = 1
        else:
            Q3_S04_CO02END006CB_1 = 0

        if 1.34 < self.q3_cuotatotal <= 1.84:
            Q3_S04_CUOTATOTAL_5 = 1
        else:
            Q3_S04_CUOTATOTAL_5 = 0

        if 0 < self.data["CO01MOR001CC"] <= 1:
            Q3_S04_CO01MOR001CC_3 = 1
        else:
            Q3_S04_CO01MOR001CC_3 = 0

        # Binary Attributes

        if self.data["CO01NUM002RO"] > 0:
            Q3_S04_TDC = 1
        else:
            Q3_S04_TDC = 0

        Q3_MAXIMO_CUPO_TOT = self.calcula_maximo_cupo_tot()
        if Q3_MAXIMO_CUPO_TOT < 0:
            Q3_MAXIMO_CUPO_TOT = -2

        if Q3_MAXIMO_CUPO_TOT == COQ1END003IN_A:
            Q3_S04_MAXCUPO_IN = 1
        else:
            Q3_S04_MAXCUPO_IN = 0

        if Q3_MAXIMO_CUPO_TOT == self.data["COQ1END003HP"]:
            Q3_S04_MAXCUPO_HP = 1
        else:
            Q3_S04_MAXCUPO_HP = 0

        Q3_S04_EXPONENTE = (0.38161 +
                            Q3_S04_MAXCUPO_HP * 0.18269 +
                            Q3_S04_MAXCUPO_IN * 0.10835 +
                            Q3_S04_TDC * 0.05491 +
                            self.data["CO02EXP001TO"] * 0.00091817 +
                            self.data["CO02NUM001TO"] * 0.00322 +
                            self.data["CO02NUM002TO"] * 0.02381 +
                            self.data["CO02NUM018TO"] * -0.30016 +
                            Q3_S04_CO01MOR001CC_3 * 0.18671 +
                            Q3_S04_CUOTATOTAL_5 * 0.28615 +
                            Q3_S04_CO02END006CB_1 * 0.14828 +
                            Q3_S04_CO01NUM005RO_5 * 0.17207 +
                            Q3_S04_COQ1END003IN_4 * 0.36001 +
                            Q3_S04_COQ1END020TC_2 * 0.07279 +
                            Q3_S04_CO01ACP017RO_3 * 0.15873 +
                            Q3_S04_CUOTATOTAL_4 * 0.22823 +
                            Q3_S04_CO01MOR001RO_3 * 0.06952 +
                            Q3_S04_COQ1END003TC_4 * 0.24504 +
                            Q3_S04_CO01END092RO_3 * 0.17317)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S04_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1

        self.cal_salida_pesos_daqu3()

    def score_card05_daqu3(self):
        """
        Computes Score Card 05
        """
        # NO TEC NODO2 GRUPO 1
        self.inicializa_variables()
        self.score_card_daqu3 = 5
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO02EXP001TO", "CO02EXP006TO", "CO02NUM002TO", "CO01ACP007CO", "CO01END005IN",
                      "CO01END021IN", "CO01END028RO", "CO01END041IN", "CO01NUM001CC", "CO01NUM001RO",
                      "CO01NUM005RO", "CO02END001IN", "CO02END002CB", "CO02END004CB", "CO02END033IN",
                      "CO02NUM039TO", "COQ1END004IN", "COQ1END004TC", "COQ1EXP002IN", "COQ1NUM002TC",
                      "COQ1END007IN"]

        # VALORES ESPECIALES
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        self.sectores_daqu3()
        if self.q3_telcos == 999:
            self.q3_telcos = -1.0

        # Dimensioning
        if self.data["CO02EXP001TO"] > 180:
            self.data["CO02EXP001TO"] = 180

        if self.data["CO02EXP006TO"] > 69:
            self.data["CO02EXP006TO"] = 69

        if self.data["CO02NUM002TO"] > 3:
            self.data["CO02NUM002TO"] = 3

        if self.data["CO01END005IN"] > 0.31:
            self.data["CO01END005IN"] = 0.31

        if self.data["CO01END041IN"] > 5.25:
            self.data["CO01END041IN"] = 5.25

        if self.data["CO01NUM001CC"] > 3:
            self.data["CO01NUM001CC"] = 3

        if self.data["CO01NUM001RO"] > 3:
            self.data["CO01NUM001RO"] = 3

        if self.data["CO01NUM005RO"] > 2:
            self.data["CO01NUM005RO"] = 2

        if self.data["CO02END002CB"] > 30.61:
            self.data["CO02END002CB"] = 30.61

        if self.data["CO02END004CB"] > 42.45:
            self.data["CO02END004CB"] = 42.45

        if self.data["COQ1END004IN"] > 4000:
            self.data["COQ1END004IN"] = 4000

        if self.data["COQ1NUM002TC"] > 3:
            self.data["COQ1NUM002TC"] = 3

        if self.data["COQ1END007IN"] > 156:
            self.data["COQ1END007IN"] = 156

        if self.data["CO01ACP007CO"] > 1:
            self.data["CO01ACP007CO"] = 1

        if self.data["CO01END021IN"] > 5.29:
            self.data["CO01END021IN"] = 5.29

        if self.data["CO01END028RO"] > 0.2:
            self.data["CO01END028RO"] = 0.2

        if self.data["CO02END001IN"] > 53.967:
            self.data["CO02END001IN"] = 53.967

        if self.data["CO02END033IN"] > 0:
            self.data["CO02END033IN"] = 0

        if self.data["CO02NUM039TO"] > 1:
            self.data["CO02NUM039TO"] = 1

        if self.data["COQ1END004TC"] > 1710.7:
            self.data["COQ1END004TC"] = 1710.7

        if self.data["COQ1EXP002IN"] > 19:
            self.data["COQ1EXP002IN"] = 19

        # Binary Attributes
        if self.data["CO01ACP007CO"] == 0:
            Q3_S05_CO01ACP007CO_2 = 1
        else:
            Q3_S05_CO01ACP007CO_2 = 0

        if 0.19 < self.data["CO01END005IN"] <= 0.34:
            Q3_S05_CO01END005IN_3 = 1
        else:
            Q3_S05_CO01END005IN_3 = 0

        if 0 <= self.data["CO01END021IN"] <= 1.39:
            Q3_S05_CO01END021IN_2 = 1
        else:
            Q3_S05_CO01END021IN_2 = 0

        if 0 <= self.data["CO01END028RO"] <= 0.14:
            Q3_S05_CO01END028RO_2 = 1
        else:
            Q3_S05_CO01END028RO_2 = 0

        if 3.77 < self.data["CO01END041IN"] <= 6.48:
            Q3_S05_CO01END041IN_4 = 1
        else:
            Q3_S05_CO01END041IN_4 = 0

        if 2 < self.data["CO01NUM001CC"] <= 3:
            Q3_S05_CO01NUM001CC_4 = 1
        else:
            Q3_S05_CO01NUM001CC_4 = 0

        if 0 <= self.data["CO01NUM001RO"] <= 1:
            Q3_S05_CO01NUM001RO_2 = 1
        else:
            Q3_S05_CO01NUM001RO_2 = 0

        if 1 < self.data["CO01NUM001RO"] <= 2:
            Q3_S05_CO01NUM001RO_3 = 1
        else:
            Q3_S05_CO01NUM001RO_3 = 0

        if 1 < self.data["CO01NUM005RO"] <= 2:
            Q3_S05_CO01NUM005RO_4 = 1
        else:
            Q3_S05_CO01NUM005RO_4 = 0

        if 0 <= self.data["CO02END001IN"] <= 16.98:
            Q3_S05_CO02END001IN_2 = 1
        else:
            Q3_S05_CO02END001IN_2 = 0

        if 24.62 < self.data["CO02END002CB"] <= 40.21:
            Q3_S05_CO02END002CB_5 = 1
        else:
            Q3_S05_CO02END002CB_5 = 0

        if 25.6 < self.data["CO02END004CB"] <= 54.81:
            Q3_S05_CO02END004CB_4 = 1
        else:
            Q3_S05_CO02END004CB_4 = 0

        if self.data["CO02END033IN"] == 0:
            Q3_S05_CO02END033IN_2 = 1
        else:
            Q3_S05_CO02END033IN_2 = 0

        if self.data["CO02NUM039TO"] == 0:
            Q3_S05_CO02NUM039TO_2 = 1
        else:
            Q3_S05_CO02NUM039TO_2 = 0

        if 0 <= self.data["COQ1END004IN"] <= 700:
            Q3_S05_COQ1END004IN_2 = 1
        else:
            Q3_S05_COQ1END004IN_2 = 0

        if 3500 < self.data["COQ1END004IN"] <= 5500:
            Q3_S05_COQ1END004IN_5 = 1
        else:
            Q3_S05_COQ1END004IN_5 = 0

        if 0 <= self.data["COQ1END004TC"] <= 740:
            Q3_S05_COQ1END004TC_2 = 1
        else:
            Q3_S05_COQ1END004TC_2 = 0

        if 0 <= self.data["COQ1EXP002IN"] <= 11:
            Q3_S05_COQ1EXP002IN_2 = 1
        else:
            Q3_S05_COQ1EXP002IN_2 = 0

        if 2 < self.data["COQ1NUM002TC"] <= 8:
            Q3_S05_COQ1NUM002TC_4 = 1
        else:
            Q3_S05_COQ1NUM002TC_4 = 0

        if 155 < self.data["COQ1END007IN"] <= 239:
            Q3_S05_COQ1END007IN_4 = 1
        else:
            Q3_S05_COQ1END007IN_4 = 0

        # Binary Attributes
        if self.data["COQ1END003MC"] == -1:
            Q3_S05_MICROCREDITO = 0
        else:
            Q3_S05_MICROCREDITO = 1

        Q3_S05_TELCOS_C = 0.0
        if self.q3_telcos < 0:
            Q3_S05_TELCOS_C = 1.0
        elif self.q3_telcos == 0:
            Q3_S05_TELCOS_C = 2.0
        elif self.q3_telcos == 1:
            Q3_S05_TELCOS_C = 3.0

        Q3_S05_EXPONENTE = (0.24788 +
                            Q3_S05_MICROCREDITO * -0.02617 +
                            self.data["CO02EXP001TO"] * 0.00011535 +
                            self.data["CO02EXP006TO"] * 0.00007635 +
                            self.data["CO02NUM002TO"] * 0.01649 +
                            Q3_S05_CO01ACP007CO_2 * 0.02242 +
                            Q3_S05_CO01END005IN_3 * 0.08494 +
                            Q3_S05_CO01END021IN_2 * 0.0248 +
                            Q3_S05_CO01END028RO_2 * 0.04067 +
                            Q3_S05_CO01END041IN_4 * 0.10528 +
                            Q3_S05_CO01NUM001CC_4 * 0.0536 +
                            Q3_S05_CO01NUM001RO_2 * -0.03729 +
                            Q3_S05_CO01NUM001RO_3 * -0.0311 +
                            Q3_S05_CO01NUM005RO_4 * 0.01016 +
                            Q3_S05_CO02END001IN_2 * -0.0433 +
                            Q3_S05_CO02END002CB_5 * 0.03739 +
                            Q3_S05_CO02END004CB_4 * 0.02844 +
                            Q3_S05_CO02END033IN_2 * -0.09589 +
                            Q3_S05_CO02NUM039TO_2 * -0.03158 +
                            Q3_S05_COQ1END004IN_2 * -0.09299 +
                            Q3_S05_COQ1END004IN_5 * 0.03315 +
                            Q3_S05_COQ1END004TC_2 * -0.05399 +
                            Q3_S05_COQ1EXP002IN_2 * -0.01416 +
                            Q3_S05_COQ1NUM002TC_4 * 0.022 +
                            Q3_S05_COQ1END007IN_4 * 0.10835 +
                            Q3_S05_TELCOS_C * 0.0448)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S05_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card06_daqu3(self):
        """
        Computes Score Card 06
        """
        # NO TEC NODO2 GRUPO 2
        self.inicializa_variables()
        self.score_card_daqu3 = 6
        self.adverse_razon_daqu3[0] = 99

        # Special Attributes
        attributes = ["CO02EXP001TO", "CO02NUM002TO", "CO01ACP007AH", "CO01END006CC", "CO01END006IN",
                      "CO01END007IN", "CO01END028CC", "CO01END028IN", "CO01END030RO", "CO01END045IN",
                      "CO01END060RO", "CO01MOR001CC", "CO01MOR001RO", "CO01NUM005CC", "CO01NUM005RO",
                      "CO02END002CB", "CO02END033CB", "CO00DEM006", "COQ1END001TO", "COQ1END006IN",
                      "COQ1END008IN"]

        # Obtain Hybrid characteristics
        self.sectores_daqu3()

        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        if self.q3_financiero == 999:
            self.q3_financiero = -1.0

        # Dimensioning
        if self.data["CO02EXP001TO"] > 245:
            self.data["CO02EXP001TO"] = 245

        if self.data["CO02NUM002TO"] > 5:
            self.data["CO02NUM002TO"] = 5

        if self.data["CO01ACP007AH"] > 2:
            self.data["CO01ACP007AH"] = 2

        if self.data["CO01END006IN"] > 1.26:
            self.data["CO01END006IN"] = 1.26

        if self.data["CO01END007IN"] > 19.42:
            self.data["CO01END007IN"] = 19.42

        if self.data["CO01END028CC"] > 0.09:
            self.data["CO01END028CC"] = 0.09

        if self.data["CO01END028IN"] > 1.45:
            self.data["CO01END028IN"] = 1.45

        if self.data["CO01END030RO"] > 2.23:
            self.data["CO01END030RO"] = 2.23

        if self.data["CO01END045IN"] > 1.94:
            self.data["CO01END045IN"] = 1.94

        if self.data["CO01MOR001CC"] > 2:
            self.data["CO01MOR001CC"] = 2

        if self.data["CO01NUM005CC"] > 3:
            self.data["CO01NUM005CC"] = 3

        if self.data["CO01NUM005RO"] > 3:
            self.data["CO01NUM005RO"] = 3

        if self.data["CO02END033CB"] > 120:
            self.data["CO02END033CB"] = 120

        if self.data["COQ1END008IN"] > 10000:
            self.data["COQ1END008IN"] = 10000

        if self.data["CO01END006CC"] > 0.07:
            self.data["CO01END006CC"] = 0.07

        if self.data["CO01END060RO"] > 1.44:
            self.data["CO01END060RO"] = 1.44

        if self.data["CO01MOR001RO"] > 2:
            self.data["CO01MOR001RO"] = 2

        if self.data["CO02END002CB"] > 33.88:
            self.data["CO02END002CB"] = 33.88

        if self.data["COQ1END001TO"] > 2543.32:
            self.data["COQ1END001TO"] = 2543.32

        # Binary Attributes
        if self.data["CO01ACP007AH"] == 0:
            Q3_S06_CO01ACP007AH_2 = 1
        else:
            Q3_S06_CO01ACP007AH_2 = 0

        if 1 < self.data["CO01ACP007AH"] <= 2:
            Q3_S06_CO01ACP007AH_4 = 1
        else:
            Q3_S06_CO01ACP007AH_4 = 0

        if 0 <= self.data["CO01END006CC"] <= 0.06:
            Q3_S06_CO01END006CC_2 = 1
        else:
            Q3_S06_CO01END006CC_2 = 0

        if 0.25 < self.data["CO01END006IN"] <= 0.38:
            Q3_S06_CO01END006IN_3 = 1
        else:
            Q3_S06_CO01END006IN_3 = 0

        if 0 <= self.data["CO01END007IN"] <= 5.47:
            Q3_S06_CO01END007IN_2 = 1
        else:
            Q3_S06_CO01END007IN_2 = 0

        if 19.15 < self.data["CO01END007IN"] <= 19.42:
            Q3_S06_CO01END007IN_5 = 1
        else:
            Q3_S06_CO01END007IN_5 = 0

        if 0.06 < self.data["CO01END028CC"] <= 0.09:
            Q3_S06_CO01END028CC_3 = 1
        else:
            Q3_S06_CO01END028CC_3 = 0

        if 0 <= self.data["CO01END028IN"] <= 0.23:
            Q3_S06_CO01END028IN_2 = 1
        else:
            Q3_S06_CO01END028IN_2 = 0

        if 0.38 < self.data["CO01END028IN"] <= 0.63:
            Q3_S06_CO01END028IN_4 = 1
        else:
            Q3_S06_CO01END028IN_4 = 0

        if 2.00100000000006 < self.data["CO01END030RO"] <= 2.23:
            Q3_S06_CO01END030RO_3 = 1
        else:
            Q3_S06_CO01END030RO_3 = 0

        if 0.94 < self.data["CO01END045IN"] <= 1.94:
            Q3_S06_CO01END045IN_5 = 1
        else:
            Q3_S06_CO01END045IN_5 = 0

        if 0 <= self.data["CO01END060RO"] <= 1.28:
            Q3_S06_CO01END060RO_2 = 1
        else:
            Q3_S06_CO01END060RO_2 = 0

        if self.data["CO01MOR001CC"] == 0:
            Q3_S06_CO01MOR001CC_2 = 1
        else:
            Q3_S06_CO01MOR001CC_2 = 0

        if 1 < self.data["CO01MOR001CC"] <= 2:
            Q3_S06_CO01MOR001CC_4 = 1
        else:
            Q3_S06_CO01MOR001CC_4 = 0

        if 0 <= self.data["CO01MOR001RO"] <= 1:
            Q3_S06_CO01MOR001RO_2 = 1
        else:
            Q3_S06_CO01MOR001RO_2 = 0

        if 2 < self.data["CO01NUM005CC"] <= 3:
            Q3_S06_CO01NUM005CC_5 = 1
        else:
            Q3_S06_CO01NUM005CC_5 = 0

        if 1 < self.data["CO01NUM005RO"] <= 2:
            Q3_S06_CO01NUM005RO_4 = 1
        else:
            Q3_S06_CO01NUM005RO_4 = 0

        if 2 < self.data["CO01NUM005RO"] <= 3:
            Q3_S06_CO01NUM005RO_5 = 1
        else:
            Q3_S06_CO01NUM005RO_5 = 0

        if 0 <= self.data["CO02END002CB"] <= 2:
            Q3_S06_CO02END002CB_2 = 1
        else:
            Q3_S06_CO02END002CB_2 = 0

        if 95.24 < self.data["CO02END033CB"] <= 120:
            Q3_S06_CO02END033CB_4 = 1
        else:
            Q3_S06_CO02END033CB_4 = 0

        if 0 <= self.data["COQ1END001TO"] <= 346.67:
            Q3_S06_COQ1END001TO_2 = 1
        else:
            Q3_S06_COQ1END001TO_2 = 0

        if 0 <= self.data["COQ1END006IN"] <= 2359:
            Q3_S06_COQ1END006IN_2 = 1
        else:
            Q3_S06_COQ1END006IN_2 = 0

        if 9900 < self.data["COQ1END008IN"] <= 10000:
            Q3_S06_COQ1END008IN_4 = 1
        else:
            Q3_S06_COQ1END008IN_4 = 0

        # Obtain Hybrid characteristics
        Q3_MAXIMO_CUPO_TOT = self.calcula_maximo_cupo_tot()

        if Q3_MAXIMO_CUPO_TOT < 0:
            Q3_MAXIMO_CUPO_TOT = -2

        if Q3_MAXIMO_CUPO_TOT == self.data["COQ1END003MC"]:
            Q3_S06_MAX_CUPOMC = 1
        else:
            Q3_S06_MAX_CUPOMC = 0

        if self.data["CO01NUM002CC"] > 0:
            Q3_S06_TELECOM = 1
        else:
            Q3_S06_TELECOM = 0

        # Categorical Attributes
        Q3_S06_NUMERO_HP = 0
        if self.data["COQ1NUM002HP"] <= 1:
            Q3_S06_NUMERO_HP = 1
        if 1 < self.data["COQ1NUM002HP"] <= 4:
            Q3_S06_NUMERO_HP = 2

        if 4 < self.data["COQ1NUM002HP"] <= 27:
            Q3_S06_NUMERO_HP = 3

        if self.data["COQ1NUM002HP"] > 27:
            Q3_S06_NUMERO_HP = 4

        Q3_S06_CO00DEM006_C = 0
        if self.data["CO00DEM006"] < 0 or self.data["CO00DEM006"] == 999:
            Q3_S06_CO00DEM006_C = 1
        elif self.data["CO00DEM006"] == 1:
            Q3_S06_CO00DEM006_C = 2
        elif self.data["CO00DEM006"] == 0:
            Q3_S06_CO00DEM006_C = 3

        Q3_S06_FINANCIERO_C = 0
        if self.q3_financiero < 0:
            Q3_S06_FINANCIERO_C = 1
        elif self.q3_financiero == 0:
            Q3_S06_FINANCIERO_C = 2
        elif self.q3_financiero == 1:
            Q3_S06_FINANCIERO_C = 3

        Q3_S06_EXPONENTE = (
            0.07641 +
            Q3_S06_MAX_CUPOMC * -0.1127 +
            Q3_S06_TELECOM * 0.10707 +
            Q3_S06_NUMERO_HP * 0.04986 +
            self.data["CO02EXP001TO"] * 0.00038416 +
            self.data["CO02NUM002TO"] * 0.01868 +
            Q3_S06_CO01ACP007AH_2 * 0.01398 +
            Q3_S06_CO01ACP007AH_4 * -0.02299 +
            Q3_S06_CO01END006CC_2 * -0.06385 +
            Q3_S06_CO01END006IN_3 * 0.05337 +
            Q3_S06_CO01END007IN_2 * -0.05849 +
            Q3_S06_CO01END007IN_5 * 0.07799 +
            Q3_S06_CO01END028CC_3 * 0.10892 +
            Q3_S06_CO01END028IN_2 * -0.10493 +
            Q3_S06_CO01END028IN_4 * 0.06787 +
            Q3_S06_CO01END030RO_3 * 0.15179 +
            Q3_S06_CO01END045IN_5 * 0.23531 +
            Q3_S06_CO01END060RO_2 * -0.03183 +
            Q3_S06_CO01MOR001CC_2 * -0.24805 +
            Q3_S06_CO01MOR001CC_4 * 0.08052 +
            Q3_S06_CO01MOR001RO_2 * -0.04393 +
            Q3_S06_CO01NUM005CC_5 * 0.06998 +
            Q3_S06_CO01NUM005RO_4 * 0.01788 +
            Q3_S06_CO01NUM005RO_5 * 0.08971 +
            Q3_S06_CO02END002CB_2 * -0.10485 +
            Q3_S06_CO02END033CB_4 * 0.04808 +
            Q3_S06_COQ1END001TO_2 * -0.12239 +
            Q3_S06_COQ1END006IN_2 * 0.06445 +
            Q3_S06_COQ1END008IN_4 * 0.14339 +
            Q3_S06_CO00DEM006_C * 0.08921 +
            Q3_S06_FINANCIERO_C * 0.06322
        )

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S06_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card07_daqu3(self):
        """
        Computes Score Card 07
        """
        self.inicializa_variables()
        self.score_card_daqu3 = 7
        self.adverse_razon_daqu3[0] = 99

        # Special Attributes
        attributes = ["CO02EXP001TO", "CO02NUM018TO", "CO02NUM042CB", "CO00DEM026", "CO01END006CC",
                      "CO01END023RO", "CO01END028IN", "CO01END040RO", "CO01END060RO", "CO01END065RO",
                      "CO01END066IN", "CO01END075RO", "CO01END077RO", "CO01END089RO", "CO01END090RO",
                      "CO01MOR001CC", "CO01NUM001CC", "CO01NUM005RO", "CO02END002CB", "CO02END044RO",
                      "CO02END046RO", "COQ1END002IN", "COQ1END013TC", "COQ1END008IN"]

        # Obtain Hybrid characteristics
        Q3_QTOT = self.qtot_daqu3()
        self.cuotatotal_daqu3()

        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        if Q3_QTOT == 999:
            Q3_QTOT = -1.0

        if self.q3_cuotatotal == 999:
            self.q3_cuotatotal = -1.0

        # Dimensioning
        if self.data["CO02EXP001TO"] > 245:
            self.data["CO02EXP001TO"] = 245

        if self.data["CO02NUM018TO"] > 1:
            self.data["CO02NUM018TO"] = 1

        if self.data["CO02NUM042CB"] > 100:
            self.data["CO02NUM042CB"] = 100

        if Q3_QTOT > 14:
            Q3_QTOT = 14

        if self.data["CO01END006CC"] > 0.07:
            self.data["CO01END006CC"] = 0.07

        if self.data["CO01END023RO"] > 0.26:
            self.data["CO01END023RO"] = 0.26

        if self.data["CO01END028IN"] > 1.45:
            self.data["CO01END028IN"] = 1.45

        if self.data["CO01END040RO"] > 1.81:
            self.data["CO01END040RO"] = 1.81

        if self.data["CO01END060RO"] > 1.44:
            self.data["CO01END060RO"] = 1.44

        if self.data["CO01END065RO"] > 0.24:
            self.data["CO01END065RO"] = 0.24

        if self.data["CO01END066IN"] > 1.36:
            self.data["CO01END066IN"] = 1.36

        if self.data["CO01END075RO"] > 59.52:
            self.data["CO01END075RO"] = 59.52

        if self.data["CO01END077RO"] > 76.6:
            self.data["CO01END077RO"] = 76.6

        if self.data["CO01END089RO"] > 75.59:
            self.data["CO01END089RO"] = 75.59

        if self.data["CO01END090RO"] > 50.54:
            self.data["CO01END090RO"] = 50.54

        if self.data["CO01MOR001CC"] > 2:
            self.data["CO01MOR001CC"] = 2

        if self.data["CO01NUM001CC"] > 4:
            self.data["CO01NUM001CC"] = 4

        if self.data["CO01NUM005RO"] > 3:
            self.data["CO01NUM005RO"] = 3

        if self.data["CO02END002CB"] > 33.88:
            self.data["CO02END002CB"] = 33.88

        if self.data["CO02END044RO"] > 8.51549999999988:
            self.data["CO02END044RO"] = 8.51549999999988

        if self.data["CO02END046RO"] > 4.98:
            self.data["CO02END046RO"] = 4.98

        if self.q3_cuotatotal > 2.05:
            self.q3_cuotatotal = 2.05

        if self.data["COQ1END002IN"] > 822:
            self.data["COQ1END002IN"] = 822

        if self.data["COQ1END013TC"] > 748.799999999988:
            self.data["COQ1END013TC"] = 748.799999999988

        if self.data["COQ1END008IN"] > 10000:
            self.data["COQ1END008IN"] = 10000

        # Binary Attributes
        if 0 <= self.data["CO01END006CC"] <= 0.05:
            Q3_S07_CO01END006CC_2 = 1
        else:
            Q3_S07_CO01END006CC_2 = 0

        if 0 <= self.data["CO01END023RO"] <= 0.25:
            Q3_S07_CO01END023RO_2 = 1
        else:
            Q3_S07_CO01END023RO_2 = 0

        if 0.4 < self.data["CO01END028IN"] <= 0.79:
            Q3_S07_CO01END028IN_3 = 1
        else:
            Q3_S07_CO01END028IN_3 = 0

        if 0 <= self.data["CO01END040RO"] <= 0.94:
            Q3_S07_CO01END040RO_2 = 1
        else:
            Q3_S07_CO01END040RO_2 = 0

        if 0 <= self.data["CO01END060RO"] <= 1.12:
            Q3_S07_CO01END060RO_2 = 1
        else:
            Q3_S07_CO01END060RO_2 = 0

        if 0 <= self.data["CO01END065RO"] <= 0.39:
            Q3_S07_CO01END065RO_2 = 1
        else:
            Q3_S07_CO01END065RO_2 = 0

        if 0 <= self.data["CO01END066IN"] <= 0.31:
            Q3_S07_CO01END066IN_2 = 1
        else:
            Q3_S07_CO01END066IN_2 = 0

        if 0 <= self.data["CO01END075RO"] <= 1.61:
            Q3_S07_CO01END075RO_2 = 1
        else:
            Q3_S07_CO01END075RO_2 = 0

        if 0 <= self.data["CO01END077RO"] <= 18.635:
            Q3_S07_CO01END077RO_2 = 1
        else:
            Q3_S07_CO01END077RO_2 = 0

        if 0 <= self.data["CO01END089RO"] <= 15.2:
            Q3_S07_CO01END089RO_2 = 1
        else:
            Q3_S07_CO01END089RO_2 = 0

        if 36.45 < self.data["CO01END090RO"] <= 64.95:
            Q3_S07_CO01END090RO_4 = 1
        else:
            Q3_S07_CO01END090RO_4 = 0

        if 1 < self.data["CO01MOR001CC"] <= 2:
            Q3_S07_CO01MOR001CC_3 = 1
        else:
            Q3_S07_CO01MOR001CC_3 = 0

        if 3 < self.data["CO01NUM001CC"] <= 4:
            Q3_S07_CO01NUM001CC_5 = 1
        else:
            Q3_S07_CO01NUM001CC_5 = 0

        if 2 < self.data["CO01NUM005RO"] <= 5:
            Q3_S07_CO01NUM005RO_4 = 1
        else:
            Q3_S07_CO01NUM005RO_4 = 0

        if 0 <= self.data["CO02END002CB"] <= 1.65:
            Q3_S07_CO02END002CB_2 = 1
        else:
            Q3_S07_CO02END002CB_2 = 0

        if 0 <= self.data["CO02END044RO"] <= 6.53:
            Q3_S07_CO02END044RO_2 = 1
        else:
            Q3_S07_CO02END044RO_2 = 0

        if 0 <= self.data["CO02END046RO"] <= 13.6575:
            Q3_S07_CO02END046RO_2 = 1
        else:
            Q3_S07_CO02END046RO_2 = 0

        if 0.98 < self.q3_cuotatotal <= 1.23:
            Q3_S07_CUOTATOTAL_4 = 1
        else:
            Q3_S07_CUOTATOTAL_4 = 0

        if 1.23 < self.q3_cuotatotal <= 2.62:
            Q3_S07_CUOTATOTAL_5 = 1
        else:
            Q3_S07_CUOTATOTAL_5 = 0

        if 0 <= self.data["COQ1END002IN"] <= 361:
            Q3_S07_COQ1END002IN_2 = 1
        else:
            Q3_S07_COQ1END002IN_2 = 0

        if 0 <= self.data["COQ1END013TC"] <= 3000:
            Q3_S07_COQ1END013TC_2 = 1
        else:
            Q3_S07_COQ1END013TC_2 = 0

        if 9600 < self.data["COQ1END008IN"] <= 16000:
            Q3_S07_COQ1END008IN_3 = 1
        else:
            Q3_S07_COQ1END008IN_3 = 0

        # Categorical Attributes
        if self.data["CO01NUM002CC"] > 0:
            Q3_S07_TELECOM = 1
        else:
            Q3_S07_TELECOM = 0

        if self.data["COQ1END003MC"] == -1:
            Q3_S07_MICROCREDITO = 0
        else:
            Q3_S07_MICROCREDITO = 1

        if Q3_S07_TELECOM == 0 and Q3_S07_MICROCREDITO == 1:
            Q3_S07_NOCC_MIC = 1
        else:
            Q3_S07_NOCC_MIC = 0

        Q3_S07_NUMERO_TC = 0.0
        if self.data["COQ1NUM002TC"] < 0:
            Q3_S07_NUMERO_TC = 0
        if self.data["COQ1NUM002TC"] <= 3:
            Q3_S07_NUMERO_TC = 1
        if 3 < self.data["COQ1NUM002TC"] <= 15:
            Q3_S07_NUMERO_TC = 2
        if 15 < self.data["COQ1NUM002TC"] <= 123:
            Q3_S07_NUMERO_TC = 3
        if self.data["COQ1NUM002TC"] > 123:
            Q3_S07_NUMERO_TC = 4

        Q3_S07_CO00DEM026_C = 0.0
        if self.data["CO00DEM026"] < 0:
            Q3_S07_CO00DEM026_C = 1
        elif self.data["CO00DEM026"] == 0:
            Q3_S07_CO00DEM026_C = 2
        elif self.data["CO00DEM026"] in (1, 2, 3):
            Q3_S07_CO00DEM026_C = 3
        elif self.data["CO00DEM026"] == 5:
            Q3_S07_CO00DEM026_C = 4
        elif self.data["CO00DEM026"] in (6, 4):
            Q3_S07_CO00DEM026_C = 5

        Q3_S07_EXPONENTE = (
            0.45787 +
            Q3_S07_NOCC_MIC * -0.22077 +
            Q3_S07_NUMERO_TC * 0.12167 +
            self.data["CO02EXP001TO"] * 0.00103 +
            self.data["CO02NUM018TO"] * -0.31128 +
            self.data["CO02NUM042CB"] * 0.00205 +
            Q3_QTOT * 0.00904 +
            Q3_S07_CO00DEM026_C * 0.02408 +
            Q3_S07_CO01END006CC_2 * -0.10851 +
            Q3_S07_CO01END023RO_2 * -0.11687 +
            Q3_S07_CO01END028IN_3 * 0.05075 +
            Q3_S07_CO01END040RO_2 * -0.04522 +
            Q3_S07_CO01END060RO_2 * -0.07632 +
            Q3_S07_CO01END065RO_2 * -0.03537 +
            Q3_S07_CO01END066IN_2 * -0.08467 +
            Q3_S07_CO01END075RO_2 * 0.06553 +
            Q3_S07_CO01END077RO_2 * 0.0598 +
            Q3_S07_CO01END089RO_2 * 0.10336 +
            Q3_S07_CO01END090RO_4 * 0.11742 +
            Q3_S07_CO01MOR001CC_3 * 0.15154 +
            Q3_S07_CO01NUM001CC_5 * 0.08619 +
            Q3_S07_CO01NUM005RO_4 * 0.07901 +
            Q3_S07_CO02END002CB_2 * -0.18124 +
            Q3_S07_CO02END044RO_2 * -0.04395 +
            Q3_S07_CO02END046RO_2 * -0.0497 +
            Q3_S07_CUOTATOTAL_4 * 0.13627 +
            Q3_S07_CUOTATOTAL_5 * 0.19954 +
            Q3_S07_COQ1END002IN_2 * -0.16464 +
            Q3_S07_COQ1END013TC_2 * -0.05893 +
            Q3_S07_COQ1END008IN_3 * 0.20303
        )

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S07_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card08_daqu3(self):
        """
        Computes Score Card 08
        """
        self.inicializa_variables()
        self.score_card_daqu3 = 8
        self.adverse_razon_daqu3[0] = 99

        # Special Attributes
        attributes = ["COQ1END011TC", "COQ1END003IN", "COQ1END003TC", "COQ1END007IN", "COQ1END008TC",
                      "COQ1END019TC", "CO02NUM002TO", "CO01END007IN", "CO01END007RO", "CO01END007RO",
                      "CO01END018RO", "CO01END023CC", "CO01END030RO", "CO01END045RO", "CO01END056IN",
                      "CO01END066RO", "CO01END080RO", "CO01END087RO", "CO01END091RO", "CO02END032CB",
                      "CO02NUM042CT", "CO00DEM026"]

        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        self.sectores_daqu3()
        if self.q3_telcos == 999:
            self.q3_telcos = -1.0

        Q3_CAST = self.calcula_cast_scodaqu3()
        if Q3_CAST == 999:
            Q3_CAST = -1.0

        # Dimensioning
        if self.data["COQ1END011TC"] > 2042.259166673:
            self.data["COQ1END011TC"] = 2042.259166673

        if self.data["COQ1END003IN"] > 50000:
            self.data["COQ1END003IN"] = 50000

        if self.data["COQ1END003TC"] > 6435.99999999999:
            self.data["COQ1END003TC"] = 6435.99999999999

        if self.data["COQ1END007IN"] > 1693.5:
            self.data["COQ1END007IN"] = 1693.5

        if self.data["COQ1END008TC"] > 19500:
            self.data["COQ1END008TC"] = 19500

        if self.data["COQ1END019TC"] > 1.06104120882:
            self.data["COQ1END019TC"] = 1.06104120882

        if Q3_CAST > 1:
            Q3_CAST = 1.0

        if self.data["CO02NUM002TO"] > 10:
            self.data["CO02NUM002TO"] = 10

        if self.data["CO01END007IN"] > 80.509:
            self.data["CO01END007IN"] = 80.509

        if self.data["CO01END007RO"] > 93.59:
            self.data["CO01END007RO"] = 93.59

        if self.data["CO01END018RO"] > 1.81:
            self.data["CO01END018RO"] = 1.81

        if self.data["CO01END023CC"] > 0.13:
            self.data["CO01END023CC"] = 0.13

        if self.data["CO01END030RO"] > 21.893:
            self.data["CO01END030RO"] = 21.893

        if self.data["CO01END045RO"] > 4.2:
            self.data["CO01END045RO"] = 4.2

        if self.data["CO01END056IN"] > 2.05:
            self.data["CO01END056IN"] = 2.05

        if self.data["CO01END066RO"] > 1.5315:
            self.data["CO01END066RO"] = 1.5315

        if self.data["CO01END080RO"] > 93.1215:
            self.data["CO01END080RO"] = 93.1215

        if self.data["CO01END087RO"] > 92.1015:
            self.data["CO01END087RO"] = 92.1015

        if self.data["CO01END091RO"] > 161.84:
            self.data["CO01END091RO"] = 161.84

        if self.data["CO02END032CB"] > 346.3525:
            self.data["CO02END032CB"] = 346.3525

        if self.data["CO02NUM042CT"] > 100:
            self.data["CO02NUM042CT"] = 100

        # Binary Attributes
        if 74.68 < self.data["CO01END007IN"] <= 80.509:
            Q3_S08_CO01END007IN_3 = 1
        else:
            Q3_S08_CO01END007IN_3 = 0

        if 49.29 < self.data["CO01END007RO"] <= 83.4280000000002:  # ERROR
            Q3_S08_CO01END007RO_4 = 1
        else:
            Q3_S08_CO01END007RO_4 = 0

        if 83.4280000000002 < self.data["CO01END007RO"] <= 93.59:  # ERROR
            Q3_S08_CO01END007RO_5 = 1
        else:
            Q3_S08_CO01END007RO_5 = 0

        if 0 <= self.data["CO01END018RO"] <= 0.38:
            Q3_S08_CO01END018RO_2 = 1
        else:
            Q3_S08_CO01END018RO_2 = 0

        if 1.17 < self.data["CO01END018RO"] <= 1.81:
            Q3_S08_CO01END018RO_5 = 1
        else:
            Q3_S08_CO01END018RO_5 = 0

        if 0.1 < self.data["CO01END023CC"] <= 0.13:
            Q3_S08_CO01END023CC_3 = 1
        else:
            Q3_S08_CO01END023CC_3 = 0

        if 10.17 < self.data["CO01END030RO"] <= 14.627:
            Q3_S08_CO01END030RO_4 = 1
        else:
            Q3_S08_CO01END030RO_4 = 0

        if 14.627 < self.data["CO01END030RO"] <= 21.893:
            Q3_S08_CO01END030RO_5 = 1
        else:
            Q3_S08_CO01END030RO_5 = 0

        if 0 <= self.data["CO01END045RO"] <= 0.68:
            Q3_S08_CO01END045RO_2 = 1
        else:
            Q3_S08_CO01END045RO_2 = 0

        if 0 <= self.data["CO01END056IN"] <= 0.4:
            Q3_S08_CO01END056IN_2 = 1
        else:
            Q3_S08_CO01END056IN_2 = 0

        if 0 <= self.data["CO01END066RO"] <= 0.45:
            Q3_S08_CO01END066RO_2 = 1
        else:
            Q3_S08_CO01END066RO_2 = 0

        if 0 <= self.data["CO01END080RO"] <= 7.36:
            Q3_S08_CO01END080RO_2 = 1
        else:
            Q3_S08_CO01END080RO_2 = 0

        if 0 <= self.data["CO01END087RO"] <= 15.5:
            Q3_S08_CO01END087RO_2 = 1
        else:
            Q3_S08_CO01END087RO_2 = 0

        if 0 <= self.data["CO01END091RO"] <= 32.334:
            Q3_S08_CO01END091RO_2 = 1
        else:
            Q3_S08_CO01END091RO_2 = 0

        if self.data["CO02END032CB"] == 999 or self.data["CO02END032CB"] < 0:
            Q3_S08_CO02END032CB_1 = 1
        else:
            Q3_S08_CO02END032CB_1 = 0

        if 206.4975 < self.data["CO02END032CB"] <= 346.3525:
            Q3_S08_CO02END032CB_5 = 1
        else:
            Q3_S08_CO02END032CB_5 = 0

        if 0 < self.data["CO02NUM042CT"] <= 100:
            Q3_S08_CO02NUM042CT_3 = 1
        else:
            Q3_S08_CO02NUM042CT_3 = 0

        if 940.5 < self.data["COQ1END011TC"] <= 2042.49166667:
            Q3_S08_COQ1END011TC_5 = 1
        else:
            Q3_S08_COQ1END011TC_5 = 0

        if 44300 < self.data["COQ1END003IN"] <= 50000:
            Q3_S08_COQ1END003IN_4 = 1
        else:
            Q3_S08_COQ1END003IN_4 = 0

        if 0 <= self.data["COQ1END003TC"] <= 3696:
            Q3_S08_COQ1END003TC_2 = 1
        else:
            Q3_S08_COQ1END003TC_2 = 0

        if 885 < self.data["COQ1END007IN"] <= 1693.5:
            Q3_S08_COQ1END007IN_4 = 1
        else:
            Q3_S08_COQ1END007IN_4 = 0

        if 15821 < self.data["COQ1END008TC"] <= 19500:
            Q3_S08_COQ1END008TC_5 = 1
        else:
            Q3_S08_COQ1END008TC_5 = 0

        if 0.9579545455 < self.data["COQ1END019TC"] <= 1.06104120882:
            Q3_S08_COQ1END019TC_5 = 1
        else:
            Q3_S08_COQ1END019TC_5 = 0

        # Categorical Attributes
        Q3_S08_NUMERO_TC = 0.0
        if self.data["COQ1NUM002TC"] < 0:  # ERROR
            Q3_S08_NUMERO_TC = 0.0
        else:
            if 0 <= self.data["COQ1NUM002TC"] <= 3:
                Q3_S08_NUMERO_TC = 1.0
            else:
                if 3 < self.data["COQ1NUM002TC"] <= 15:
                    Q3_S08_NUMERO_TC = 2.0
                else:
                    if 15 < self.data["COQ1NUM002TC"] <= 123:
                        Q3_S08_NUMERO_TC = 3.0
                    else:
                        if 123 < self.data["COQ1NUM002TC"]:
                            Q3_S08_NUMERO_TC = 4.0

        Q3_S08_NUMERO_HP = 0.0
        if self.data["COQ1NUM002HP"] <= 1:
            Q3_S08_NUMERO_HP = 1.0

        if 1 < self.data["COQ1NUM002HP"] <= 4:
            Q3_S08_NUMERO_HP = 2.0

        if 4 < self.data["COQ1NUM002HP"] <= 27:
            Q3_S08_NUMERO_HP = 3.0

        if self.data["COQ1NUM002HP"] > 27:
            Q3_S08_NUMERO_HP = 4.0

        if self.data["CO01NUM002CC"] > 0:
            Q3_S08_OTRO = 1
        else:
            Q3_S08_OTRO = 0

        Q3_MAXIMO_CUPO_TOT = self.calcula_maximo_cupo_tot()

        if Q3_MAXIMO_CUPO_TOT < 0:
            Q3_MAXIMO_CUPO_TOT = -2

        if Q3_MAXIMO_CUPO_TOT == self.data["COQ1END003MC"]:
            Q3_S08_MAX_CUPOMC = 1
        else:
            Q3_S08_MAX_CUPOMC = 0

        Q3_ACTIVIDAD_ECONOMICA_C = 0.0
        if self.q3_act_econ == 7:
            Q3_ACTIVIDAD_ECONOMICA_C = 1.0
        elif self.q3_act_econ in (3, 5, 6, 1):
            Q3_ACTIVIDAD_ECONOMICA_C = 2.0
        elif self.q3_act_econ in (4, 2):
            Q3_ACTIVIDAD_ECONOMICA_C = 3.0

        Q3_S08_CO00DEM026_C = 0.0
        if self.data["CO00DEM026"] < 0 or self.data["CO00DEM026"] == 999:
            Q3_S08_CO00DEM026_C = 1.0
        elif self.data["CO00DEM026"] in (0, 4):
            Q3_S08_CO00DEM026_C = 2.0
        elif self.data["CO00DEM026"] in (3, 1, 2):
            Q3_S08_CO00DEM026_C = 3.0
        elif self.data["CO00DEM026"] == 5:
            Q3_S08_CO00DEM026_C = 4.0
        elif self.data["CO00DEM026"] == 6:
            Q3_S08_CO00DEM026_C = 5.0

        Q3_S08_TELCOS_C = 0.0
        if self.q3_telcos < 0 or self.q3_telcos == 999:
            Q3_S08_TELCOS_C = 1.0
        elif self.q3_telcos == 0:
            Q3_S08_TELCOS_C = 2.0
        elif self.q3_telcos == 1:
            Q3_S08_TELCOS_C = 3.0

        Q3_S08_EXPONENTE = (0.73535 +
                            Q3_S08_NUMERO_TC * 0.12489 +
                            Q3_S08_NUMERO_HP * 0.05832 +
                            Q3_S08_OTRO * -0.16723 +
                            Q3_S08_MAX_CUPOMC * -0.53711 +
                            Q3_CAST * -0.19011 +
                            self.data["CO02NUM002TO"] * 0.01212 +
                            Q3_S08_CO01END007IN_3 * 0.26789 +
                            Q3_S08_CO01END007RO_4 * 0.14903 +
                            Q3_S08_CO01END007RO_5 * 0.16844 +
                            Q3_S08_CO01END018RO_2 * -0.07341 +
                            Q3_S08_CO01END018RO_5 * 0.15816 +
                            Q3_S08_CO01END023CC_3 * 0.12391 +
                            Q3_S08_CO01END030RO_4 * 0.14946 +
                            Q3_S08_CO01END030RO_5 * 0.19574 +
                            Q3_S08_CO01END045RO_2 * -0.05145 +
                            Q3_S08_CO01END056IN_2 * -0.19355 +
                            Q3_S08_CO01END066RO_2 * -0.12426 +
                            Q3_S08_CO01END080RO_2 * 0.11301 +
                            Q3_S08_CO01END087RO_2 * 0.1317 +
                            Q3_S08_CO01END091RO_2 * -0.06915 +
                            Q3_S08_CO02END032CB_1 * 0.07204 +
                            Q3_S08_CO02END032CB_5 * 0.09324 +
                            Q3_S08_CO02NUM042CT_3 * 0.22545 +
                            Q3_S08_COQ1END011TC_5 * 0.09694 +
                            Q3_S08_COQ1END003IN_4 * 0.32174 +
                            Q3_S08_COQ1END003TC_2 * -0.0686 +
                            Q3_S08_COQ1END007IN_4 * 0.16669 +
                            Q3_S08_COQ1END008TC_5 * 0.11483 +
                            Q3_S08_COQ1END019TC_5 * -0.10709 +
                            Q3_ACTIVIDAD_ECONOMICA_C * 0.10711 +
                            Q3_S08_CO00DEM026_C * 0.0203 +
                            Q3_S08_TELCOS_C * 0.0857)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S08_EXPONENTE, 2)

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card09_daqu3(self):
        """
        Computes Score Card 09
        """
        self.inicializa_variables()
        self.score_card_daqu3 = 9
        self.adverse_razon_daqu3[0] = 99

        # Scpecial Attributes
        attributes = ["CO02EXP001TO", "CO02NUM002TO", "COQ1END011TC", "COQ1NUM003TC", "CO01END028IN",
                      "CO01EXP001HP", "CO01END028IN", "CO01NUM001CC", "COQ1END002IN", "COQ1END004IN",
                      "CO01NUM005HP", "CO01END007IN", "COQ1END001TO", "CO02END002CB", "COQ1END003IN",
                      "COQ1END010TC", "CO01END029RO", "CO01NUM001CC", "CO01MOR001RO", "COQ1END007IN",
                      "CO01END028CC"]

        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Dimensioning
        if self.data["CO02EXP001TO"] > 431:
            self.data["CO02EXP001TO"] = 431

        if self.data["CO02NUM002TO"] > 36:
            self.data["CO02NUM002TO"] = 36

        if self.data["COQ1END011TC"] > 5939.876666688:
            self.data["COQ1END011TC"] = 5939.876666688

        if self.data["COQ1NUM003TC"] > 5:
            self.data["COQ1NUM003TC"] = 5

        if self.data["CO01END028IN"] > 5.44599999999999:
            self.data["CO01END028IN"] = 5.44599999999999

        if self.data["CO01EXP001HP"] > 280:
            self.data["CO01EXP001HP"] = 280

        if self.data["CO01END028IN"] > 5.44599999999999:
            self.data["CO01END028IN"] = 5.44599999999999

        if self.data["CO01NUM001CC"] > 10:
            self.data["CO01NUM001CC"] = 10

        if self.data["COQ1END002IN"] > 7499.2:
            self.data["COQ1END002IN"] = 7499.2

        if self.data["COQ1END004IN"] > 230000:
            self.data["COQ1END004IN"] = 230000

        if self.data["CO01NUM005HP"] > 4:
            self.data["CO01NUM005HP"] = 4

        if self.data["CO01END007IN"] > 534.88:
            self.data["CO01END007IN"] = 534.88

        if self.data["COQ1END001TO"] > 74983.35:
            self.data["COQ1END001TO"] = 74983.35

        if self.data["CO02END002CB"] > 32.96:
            self.data["CO02END002CB"] = 32.96

        if self.data["COQ1END003IN"] > 194054:
            self.data["COQ1END003IN"] = 194054

        if self.data["COQ1END010TC"] > 142921.6:
            self.data["COQ1END010TC"] = 142921.6

        if self.data["CO01END029RO"] > 47.22:
            self.data["CO01END029RO"] = 47.22

        if self.data["CO01NUM001CC"] > 10:
            self.data["CO01NUM001CC"] = 10

        if self.data["CO01MOR001RO"] > 13:
            self.data["CO01MOR001RO"] = 13

        if self.data["COQ1END007IN"] > 4785.39999999998:
            self.data["COQ1END007IN"] = 4785.39999999998

        if self.data["CO01END028CC"] > 0.37:
            self.data["CO01END028CC"] = 0.37

        if self.data["COQ1END003TC"] > 40000:
            self.data["COQ1END003TC"] = 40000

        # Binary Attributes
        if 0.21 < self.data["CO01END028IN"] <= 24.99:
            Q3_S09_CO01END028IN_5 = 1
        else:
            Q3_S09_CO01END028IN_5 = 0

        if 0 <= self.data["CO01EXP001HP"] <= 60:
            Q3_S09_CO01EXP001HP_2 = 1
        else:
            Q3_S09_CO01EXP001HP_2 = 0

        if 0.18 < self.data["CO01END028IN"] <= 0.21:
            Q3_S09_CO01END028IN_4 = 1
        else:
            Q3_S09_CO01END028IN_4 = 0

        if self.data["CO01NUM001CC"] < 0:
            Q3_S09_CO01NUM001CC_1 = 1
        else:
            Q3_S09_CO01NUM001CC_1 = 0

        if 312 < self.data["COQ1END002IN"] <= 53563:
            Q3_S09_COQ1END002IN_5 = 1
        else:
            Q3_S09_COQ1END002IN_5 = 0

        if 0 <= self.data["COQ1END004IN"] <= 768:
            Q3_S09_COQ1END004IN_2 = 1
        else:
            Q3_S09_COQ1END004IN_2 = 0

        if 0 < self.data["CO01NUM005HP"] <= 14:
            Q3_S09_CO01NUM005HP_3 = 1
        else:
            Q3_S09_CO01NUM005HP_3 = 0

        if self.data["CO01END007IN"] < 0:
            Q3_S09_CO01END007IN_1 = 1
        else:
            Q3_S09_CO01END007IN_1 = 0

        if 0 <= self.data["COQ1END001TO"] <= 303.33:
            Q3_S09_COQ1END001TO_2 = 1
        else:
            Q3_S09_COQ1END001TO_2 = 0

        if 28.6805 < self.data["CO02END002CB"] <= 100:
            Q3_S09_CO02END002CB_5 = 1
        else:
            Q3_S09_CO02END002CB_5 = 0

        if 829.200000000001 < self.data["COQ1END003IN"] <= 6807.60000000001:  # ERROR
            Q3_S09_COQ1END003IN_3 = 1
        else:
            Q3_S09_COQ1END003IN_3 = 0

        if self.data["COQ1END010TC"] < 0:
            Q3_S09_COQ1END010TC_1 = 1
        else:
            Q3_S09_COQ1END010TC_1 = 0

        if 1.9 < self.data["CO01END029RO"] <= 105.3:
            Q3_S09_CO01END029RO_4 = 1
        else:
            Q3_S09_CO01END029RO_4 = 0

        if 0 <= self.data["CO01NUM001CC"] <= 1:
            Q3_S09_CO01NUM001CC_2 = 1
        else:
            Q3_S09_CO01NUM001CC_2 = 0

        if 0 <= self.data["CO01MOR001RO"] <= 1:
            Q3_S09_CO01MOR001RO_2 = 1
        else:
            Q3_S09_CO01MOR001RO_2 = 0

        if 0 <= self.data["COQ1END007IN"] <= 174:
            Q3_S09_COQ1END007IN_2 = 1
        else:
            Q3_S09_COQ1END007IN_2 = 0

        if 0 <= self.data["CO01END028CC"] <= 0.06:
            Q3_S09_CO01END028CC_2 = 1
        else:
            Q3_S09_CO01END028CC_2 = 0

        if self.data["COQ1END003MC"] == -1: 
            Q3_S09_MICROCREDITO = 0
        else:
            Q3_S09_MICROCREDITO = 1

        if self.data["CO01NUM002CC"] > 0:
            Q3_S09_TELECOM = 1
        else:
            Q3_S09_TELECOM = 0

        if Q3_S09_TELECOM == 0 and Q3_S09_MICROCREDITO == 1:
            Q3_S09_NOCC_MIC = 1
        else:
            Q3_S09_NOCC_MIC = 0

        Q3_MAXIMO_CUPO_TOT = self.calcula_maximo_cupo_tot()
        if Q3_MAXIMO_CUPO_TOT < 0:
            Q3_MAXIMO_CUPO_TOT = -2

        Q3_S09_MAXCUPO_TOT = 0
        if 0 <= Q3_MAXIMO_CUPO_TOT <= 2069:
            Q3_S09_MAXCUPO_TOT = 1

        if 2069 < Q3_MAXIMO_CUPO_TOT <= 3800:
            Q3_S09_MAXCUPO_TOT = 2

        if 3800 < Q3_MAXIMO_CUPO_TOT <= 7400:
            Q3_S09_MAXCUPO_TOT = 3

        if Q3_MAXIMO_CUPO_TOT > 7400:
            Q3_S09_MAXCUPO_TOT = 4

        if Q3_MAXIMO_CUPO_TOT < 0:
            Q3_S09_MAXCUPO_TOT = 5

        Q3_S09_EXPONENTE = (
            0.51477 +
            Q3_S09_NOCC_MIC * -0.04779 +
            Q3_S09_MAXCUPO_TOT * 0.01757 +
            self.data["CO02EXP001TO"] * 0.00028958 +
            self.data["CO02NUM002TO"] * 0.00491 +
            self.data["COQ1END011TC"] * 0.00010744 +
            self.data["COQ1NUM003TC"] * 0.02135 +
            Q3_S09_CO01END028IN_5 * 0.1453 +
            Q3_S09_CO01EXP001HP_2 * -0.13181 +
            Q3_S09_CO01END028IN_4 * 0.05859 +
            Q3_S09_CO01NUM001CC_1 * -0.09608 +
            Q3_S09_COQ1END002IN_5 * 0.07421 +
            Q3_S09_COQ1END004IN_2 * -0.08925 +
            Q3_S09_CO01NUM005HP_3 * 0.07022 +
            Q3_S09_CO01END007IN_1 * -0.05123 +
            Q3_S09_COQ1END001TO_2 * -0.02193 +
            Q3_S09_CO02END002CB_5 * 0.05631 +
            Q3_S09_COQ1END003IN_3 * -0.06119 +
            Q3_S09_COQ1END010TC_1 * 0.01975 +
            Q3_S09_CO01END029RO_4 * 0.09344 +
            Q3_S09_CO01NUM001CC_2 * -0.03903 +
            Q3_S09_CO01MOR001RO_2 * -0.0343 +
            Q3_S09_COQ1END007IN_2 * -0.07091 +
            Q3_S09_CO01END028CC_2 * -0.05235
        )

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S09_EXPONENTE, 2)

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card10_daqu3(self):
        """
        Computes Score Card 10
        """
        self.inicializa_variables()
        self.score_card_daqu3 = 10
        self.adverse_razon_daqu3[0] = 99

        # Special Attributes
        attributes = ["CO02EXP001TO", "CO02EXP006TO", "CO02NUM002TO", "CO02NUM018TO", "CO02NUM029TO",
                      "COQ1NUM002TC", "CO01MOR008OT", "CO01NUM001CC", "COQ1END004TC", "COQ1END012TC",
                      "CO01NUM001CC", "COQ1END008TC", "CO02NUM004TO", "COQ1END014TC", "CO01MOR008OT",
                      "CO01NUM005RO", "COQ1END003IN", "CO01MOR008CC", "CO01NUM001CC", "CO01NUM002IN",
                      "CO01NUM005HP"]
        
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Dimensioning
        if self.data["CO02EXP001TO"] > 188:
            self.data["CO02EXP001TO"] = 188

        if self.data["CO02EXP006TO"] > 76:
            self.data["CO02EXP006TO"] = 76

        if self.data["CO02NUM002TO"] > 7:
            self.data["CO02NUM002TO"] = 7

        if self.data["CO02NUM018TO"] > 1:
            self.data["CO02NUM018TO"] = 1

        if self.data["CO02NUM029TO"] > 16:
            self.data["CO02NUM029TO"] = 16

        if self.data["COQ1NUM002TC"] > 10:
            self.data["COQ1NUM002TC"] = 10

        if self.data["CO01MOR008OT"] > 7:
            self.data["CO01MOR008OT"] = 7

        if self.data["CO01NUM001CC"] > 5:
            self.data["CO01NUM001CC"] = 5

        if self.data["COQ1END004TC"] > 2900:
            self.data["COQ1END004TC"] = 2900

        if self.data["COQ1END012TC"] > 100:
            self.data["COQ1END012TC"] = 100

        if self.data["CO01NUM001CC"] > 5:
            self.data["CO01NUM001CC"] = 5

        if self.data["COQ1END008TC"] > 2800:
            self.data["COQ1END008TC"] = 2800

        if self.data["CO02NUM004TO"] > 3:
            self.data["CO02NUM004TO"] = 3

        if self.data["COQ1END014TC"] > 5873:
            self.data["COQ1END014TC"] = 5873

        if self.data["CO01MOR008OT"] > 7:
            self.data["CO01MOR008OT"] = 7

        if self.data["CO01NUM005RO"] > 4:
            self.data["CO01NUM005RO"] = 4

        if self.data["COQ1END003IN"] > 6044.99999999999:
            self.data["COQ1END003IN"] = 6044.99999999999

        if self.data["CO01MOR008CC"] > 6:
            self.data["CO01MOR008CC"] = 6

        if self.data["CO01NUM001CC"] > 5:
            self.data["CO01NUM001CC"] = 5

        if self.data["CO01NUM002IN"] > 2:
            self.data["CO01NUM002IN"] = 2

        if self.data["CO01NUM005HP"] > 1:
            self.data["CO01NUM005HP"] = 1

        # Binary Attributes
        if self.data["COQ1NUM002TC"] < 0:
            Q3_S10_COQ1NUM002TC_1 = 1
        else:
            Q3_S10_COQ1NUM002TC_1 = 0

        if 0 < self.data["CO01MOR008OT"] <= 7:
            Q3_S10_CO01MOR008OT_3 = 1
        else:
            Q3_S10_CO01MOR008OT_3 = 0

        if 1 < self.data["CO01NUM001CC"] <= 2:
            Q3_S10_CO01NUM001CC_3 = 1
        else:
            Q3_S10_CO01NUM001CC_3 = 0

        if 0 <= self.data["COQ1END004TC"] <= 800:
            Q3_S10_COQ1END004TC_2 = 1
        else:
            Q3_S10_COQ1END004TC_2 = 0

        if 0 <= self.data["COQ1END012TC"] <= 97.1002026265:
            Q3_S10_COQ1END012TC_2 = 1
        else:
            Q3_S10_COQ1END012TC_2 = 0

        if self.data["CO01NUM001CC"] < 0:
            Q3_S10_CO01NUM001CC_1 = 1
        else:
            Q3_S10_CO01NUM001CC_1 = 0

        if self.data["COQ1END008TC"] < 0:
            Q3_S10_COQ1END008TC_1 = 1
        else:
            Q3_S10_COQ1END008TC_1 = 0

        if 1 < self.data["CO02NUM004TO"] <= 79:
            Q3_S10_CO02NUM004TO_4 = 1
        else:
            Q3_S10_CO02NUM004TO_4 = 0

        if 2427 < self.data["COQ1END014TC"] <= 109200:
            Q3_S10_COQ1END014TC_5 = 1
        else:
            Q3_S10_COQ1END014TC_5 = 0

        if self.data["CO01MOR008OT"] < 0:
            Q3_S10_CO01MOR008OT_1 = 1
        else:
            Q3_S10_CO01MOR008OT_1 = 0

        if 1 < self.data["CO01NUM005RO"] <= 3:
            Q3_S10_CO01NUM005RO_4 = 1
        else:
            Q3_S10_CO01NUM005RO_4 = 0

        if 0 <= self.data["COQ1END003IN"] <= 800:
            Q3_S10_COQ1END003IN_2 = 1
        else:
            Q3_S10_COQ1END003IN_2 = 0

        if 0 < self.data["CO01MOR008CC"] <= 7:
            Q3_S10_CO01MOR008CC_3 = 1
        else:
            Q3_S10_CO01MOR008CC_3 = 0

        if 2 < self.data["CO01NUM001CC"] <= 48:
            Q3_S10_CO01NUM001CC_4 = 1
        else:
            Q3_S10_CO01NUM001CC_4 = 0

        if 0 < self.data["CO01NUM002IN"] <= 51:
            Q3_S10_CO01NUM002IN_3 = 1
        else:
            Q3_S10_CO01NUM002IN_3 = 0

        if 0 <= self.data["CO01NUM005HP"] <= 0:
            Q3_S10_CO01NUM005HP_2 = 1
        else:
            Q3_S10_CO01NUM005HP_2 = 0

        if 3 < self.data["CO01NUM005RO"] <= 35:
            Q3_S10_CO01NUM005RO_5 = 1
        else:
            Q3_S10_CO01NUM005RO_5 = 0

        if self.data["COQ1END003MC"] == -1: 
            Q3_S10_MICROCREDITO = 0
        else:
            Q3_S10_MICROCREDITO = 1

        if self.data["CO01NUM002CC"] > 0:
            Q3_S10_TELECOM = 1
        else:
            Q3_S10_TELECOM = 0

        if Q3_S10_TELECOM == 0 and Q3_S10_MICROCREDITO == 1:
            Q3_S10_NOCC_MIC = 1
        else:
            Q3_S10_NOCC_MIC = 0

        if self.data["CO00DEM026"] in (4, 5, 6):
            Q3_S10_ESTRATO456 = 1
        else:
            Q3_S10_ESTRATO456 = 0

        if self.q3_tipoid == 4:
            Q3_S10_EXTRANJERIA = 1
        else:
            Q3_S10_EXTRANJERIA = 0

        Q3_S10_NUMERO_TC = 0
        if 0 < self.data["COQ1NUM002TC"] <= 1:
            Q3_S10_NUMERO_TC = 1

        if 1 < self.data["COQ1NUM002TC"] <= 3:
            Q3_S10_NUMERO_TC = 2

        if 3 < self.data["COQ1NUM002TC"] <= 6:
            Q3_S10_NUMERO_TC = 3

        if self.data["COQ1NUM002TC"] > 6:
            Q3_S10_NUMERO_TC = 4

        if self.data["COQ1NUM002TC"] < 0:
            Q3_S10_NUMERO_TC = 0

        Q3_S10_EXPONENTE = (
            0.32226 +
            Q3_S10_MICROCREDITO * -0.05619 +
            Q3_S10_TELECOM * 0.01882 +
            Q3_S10_NOCC_MIC * 0.0474 +
            Q3_S10_ESTRATO456 * 0.07855 +
            Q3_S10_NUMERO_TC * 0.0131 +
            Q3_S10_EXTRANJERIA * 0.3924 +
            self.data["CO02EXP001TO"] * 0.00043712 +
            self.data["CO02EXP006TO"] * 0.00019402 +
            self.data["CO02NUM002TO"] * 0.0124 +
            self.data["CO02NUM018TO"] * -0.02626 +
            self.data["CO02NUM029TO"] * -0.00452 +
            Q3_S10_CO01NUM005RO_5 * 0.13938 +
            Q3_S10_CO01NUM005HP_2 * -0.09066 +
            Q3_S10_CO01NUM002IN_3 * -0.08106 +
            Q3_S10_CO01NUM001CC_4 * 0.07655 +
            Q3_S10_CO01MOR008CC_3 * -0.10457 +
            Q3_S10_COQ1END003IN_2 * -0.08606 +
            Q3_S10_CO01NUM005RO_4 * 0.05063 +
            Q3_S10_CO01MOR008OT_1 * 0.05398 +
            Q3_S10_COQ1END014TC_5 * 0.05482 +
            Q3_S10_CO02NUM004TO_4 * 0.03402 +
            Q3_S10_COQ1END008TC_1 * 0.07952 +
            Q3_S10_CO01NUM001CC_1 * -0.04869 +
            Q3_S10_COQ1END012TC_2 * -0.06943 +
            Q3_S10_COQ1END004TC_2 * -0.07074 +
            Q3_S10_CO01NUM001CC_3 * 0.04327 +
            Q3_S10_CO01MOR008OT_3 * -0.05565 +
            Q3_S10_COQ1NUM002TC_1 * -0.02551
        )

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S10_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0
        self.cal_salida_pesos_daqu3()

    def score_card11_daqu3(self):
        """
        Computes Score Card 11
        """
        self.inicializa_variables()
        self.score_card_daqu3 = 11
        self.adverse_razon_daqu3[0] = 99

        # Special Attributes
        attributes = ["CO02EXP001TO", "CO02NUM043CB", "CO02NUM002TO", "CO01END028IN", "CO01END045IN",
                      "COQ1END010HP", "CO01EXP001HP", "COQ1NUM002TC", "CO02NUM042HP", "CO01END007IN",
                      "CO01END092HP", "CO01END018HP", "CO01NUM001CC", "COQ1END010HP", "CO01END008RO",
                      "COQ1EXP004HP", "CO01END006CC", "CO01END028CO", "COQ1END003HP"]

        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Dimensioning
        if self.data["CO02EXP001TO"] > 191:
            self.data["CO02EXP001TO"] = 191

        if self.data["CO02NUM043CB"] > 78.26:
            self.data["CO02NUM043CB"] = 78.26

        if self.data["CO02NUM002TO"] > 8:
            self.data["CO02NUM002TO"] = 8

        if self.data["CO01END028IN"] > 1.05:
            self.data["CO01END028IN"] = 1.05

        if self.data["CO01END045IN"] > 2.11:
            self.data["CO01END045IN"] = 2.11

        if self.data["COQ1END010HP"] > 161508:
            self.data["COQ1END010HP"] = 161508

        if self.data["CO01EXP001HP"] > 164:
            self.data["CO01EXP001HP"] = 164

        if self.data["COQ1NUM002TC"] > 24:
            self.data["COQ1NUM002TC"] = 24

        if self.data["CO02NUM042HP"] > 100:
            self.data["CO02NUM042HP"] = 100

        if self.data["CO01END007IN"] > 25.495:
            self.data["CO01END007IN"] = 25.495

        if self.data["CO01END092HP"] > 14.7825:
            self.data["CO01END092HP"] = 14.7825

        if self.data["CO01END018HP"] > 0.73:
            self.data["CO01END018HP"] = 0.73

        if self.data["CO01NUM001CC"] > 5:
            self.data["CO01NUM001CC"] = 5

        if self.data["COQ1END010HP"] > 161508:
            self.data["COQ1END010HP"] = 161508

        if self.data["CO01END008RO"] > 6.72:
            self.data["CO01END008RO"] = 6.72

        if self.data["COQ1EXP004HP"] > 218:
            self.data["COQ1EXP004HP"] = 218

        if self.data["CO01END006CC"] > 0.23:
            self.data["CO01END006CC"] = 0.23

        if self.data["CO01END028CO"] > 1.72:
            self.data["CO01END028CO"] = 1.72

        if self.data["COQ1END003HP"] > 51111.5:
            self.data["COQ1END003HP"] = 51111.5

        # Binary Attributes
        if 0.29 < self.data["CO01END028IN"] <= 0.42:
            Q3_S11_CO01END028IN_4 = 1
        else:
            Q3_S11_CO01END028IN_4 = 0

        if 0.52 < self.data["CO01END045IN"] <= 41.27:
            Q3_S11_CO01END045IN_5 = 1
        else:
            Q3_S11_CO01END045IN_5 = 0

        if 45565.85 < self.data["COQ1END010HP"] <= 986590:
            Q3_S11_COQ1END010HP_3 = 1
        else:
            Q3_S11_COQ1END010HP_3 = 0

        if 62 < self.data["CO01EXP001HP"] <= 282:
            Q3_S11_CO01EXP001HP_3 = 1
        else:
            Q3_S11_CO01EXP001HP_3 = 0

        if 3 < self.data["COQ1NUM002TC"] <= 6:
            Q3_S11_COQ1NUM002TC_4 = 1
        else:
            Q3_S11_COQ1NUM002TC_4 = 0

        if 50 < self.data["CO02NUM042HP"] <= 100:
            Q3_S11_CO02NUM042HP_3 = 1
        else:
            Q3_S11_CO02NUM042HP_3 = 0

        if 0 <= self.data["CO01END007IN"] <= 2.49:
            Q3_S11_CO01END007IN_2 = 1
        else:
            Q3_S11_CO01END007IN_2 = 0

        if 0 <= self.data["CO01END092HP"] <= 2.07:
            Q3_S11_CO01END092HP_2 = 1
        else:
            Q3_S11_CO01END092HP_2 = 0

        if 0.43 < self.data["CO01END018HP"] <= 126.38:
            Q3_S11_CO01END018HP_3 = 1
        else:
            Q3_S11_CO01END018HP_3 = 0

        if self.data["CO01NUM001CC"] < 0:
            Q3_S11_CO01NUM001CC_1 = 1
        else:
            Q3_S11_CO01NUM001CC_1 = 0

        if 6 < self.data["COQ1NUM002TC"] <= 637:
            Q3_S11_COQ1NUM002TC_5 = 1
        else:
            Q3_S11_COQ1NUM002TC_5 = 0

        if 0 <= self.data["COQ1END010HP"] <= 45565.85:
            Q3_S11_COQ1END010HP_2 = 1
        else:
            Q3_S11_COQ1END010HP_2 = 0

        if 3.5 < self.data["CO01END008RO"] <= 4.35:
            Q3_S11_CO01END008RO_4 = 1
        else:
            Q3_S11_CO01END008RO_4 = 0

        if 0 <= self.data["COQ1EXP004HP"] <= 181:
            Q3_S11_COQ1EXP004HP_2 = 1
        else:
            Q3_S11_COQ1EXP004HP_2 = 0

        if 0 <= self.data["CO01END006CC"] <= 0.05:
            Q3_S11_CO01END006CC_2 = 1
        else:
            Q3_S11_CO01END006CC_2 = 0

        if 0.56 < self.data["CO01END028CO"] <= 450.07:
            Q3_S11_CO01END028CO_3 = 1
        else:
            Q3_S11_CO01END028CO_3 = 0

        if 34900 < self.data["COQ1END003HP"] <= 200000:
            Q3_S11_COQ1END003HP_3 = 1
        else:
            Q3_S11_COQ1END003HP_3 = 0

        if 0.42 < self.data["CO01END028IN"] <= 37.87:
            Q3_S11_CO01END028IN_5 = 1
        else:
            Q3_S11_CO01END028IN_5 = 0

        if 4.35 < self.data["CO01END008RO"] <= 130.69:
            Q3_S11_CO01END008RO_5 = 1
        else:
            Q3_S11_CO01END008RO_5 = 0

        # Binary Attributes
        if self.data["CO00DEM026"] in (5, 6):
            Q3_S11_ESTRATO56 = 1
        else:
            Q3_S11_ESTRATO56 = 0

        if self.data["CO01NUM002CC"] > 0:
            Q3_S11_TELECOM = 1
        else:
            Q3_S11_TELECOM = 0

        Q3_MAXIMO_CUPO_TOT = self.calcula_maximo_cupo_tot()
        if Q3_MAXIMO_CUPO_TOT < 0:
            Q3_MAXIMO_CUPO_TOT = -2

        Q3_S11_MAXCUPO_TOT = 0.0
        if 0 <= Q3_MAXIMO_CUPO_TOT <= 1500:
            Q3_S11_MAXCUPO_TOT = 1.0
        if 1500 < Q3_MAXIMO_CUPO_TOT <= 3150:
            Q3_S11_MAXCUPO_TOT = 2.0
        if 3150 < Q3_MAXIMO_CUPO_TOT <= 8000:
            Q3_S11_MAXCUPO_TOT = 3.0
        if Q3_MAXIMO_CUPO_TOT > 8000:
            Q3_S11_MAXCUPO_TOT = 4.0
        if Q3_MAXIMO_CUPO_TOT < 0:
            Q3_S11_MAXCUPO_TOT = 0.0

        if Q3_MAXIMO_CUPO_TOT == self.data["COQ1END003MC"]:
            Q3_S11_MAXCUPO_MC = 1
        else:
            Q3_S11_MAXCUPO_MC = 0

        Q3_S11_EXPONENTE = (0.41196 +
                            Q3_S11_CO01END008RO_5 * 0.20731 +
                            Q3_S11_CO01END028IN_5 * 0.19319 +
                            Q3_S11_COQ1END003HP_3 * 0.20876 +
                            Q3_S11_CO01END028CO_3 * 0.16241 +
                            Q3_S11_CO01END006CC_2 * -0.14003 +
                            Q3_S11_COQ1EXP004HP_2 * 0.14 +
                            Q3_S11_CO01END008RO_4 * 0.1295 +
                            Q3_S11_COQ1END010HP_2 * -0.15542 +
                            Q3_S11_COQ1NUM002TC_5 * 0.09775 +
                            Q3_S11_CO01NUM001CC_1 * -0.06873 +
                            Q3_S11_CO01END018HP_3 * 0.1514 +
                            Q3_S11_TELECOM * 0.13356 +
                            Q3_S11_CO01END092HP_2 * -0.11938 +
                            Q3_S11_ESTRATO56 * 0.10296 +
                            Q3_S11_CO01END007IN_2 * -0.09337 +
                            Q3_S11_CO02NUM042HP_3 * -0.11408 +
                            Q3_S11_COQ1NUM002TC_4 * 0.06252 +
                            Q3_S11_CO01EXP001HP_3 * 0.07752 +
                            Q3_S11_COQ1END010HP_3 * -0.104 +
                            Q3_S11_CO01END045IN_5 * 0.07444 +
                            Q3_S11_CO01END028IN_4 * 0.07909 +
                            Q3_S11_MAXCUPO_MC * -0.07887 +
                            self.data["CO02NUM002TO"] * 0.02699 +
                            Q3_S11_MAXCUPO_TOT * 0.01742 +
                            self.data["CO02NUM043CB"] * -0.00065344 +
                            self.data["CO02EXP001TO"] * 0.00067073)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S11_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0
        self.cal_salida_pesos_daqu3()

    def score_card12_daqu3(self):
        """
        Computes Score Card 12
        """
        # NO TEC NODO3 GRUPO 4
        self.inicializa_variables()
        self.score_card_daqu3 = 12
        self.adverse_razon_daqu3[0] = 99

        attributes = ["COQ1NUM002HP", "CO01END007IN", "COQ1END011TC", "CO01NUM001CC", "CO01END030RO",
                      "CO01END025RO", "COQ1END003IN", "CO01MOR008OT", "CO01END008RO", "COQ1END008TC",
                      "CO01NUM005HP", "CO02NUM018TO", "CO01MOR001RO"]
        # VALORES ESPECIALES
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        if self.q3_cuotatotal == 999:
            self.q3_cuotatotal = -1.0

        # Dimensioning
        if self.data["COQ1NUM002HP"] > 9:
            self.data["COQ1NUM002HP"] = 9

        if self.data["CO01END007IN"] > 48.67:
            self.data["CO01END007IN"] = 48.67

        if self.data["COQ1END011TC"] > 746.921428573:
            self.data["COQ1END011TC"] = 746.921428573

        if self.data["CO01NUM001CC"] > 6:
            self.data["CO01NUM001CC"] = 6

        if self.data["CO01END030RO"] > 7.41:
            self.data["CO01END030RO"] = 7.41

        if self.q3_cuotatotal > 4.28:
            self.q3_cuotatotal = 4.28

        if self.data["CO01END025RO"] > 7.58:
            self.data["CO01END025RO"] = 7.58

        if self.data["COQ1END003IN"] > 25086.8:
            self.data["COQ1END003IN"] = 25086.8

        if self.data["CO01MOR008OT"] > 7:
            self.data["CO01MOR008OT"] = 7

        if self.data["CO01END008RO"] > 13.77:
            self.data["CO01END008RO"] = 13.77

        if self.data["COQ1END008TC"] > 7333.183333315:
            self.data["COQ1END008TC"] = 7333.183333315

        if self.data["CO01NUM005HP"] > 2:
            self.data["CO01NUM005HP"] = 2

        if self.data["CO02NUM018TO"] > 1:
            self.data["CO02NUM018TO"] = 1

        if self.data["CO01MOR001RO"] > 6:
            self.data["CO01MOR001RO"] = 6

        # Binary Attributes
        if 0 <= self.data["COQ1NUM002HP"] <= 1:
            Q3_S12_COQ1NUM002HP_2 = 1
        else:
            Q3_S12_COQ1NUM002HP_2 = 0

        if 33.93 < self.data["CO01END007IN"] <= 2363.71:
            Q3_S12_CO01END007IN_5 = 1
        else:
            Q3_S12_CO01END007IN_5 = 0

        if 5.97 < self.data["CO01END007IN"] <= 19.28:
            Q3_S12_CO01END007IN_3 = 1
        else:
            Q3_S12_CO01END007IN_3 = 0

        if 342.4 < self.data["COQ1END011TC"] <= 746.921428573002:
            Q3_S12_COQ1END011TC_4 = 1
        else:
            Q3_S12_COQ1END011TC_4 = 0

        if self.data["CO01NUM001CC"] < 0:
            Q3_S12_CO01NUM001CC_1 = 1
        else:
            Q3_S12_CO01NUM001CC_1 = 0

        if 5.14 < self.data["CO01END030RO"] <= 128.81:
            Q3_S12_CO01END030RO_5 = 1
        else:
            Q3_S12_CO01END030RO_5 = 0

        if 1.41 < self.q3_cuotatotal <= 1.9:
            Q3_S12_CUOTATOTAL_4 = 1
        else:
            Q3_S12_CUOTATOTAL_4 = 0

        if 3.36 < self.data["CO01END025RO"] <= 130.9:
            Q3_S12_CO01END025RO_5 = 1
        else:
            Q3_S12_CO01END025RO_5 = 0

        if 14500 < self.data["COQ1END003IN"] <= 1000000:
            Q3_S12_COQ1END003IN_4 = 1
        else:
            Q3_S12_COQ1END003IN_4 = 0

        if 1.9 < self.q3_cuotatotal <= 149.96:
            Q3_S12_CUOTATOTAL_5 = 1
        else:
            Q3_S12_CUOTATOTAL_5 = 0

        if 0 <= self.data["CO01END007IN"] <= 5.97:
            Q3_S12_CO01END007IN_2 = 1
        else:
            Q3_S12_CO01END007IN_2 = 0

        if 0 < self.data["CO01MOR008OT"] <= 7:
            Q3_S12_CO01MOR008OT_3 = 1
        else:
            Q3_S12_CO01MOR008OT_3 = 0

        if 0 <= self.data["CO01END008RO"] <= 1.32:
            Q3_S12_CO01END008RO_2 = 1
        else:
            Q3_S12_CO01END008RO_2 = 0

        if 5400 < self.data["COQ1END008TC"] <= 115000:
            Q3_S12_COQ1END008TC_5 = 1
        else:
            Q3_S12_COQ1END008TC_5 = 0

        if 0 <= self.data["CO01NUM005HP"] <= 0:
            Q3_S12_CO01NUM005HP_2 = 1
        else:
            Q3_S12_CO01NUM005HP_2 = 0

        if self.data["CO01MOR001RO"] < 0:
            Q3_S12_CO01MOR001RO_1 = 1
        else:
            Q3_S12_CO01MOR001RO_1 = 0

        # Binary Attributes
        Q3_MAXIMO_CUPO_TOT = self.calcula_maximo_cupo_tot()
        if Q3_MAXIMO_CUPO_TOT < 0:
            Q3_MAXIMO_CUPO_TOT = -2

        if Q3_MAXIMO_CUPO_TOT == self.data["COQ1END003MC"]:
            Q3_S12_MAXCUPO_MC = 1
        else:
            Q3_S12_MAXCUPO_MC = 0

        if Q3_MAXIMO_CUPO_TOT == self.data["COQ1END003HP"]:
            Q3_S12_MAXCUPO_HP = 1
        else:
            Q3_S12_MAXCUPO_HP = 0

        if self.data["CO00DEM026"] in (4, 5, 6):
            Q3_S12_ESTRATO456 = 1
        else:
            Q3_S12_ESTRATO456 = 0

        if self.q3_tipoid == 4:
            Q3_S12_EXTRANJERIA = 1
        else:
            Q3_S12_EXTRANJERIA = 0

        Q3_S12_EXPONENTE = (0.96012 +
                            Q3_S12_EXTRANJERIA * 0.31975 +
                            Q3_S12_CO01MOR001RO_1 * 0.00661 +
                            self.data["CO02NUM018TO"] * -0.2661 +
                            Q3_S12_CO01NUM005HP_2 * -0.21768 +
                            Q3_S12_COQ1END008TC_5 * 0.12829 +
                            Q3_S12_CO01END008RO_2 * -0.17484 +
                            Q3_S12_CO01MOR008OT_3 * -0.19903 +
                            Q3_S12_CO01END007IN_2 * -0.14747 +
                            Q3_S12_CUOTATOTAL_5 * 0.21334 +
                            Q3_S12_COQ1END003IN_4 * 0.18315 +
                            Q3_S12_CO01END025RO_5 * 0.20388 +
                            Q3_S12_ESTRATO456 * 0.18432 +
                            Q3_S12_MAXCUPO_HP * 0.18763 +
                            Q3_S12_CUOTATOTAL_4 * 0.17108 +
                            Q3_S12_CO01END030RO_5 * 0.13878 +
                            Q3_S12_MAXCUPO_MC * -0.24126 +
                            Q3_S12_CO01NUM001CC_1 * -0.09068 +
                            Q3_S12_COQ1END011TC_4 * 0.11986 +
                            Q3_S12_CO01END007IN_3 * -0.07626 +
                            Q3_S12_CO01END007IN_5 * 0.06282 +
                            Q3_S12_COQ1NUM002HP_2 * 0.03475)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S12_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card13_daqu3(self):
        """
        Computes Score Card 13
        """
        # NO TEC NODO3 GRUPO 5
        self.inicializa_variables()
        self.score_card_daqu3 = 13
        self.adverse_razon_daqu3[0] = 99

        attributes = ["COQ1END016TC", "COQ1END009HP", "CO01END020RO", "CO01END028IN", "COQ1END003IN",
                      "CO01END028HP", "COQ1END008TC", "CO01END007IN", "COQ1END008TC", "COQ1END003HP",
                      "CO01END006CC", "CO01NUM001CT", "COQ1END003IN"]

        # VALORES ESPECIALES
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        if self.q3_cuotatotal == 999:
            self.q3_cuotatotal = -1.0

        # Dimensioning

        if self.data["COQ1END016TC"] > 30:
            self.data["COQ1END016TC"] = 30

        if self.data["COQ1END009HP"] > 1844.45:
            self.data["COQ1END009HP"] = 1844.45

        if self.data["CO01END020RO"] > 15.29:
            self.data["CO01END020RO"] = 15.29

        if self.data["CO01END028IN"] > 2.15:
            self.data["CO01END028IN"] = 2.15

        if self.data["COQ1END003IN"] > 64731.3:
            self.data["COQ1END003IN"] = 64731.3

        if self.data["CO01END028HP"] > 0.97:
            self.data["CO01END028HP"] = 0.97

        if self.data["COQ1END008TC"] > 14800:
            self.data["COQ1END008TC"] = 14800

        if self.data["CO01END007IN"] > 129.053:
            self.data["CO01END007IN"] = 129.053

        if self.data["COQ1END008TC"] > 14800:
            self.data["COQ1END008TC"] = 14800

        if self.data["COQ1END003HP"] > 56000:
            self.data["COQ1END003HP"] = 56000

        if self.data["CO01END006CC"] > 0.18:
            self.data["CO01END006CC"] = 0.18

        if self.data["CO01NUM001CT"] > 3:
            self.data["CO01NUM001CT"] = 3

        if self.q3_cuotatotal > 8.63:
            self.q3_cuotatotal = 8.63

        # Binary Attributes
        if 17 < self.data["COQ1END016TC"] <= 30:
            Q3_S13_COQ1END016TC_5 = 1
        else:
            Q3_S13_COQ1END016TC_5 = 0

        if 0 <= self.data["COQ1END009HP"] <= 1801.2:
            Q3_S13_COQ1END009HP_2 = 1
        else:
            Q3_S13_COQ1END009HP_2 = 0

        if 0 <= self.data["CO01END020RO"] <= 1:
            Q3_S13_CO01END020RO_2 = 1
        else:
            Q3_S13_CO01END020RO_2 = 0

        if 1.33 < self.data["CO01END028IN"] <= 1.97:
            Q3_S13_CO01END028IN_4 = 1
        else:
            Q3_S13_CO01END028IN_4 = 0

        if 39084 < self.data["COQ1END003IN"] <= 58000:
            Q3_S13_COQ1END003IN_4 = 1
        else:
            Q3_S13_COQ1END003IN_4 = 0

        if 0.91 < self.data["CO01END028HP"] <= 0.97:
            Q3_S13_CO01END028HP_3 = 1
        else:
            Q3_S13_CO01END028HP_3 = 0

        if 7150 < self.data["COQ1END008TC"] <= 9530:
            Q3_S13_COQ1END008TC_4 = 1
        else:
            Q3_S13_COQ1END008TC_4 = 0

        if 0 <= self.data["CO01END007IN"] <= 11.2:
            Q3_S13_CO01END007IN_2 = 1
        else:
            Q3_S13_CO01END007IN_2 = 0

        if 9530 < self.data["COQ1END008TC"] <= 14800:
            Q3_S13_COQ1END008TC_5 = 1
        else:
            Q3_S13_COQ1END008TC_5 = 0

        if 53903.6 < self.data["COQ1END003HP"] <= 56000:
            Q3_S13_COQ1END003HP_3 = 1
        else:
            Q3_S13_COQ1END003HP_3 = 0

        if 0 <= self.data["CO01END006CC"] <= 0:
            Q3_S13_CO01END006CC_2 = 1
        else:
            Q3_S13_CO01END006CC_2 = 0

        if self.data["CO01NUM001CT"] < 0:
            Q3_S13_CO01NUM001CT_1 = 1
        else:
            Q3_S13_CO01NUM001CT_1 = 0

        if 58000 < self.data["COQ1END003IN"] <= 64731.3:
            Q3_S13_COQ1END003IN_5 = 1
        else:
            Q3_S13_COQ1END003IN_5 = 0

        if self.q3_cuotatotal < 0:
            Q3_S13_CUOTATOTAL_1 = 1
        else:
            Q3_S13_CUOTATOTAL_1 = 0

        if self.q3_act_econ in (6, 2):
            Q3_ACTIVIDAD_ECONOMICA_3 = 1
        else:
            Q3_ACTIVIDAD_ECONOMICA_3 = 0

        # Binary Attributes
        if self.data["CO00DEM026"] in (4, 5, 6):
            Q3_S13_ESTRATO456 = 1
        else:
            Q3_S13_ESTRATO456 = 0

        Q3_MAXIMO_CUPO_TOT = self.calcula_maximo_cupo_tot()

        if Q3_MAXIMO_CUPO_TOT < 0:
            Q3_MAXIMO_CUPO_TOT = -2

        if Q3_MAXIMO_CUPO_TOT == self.data["COQ1END003TC"]:
            Q3_S13_MAXCUPO_TC = 1
        else:
            Q3_S13_MAXCUPO_TC = 0

        if self.q3_tipoid == 4:
            Q3_S13_EXTRANJERIA = 1
        else:
            Q3_S13_EXTRANJERIA = 0

        if self.data["COQ1END003MC"] == -1:
            Q3_S13_MICROCREDITO = 0
        else:
            Q3_S13_MICROCREDITO = 1

        Q3_S13_EXPONENTE = (1.78169 +
                            Q3_S13_CUOTATOTAL_1 * -0.57342 +
                            Q3_S13_COQ1END003IN_5 * 0.56523 +
                            Q3_S13_CO01NUM001CT_1 * -0.30414 +
                            Q3_S13_CO01END006CC_2 * -0.2882 +
                            Q3_S13_COQ1END003HP_3 * 0.28162 +
                            Q3_S13_COQ1END008TC_5 * 0.31457 +
                            Q3_ACTIVIDAD_ECONOMICA_3 * 0.25571 +
                            Q3_S13_MICROCREDITO * -0.19227 +
                            Q3_S13_CO01END007IN_2 * -0.24197 +
                            Q3_S13_EXTRANJERIA * 0.24271 +
                            Q3_S13_MAXCUPO_TC * 0.04062 +
                            Q3_S13_ESTRATO456 * 0.19886 +
                            Q3_S13_COQ1END008TC_4 * 0.18682 +
                            Q3_S13_CO01END028HP_3 * 0.16396 +
                            Q3_S13_COQ1END003IN_4 * 0.33267 +
                            Q3_S13_CO01END028IN_4 * 0.20013 +
                            Q3_S13_CO01END020RO_2 * -0.113 +
                            Q3_S13_COQ1END009HP_2 * -0.21321 +
                            Q3_S13_COQ1END016TC_5 * -0.13861)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S13_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1

        self.cal_salida_pesos_daqu3()

    def score_card14_daqu3(self):
        """
        Computes Score Card 14
        """
        # NO TEC NODO4 GRUPO 1
        self.inicializa_variables()
        self.score_card_daqu3 = 14
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO00DEM006", "CO00DEM026", "CO01NUM005RO", "CO02NUM043CC", "COQ1END011TC",
                      "COQ1END002HP", "COQ1END003IN", "COQ1END004TC", "COQ1END016TC"]

        # VALORES ESPECIALES
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        if self.q3_prexposicionin == 999:
            self.q3_prexposicionin = -1.0

        # Dimensioning
        if self.data["CO02EXP001TO"] > 274:
            self.data["CO02EXP001TO"] = 274

        if self.data["CO02NUM002TO"] > 10:
            self.data["CO02NUM002TO"] = 10

        if self.data["CO01END028IN"] > 1.03:
            self.data["CO01END028IN"] = 1.03

        if self.data["COQ1END002HP"] > 290:
            self.data["COQ1END002HP"] = 290

        # ERROR      MOVE FUNCTION NUMVAL(01END023CO) TO self.data["CO01END023CO"].
        if self.data["CO01END023CO"] > 0.61:
            self.data["CO01END023CO"] = 0.61

        # ERROR      MOVE FUNCTION NUMVAL(Q1END007IN) TO self.data["COQ1END007IN"].
        if self.data["COQ1END007IN"] > 615:
            self.data["COQ1END007IN"] = 615

        if self.data["COQ1END003IN"] > 11442.85:
            self.data["COQ1END003IN"] = 11442.85

        # ERROR      MOVE FUNCTION NUMVAL(01END029RO) TO self.data["CO01END029RO"].
        if self.data["CO01END029RO"] > 4.25:
            self.data["CO01END029RO"] = 4.25

        # ERROR      MOVE FUNCTION NUMVAL(Q1EXP004HP) TO self.data["COQ1EXP004HP"].
        if self.data["COQ1EXP004HP"] > 180:
            self.data["COQ1EXP004HP"] = 180

        # ERROR      MOVE FUNCTION NUMVAL(01END006CC) TO self.data["CO01END006CC"].
        if self.data["CO01END006CC"] > 0.08:
            self.data["CO01END006CC"] = 0.08

        # ERROR      MOVE FUNCTION NUMVAL(Q1END004TC) TO self.data["COQ1END004TC"].
        if self.data["COQ1END004TC"] > 3000:
            self.data["COQ1END004TC"] = 3000

        if self.data["CO01NUM005RO"] > 4:
            self.data["CO01NUM005RO"] = 4

        if self.q3_prexposicionin > 1:
            self.q3_prexposicionin = 1

        if self.data["CO00DEM006"] > 1:
            self.data["CO00DEM006"] = 1

        if self.data["CO00DEM026"] > 4:
            self.data["CO00DEM026"] = 4

        if self.data["CO02NUM043CC"] > 100:
            self.data["CO02NUM043CC"] = 100

        # ERROR      MOVE FUNCTION NUMVAL(01MOR008CC) TO self.data["CO01MOR008CC"].
        if self.data["CO01MOR008CC"] > 4:
            self.data["CO01MOR008CC"] = 4

        if self.data["COQ1END011TC"] > 352:
            self.data["COQ1END011TC"] = 352

        if self.data["COQ1END016TC"] > 20:
            self.data["COQ1END016TC"] = 20

        # ERROR      MOVE FUNCTION NUMVAL(01END005IN) TO self.data["CO01END005IN"].
        if self.data["CO01END005IN"] > 1.24:
            self.data["CO01END005IN"] = 1.24

        # Binary Attributes
        if 0.34 < self.data["CO01END028IN"] <= 0.51:
            Q3_S14_D_CO01END028IN_4 = 1
        else:
            Q3_S14_D_CO01END028IN_4 = 0

        if 0.51 < self.data["CO01END028IN"] <= 1.03:
            Q3_S14_D_CO01END028IN_5 = 1
        else:
            Q3_S14_D_CO01END028IN_5 = 0

        if 0 <= self.data["COQ1END002HP"] <= 275:
            Q3_S14_D_COQ1END002HP_2 = 1
        else:
            Q3_S14_D_COQ1END002HP_2 = 0

        if 0.5 < self.data["CO01END023CO"] <= 0.61:
            Q3_S14_D_CO01END023CO_4 = 1
        else:
            Q3_S14_D_CO01END023CO_4 = 0

        if 0 <= self.data["COQ1END007IN"] <= 111:
            Q3_S14_D_COQ1END007IN_2 = 1
        else:
            Q3_S14_D_COQ1END007IN_2 = 0

        if 10000 < self.data["COQ1END003IN"] <= 11442.85:
            Q3_S14_D_COQ1END003IN_5 = 1
        else:
            Q3_S14_D_COQ1END003IN_5 = 0

        if 3.95 < self.data["CO01END029RO"] <= 4.25:
            Q3_S14_D_CO01END029RO_4 = 1
        else:
            Q3_S14_D_CO01END029RO_4 = 0

        if 0 <= self.data["COQ1EXP004HP"] <= 171:
            Q3_S14_D_COQ1EXP004HP_2 = 1
        else:
            Q3_S14_D_COQ1EXP004HP_2 = 0

        if 0 <= self.data["CO01END006CC"] <= 0.03:
            Q3_S14_D_CO01END006CC_2 = 1
        else:
            Q3_S14_D_CO01END006CC_2 = 0

        if 0 <= self.data["COQ1END004TC"] <= 890:
            Q3_S14_D_COQ1END004TC_2 = 1
        else:
            Q3_S14_D_COQ1END004TC_2 = 0

        if 3 < self.data["CO01NUM005RO"] <= 4:
            Q3_S14_D_CO01NUM005RO_5 = 1
        else:
            Q3_S14_D_CO01NUM005RO_5 = 0

        if self.q3_prexposicionin < 0:
            Q3_S14_D_PREXPOSICIONIN_1 = 1
        else:
            Q3_S14_D_PREXPOSICIONIN_1 = 0

        if self.data["CO00DEM006"] == 0:
            Q3_S14_D_CO00DEM006_3 = 1
        else:
            Q3_S14_D_CO00DEM006_3 = 0

        if self.data["CO00DEM026"] == 1 or self.data["CO00DEM026"] == 2:  # ERROR
            Q3_S14_D_CO00DEM026_3 = 1
        else:
            Q3_S14_D_CO00DEM026_3 = 0

        if 0 < self.data["CO02NUM043CC"] <= 100:
            Q3_S14_D_CO02NUM043CC_3 = 1
        else:
            Q3_S14_D_CO02NUM043CC_3 = 0

        if 0 <= self.data["CO01MOR008CC"] <= 1:
            Q3_S14_D_CO01MOR008CC_2 = 1
        else:
            Q3_S14_D_CO01MOR008CC_2 = 0

        if 232 < self.data["COQ1END011TC"] <= 352:
            Q3_S14_D_COQ1END011TC_4 = 1
        else:
            Q3_S14_D_COQ1END011TC_4 = 0

        if 10 < self.data["COQ1END016TC"] <= 20:
            Q3_S14_D_COQ1END016TC_4 = 1
        else:
            Q3_S14_D_COQ1END016TC_4 = 0

        # Categoricas: Creacion
        # ERROR      MOVE FUNCTION NUMVAL(01END005IN) TO self.data["CO01END005IN"].
        if 0.425 <= self.data["CO01END005IN"] or 7.005 <= self.data["CO01END007RO"]:
            Q3_S14_BAJO_END_IN_RO = 0
        else:
            Q3_S14_BAJO_END_IN_RO = 1

        # ERROR      MOVE FUNCTION NUMVAL(Q1NUM002TC) TO self.data["COQ1NUM002TC"].
        if 0 < self.data["COQ1NUM002TC"] <= 1:
            Q3_S14_NUMERO_TC = 1

        if 1 < self.data["COQ1NUM002TC"] <= 3:
            Q3_S14_NUMERO_TC = 2

        if 3 < self.data["COQ1NUM002TC"] <= 6:
            Q3_S14_NUMERO_TC = 3

        if self.data["COQ1NUM002TC"] > 6:
            Q3_S14_NUMERO_TC = 4

        if self.data["COQ1NUM002TC"] < 0:
            Q3_S14_NUMERO_TC = 0

        Q3_S14_EXPONENTE = (0.38569 +
                            Q3_S14_BAJO_END_IN_RO * -0.0539 +
                            Q3_S14_NUMERO_TC * 0.02428 +
                            self.data["CO02EXP001TO"] * 0.00055507 +
                            self.data["CO02NUM002TO"] * 0.01987 +
                            Q3_S14_D_CO01END028IN_4 * 0.13491 +
                            Q3_S14_D_CO01END028IN_5 * 0.23672 +
                            Q3_S14_D_COQ1END002HP_2 * -0.18501 +
                            Q3_S14_D_CO01END023CO_4 * 0.14394 +
                            Q3_S14_D_COQ1END007IN_2 * -0.09227 +
                            Q3_S14_D_COQ1END003IN_5 * 0.1646 +
                            Q3_S14_D_CO01END029RO_4 * 0.1099 +
                            Q3_S14_D_COQ1EXP004HP_2 * 0.14813 +
                            Q3_S14_D_CO01END006CC_2 * -0.14806 +
                            Q3_S14_D_COQ1END004TC_2 * -0.08671 +
                            Q3_S14_D_CO01NUM005RO_5 * 0.07914 +
                            Q3_S14_D_PREXPOSICIONIN_1 * -0.09961 +
                            Q3_S14_D_CO00DEM006_3 * 0.06294 +
                            Q3_S14_D_CO00DEM026_3 * -0.08171 +
                            Q3_S14_D_CO02NUM043CC_3 * 0.04297 +
                            Q3_S14_D_CO01MOR008CC_2 * 0.12649 +
                            Q3_S14_D_COQ1END011TC_4 * 0.07775 +
                            Q3_S14_D_COQ1END016TC_4 * -0.06787)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S14_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1
        self.cal_salida_pesos_daqu3()

    def score_card15_daqu3(self):
        """
        Computes Score Card 15
        """
        # NO TEC NODO4 GRUPO 2
        self.inicializa_variables()
        self.score_card_daqu3 = 15
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO00DEM026", "CO01NUM001CC", "CO01NUM001CT", "CO01NUM002CC", "COQ1END002IN",
                      "COQ1END003HP", "COQ1END003IN", "COQ1END003MC", "COQ1END003TC", "COQ1END015TC",
                      "COQ1NUM002TC"]

        # VALORES ESPECIALES
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        self.cuotatotal_daqu3()  # ERROR
        if self.q3_cuotatotal == 999:
            self.q3_cuotatotal = -1.0

        # Dimensioning
        # ERROR      MOVE FUNCTION NUMVAL(02EXP003TO) TO self.data["CO02EXP003TO"]
        if self.data["CO02EXP003TO"] > 268:
            self.data["CO02EXP003TO"] = 268

        if self.data["CO01NUM001CT"] > 2:
            self.data["CO01NUM001CT"] = 2

        # ERROR      MOVE FUNCTION NUMVAL(01END008RO) TO self.data["CO01END008RO"]
        if self.data["CO01END008RO"] > 9.62:
            self.data["CO01END008RO"] = 9.62

        # ERROR      MOVE FUNCTION NUMVAL(01END025RO) TO self.data["CO01END025RO"]
        if self.data["CO01END025RO"] > 5.6:
            self.data["CO01END025RO"] = 5.6

        if self.data["CO00DEM026"] > 5:
            self.data["CO00DEM026"] = 5

        if self.data["CO01NUM001CC"] > 5:
            self.data["CO01NUM001CC"] = 5

        # ERROR      MOVE FUNCTION NUMVAL(01END018IN) TO self.data["CO01END018IN"]
        if self.data["CO01END018IN"] > 0.93:
            self.data["CO01END018IN"] = 0.93

        # ERROR      MOVE FUNCTION NUMVAL(01END028IN) TO self.data["CO01END028IN"]
        if self.data["CO01END028IN"] > 0.97:
            self.data["CO01END028IN"] = 0.97

        if self.data["CO01NUM002CC"] > 3:
            self.data["CO01NUM002CC"] = 3

        if self.data["COQ1END003IN"] > 23847.75:
            self.data["COQ1END003IN"] = 23847.75

        if self.data["COQ1END002IN"] > 688.25:
            self.data["COQ1END002IN"] = 688.25

        if self.q3_cuotatotal > 1.29:
            self.q3_cuotatotal = 1.29

        # ERROR      MOVE FUNCTION NUMVAL(01END028CO) TO self.data["CO01END028CO"]
        if self.data["CO01END028CO"] > 0.89:
            self.data["CO01END028CO"] = 0.89

        # ERROR      MOVE FUNCTION NUMVAL(01END005CC) TO self.data["CO01END005CC"]
        if self.data["CO01END005CC"] > 0.17:
            self.data["CO01END005CC"] = 0.17

        if self.data["CO01END012CC"] > 0.04:
            self.data["CO01END012CC"] = 0.04

        if self.data["COQ1END015TC"] > 26:
            self.data["COQ1END015TC"] = 26

        # Binary Attributes
        if self.data["CO01NUM001CT"] < 0:
            Q3_S15_D_CO01NUM001CT_1 = 1
        else:
            Q3_S15_D_CO01NUM001CT_1 = 0

        if 0 <= self.data["CO01END008RO"] <= 1.59:
            Q3_S15_D_CO01END008RO_2 = 1
        else:
            Q3_S15_D_CO01END008RO_2 = 0

        if 4.18 < self.data["CO01END025RO"] <= 5.6:
            Q3_S15_D_CO01END025RO_5 = 1
        else:
            Q3_S15_D_CO01END025RO_5 = 0

        if 1 <= self.data["CO00DEM026"] <= 2:
            Q3_S15_D_CO00DEM026_4 = 1
        else:
            Q3_S15_D_CO00DEM026_4 = 0

        if 4 <= self.data["CO00DEM026"] <= 6:
            Q3_S15_D_CO00DEM026_5 = 1
        else:
            Q3_S15_D_CO00DEM026_5 = 0

        if self.data["CO01NUM001CC"] < 0:
            Q3_S15_D_CO01NUM001CC_1 = 1
        else:
            Q3_S15_D_CO01NUM001CC_1 = 0

        if 0 <= self.data["CO01END018IN"] <= 0.27:
            Q3_S15_D_CO01END018IN_2 = 1
        else:
            Q3_S15_D_CO01END018IN_2 = 0

        if 0.78 < self.data["CO01END028IN"] <= 0.97:
            Q3_S15_D_CO01END028IN_5 = 1
        else:
            Q3_S15_D_CO01END028IN_5 = 0

        if 0 <= self.data["CO01NUM002CC"] <= 1:
            Q3_S15_D_CO01NUM002CC_2 = 1
        else:
            Q3_S15_D_CO01NUM002CC_2 = 0

        if 22900 < self.data["COQ1END003IN"] <= 23847.75:
            Q3_S15_D_COQ1END003IN_5 = 1
        else:
            Q3_S15_D_COQ1END003IN_5 = 0

        if 446 < self.data["COQ1END002IN"] <= 688.25:
            Q3_S15_D_COQ1END002IN_5 = 1
        else:
            Q3_S15_D_COQ1END002IN_5 = 0

        if 0 <= self.q3_cuotatotal <= 0.52:
            Q3_S15_D_CUOTATOTAL_2 = 1
        else:
            Q3_S15_D_CUOTATOTAL_2 = 0

        if 0.7 < self.data["CO01END028CO"] <= 0.89:
            Q3_S15_D_CO01END028CO_5 = 1
        else:
            Q3_S15_D_CO01END028CO_5 = 0

        if 0 <= self.data["CO01END005CC"] <= 0.05:
            Q3_S15_D_CO01END005CC_2 = 1
        else:
            Q3_S15_D_CO01END005CC_2 = 0

        if 0 <= self.data["CO01END012CC"] <= 0.03:
            Q3_S15_D_CO01END012CC_2 = 1
        else:
            Q3_S15_D_CO01END012CC_2 = 0

        if 13 < self.data["COQ1END015TC"] <= 26:
            Q3_S15_D_COQ1END015TC_5 = 1
        else:
            Q3_S15_D_COQ1END015TC_5 = 0

        # ERROR      MOVE FUNCTION NUMVAL(01END007RO) TO self.data["CO01END007RO"]
        if 9.685 <= self.data["CO01END007RO"]:
            Q3_S15_DD_CO01END007RO = 1
        else:
            Q3_S15_DD_CO01END007RO = 0

        # Binary Attributes
        Q3_S15_NUMERO_TC = 0.0
        if 0 < self.data["COQ1NUM002TC"] <= 1:
            Q3_S15_NUMERO_TC = 1

        if 1 < self.data["COQ1NUM002TC"] <= 3:
            Q3_S15_NUMERO_TC = 2

        if 3 < self.data["COQ1NUM002TC"] <= 6:
            Q3_S15_NUMERO_TC = 3

        if self.data["COQ1NUM002TC"] > 6:
            Q3_S15_NUMERO_TC = 4

        if self.data["COQ1NUM002TC"] < 0:
            Q3_S15_NUMERO_TC = 0

        Q3_MAXIMO_CUPO_TOT = self.calcula_maximo_cupo_tot()
        Q3_S15_MAXCUPO_TOT = 0.0
        if Q3_MAXIMO_CUPO_TOT < 0:
            Q3_MAXIMO_CUPO_TOT = -2

        if Q3_MAXIMO_CUPO_TOT < 0:
            Q3_S15_MAXCUPO_TOT = 1

        if 0 <= Q3_MAXIMO_CUPO_TOT <= 2730:
            Q3_S15_MAXCUPO_TOT = 2

        if 2730 < Q3_MAXIMO_CUPO_TOT <= 7000:
            Q3_S15_MAXCUPO_TOT = 3

        if 7000 < Q3_MAXIMO_CUPO_TOT <= 15000:
            Q3_S15_MAXCUPO_TOT = 4

        if Q3_MAXIMO_CUPO_TOT > 15000:
            Q3_S15_MAXCUPO_TOT = 5

        Q3_S15_EXPONENTE = (1.03823 +
                            Q3_S15_DD_CO01END007RO * 0.13646 +
                            Q3_S15_MAXCUPO_TOT * 0.0137 +
                            Q3_S15_NUMERO_TC * 0.03305 +
                            self.data["CO02EXP003TO"] * 0.00039504 +
                            Q3_S15_D_CO01NUM001CT_1 * -0.19427 +
                            Q3_S15_D_CO01END008RO_2 * -0.12637 +
                            Q3_S15_D_CO01END025RO_5 * 0.15468 +
                            Q3_S15_D_CO00DEM026_4 * -0.12129 +
                            Q3_S15_D_CO00DEM026_5 * 0.09344 +
                            Q3_S15_D_CO01NUM001CC_1 * -0.14167 +
                            Q3_S15_D_CO01END018IN_2 * -0.09585 +
                            Q3_S15_D_CO01END028IN_5 * 0.11469 +
                            Q3_S15_D_CO01NUM002CC_2 * -0.06448 +
                            Q3_S15_D_COQ1END003IN_5 * 0.23882 +
                            Q3_S15_D_COQ1END002IN_5 * 0.08301 +
                            Q3_S15_D_CUOTATOTAL_2 * -0.07543 +
                            Q3_S15_D_CO01END028CO_5 * 0.11997 +
                            Q3_S15_D_CO01END005CC_2 * -0.13974 +
                            Q3_S15_D_CO01END012CC_2 * 0.11495 +
                            Q3_S15_D_COQ1END015TC_5 * -0.10092)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S15_EXPONENTE, 2)  # rounded

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card16_daqu3(self):
        """
        Computes Score Card 16
        """
        # NO TEC NODO4 GRUPO 3
        self.inicializa_variables()
        self.score_card_daqu3 = 16
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO02NUM002TO", "CO02NUM005TO", "CO02NUM018TO", "CO01END007IN", "CO01END010RO",
                      "CO01END011CO", "CO01END023CC", "CO01END028CO", "CO01END035CC", "CO01END046IN",
                      "CO01END065IN", "CO01END075RO", "CO01NUM001CT", "CO01NUM005HP", "CO02END007HP",
                      "CO02END040RO", "COQ1END011TC", "COQ1END002HP", "COQ1END004HP", "COQ1END005IN",
                      "COQ1END005TC", "COQ1END013TC", "COQ1END013TC", "COQ1END014TC", "COQ1END008TC",
                      "COQ1END009HP", "COQ1END009IN"]

        # VALORES ESPECIALES
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        self.sectores_daqu3()  # ERROR
        if self.q3_telcos == 999:
            self.q3_telcos = -1.0

        # Dimensioning
        if self.data["CO02NUM002TO"] > 14:
            self.data["CO02NUM002TO"] = 14

        if self.data["CO02NUM005TO"] > 28:
            self.data["CO02NUM005TO"] = 28

        if self.data["CO02NUM018TO"] > 1:
            self.data["CO02NUM018TO"] = 1

        if self.data["CO01END007IN"] > 72.6205:
            self.data["CO01END007IN"] = 72.6205

        if self.data["CO01END010RO"] > 10.25:
            self.data["CO01END010RO"] = 10.25

        if self.data["CO01END011CO"] > 11.0109999999999:
            self.data["CO01END011CO"] = 11.0109999999999

        if self.data["CO01END023CC"] > 0.19:
            self.data["CO01END023CC"] = 0.19

        if self.data["CO01END028CO"] > 0.97:
            self.data["CO01END028CO"] = 0.97

        if self.data["CO01END035CC"] > 0.2:
            self.data["CO01END035CC"] = 0.2

        if self.data["CO01END046IN"] > 1.72:
            self.data["CO01END046IN"] = 1.72

        if self.data["CO01END065IN"] > 2.82:
            self.data["CO01END065IN"] = 2.82

        if self.data["CO01END075RO"] > 99.0204999999999:
            self.data["CO01END075RO"] = 99.0204999999999

        if self.data["CO01NUM001CT"] > 3:
            self.data["CO01NUM001CT"] = 3

        if self.data["CO01NUM005HP"] > 1:
            self.data["CO01NUM005HP"] = 1

        if self.data["CO02END007HP"] > 1.42:
            self.data["CO02END007HP"] = 1.42

        if self.data["CO02END040RO"] > 167.562:
            self.data["CO02END040RO"] = 167.562

        if self.data["COQ1END011TC"] > 1138.5:
            self.data["COQ1END011TC"] = 1138.5

        if self.data["COQ1END002HP"] > 512:
            self.data["COQ1END002HP"] = 512

        if self.data["COQ1END004HP"] > 38659.3999999998:
            self.data["COQ1END004HP"] = 38659.3999999998

        if self.data["COQ1END005IN"] > 16793.9999999999:
            self.data["COQ1END005IN"] = 16793.9999999999

        if self.data["COQ1END005TC"] > 3600:
            self.data["COQ1END005TC"] = 3600

        if self.data["COQ1END013TC"] > 14867.9999999999:
            self.data["COQ1END013TC"] = 14867.9999999999

        if self.data["COQ1END014TC"] > 28800:
            self.data["COQ1END014TC"] = 28800

        if self.data["COQ1END008TC"] > 9000:
            self.data["COQ1END008TC"] = 9000

        if self.data["COQ1END009HP"] > 996:
            self.data["COQ1END009HP"] = 996

        if self.data["COQ1END009IN"] > 3716.39999999999:
            self.data["COQ1END009IN"] = 3716.39999999999

        # Binary Attributes
        if 52.518 < self.data["CO01END007IN"] <= 69.0160000000001:
            Q3_S16_CO01END007IN_4 = 1
        else:
            Q3_S16_CO01END007IN_4 = 0

        if 69.0160000000001 < self.data["CO01END007IN"] <= 72.6205:
            Q3_S16_CO01END007IN_5 = 1
        else:
            Q3_S16_CO01END007IN_5 = 0

        if 4.88 < self.data["CO01END010RO"] <= 8.97:
            Q3_S16_CO01END010RO_4 = 1
        else:
            Q3_S16_CO01END010RO_4 = 0

        if 10.83 < self.data["CO01END011CO"] <= 11.0109999999999:
            Q3_S16_CO01END011CO_3 = 1
        else:
            Q3_S16_CO01END011CO_3 = 0

        if 0.14 < self.data["CO01END023CC"] <= 0.19:
            Q3_S16_CO01END023CC_5 = 1
        else:
            Q3_S16_CO01END023CC_5 = 0

        if 0 <= self.data["CO01END028CO"] <= 0.31:
            Q3_S16_CO01END028CO_2 = 1
        else:
            Q3_S16_CO01END028CO_2 = 0

        if 0.68 < self.data["CO01END028CO"] <= 0.97:
            Q3_S16_CO01END028CO_4 = 1
        else:
            Q3_S16_CO01END028CO_4 = 0

        if 0 <= self.data["CO01END035CC"] <= 0.05:
            Q3_S16_CO01END035CC_2 = 1
        else:
            Q3_S16_CO01END035CC_2 = 0

        if 0 <= self.data["CO01END046IN"] <= 0.34:
            Q3_S16_CO01END046IN_2 = 1
        else:
            Q3_S16_CO01END046IN_2 = 0

        if 0 <= self.data["CO01END065IN"] <= 0.63:
            Q3_S16_CO01END065IN_2 = 1
        else:
            Q3_S16_CO01END065IN_2 = 0

        if 87.06 < self.data["CO01END075RO"] <= 98.14:
            Q3_S16_CO01END075RO_4 = 1
        else:
            Q3_S16_CO01END075RO_4 = 0

        if 0 <= self.data["CO01NUM001CT"] <= 1:
            Q3_S16_CO01NUM001CT_2 = 1
        else:
            Q3_S16_CO01NUM001CT_2 = 0

        if 1 < self.data["CO01NUM001CT"] <= 2:
            Q3_S16_CO01NUM001CT_3 = 1
        else:
            Q3_S16_CO01NUM001CT_3 = 0

        if 2 < self.data["CO01NUM001CT"] <= 3:
            Q3_S16_CO01NUM001CT_4 = 1
        else:
            Q3_S16_CO01NUM001CT_4 = 0

        if 0 < self.data["CO01NUM005HP"] <= 1:
            Q3_S16_CO01NUM005HP_3 = 1
        else:
            Q3_S16_CO01NUM005HP_3 = 0

        if 1.38 < self.data["CO02END007HP"] <= 1.42:
            Q3_S16_CO02END007HP_3 = 1
        else:
            Q3_S16_CO02END007HP_3 = 0

        if 0 <= self.data["CO02END040RO"] <= 2.7935:
            Q3_S16_CO02END040RO_2 = 1
        else:
            Q3_S16_CO02END040RO_2 = 0

        if 2.7935 < self.data["CO02END040RO"] <= 37.632:
            Q3_S16_CO02END040RO_3 = 1
        else:
            Q3_S16_CO02END040RO_3 = 0

        if 209.291428574 < self.data["COQ1END011TC"] <= 445:
            Q3_S16_COQ1END011TC_3 = 1
        else:
            Q3_S16_COQ1END011TC_3 = 0

        if 0 <= self.data["COQ1END002HP"] <= 419.75:
            Q3_S16_COQ1END002HP_2 = 1
        else:
            Q3_S16_COQ1END002HP_2 = 0

        if 38221.7 < self.data["COQ1END004HP"] <= 38659.3999999998:
            Q3_S16_COQ1END004HP_3 = 1
        else:
            Q3_S16_COQ1END004HP_3 = 0

        if 0 <= self.data["COQ1END005IN"] <= 16000:
            Q3_S16_COQ1END005IN_2 = 1
        else:
            Q3_S16_COQ1END005IN_2 = 0

        if 0 <= self.data["COQ1END005TC"] <= 2360:
            Q3_S16_COQ1END005TC_2 = 1
        else:
            Q3_S16_COQ1END005TC_2 = 0

        if 0 <= self.data["COQ1END013TC"] <= 4500:
            Q3_S16_COQ1END013TC_2 = 1
        else:
            Q3_S16_COQ1END013TC_2 = 0

        if 4500 < self.data["COQ1END013TC"] <= 10522:
            Q3_S16_COQ1END013TC_3 = 1
        else:
            Q3_S16_COQ1END013TC_3 = 0

        if 0 <= self.data["COQ1END014TC"] <= 1600:
            Q3_S16_COQ1END014TC_2 = 1
        else:
            Q3_S16_COQ1END014TC_2 = 0

        if 1600 < self.data["COQ1END014TC"] <= 10000:
            Q3_S16_COQ1END014TC_3 = 1
        else:
            Q3_S16_COQ1END014TC_3 = 0

        if 7350 < self.data["COQ1END008TC"] <= 9000:
            Q3_S16_COQ1END008TC_5 = 1
        else:
            Q3_S16_COQ1END008TC_5 = 0

        if 0 <= self.data["COQ1END009HP"] <= 716:
            Q3_S16_COQ1END009HP_2 = 1
        else:
            Q3_S16_COQ1END009HP_2 = 0

        if 0 <= self.data["COQ1END009IN"] <= 246:
            Q3_S16_COQ1END009IN_2 = 1
        else:
            Q3_S16_COQ1END009IN_2 = 0

        # Binary Attributes
        # ERROR      MOVE FUNCTION NUMVAL(Q1NUM002TC) TO self.data["COQ1NUM002TC"]
        Q3_S16_NUMERO_TC = 0.0
        if self.data["COQ1NUM002TC"] < 0:
            Q3_S16_NUMERO_TC = 0

        if 0 <= self.data["COQ1NUM002TC"] <= 3:
            Q3_S16_NUMERO_TC = 1

        if 3 < self.data["COQ1NUM002TC"] <= 15:
            Q3_S16_NUMERO_TC = 2

        if 15 < self.data["COQ1NUM002TC"] <= 123:
            Q3_S16_NUMERO_TC = 3

        if self.data["COQ1NUM002TC"] > 123:
            Q3_S16_NUMERO_TC = 4

        Q3_ACTIVIDAD_ECONOMICA_C = 0.0
        if self.q3_act_econ == 7:
            Q3_ACTIVIDAD_ECONOMICA_C = 1.0
        elif self.q3_act_econ in (3, 2):
            Q3_ACTIVIDAD_ECONOMICA_C = 2.0
        elif self.q3_act_econ in (6, 5, 4, 1):
            Q3_ACTIVIDAD_ECONOMICA_C = 3.0

        Q3_S16_TELCOS_C = 0.0
        if self.q3_telcos < 0 or self.q3_telcos == 999:
            Q3_S16_TELCOS_C = 1.0
        elif self.q3_telcos == 0:
            Q3_S16_TELCOS_C = 2.0
        elif self.q3_telcos == 1:
            Q3_S16_TELCOS_C = 3.0

        Q3_S16_EXPONENTE = (0.76873 +
                            Q3_S16_NUMERO_TC * 0.06027 +
                            self.data["CO02NUM002TO"] * 0.01569 +
                            self.data["CO02NUM005TO"] * -0.00226 +
                            self.data["CO02NUM018TO"] * -0.3195 +
                            Q3_S16_CO01END007IN_4 * 0.24118 +
                            Q3_S16_CO01END007IN_5 * 0.34298 +
                            Q3_S16_CO01END010RO_4 * 0.15307 +
                            Q3_S16_CO01END011CO_3 * 0.07548 +
                            Q3_S16_CO01END023CC_5 * 0.17161 +
                            Q3_S16_CO01END028CO_2 * -0.07857 +
                            Q3_S16_CO01END028CO_4 * 0.0805 +
                            Q3_S16_CO01END035CC_2 * -0.03551 +
                            Q3_S16_CO01END046IN_2 * -0.09556 +
                            Q3_S16_CO01END065IN_2 * -0.04792 +
                            Q3_S16_CO01END075RO_4 * -0.03344 +
                            Q3_S16_CO01NUM001CT_2 * 0.1944 +
                            Q3_S16_CO01NUM001CT_3 * 0.27313 +
                            Q3_S16_CO01NUM001CT_4 * 0.3371 +
                            Q3_S16_CO01NUM005HP_3 * 0.09334 +
                            Q3_S16_CO02END007HP_3 * 0.1095 +
                            Q3_S16_CO02END040RO_2 * -0.097 +
                            Q3_S16_CO02END040RO_3 * -0.03465 +
                            Q3_S16_COQ1END011TC_3 * 0.01622 +
                            Q3_S16_COQ1END002HP_2 * -0.18235 +
                            Q3_S16_COQ1END004HP_3 * 0.08692 +
                            Q3_S16_COQ1END005IN_2 * -0.05 +
                            Q3_S16_COQ1END005TC_2 * -0.06598 +
                            Q3_S16_COQ1END013TC_2 * -0.06737 +
                            Q3_S16_COQ1END013TC_3 * -0.05955 +
                            Q3_S16_COQ1END014TC_2 * -0.13309 +
                            Q3_S16_COQ1END014TC_3 * -0.03987 +
                            Q3_S16_COQ1END008TC_5 * 0.16769 +
                            Q3_S16_COQ1END009HP_2 * -0.10754 +
                            Q3_S16_COQ1END009IN_2 * -0.07199 +
                            Q3_ACTIVIDAD_ECONOMICA_C * 0.03775 +
                            Q3_S16_TELCOS_C * 0.08873)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S16_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card17_daqu3(self):
        """
        Computes Score Card 17
        """
        # NO TEC NODO4 GRUPO 4
        self.inicializa_variables()
        self.score_card_daqu3 = 17
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO02NUM018TO", "CO01END003RO", "CO01END005RO", "CO01END006CC", "CO01END006HP",
                      "CO01END007IN", "CO01END010RO", "CO01END013IN", "CO01END018VE", "CO01END019RO",
                      "CO01END021RO", "CO01END028IN", "CO01END030RO", "CO01END034RO", "CO01END035RO",
                      "CO01END046CO", "CO01MOR001CC", "CO01MOR008RO", "CO01NUM002CT", "CO02END006CB",
                      "CO02END037RO", "CO02NUM042HP", "COQ1END003IN", "COQ1END013TC", "COQ1END010IN"]

        # CALCULO DE HIBRIDAS
        self.sectores_daqu3()
        self.cuotatotal_daqu3()

        # VALORES ESPECIALES
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        if self.q3_cuotatotal == 999:
            self.q3_cuotatotal = -1.0

        # Dimensioning
        if self.data["CO02NUM018TO"] > 1:
            self.data["CO02NUM018TO"] = 1

        if self.q3_cuotatotal > 11.2825:
            self.q3_cuotatotal = 11.2825

        if self.data["CO01END003RO"] > 3.03:
            self.data["CO01END003RO"] = 3.03

        if self.data["CO01END005RO"] > 6.93:
            self.data["CO01END005RO"] = 6.93

        if self.data["CO01END006CC"] > 0.2:
            self.data["CO01END006CC"] = 0.2

        if self.data["CO01END006HP"] > 1.15:
            self.data["CO01END006HP"] = 1.15

        if self.data["CO01END007IN"] > 126.21:
            self.data["CO01END007IN"] = 126.21

        if self.data["CO01END010RO"] > 8.86:
            self.data["CO01END010RO"] = 8.86

        if self.data["CO01END013IN"] > 2.655:
            self.data["CO01END013IN"] = 2.655

        if self.data["CO01END018VE"] > 1.47:
            self.data["CO01END018VE"] = 1.47

        if self.data["CO01END019RO"] > 18.67:
            self.data["CO01END019RO"] = 18.67

        if self.data["CO01END021RO"] > 12.135:
            self.data["CO01END021RO"] = 12.135

        if self.data["CO01END028IN"] > 2.55:
            self.data["CO01END028IN"] = 2.55

        if self.data["CO01END030RO"] > 9.305:
            self.data["CO01END030RO"] = 9.305

        if self.data["CO01END034RO"] > 0.885:
            self.data["CO01END034RO"] = 0.885

        if self.data["CO01END035RO"] > 5.995:
            self.data["CO01END035RO"] = 5.995

        if self.data["CO01END046CO"] > 0.71:
            self.data["CO01END046CO"] = 0.71

        if self.data["CO01MOR001CC"] > 3:
            self.data["CO01MOR001CC"] = 3

        if self.data["CO01MOR008RO"] > 7:
            self.data["CO01MOR008RO"] = 7

        if self.data["CO01NUM002CT"] > 2:
            self.data["CO01NUM002CT"] = 2

        if self.data["CO02END006CB"] > 79.61:
            self.data["CO02END006CB"] = 79.61

        if self.data["CO02END037RO"] > 306.465:
            self.data["CO02END037RO"] = 306.465

        if self.data["CO02NUM042HP"] > 100:
            self.data["CO02NUM042HP"] = 100

        if self.data["COQ1END003IN"] > 50000:
            self.data["COQ1END003IN"] = 50000

        if self.data["COQ1END013TC"] > 10377.8:
            self.data["COQ1END013TC"] = 10377.8

        if self.data["COQ1END010IN"] > 73580.4:
            self.data["COQ1END010IN"] = 73580.4

        # Binary Attributes
        if 0 <= self.data["CO01END003RO"] <= 0.17:
            Q3_S17_CO01END003RO_2 = 1
        else:
            Q3_S17_CO01END003RO_2 = 0

        if 0 <= self.data["CO01END005RO"] <= 1.97:
            Q3_S17_CO01END005RO_2 = 1
        else:
            Q3_S17_CO01END005RO_2 = 0

        if 0 <= self.data["CO01END006CC"] <= 0.04:
            Q3_S17_CO01END006CC_2 = 1
        else:
            Q3_S17_CO01END006CC_2 = 0

        if 0 <= self.data["CO01END006HP"] <= 0.99:
            Q3_S17_CO01END006HP_2 = 1
        else:
            Q3_S17_CO01END006HP_2 = 0

        if 73.4700000000001 < self.data["CO01END007IN"] <= 126.21:
            Q3_S17_CO01END007IN_4 = 1
        else:
            Q3_S17_CO01END007IN_4 = 0

        if 6.78 < self.data["CO01END010RO"] <= 8.86:
            Q3_S17_CO01END010RO_5 = 1
        else:
            Q3_S17_CO01END010RO_5 = 0

        if 0 <= self.data["CO01END013IN"] <= 0.36:
            Q3_S17_CO01END013IN_2 = 1
        else:
            Q3_S17_CO01END013IN_2 = 0

        if 0.699000000000001 < self.data["CO01END018VE"] <= 1.2:
            Q3_S17_CO01END018VE_3 = 1
        else:
            Q3_S17_CO01END018VE_3 = 0

        if 1.2 < self.data["CO01END018VE"] <= 1.47:
            Q3_S17_CO01END018VE_4 = 1
        else:
            Q3_S17_CO01END018VE_4 = 0

        if 0 <= self.data["CO01END019RO"] <= 2.53:
            Q3_S17_CO01END019RO_2 = 1
        else:
            Q3_S17_CO01END019RO_2 = 0

        if 2.24 < self.data["CO01END021RO"] <= 4.21:
            Q3_S17_CO01END021RO_3 = 1
        else:
            Q3_S17_CO01END021RO_3 = 0

        if 1.01 < self.data["CO01END028IN"] <= 2.55:
            Q3_S17_CO01END028IN_5 = 1
        else:
            Q3_S17_CO01END028IN_5 = 0

        if 3.82 < self.data["CO01END030RO"] <= 6.829:
            Q3_S17_CO01END030RO_4 = 1
        else:
            Q3_S17_CO01END030RO_4 = 0

        if 6.829 < self.data["CO01END030RO"] <= 9.305:
            Q3_S17_CO01END030RO_5 = 1
        else:
            Q3_S17_CO01END030RO_5 = 0

        if 0 <= self.data["CO01END034RO"] <= 0:
            Q3_S17_CO01END034RO_2 = 1
        else:
            Q3_S17_CO01END034RO_2 = 0

        if 0 <= self.data["CO01END035RO"] <= 1.37:
            Q3_S17_CO01END035RO_2 = 1
        else:
            Q3_S17_CO01END035RO_2 = 0

        if 3.6 < self.data["CO01END035RO"] <= 5.995:
            Q3_S17_CO01END035RO_5 = 1
        else:
            Q3_S17_CO01END035RO_5 = 0

        if 0 <= self.data["CO01END046CO"] <= 0.55:
            Q3_S17_CO01END046CO_2 = 1
        else:
            Q3_S17_CO01END046CO_2 = 0

        if 0 <= self.data["CO01MOR001CC"] <= 1:
            Q3_S17_CO01MOR001CC_2 = 1
        else:
            Q3_S17_CO01MOR001CC_2 = 0

        if 0 < self.data["CO01MOR008RO"] <= 7:
            Q3_S17_CO01MOR008RO_3 = 1
        else:
            Q3_S17_CO01MOR008RO_3 = 0

        if 0 <= self.data["CO01NUM002CT"] <= 0:
            Q3_S17_CO01NUM002CT_2 = 1
        else:
            Q3_S17_CO01NUM002CT_2 = 0

        if 0 < self.data["CO01NUM002CT"] <= 1:
            Q3_S17_CO01NUM002CT_3 = 1
        else:
            Q3_S17_CO01NUM002CT_3 = 0

        if 1 < self.data["CO01NUM002CT"] <= 2:
            Q3_S17_CO01NUM002CT_4 = 1
        else:
            Q3_S17_CO01NUM002CT_4 = 0

        if 0 <= self.data["CO02END006CB"] <= 6.17:
            Q3_S17_CO02END006CB_2 = 1
        else:
            Q3_S17_CO02END006CB_2 = 0

        if 6.17 < self.data["CO02END006CB"] <= 21.51:
            Q3_S17_CO02END006CB_3 = 1
        else:
            Q3_S17_CO02END006CB_3 = 0

        if 0 <= self.data["CO02END037RO"] <= 0:
            Q3_S17_CO02END037RO_2 = 1
        else:
            Q3_S17_CO02END037RO_2 = 0

        if 0 <= self.data["CO02NUM042HP"] <= 66.67:
            Q3_S17_CO02NUM042HP_2 = 1
        else:
            Q3_S17_CO02NUM042HP_2 = 0

        if 0 <= self.data["COQ1END003IN"] <= 9800:
            Q3_S17_COQ1END003IN_2 = 1
        else:
            Q3_S17_COQ1END003IN_2 = 0

        if 0 <= self.data["COQ1END013TC"] <= 2340:
            Q3_S17_COQ1END013TC_2 = 1
        else:
            Q3_S17_COQ1END013TC_2 = 0

        if 43434 < self.data["COQ1END010IN"] <= 73580.4:
            Q3_S17_COQ1END010IN_4 = 1
        else:
            Q3_S17_COQ1END010IN_4 = 0

        # Binary Attributes
        if self.data["COQ1END003MC"] == -1:
            Q3_S17_MICROCREDITO = 0
        else:
            Q3_S17_MICROCREDITO = 1

        if self.data["CO01NUM002CC"] > 0:
            Q3_S17_TELECOM = 1
        else:
            Q3_S17_TELECOM = 0

        Q3_S17_EXPONENTE = (1.17974 +
                            Q3_S17_MICROCREDITO * -0.18843 +
                            Q3_S17_TELECOM * 0.19684 +
                            self.data["CO02NUM018TO"] * -0.3646 +
                            self.q3_cuotatotal * 0.0262 +
                            Q3_S17_CO01END003RO_2 * 0.09514 +
                            Q3_S17_CO01END005RO_2 * -0.0601 +
                            Q3_S17_CO01END006CC_2 * -0.15298 +
                            Q3_S17_CO01END006HP_2 * -0.19123 +
                            Q3_S17_CO01END007IN_4 * 0.16115 +
                            Q3_S17_CO01END010RO_5 * 0.12195 +
                            Q3_S17_CO01END013IN_2 * -0.0638 +
                            Q3_S17_CO01END018VE_3 * 0.13406 +
                            Q3_S17_CO01END018VE_4 * 0.23657 +
                            Q3_S17_CO01END019RO_2 * -0.13413 +
                            Q3_S17_CO01END021RO_3 * -0.04011 +
                            Q3_S17_CO01END028IN_5 * 0.07067 +
                            Q3_S17_CO01END030RO_4 * 0.11859 +
                            Q3_S17_CO01END030RO_5 * 0.15418 +
                            Q3_S17_CO01END034RO_2 * 0.11081 +
                            Q3_S17_CO01END035RO_2 * -0.04847 +
                            Q3_S17_CO01END035RO_5 * 0.07912 +
                            Q3_S17_CO01END046CO_2 * -0.08294 +
                            Q3_S17_CO01MOR001CC_2 * -0.08998 +
                            Q3_S17_CO01MOR008RO_3 * -0.18579 +
                            Q3_S17_CO01NUM002CT_2 * 0.14484 +
                            Q3_S17_CO01NUM002CT_3 * 0.22179 +
                            Q3_S17_CO01NUM002CT_4 * 0.36305 +
                            Q3_S17_CO02END006CB_2 * 0.1645 +
                            Q3_S17_CO02END006CB_3 * 0.08411 +
                            Q3_S17_CO02END037RO_2 * -0.10622 +
                            Q3_S17_CO02NUM042HP_2 * 0.07998 +
                            Q3_S17_COQ1END003IN_2 * -0.13846 +
                            Q3_S17_COQ1END013TC_2 * -0.08872 +
                            Q3_S17_COQ1END010IN_4 * 0.14311)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S17_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0
        self.cal_salida_pesos_daqu3()

    def score_card18_daqu3(self):
        """
        Computes Score Card 18
        """
        # NO TEC NODO4 GRUPO 5
        self.inicializa_variables()
        self.sectores_daqu3()

        self.score_card_daqu3 = 18
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO02EXP002TO", "CO02EXP003TO", "CO02NUM002TO", "CO01END005CC", "CO01END007HP",
                      "CO01END009RO", "CO01END013RO", "CO01END018VE", "CO01END023RO", "CO01END025RO",
                      "CO01END028IN", "CO01END028RO", "CO01END055HP", "CO01END056CC", "CO01END057RO",
                      "CO01END066IN", "CO01END086RO", "CO01NUM002CT", "CO00DEM006", "CO00DEM026",
                      "COQ1END002HP", "COQ1END002IN", "COQ1END003IN", "COQ1END004TC", "COQ1END008TC"]

        # VALORES ESPECIALES
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        if self.q3_cuotatotal == 999:
            self.q3_cuotatotal = -1.0

        if self.q3_telcos == 999:
            self.q3_telcos = -1.0

        # ACOTACION
        if self.data["CO02EXP002TO"] > 27:
            self.data["CO02EXP002TO"] = 27

        if self.data["CO02EXP003TO"] > 374:
            self.data["CO02EXP003TO"] = 374

        if self.data["CO02NUM002TO"] > 20:
            self.data["CO02NUM002TO"] = 20

        if self.data["CO01END005CC"] > 0.36:
            self.data["CO01END005CC"] = 0.36

        if self.data["CO01END007HP"] > 194.17:
            self.data["CO01END007HP"] = 194.17

        if self.data["CO01END009RO"] > 122.498:
            self.data["CO01END009RO"] = 122.498

        if self.data["CO01END013RO"] > 2.88:
            self.data["CO01END013RO"] = 2.88

        if self.data["CO01END018VE"] > 1.61:
            self.data["CO01END018VE"] = 1.61

        if self.data["CO01END023RO"] > 2.75:
            self.data["CO01END023RO"] = 2.75

        if self.data["CO01END025RO"] > 33.006:
            self.data["CO01END025RO"] = 33.006

        if self.data["CO01END028IN"] > 3.06799999999999:
            self.data["CO01END028IN"] = 3.06799999999999

        if self.data["CO01END028RO"] > 2.65:
            self.data["CO01END028RO"] = 2.65

        if self.data["CO01END055HP"] > 2.18799999999999:
            self.data["CO01END055HP"] = 2.18799999999999

        if self.data["CO01END056CC"] > 0.23:
            self.data["CO01END056CC"] = 0.23

        if self.data["CO01END057RO"] > 156.572:
            self.data["CO01END057RO"] = 156.572

        if self.data["CO01END066IN"] > 2.57:
            self.data["CO01END066IN"] = 2.57

        if self.data["CO01END086RO"] > 95.716:
            self.data["CO01END086RO"] = 95.716

        if self.data["CO01NUM002CT"] > 3:
            self.data["CO01NUM002CT"] = 3

        if self.q3_cuotatotal > 16.43:
            self.q3_cuotatotal = 16.43

        if self.data["COQ1END002HP"] > 1371.8:
            self.data["COQ1END002HP"] = 1371.8

        if self.data["COQ1END002IN"] > 2720.6:
            self.data["COQ1END002IN"] = 2720.6

        if self.data["COQ1END003IN"] > 94000:
            self.data["COQ1END003IN"] = 94000

        if self.data["COQ1END004TC"] > 32700:
            self.data["COQ1END004TC"] = 32700

        if self.data["COQ1END008TC"] > 30000:
            self.data["COQ1END008TC"] = 30000

        # BINARIAS: CREACION
        if 0 <= self.data["CO01END005CC"] and self.data["CO01END005CC"] <= 0:
            Q3_S18_CO01END005CC_2 = 1
        else:
            Q3_S18_CO01END005CC_2 = 0

        if 186.543 < self.data["CO01END007HP"] and self.data["CO01END007HP"] <= 194.17:
            Q3_S18_CO01END007HP_4 = 1
        else:
            Q3_S18_CO01END007HP_4 = 0

        if 52.8025 < self.data["CO01END009RO"] and self.data["CO01END009RO"] <= 94.042:
            Q3_S18_CO01END009RO_4 = 1
        else:
            Q3_S18_CO01END009RO_4 = 0

        if 0 <= self.data["CO01END013RO"] and self.data["CO01END013RO"] <= 0.44:
            Q3_S18_CO01END013RO_2 = 1
        else:
            Q3_S18_CO01END013RO_2 = 0

        if 1.51 < self.data["CO01END018VE"] and self.data["CO01END018VE"] <= 1.61:
            Q3_S18_CO01END018VE_3 = 1
        else:
            Q3_S18_CO01END018VE_3 = 0

        if 1.95 < self.data["CO01END023RO"] and self.data["CO01END023RO"] <= 2.75:
            Q3_S18_CO01END023RO_5 = 1
        else:
            Q3_S18_CO01END023RO_5 = 0

        if 14.1 < self.data["CO01END025RO"] and self.data["CO01END025RO"] <= 20.0705:
            Q3_S18_CO01END025RO_4 = 1
        else:
            Q3_S18_CO01END025RO_4 = 0

        if 20.0705 < self.data["CO01END025RO"] and self.data["CO01END025RO"] <= 33.006:
            Q3_S18_CO01END025RO_5 = 1
        else:
            Q3_S18_CO01END025RO_5 = 0

        if 0 <= self.data["CO01END028IN"] and self.data["CO01END028IN"] <= 0.62:
            Q3_S18_CO01END028IN_2 = 1
        else:
            Q3_S18_CO01END028IN_2 = 0

        if 1.23 < self.data["CO01END028RO"] and self.data["CO01END028RO"] <= 1.91:
            Q3_S18_CO01END028RO_4 = 1
        else:
            Q3_S18_CO01END028RO_4 = 0

        if 1.97 < self.data["CO01END055HP"] and self.data["CO01END055HP"] <= 2.18799999999999:
            Q3_S18_CO01END055HP_3 = 1
        else:
            Q3_S18_CO01END055HP_3 = 0

        if 0 <= self.data["CO01END056CC"] and self.data["CO01END056CC"] <= 0.13:
            Q3_S18_CO01END056CC_2 = 1
        else:
            Q3_S18_CO01END056CC_2 = 0

        if 126.31 < self.data["CO01END057RO"] and self.data["CO01END057RO"] <= 156.572:
            Q3_S18_CO01END057RO_5 = 1
        else:
            Q3_S18_CO01END057RO_5 = 0

        if 0 <= self.data["CO01END066IN"] and self.data["CO01END066IN"] <= 1.04:
            Q3_S18_CO01END066IN_2 = 1
        else:
            Q3_S18_CO01END066IN_2 = 0

        if 0 <= self.data["CO01END086RO"] and self.data["CO01END086RO"] <= 18.51:
            Q3_S18_CO01END086RO_2 = 1
        else:
            Q3_S18_CO01END086RO_2 = 0

        if 18.51 < self.data["CO01END086RO"] and self.data["CO01END086RO"] <= 66.39:
            Q3_S18_CO01END086RO_3 = 1
        else:
            Q3_S18_CO01END086RO_3 = 0

        if 0 <= self.data["CO01NUM002CT"] and self.data["CO01NUM002CT"] <= 0:
            Q3_S18_CO01NUM002CT_2 = 1
        else:
            Q3_S18_CO01NUM002CT_2 = 0

        if 0 < self.data["CO01NUM002CT"] and self.data["CO01NUM002CT"] <= 1:
            Q3_S18_CO01NUM002CT_3 = 1
        else:
            Q3_S18_CO01NUM002CT_3 = 0

        if 1 < self.data["CO01NUM002CT"] and self.data["CO01NUM002CT"] <= 2:
            Q3_S18_CO01NUM002CT_4 = 1
        else:
            Q3_S18_CO01NUM002CT_4 = 0

        if 2 < self.data["CO01NUM002CT"] and self.data["CO01NUM002CT"] <= 3:
            Q3_S18_CO01NUM002CT_5 = 1
        else:
            Q3_S18_CO01NUM002CT_5 = 0

        if 0 <= self.q3_cuotatotal and self.q3_cuotatotal <= 3.25:
            Q3_S18_CUOTATOTAL_2 = 1
        else:
            Q3_S18_CUOTATOTAL_2 = 0

        if 0 <= self.data["COQ1END002HP"] and self.data["COQ1END002HP"] <= 1285.2:
            Q3_S18_COQ1END002HP_2 = 1
        else:
            Q3_S18_COQ1END002HP_2 = 0

        if 0 <= self.data["COQ1END002IN"] and self.data["COQ1END002IN"] <= 708:
            Q3_S18_COQ1END002IN_2 = 1
        else:
            Q3_S18_COQ1END002IN_2 = 0

        if 28500 < self.data["COQ1END003IN"] and self.data["COQ1END003IN"] <= 49506.5:
            Q3_S18_COQ1END003IN_3 = 1
        else:
            Q3_S18_COQ1END003IN_3 = 0

        if 49506.5 < self.data["COQ1END003IN"] and self.data["COQ1END003IN"] <= 64057:
            Q3_S18_COQ1END003IN_4 = 1
        else:
            Q3_S18_COQ1END003IN_4 = 0

        if 64057 < self.data["COQ1END003IN"] and self.data["COQ1END003IN"] <= 94000:
            Q3_S18_COQ1END003IN_5 = 1
        else:
            Q3_S18_COQ1END003IN_5 = 0

        if 3750 < self.data["COQ1END004TC"] and self.data["COQ1END004TC"] <= 18800:
            Q3_S18_COQ1END004TC_3 = 1
        else:
            Q3_S18_COQ1END004TC_3 = 0

        if 0 <= self.data["COQ1END008TC"] and self.data["COQ1END008TC"] <= 3600:
            Q3_S18_COQ1END008TC_2 = 1
        else:
            Q3_S18_COQ1END008TC_2 = 0

        # CATEGORICAS: CREACION
        Q3_S18_NUMERO_HP = 0.0
        if self.data["COQ1NUM002HP"] <= 1:
            Q3_S18_NUMERO_HP = 1.0

        if 1 < self.data["COQ1NUM002HP"] and self.data["COQ1NUM002HP"] <= 4:
            Q3_S18_NUMERO_HP = 2.0

        if 4 < self.data["COQ1NUM002HP"] and self.data["COQ1NUM002HP"] <= 27:
            Q3_S18_NUMERO_HP = 3.0

        if self.data["COQ1NUM002HP"] > 27:
            Q3_S18_NUMERO_HP = 4.0

        Q3_S18_CO00DEM006_C = 0.0
        if self.data["CO00DEM006"] < 0 or self.data["CO00DEM006"] == 999:
            Q3_S18_CO00DEM006_C = 1.0
        elif self.data["CO00DEM006"] == 0:
            Q3_S18_CO00DEM006_C = 2.0
        elif self.data["CO00DEM006"] == 1:
            Q3_S18_CO00DEM006_C = 3.0

        Q3_S18_CO00DEM026_C = 0.0
        if self.data["CO00DEM026"] < 0 or self.data["CO00DEM026"] == 999:
            Q3_S18_CO00DEM026_C = 1.0
        elif self.data["CO00DEM026"] in (0, 1, 2, 3):
            Q3_S18_CO00DEM026_C = 2.0
        elif self.data["CO00DEM026"] == 4:
            Q3_S18_CO00DEM026_C == 3.0
        elif self.data["CO00DEM026"] == 5:
            Q3_S18_CO00DEM026_C = 4.0
        elif self.data["CO00DEM026"] == 6:
            Q3_S18_CO00DEM026_C = 5.0

        Q3_S18_TELCOS_C = 0.0
        if self.q3_telcos < 0 or self.q3_telcos == 999:
            Q3_S18_TELCOS_C = 1.0
        elif self.q3_telcos == 0:
            Q3_S18_TELCOS_C = 2.0
        elif self.q3_telcos == 1:
            Q3_S18_TELCOS_C = 3.0

        Q3_S18_EXPONENTE = (1.73428 +
                            Q3_S18_NUMERO_HP * 0.06201 +
                            self.data["CO02EXP002TO"] * -0.00368 +
                            self.data["CO02EXP003TO"] * -0.00040454 +
                            self.data["CO02NUM002TO"] * 0.01538 +
                            Q3_S18_CO01END005CC_2 * -0.24914 +
                            Q3_S18_CO01END007HP_4 * 0.14066 +
                            Q3_S18_CO01END009RO_4 * 0.07599 +
                            Q3_S18_CO01END013RO_2 * -0.11766 +
                            Q3_S18_CO01END018VE_3 * 0.25561 +
                            Q3_S18_CO01END023RO_5 * 0.10002 +
                            Q3_S18_CO01END025RO_4 * 0.12413 +
                            Q3_S18_CO01END025RO_5 * 0.18133 +
                            Q3_S18_CO01END028IN_2 * -0.0791 +
                            Q3_S18_CO01END028RO_4 * 0.10883 +
                            Q3_S18_CO01END055HP_3 * 0.12284 +
                            Q3_S18_CO01END056CC_2 * -0.10953 +
                            Q3_S18_CO01END057RO_5 * 0.11441 +
                            Q3_S18_CO01END066IN_2 * -0.06917 +
                            Q3_S18_CO01END086RO_2 * 0.1724 +
                            Q3_S18_CO01END086RO_3 * 0.08969 +
                            Q3_S18_CO01NUM002CT_2 * 0.09579 +
                            Q3_S18_CO01NUM002CT_3 * 0.15956 +
                            Q3_S18_CO01NUM002CT_4 * 0.25012 +
                            Q3_S18_CO01NUM002CT_5 * 0.28514 +
                            Q3_S18_CUOTATOTAL_2 * -0.11982 +
                            Q3_S18_COQ1END002HP_2 * -0.07522 +
                            Q3_S18_COQ1END002IN_2 * -0.10247 +
                            Q3_S18_COQ1END003IN_3 * 0.11432 +
                            Q3_S18_COQ1END003IN_4 * 0.27022 +
                            Q3_S18_COQ1END003IN_5 * 0.41821 +
                            Q3_S18_COQ1END004TC_3 * -0.0771 +
                            Q3_S18_COQ1END008TC_2 * -0.16345 +
                            Q3_S18_CO00DEM006_C * -0.07085 +
                            Q3_S18_CO00DEM026_C * 0.06332 +
                            Q3_S18_TELCOS_C * 0.07255)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S18_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card19_daqu3(self):
        """
        Computes Score Card 19
        """
        # NO TEC NODO5 GRUPO 1
        self.inicializa_variables()
        self.score_card_daqu3 = 19
        self.adverse_razon_daqu3[0] = 99

        # VALORES ESPECIALES */
        attributes = ["CO01END028IN", "CO01END030RO", "CO01END007RO", "CO01END013CC", "CO01END023CO",
                      "CO02END010HP", "CO01MOR001CC", "CO01EXP001HP", "CO01END023RO", "CO00DEM026",
                      "CO02NUM043RO", "CO01END025RO", "CO02NUM004TO", "CO01END029RO", "COQ1END003IN",
                      "COQ1END008TC", "COQ1EXP004HP", "COQ1END007IN", "COQ1END002HP", "COQ1END014TC",
                      "COQ1END011TC"]
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        if self.q3_cuotatotal == 999:
            self.q3_cuotatotal = -1.0

        # Dimensioning

        if self.data["COQ1END003IN"] > 13500:
            self.data["COQ1END003IN"] = 13500

        if self.data["COQ1END008TC"] > 3795:
            self.data["COQ1END008TC"] = 3795

        if self.data["CO01END028IN"] > 0.49:
            self.data["CO01END028IN"] = 0.49

        if self.data["CO01END030RO"] > 3.16:
            self.data["CO01END030RO"] = 3.16

        if self.data["CO01END007RO"] > 13.1:
            self.data["CO01END007RO"] = 13.1

        if self.data["CO01END023CO"] > 0.49:
            self.data["CO01END023CO"] = 0.49

        if self.data["CO01EXP001HP"] > 144:
            self.data["CO01EXP001HP"] = 144

        if self.data["CO01END023RO"] > 0.39:
            self.data["CO01END023RO"] = 0.39

        if self.data["COQ1END011TC"] > 504.5016666667:
            self.data["COQ1END011TC"] = 504.5016666667

        if self.data["CO02NUM043RO"] > 100:
            self.data["CO02NUM043RO"] = 100

        if self.data["CO01END025RO"] > 3.18:
            self.data["CO01END025RO"] = 3.18

        if self.q3_cuotatotal > 1.3:
            self.q3_cuotatotal = 1.3

        if self.data["CO02NUM004TO"] > 4:
            self.data["CO02NUM004TO"] = 4

        if self.data["CO01END029RO"] > 5.75:
            self.data["CO01END029RO"] = 5.75

        if self.data["COQ1END007IN"] > 389:
            self.data["COQ1END007IN"] = 389

        if self.data["CO01END028IN"] > 0.49:
            self.data["CO01END028IN"] = 0.49

        if self.data["COQ1EXP004HP"] > 181:
            self.data["COQ1EXP004HP"] = 181

        if self.data["COQ1END002HP"] > 443:
            self.data["COQ1END002HP"] = 443

        if self.data["COQ1END014TC"] > 10000:
            self.data["COQ1END014TC"] = 10000

        if self.data["CO01END013CC"] > 0.1:
            self.data["CO01END013CC"] = 0.1

        if self.data["CO02END010HP"] > 1.69:
            self.data["CO02END010HP"] = 1.69

        if self.data["CO01MOR001CC"] > 3:
            self.data["CO01MOR001CC"] = 3

        if self.data["CO00DEM026"] > 5:
            self.data["CO00DEM026"] = 5

        # Binary Attributes

        if 12000 < self.data["COQ1END003IN"] <= 13500:
            Q3_S19_COQ1END003IN_5 = 1.0
        else:
            Q3_S19_COQ1END003IN_5 = 0.0

        if 3375 < self.data["COQ1END008TC"] <= 3795:
            Q3_S19_COQ1END008TC_5 = 1.0
        else:
            Q3_S19_COQ1END008TC_5 = 0.0

        if 0 <= self.data["COQ1EXP004HP"] <= 159:
            Q3_S19_COQ1EXP004HP_2 = 1.0
        else:
            Q3_S19_COQ1EXP004HP_2 = 0.0

        if 0.33 < self.data["CO01END028IN"] <= 0.47:
            Q3_S19_CO01END028IN_4 = 1.0
        else:
            Q3_S19_CO01END028IN_4 = 0.0

        if 2.91 < self.data["CO01END030RO"] <= 3.16:
            Q3_S19_CO01END030RO_5 = 1.0
        else:
            Q3_S19_CO01END030RO_5 = 0.0

        if 0 <= self.data["COQ1END014TC"] <= 935:
            Q3_S19_COQ1END014TC_2 = 1.0
        else:
            Q3_S19_COQ1END014TC_2 = 0.0

        if 11.56 < self.data["CO01END007RO"] <= 13.1:
            Q3_S19_CO01END007RO_5 = 1.0
        else:
            Q3_S19_CO01END007RO_5 = 0.0

        if 0 <= self.data["CO01END013CC"] <= 0.02:
            Q3_S19_CO01END013CC_2 = 1.0
        else:
            Q3_S19_CO01END013CC_2 = 0.0

        if 0.44 < self.data["CO01END023CO"] <= 0.49:
            Q3_S19_CO01END023CO_3 = 1.0
        else:
            Q3_S19_CO01END023CO_3 = 0.0

        if 0 <= self.data["CO02END010HP"] <= 1.08:
            Q3_S19_CO02END010HP_2 = 1.0
        else:
            Q3_S19_CO02END010HP_2 = 0.0

        if 0 <= self.data["CO01MOR001CC"] <= 0:
            Q3_S19_CO01MOR001CC_2 = 1.0
        else:
            Q3_S19_CO01MOR001CC_2 = 0.0

        if 125 < self.data["CO01EXP001HP"] <= 144:
            Q3_S19_CO01EXP001HP_4 = 1.0
        else:
            Q3_S19_CO01EXP001HP_4 = 0.0

        if 0 <= self.data["COQ1END007IN"] <= 111:
            Q3_S19_COQ1END007IN_2 = 1.0
        else:
            Q3_S19_COQ1END007IN_2 = 0.0

        if 0.28 < self.data["CO01END023RO"] <= 0.39:
            Q3_S19_CO01END023RO_5 = 1.0
        else:
            Q3_S19_CO01END023RO_5 = 0.0

        if self.data["CO00DEM026"] == 6 or self.data["CO00DEM026"] == 5 or self.data["CO00DEM026"] == 4:
            Q3_S19_CO00DEM026_6 = 1.0
        else:
            Q3_S19_CO00DEM026_6 = 0.0

        if 213 < self.data["COQ1END011TC"] <= 504.516666667001:
            Q3_S19_COQ1END011TC_4 = 1.0
        else:
            Q3_S19_COQ1END011TC_4 = 0.0

        if self.data["CO00DEM026"] == 1 or self.data["CO00DEM026"] == 2:
            Q3_S19_CO00DEM026_4 = 1.0
        else:
            Q3_S19_CO00DEM026_4 = 0.0

        if 50 < self.data["CO02NUM043RO"] <= 100:
            Q3_S19_CO02NUM043RO_4 = 1.0
        else:
            Q3_S19_CO02NUM043RO_4 = 0.0

        if 1.68 < self.data["CO01END025RO"] <= 2.94:
            Q3_S19_CO01END025RO_4 = 1.0
        else:
            Q3_S19_CO01END025RO_4 = 0.0

        if 1.19 < self.q3_cuotatotal <= 1.3:
            Q3_S19_CUOTATOTAL_5 = 1.0
        else:
            Q3_S19_CUOTATOTAL_5 = 0.0

        if 3 < self.data["CO02NUM004TO"] <= 4:
            Q3_S19_CO02NUM004TO_5 = 1.0
        else:
            Q3_S19_CO02NUM004TO_5 = 0.0

        if 5.23 < self.data["CO01END029RO"] <= 5.75:
            Q3_S19_CO01END029RO_5 = 1.0
        else:
            Q3_S19_CO01END029RO_5 = 0.0

        if 111 < self.data["COQ1END007IN"] <= 202.5:
            Q3_S19_COQ1END007IN_3 = 1.0
        else:
            Q3_S19_COQ1END007IN_3 = 0.0

        if 0.89 < self.q3_cuotatotal <= 1.19:
            Q3_S19_CUOTATOTAL_4 = 1.0
        else:
            Q3_S19_CUOTATOTAL_4 = 0.0

        if 0 <= self.data["COQ1END002HP"] <= 249:
            Q3_S19_COQ1END002HP_2 = 1.0
        else:
            Q3_S19_COQ1END002HP_2 = 0.0

        if 0.47 < self.data["CO01END028IN"] <= 0.49:
            Q3_S19_CO01END028IN_5 = 1.0
        else:
            Q3_S19_CO01END028IN_5 = 0.0

        # Binary Attributes

        if self.data["CO01NUM002CC"] > 0:
            Q3_S19_TELECOM = 1.0
        else:
            Q3_S19_TELECOM = 0.0

        if self.data["COQ1END003MC"] == -1:
            Q3_S19_MICROCREDITO = 0.0
        else:
            Q3_S19_MICROCREDITO = 1.0

        if Q3_S19_TELECOM == 0 and Q3_S19_MICROCREDITO == 1:
            Q3_S19_NOCC_MIC = 1.0
        else:
            Q3_S19_NOCC_MIC = 0.0

        Q3_S19_EXPONENTE = (0.64554 +
                            Q3_S19_NOCC_MIC * -0.20061 +
                            Q3_S19_COQ1END003IN_5 * 0.18179 +
                            Q3_S19_COQ1END008TC_5 * 0.15917 +
                            Q3_S19_COQ1EXP004HP_2 * 0.12507 +
                            Q3_S19_CO01END028IN_4 * 0.11659 +
                            Q3_S19_CO01END030RO_5 * 0.1492 +
                            Q3_S19_COQ1END014TC_2 * -0.10257 +
                            Q3_S19_CO01END007RO_5 * 0.14031 +
                            Q3_S19_CO01END013CC_2 * -0.11344 +
                            Q3_S19_CO01END023CO_3 * 0.10479 +
                            Q3_S19_CO02END010HP_2 * -0.10373 +
                            Q3_S19_CO01MOR001CC_2 * -0.12847 +
                            Q3_S19_CO01EXP001HP_4 * 0.11897 +
                            Q3_S19_COQ1END007IN_2 * -0.10824 +
                            Q3_S19_CO01END023RO_5 * 0.07885 +
                            Q3_S19_CO00DEM026_6 * 0.09506 +
                            Q3_S19_COQ1END011TC_4 * 0.09636 +
                            Q3_S19_CO00DEM026_4 * -0.07357 +
                            Q3_S19_CO02NUM043RO_4 * 0.084 +
                            Q3_S19_CO01END025RO_4 * 0.08894 +
                            Q3_S19_CUOTATOTAL_5 * 0.11159 +
                            Q3_S19_CO02NUM004TO_5 * 0.12872 +
                            Q3_S19_CO01END029RO_5 * 0.0512 +
                            Q3_S19_COQ1END007IN_3 * -0.06275 +
                            Q3_S19_CUOTATOTAL_4 * 0.08293 +
                            Q3_S19_COQ1END002HP_2 * -0.2082 +
                            Q3_S19_CO01END028IN_5 * 0.19578)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S19_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card20_daqu3(self):
        """
        Computes Score Card 20
        """
        # NO TEC NODO5 GRUPO 2
        self.inicializa_variables()
        self.score_card_daqu3 = 20
        self.adverse_razon_daqu3[0] = 99

        # VALORES ESPECIALES
        attributes = ["COQ1END003HP", "CO01END030RO", "COQ1END008HP", "CO01NUM001CT", "CO02END009HP",
                      "CO01END008RO", "CO01END026HP", "CO01END007HP", "COQ1END009HP", "CO01END028IN",
                      "CO01END028HP", "CO01END007IN", "CO01END001CO", "CO01END018CC", "CO01END007CO",
                      "CO02NUM043HP", "CO02NUM002TO", "CO00DEM026", "CO02EXP006TO", "CO02EXP001TO"]
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Dimensioning
        if self.data["COQ1END003HP"] > 62000:
            self.data["COQ1END003HP"] = 62000

        if self.data["CO01END030RO"] > 12.6479999999999:
            self.data["CO01END030RO"] = 12.6479999999999

        if self.data["COQ1END008HP"] > 60000:
            self.data["COQ1END008HP"] = 60000

        if self.data["CO01NUM001CT"] > 4:
            self.data["CO01NUM001CT"] = 4

        if self.data["CO02END009HP"] > 2.35:
            self.data["CO02END009HP"] = 2.35

        if self.data["CO01END008RO"] > 20.08:
            self.data["CO01END008RO"] = 20.08

        if self.data["CO01END026HP"] > 102.888:
            self.data["CO01END026HP"] = 102.888

        if self.data["CO01NUM001CT"] > 4:
            self.data["CO01NUM001CT"] = 4

        if self.data["CO01END007HP"] > 123.52:
            self.data["CO01END007HP"] = 123.52

        if self.data["COQ1END009HP"] > 2207.69999999998:
            self.data["COQ1END009HP"] = 2207.69999999998

        if self.data["CO01END028IN"] > 2.08:
            self.data["CO01END028IN"] = 2.08

        if self.data["CO01END028HP"] > 1.53:
            self.data["CO01END028HP"] = 1.53

        if self.data["CO02END009HP"] > 2.35:
            self.data["CO02END009HP"] = 2.35

        if self.data["CO01END007IN"] > 116.04:
            self.data["CO01END007IN"] = 116.04

        if self.data["CO01END001CO"] > 48.54:
            self.data["CO01END001CO"] = 48.54

        if self.data["CO01END018CC"] > 0.23:
            self.data["CO01END018CC"] = 0.23

        if self.data["CO01END007CO"] > 67.48:
            self.data["CO01END007CO"] = 67.48

        if self.data["CO02NUM043HP"] > 100:
            self.data["CO02NUM043HP"] = 100

        if self.data["CO01END030RO"] > 12.6479999999999:
            self.data["CO01END030RO"] = 12.6479999999999

        if self.data["CO02NUM002TO"] > 20:
            self.data["CO02NUM002TO"] = 20

        if self.data["CO00DEM026"] > 6:
            self.data["CO00DEM026"] = 6

        if self.data["CO02EXP006TO"] > 98:
            self.data["CO02EXP006TO"] = 98

        if self.data["CO02EXP001TO"] > 337:
            self.data["CO02EXP001TO"] = 337

        if self.data["CO00DEM026"] < 0:
            self.data["CO00DEM026"] = 7

        # Binary Attributes
        if 0 <= self.data["COQ1END003HP"] <= 39147.6:
            Q3_S20_COQ1END003HP_2 = 1
        else:
            Q3_S20_COQ1END003HP_2 = 0

        if 0 <= self.data["CO01END030RO"] <= 0.32:
            Q3_S20_CO01END030RO_2 = 1
        else:
            Q3_S20_CO01END030RO_2 = 0

        if self.data["COQ1END008HP"] < 0:
            Q3_S20_COQ1END008HP_1 = 1
        else:
            Q3_S20_COQ1END008HP_1 = 0

        if 2 < self.data["CO01NUM001CT"] <= 3:
            Q3_S20_CO01NUM001CT_4 = 1
        else:
            Q3_S20_CO01NUM001CT_4 = 0

        if 1 < self.data["CO01NUM001CT"] <= 2:
            Q3_S20_CO01NUM001CT_3 = 1
        else:
            Q3_S20_CO01NUM001CT_3 = 0

        if 39147.6 < self.data["COQ1END003HP"] <= 51220.8499999999:
            Q3_S20_COQ1END003HP_3 = 1
        else:
            Q3_S20_COQ1END003HP_3 = 0

        if 0 <= self.data["CO02END009HP"] <= 1.27:
            Q3_S20_CO02END009HP_2 = 1
        else:
            Q3_S20_CO02END009HP_2 = 0

        if 0 <= self.data["CO01END008RO"] <= 1.81:
            Q3_S20_CO01END008RO_2 = 1
        else:
            Q3_S20_CO01END008RO_2 = 0

        if self.data["CO01END026HP"] < 0:
            Q3_S20_CO01END026HP_1 = 1
        else:
            Q3_S20_CO01END026HP_1 = 0

        if 0 <= self.data["CO01NUM001CT"] <= 1:
            Q3_S20_CO01NUM001CT_2 = 1
        else:
            Q3_S20_CO01NUM001CT_2 = 0

        if 0 <= self.data["CO01END007HP"] <= 61.835:
            Q3_S20_CO01END007HP_2 = 1
        else:
            Q3_S20_CO01END007HP_2 = 0

        if 0 <= self.data["COQ1END009HP"] <= 412:
            Q3_S20_COQ1END009HP_2 = 1
        else:
            Q3_S20_COQ1END009HP_2 = 0

        if self.data["CO01END028IN"] < 0:
            Q3_S20_CO01END028IN_1 = 1
        else:
            Q3_S20_CO01END028IN_1 = 0

        if 0 <= self.data["CO01END028HP"] <= 0.67:
            Q3_S20_CO01END028HP_2 = 1
        else:
            Q3_S20_CO01END028HP_2 = 0

        if 1.27 < self.data["CO02END009HP"] <= 1.7:
            Q3_S20_CO02END009HP_3 = 1
        else:
            Q3_S20_CO02END009HP_3 = 0

        if 0 <= self.data["CO01END007IN"] <= 4.65:
            Q3_S20_CO01END007IN_2 = 1
        else:
            Q3_S20_CO01END007IN_2 = 0

        if self.data["CO02END009HP"] < 0:
            Q3_S20_CO02END009HP_1 = 1
        else:
            Q3_S20_CO02END009HP_1 = 0

        if 1.7 < self.data["CO02END009HP"] <= 1.96:
            Q3_S20_CO02END009HP_4 = 1
        else:
            Q3_S20_CO02END009HP_4 = 0

        if 0 <= self.data["CO01END001CO"] <= 5.05:
            Q3_S20_CO01END001CO_2 = 1
        else:
            Q3_S20_CO01END001CO_2 = 0

        if 51.45 < self.data["CO01END007IN"] <= 54.4704999999999:
            Q3_S20_CO01END007IN_5 = 1
        else:
            Q3_S20_CO01END007IN_5 = 0

        if 0 <= self.data["CO01END018CC"] <= 0.03:
            Q3_S20_CO01END018CC_2 = 1
        else:
            Q3_S20_CO01END018CC_2 = 0

        if self.data["CO01END007CO"] < 0:
            Q3_S20_CO01END007CO_1 = 1
        else:
            Q3_S20_CO01END007CO_1 = 0

        if 5.05 < self.data["CO01END001CO"] <= 10.47:
            Q3_S20_CO01END001CO_3 = 1
        else:
            Q3_S20_CO01END001CO_3 = 0

        if 0 <= self.data["CO02NUM043HP"] <= 0:
            Q3_S20_CO02NUM043HP_2 = 1
        else:
            Q3_S20_CO02NUM043HP_2 = 0

        if 0.32 < self.data["CO01END030RO"] <= 3.67:
            Q3_S20_CO01END030RO_3 = 1
        else:
            Q3_S20_CO01END030RO_3 = 0

        if self.data["CO01END030RO"] < 0:
            Q3_S20_CO01END030RO_1 = 1
        else:
            Q3_S20_CO01END030RO_1 = 0

        # Binary Attributes

        if self.data["COQ1END003MC"] == -1:
            Q3_S20_MICROCREDITO = 0
        else:
            Q3_S20_MICROCREDITO = 1

        Q3_MAXIMO_CUPO_TOT = self.calcula_maximo_cupo_tot()

        if Q3_MAXIMO_CUPO_TOT < 0:
            Q3_MAXIMO_CUPO_TOT = -2

        if Q3_MAXIMO_CUPO_TOT == self.data["COQ1END003MC"]:
            Q3_S20_MAX_CUPOMC = 1
        else:
            Q3_S20_MAX_CUPOMC = 0

        Q3_S20_EXPONENTE = (1.67903 +
                            self.data["CO02EXP001TO"] * 0.00040563 +
                            self.data["CO02EXP006TO"] * 0.00037255 +
                            self.data["CO00DEM026"] * 0.00595 +
                            self.data["CO02NUM002TO"] * 0.01499 +
                            Q3_S20_CO01END030RO_1 * -0.20411 +
                            Q3_S20_CO01END030RO_3 * -0.15937 +
                            Q3_S20_CO02NUM043HP_2 * -0.06654 +
                            Q3_S20_CO01END001CO_3 * -0.07329 +
                            Q3_S20_CO02END009HP_4 * -0.03911 +
                            Q3_S20_CO01END007CO_1 * -0.00469 +
                            Q3_S20_CO01END018CC_2 * -0.17112 +
                            Q3_S20_CO01END007IN_5 * 0.15655 +
                            Q3_S20_CO01END001CO_2 * -0.10187 +
                            Q3_S20_CO02END009HP_1 * -0.08449 +
                            Q3_S20_CO01END007IN_2 * -0.16868 +
                            Q3_S20_CO02END009HP_3 * -0.09622 +
                            Q3_S20_CO01END028HP_2 * -0.12755 +
                            Q3_S20_CO01END028IN_1 * -0.02072 +
                            Q3_S20_COQ1END009HP_2 * -0.1227 +
                            Q3_S20_MAX_CUPOMC * -0.07627 +
                            Q3_S20_CO01END007HP_2 * -0.08172 +
                            Q3_S20_CO01NUM001CT_2 * 0.16088 +
                            Q3_S20_CO01END026HP_1 * -0.14887 +
                            Q3_S20_CO01END008RO_2 * -0.13454 +
                            Q3_S20_MICROCREDITO * -0.1905 +
                            Q3_S20_CO02END009HP_2 * -0.20242 +
                            Q3_S20_COQ1END003HP_3 * -0.18827 +
                            Q3_S20_CO01NUM001CT_3 * 0.22621 +
                            Q3_S20_CO01NUM001CT_4 * 0.25619 +
                            Q3_S20_COQ1END008HP_1 * -0.2765 +
                            Q3_S20_CO01END030RO_2 * -0.23447 +
                            Q3_S20_COQ1END003HP_2 * -0.3098)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S20_EXPONENTE, 2)  # ROUNDED revisar
        if self.q3_ingreso < 1:
            self.q3_ingreso = 1
        self.cal_salida_pesos_daqu3()

    def score_card21_daqu3(self):
        """
        Computes Score Card 21
        """
        # NO TEC NODO5 GRUPO 3
        self.inicializa_variables()
        self.score_card_daqu3 = 21
        self.adverse_razon_daqu3[0] = 99

        # VALORES ESPECIALES
        attributes = ["COQ1END017TC", "CO01END001VE", "CO01END028VE", "CO01END068RO", "CO01END007RO",
                      "CO01END011CO", "CO01END023HP", "CO01END035HP", "CO01END046CO", "CO01END023CC",
                      "CO01END001HP", "CO01END030RO", "CO01END056HP", "CO01END007VE", "CO01END028CO",
                      "CO01END007IN", "CO01END006CC", "COQ1END003IN", "CO01END023VE", "CO01NUM001CT",
                      "CO01END013CC", "CO01END005HP", "CO01END019RO"]
        for key in attributes:
            if self.data[key] == 999:
                self.data[key] = -1.0

        # Dimensioning
        if self.data["COQ1END017TC"] > 7:
            self.data["COQ1END017TC"] = 7

        if self.data["CO01END001VE"] > 35.42:
            self.data["CO01END001VE"] = 35.42

        if self.data["CO01END028VE"] > 1.29:
            self.data["CO01END028VE"] = 1.29

        if self.data["CO01END068RO"] > 20.13:
            self.data["CO01END068RO"] = 20.13

        if self.data["CO01END007RO"] > 85.61:
            self.data["CO01END007RO"] = 85.61

        if self.data["CO01END011CO"] > 32.2659999999998:
            self.data["CO01END011CO"] = 32.2659999999998

        if self.data["CO01END023HP"] > 1.51:
            self.data["CO01END023HP"] = 1.51

        if self.data["CO01END035HP"] > 1.5:
            self.data["CO01END035HP"] = 1.5

        if self.data["CO01END046CO"] > 1.58:
            self.data["CO01END046CO"] = 1.58

        if self.data["CO01END023CC"] > 0.24:
            self.data["CO01END023CC"] = 0.24

        if self.data["CO01END001HP"] > 107.498:
            self.data["CO01END001HP"] = 107.498

        if self.data["CO01END030RO"] > 12.6479999999999:
            self.data["CO01END030RO"] = 12.6479999999999

        if self.data["CO01END056HP"] > 1.37:
            self.data["CO01END056HP"] = 1.37

        if self.data["CO01END007VE"] > 48.54:
            self.data["CO01END007VE"] = 48.54

        if self.data["CO01END028CO"] > 1.93:
            self.data["CO01END028CO"] = 1.93

        if self.data["CO01END007IN"] > 116.04:
            self.data["CO01END007IN"] = 116.04

        if self.data["CO01END006CC"] > 0.22:
            self.data["CO01END006CC"] = 0.22

        if self.data["COQ1END003IN"] > 52000:
            self.data["COQ1END003IN"] = 52000

        if self.data["CO01END023VE"] > 1.27:
            self.data["CO01END023VE"] = 1.27

        if self.data["CO01NUM001CT"] > 4:
            self.data["CO01NUM001CT"] = 4

        if self.data["CO01END013CC"] > 0.22:
            self.data["CO01END013CC"] = 0.22

        if self.data["CO01END005HP"] > 1.54:
            self.data["CO01END005HP"] = 1.54

        if self.data["CO01END019RO"] > 20.39:
            self.data["CO01END019RO"] = 20.39

        if self.data["CO01NUM001CT"] > 4:
            self.data["CO01NUM001CT"] = 4

        if self.data["CO01END007IN"] > 116.04:
            self.data["CO01END007IN"] = 116.04

        # Binary Attributes
        if 32.664 < self.data["CO01END001VE"] <= 35.42:
            Q3_S21_CO01END001VE_3 = 1
        else:
            Q3_S21_CO01END001VE_3 = 0

        if 0 <= self.data["CO01END028VE"] <= 0.45:
            Q3_S21_CO01END028VE_2 = 1
        else:
            Q3_S21_CO01END028VE_2 = 0

        if self.data["CO01END068RO"] < 0:
            Q3_S21_CO01END068RO_1 = 1
        else:
            Q3_S21_CO01END068RO_1 = 0

        if 68.91 < self.data["CO01END007RO"] <= 85.61:
            Q3_S21_CO01END007RO_5 = 1
        else:
            Q3_S21_CO01END007RO_5 = 0

        if 25.746 < self.data["CO01END011CO"] <= 32.2659999999998:
            Q3_S21_CO01END011CO_4 = 1
        else:
            Q3_S21_CO01END011CO_4 = 0

        if 1.38 < self.data["CO01END023HP"] <= 1.51:
            Q3_S21_CO01END023HP_4 = 1
        else:
            Q3_S21_CO01END023HP_4 = 0

        if 1.46 < self.data["CO01END035HP"] <= 1.5:
            Q3_S21_CO01END035HP_4 = 1
        else:
            Q3_S21_CO01END035HP_4 = 0

        if 0 <= self.data["CO01END046CO"] <= 0.34:
            Q3_S21_CO01END046CO_2 = 1
        else:
            Q3_S21_CO01END046CO_2 = 0

        if 0.14 < self.data["CO01END023CC"] <= 0.24:
            Q3_S21_CO01END023CC_5 = 1
        else:
            Q3_S21_CO01END023CC_5 = 0

        if 95.9375 < self.data["CO01END001HP"] <= 107.498:
            Q3_S21_CO01END001HP_4 = 1
        else:
            Q3_S21_CO01END001HP_4 = 0

        if 9.96 < self.data["CO01END030RO"] <= 12.6479999999999:
            Q3_S21_CO01END030RO_5 = 1
        else:
            Q3_S21_CO01END030RO_5 = 0

        if 0 <= self.data["CO01END056HP"] <= 0.65:
            Q3_S21_CO01END056HP_2 = 1
        else:
            Q3_S21_CO01END056HP_2 = 0

        if 26.47 < self.data["CO01END007VE"] <= 48.54:
            Q3_S21_CO01END007VE_3 = 1
        else:
            Q3_S21_CO01END007VE_3 = 0

        if 1.86 < self.data["CO01END028CO"] <= 1.93:
            Q3_S21_CO01END028CO_5 = 1
        else:
            Q3_S21_CO01END028CO_5 = 0

        if 56.01 < self.data["CO01END007IN"] <= 98.82:
            Q3_S21_CO01END007IN_4 = 1
        else:
            Q3_S21_CO01END007IN_4 = 0

        if 0 <= self.data["CO01END006CC"] <= 0.06:
            Q3_S21_CO01END006CC_2 = 1
        else:
            Q3_S21_CO01END006CC_2 = 0

        if 29000 < self.data["COQ1END003IN"] <= 45000:
            Q3_S21_COQ1END003IN_4 = 1
        else:
            Q3_S21_COQ1END003IN_4 = 0

        if 1.03 < self.data["CO01END023VE"] <= 1.27:
            Q3_S21_CO01END023VE_4 = 1
        else:
            Q3_S21_CO01END023VE_4 = 0

        if 0 <= self.data["CO01NUM001CT"] <= 1:
            Q3_S21_CO01NUM001CT_2 = 1
        else:
            Q3_S21_CO01NUM001CT_2 = 0

        if 0 <= self.data["CO01END013CC"] <= 0.02:
            Q3_S21_CO01END013CC_2 = 1
        else:
            Q3_S21_CO01END013CC_2 = 0

        if 0 <= self.data["CO01END005HP"] <= 0.81:
            Q3_S21_CO01END005HP_2 = 1
        else:
            Q3_S21_CO01END005HP_2 = 0

        if 0 <= self.data["CO01END019RO"] <= 2.86:
            Q3_S21_CO01END019RO_2 = 1
        else:
            Q3_S21_CO01END019RO_2 = 0

        if 1 < self.data["CO01NUM001CT"] <= 2:
            Q3_S21_CO01NUM001CT_3 = 1
        else:
            Q3_S21_CO01NUM001CT_3 = 0

        if 2 < self.data["CO01NUM001CT"] <= 3:
            Q3_S21_CO01NUM001CT_4 = 1
        else:
            Q3_S21_CO01NUM001CT_4 = 0

        if 98.82 < self.data["CO01END007IN"] <= 116.04:
            Q3_S21_CO01END007IN_5 = 1
        else:
            Q3_S21_CO01END007IN_5 = 0

        if 45000 < self.data["COQ1END003IN"] <= 52000:
            Q3_S21_COQ1END003IN_5 = 1
        else:
            Q3_S21_COQ1END003IN_5 = 0

        # Binary Attributes
        Q3_SUMA_CUOTA_TOT = self.calcula_suma_cuota_tot()
        Q3_S21_SUMACUOTA_TOT = 0

        if 0 <= Q3_SUMA_CUOTA_TOT <= 652:
            Q3_S21_SUMACUOTA_TOT = 1

        if 652 < Q3_SUMA_CUOTA_TOT <= 1014:
            Q3_S21_SUMACUOTA_TOT = 2

        if 1014 < Q3_SUMA_CUOTA_TOT <= 1536:
            Q3_S21_SUMACUOTA_TOT = 3

        if Q3_SUMA_CUOTA_TOT > 1536:
            Q3_S21_SUMACUOTA_TOT = 4

        if Q3_SUMA_CUOTA_TOT < 0:
            Q3_S21_SUMACUOTA_TOT = 5

        if self.data["CO01NUM002RO"] > 0:
            Q3_S21_TDC = 1
        else:
            Q3_S21_TDC = 0

        if self.data["CO01NUM002IN"] > 0 or self.data["CO01NUM002VE"] > 0:
            self.prestamos_daqu3 = 1
        else:
            self.prestamos_daqu3 = 0

        if self.data["CO01NUM002RO"] > 0:
            self.q3_ro = 1
        else:
            self.q3_ro = 0

        if self.data["CO01NUM002HP"] > 0:
            self.q3_hp = 1
        else:
            self.q3_hp = 0

        if self.data["CO01NUM002CC"] > 0:
            self.q3_cc = 1
        else:
            self.q3_cc = 0

        if self.data["CO01NUM002OT"] > 0:
            self.q3_ot = 1
        else:
            self.q3_ot = 0

        if self.data["CO01NUM002CO"] > 0:
            self.q3_co = 1
        else:
            self.q3_co = 0

        if self.data["CO01NUM002AH"] > 0 or self.data["CO01NUM002CT"] > 0:
            self.q3_ah_ct = 1
        else:
            self.q3_ah_ct = 0

        self.num_port_daqu3 = (self.prestamos_daqu3 + self.q3_ro + self.q3_hp +
                               self.q3_cc + self.q3_ot + self.q3_co + self.q3_ah_ct)

        if self.num_port_daqu3 > 6:
            self.num_port_daqu3 = 6

        Q3_S21_EXPONENTE = (1.05192 +
                            self.num_port_daqu3 * 0.03343 +
                            Q3_S21_SUMACUOTA_TOT * 0.03209 +
                            self.data["COQ1END017TC"] * -0.00537 +
                            Q3_S21_CO01END001VE_3 * 0.059 +
                            Q3_S21_CO01END028VE_2 * -0.06754 +
                            Q3_S21_CO01END068RO_1 * 0.04128 +
                            Q3_S21_CO01END007RO_5 * 0.19863 +
                            Q3_S21_CO01END011CO_4 * 0.06395 +
                            Q3_S21_CO01END023HP_4 * 0.10076 +
                            Q3_S21_CO01END035HP_4 * 0.08938 +
                            Q3_S21_CO01END046CO_2 * -0.14854 +
                            Q3_S21_CO01END023CC_5 * 0.09899 +
                            Q3_S21_CO01END001HP_4 * 0.08798 +
                            Q3_S21_CO01END030RO_5 * 0.23969 +
                            Q3_S21_CO01END056HP_2 * -0.08473 +
                            Q3_S21_CO01END007VE_3 * 0.13481 +
                            Q3_S21_CO01END028CO_5 * 0.10115 +
                            Q3_S21_CO01END007IN_4 * 0.13387 +
                            Q3_S21_CO01END006CC_2 * -0.10302 +
                            Q3_S21_COQ1END003IN_4 * 0.12093 +
                            Q3_S21_CO01END023VE_4 * 0.12569 +
                            Q3_S21_CO01NUM001CT_2 * 0.15266 +
                            Q3_S21_CO01END013CC_2 * -0.11367 +
                            Q3_S21_CO01END005HP_2 * -0.1205 +
                            Q3_S21_CO01END019RO_2 * -0.22852 +
                            Q3_S21_CO01NUM001CT_3 * 0.24321 +
                            Q3_S21_TDC * 0.27929 +
                            Q3_S21_CO01NUM001CT_4 * 0.28874 +
                            Q3_S21_CO01END007IN_5 * 0.25371 +
                            Q3_S21_COQ1END003IN_5 * 0.32376)

        self.q3_ingreso = (2.7182818284590452 ** Q3_S21_EXPONENTE)

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card22_daqu3(self):
        """
        Computes Score Card 22
        """
        # NO TEC NODO5 GRUPO 4
        self.inicializa_variables()
        self.score_card_daqu3 = 22
        self.adverse_razon_daqu3[0] = 99

        # VALORES ESPECIALES
        attributes = ["CO00DEM006", "CO00DEM026", "CO01NUM001CT", "COQ1END003IN", "COQ1END004IN"]
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -99.0

        # Dimensioning
        if self.data["CO01END007VE"] > 75.73:
            self.data["CO01END007VE"] = 75.73

        if self.data["CO01END007HP"] > 155.34:
            self.data["CO01END007HP"] = 155.34

        if self.data["CO01END013CO"] > 2.52:
            self.data["CO01END013CO"] = 2.52

        if self.data["CO01END006CO"] > 2.52:
            self.data["CO01END006CO"] = 2.52

        if self.data["CO01END046HP"] > 1.73:
            self.data["CO01END046HP"] = 1.73

        if self.data["CO01NUM001CT"] > 5:
            self.data["CO01NUM001CT"] = 5

        if self.q3_cuotatotal > 15.43:
            self.q3_cuotatotal = 15.43

        if self.data["CO01END013CC"] > 0.24:
            self.data["CO01END013CC"] = 0.24

        if self.data["COQ1END004IN"] > 71496.8999999998:
            self.data["COQ1END004IN"] = 71496.8999999998

        if self.data["CO00DEM026"] > 6:
            self.data["CO00DEM026"] = 6

        if self.data["CO01END030RO"] > 13.98:
            self.data["CO01END030RO"] = 13.98

        if self.data["COQ1END003IN"] > 70000:
            self.data["COQ1END003IN"] = 70000

        if self.data["CO01END013IN"] > 3.2:
            self.data["CO01END013IN"] = 3.2

        if self.data["CO02NUM002TO"] > 25:
            self.data["CO02NUM002TO"] = 25

        if self.data["CO01END028OT"] > 1.65:
            self.data["CO01END028OT"] = 1.65

        if self.data["CO01END086RO"] > 98.49:
            self.data["CO01END086RO"] = 98.49

        if self.data["CO02END002IN"] > 28.7789999999999:
            self.data["CO02END002IN"] = 28.7789999999999

        if self.data["CO01END018RO"] > 1.58:
            self.data["CO01END018RO"] = 1.58

        if self.data["CO00DEM006"] > 1:
            self.data["CO00DEM006"] = 1

        if self.data["CO01END004RO"] > 0.35:
            self.data["CO01END004RO"] = 0.35

        if self.data["CO01MOR008RO"] > 1:
            self.data["CO01MOR008RO"] = 1

        if self.data["CO02END006CB"] > 27.07:
            self.data["CO02END006CB"] = 27.07

        if self.data["CO02NUM043CB"] > 80:
            self.data["CO02NUM043CB"] = 80

        if self.data["CO02NUM002TO"] > 25:
            self.data["CO02NUM002TO"] = 25

        if self.data["CO02NUM043CB"] > 80:
            self.data["CO02NUM043CB"] = 80

        if self.q3_cuotatotal > 15.43:
            self.q3_cuotatotal = 15.43

        # Binary Attributes
        if 52.198 < self.data["CO01END007VE"] <= 75.73:
            Q3_S22_D_CO01END007VE_4 = 1
        else:
            Q3_S22_D_CO01END007VE_4 = 0

        if 149.912 < self.data["CO01END007HP"] <= 155.34:
            Q3_S22_D_CO01END007HP_5 = 1
        else:
            Q3_S22_D_CO01END007HP_5 = 0

        if 0 <= self.data["CO01END013CO"] <= 0.33:
            Q3_S22_D_CO01END013CO_2 = 1
        else:
            Q3_S22_D_CO01END013CO_2 = 0

        if 1.65 < self.data["CO01END006CO"] <= 2.52:
            Q3_S22_D_CO01END006CO_5 = 1
        else:
            Q3_S22_D_CO01END006CO_5 = 0

        if 1.36 < self.data["CO01END046HP"] <= 1.73:
            Q3_S22_D_CO01END046HP_4 = 1
        else:
            Q3_S22_D_CO01END046HP_4 = 0

        if self.data["CO01NUM001CT"] < 0:
            Q3_S22_D_CO01NUM001CT_1 = 1
        else:
            Q3_S22_D_CO01NUM001CT_1 = 0

        if 0 <= self.data["CO01NUM001CT"] <= 1:
            Q3_S22_D_CO01NUM001CT_2 = 1
        else:
            Q3_S22_D_CO01NUM001CT_2 = 0

        if 0 <= self.data["CO01END013CC"] <= 0.03:
            Q3_S22_D_CO01END013CC_2 = 1
        else:
            Q3_S22_D_CO01END013CC_2 = 0

        if 0 <= self.data["COQ1END004IN"] <= 17596.6:
            Q3_S22_D_COQ1END004IN_2 = 1
        else:
            Q3_S22_D_COQ1END004IN_2 = 0

        if 1 <= self.data["CO00DEM026"] <= 3:
            Q3_S22_D_CO00DEM026_2 = 1
        else:
            Q3_S22_D_CO00DEM026_2 = 0

        if 7.28 < self.data["CO01END030RO"] <= 10.611:
            Q3_S22_D_CO01END030RO_4 = 1
        else:
            Q3_S22_D_CO01END030RO_4 = 0

        if 10.611 < self.data["CO01END030RO"] <= 13.98:
            Q3_S22_D_CO01END030RO_5 = 1
        else:
            Q3_S22_D_CO01END030RO_5 = 0

        if 48500 < self.data["COQ1END003IN"] <= 63098.2:
            Q3_S22_D_COQ1END003IN_4 = 1
        else:
            Q3_S22_D_COQ1END003IN_4 = 0

        if 63098.2 < self.data["COQ1END003IN"] <= 70000:
            Q3_S22_D_COQ1END003IN_5 = 1
        else:
            Q3_S22_D_COQ1END003IN_5 = 0

        if 0 <= self.data["CO01END013IN"] <= 0.61:
            Q3_S22_D_CO01END013IN_2 = 1
        else:
            Q3_S22_D_CO01END013IN_2 = 0

        if 1.5 < self.data["CO01END028OT"] <= 1.65:
            Q3_S22_D_CO01END028OT_5 = 1
        else:
            Q3_S22_D_CO01END028OT_5 = 0

        if 88.48 < self.data["CO01END086RO"] <= 98.49:
            Q3_S22_D_CO01END086RO_5 = 1
        else:
            Q3_S22_D_CO01END086RO_5 = 0

        if 8.21 < self.data["CO02END002IN"] <= 28.7789999999999:
            Q3_S22_D_CO02END002IN_5 = 1
        else:
            Q3_S22_D_CO02END002IN_5 = 0

        if 0.85 < self.data["CO01END018RO"] <= 1.58:
            Q3_S22_D_CO01END018RO_5 = 1
        else:
            Q3_S22_D_CO01END018RO_5 = 0

        if self.data["CO00DEM006"] == 0:
            Q3_S22_D_CO00DEM006_2 = 1
        else:
            Q3_S22_D_CO00DEM006_2 = 0

        if 0 <= self.data["CO01END004RO"] <= 0.09:
            Q3_S22_D_CO01END004RO_2 = 1
        else:
            Q3_S22_D_CO01END004RO_2 = 0

        if 0 < self.data["CO01MOR008RO"] <= 1:
            Q3_S22_D_CO01MOR008RO_3 = 1
        else:
            Q3_S22_D_CO01MOR008RO_3 = 0

        # Binary Attributes
        if 134.4 <= self.data["CO01END007IN"]:
            Q3_S22_CUPO_IN_RO = 3
        else:
            if 45.165 <= self.data["CO01END007RO"]:
                Q3_S22_CUPO_IN_RO = 2
            else:
                Q3_S22_CUPO_IN_RO = 1

        if 17.57 < self.data["CO02END006CB"] <= 27.07:
            Q3_S22_D_CO02END006CB_5 = 1
        else:
            Q3_S22_D_CO02END006CB_5 = 0

        Q3_S22_EXPONENTE = (1.76638 +
                            Q3_S22_D_CO02END006CB_5 * -0.09951 +
                            Q3_S22_CUPO_IN_RO * 0.10046 +
                            Q3_S22_D_CO00DEM006_2 * 0.06813 +
                            self.data["CO02NUM002TO"] * 0.00783 +
                            self.data["CO02NUM043CB"] * -0.00244 +
                            self.q3_cuotatotal * 0.01082 +
                            Q3_S22_D_CO00DEM026_2 * -0.06232 +
                            Q3_S22_D_CO01END004RO_2 * 0.14918 +
                            Q3_S22_D_CO01END006CO_5 * 0.11205 +
                            Q3_S22_D_CO01END007HP_5 * 0.18817 +
                            Q3_S22_D_CO01END007VE_4 * 0.23666 +
                            Q3_S22_D_CO01END013CC_2 * -0.14028 +
                            Q3_S22_D_CO01END013CO_2 * -0.13456 +
                            Q3_S22_D_CO01END013IN_2 * -0.06109 +
                            Q3_S22_D_CO01END018RO_5 * 0.13136 +
                            Q3_S22_D_CO01END028OT_5 * 0.09002 +
                            Q3_S22_D_CO01END030RO_4 * 0.1328 +
                            Q3_S22_D_CO01END030RO_5 * 0.21866 +
                            Q3_S22_D_CO01END046HP_4 * 0.1295 +
                            Q3_S22_D_CO01END086RO_5 * -0.09365 +
                            Q3_S22_D_CO01MOR008RO_3 * -0.24077 +
                            Q3_S22_D_CO01NUM001CT_1 * -0.28515 +
                            Q3_S22_D_CO01NUM001CT_2 * -0.13896 +
                            Q3_S22_D_CO02END002IN_5 * 0.09232 +
                            Q3_S22_D_COQ1END003IN_4 * 0.08486 +
                            Q3_S22_D_COQ1END003IN_5 * 0.10637 +
                            Q3_S22_D_COQ1END004IN_2 * -0.10898)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S22_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card23_daqu3(self):
        """
        Computes Score Card 23
        """
        # NO TEC NODO5 GRUPO 5
        self.inicializa_variables()
        self.score_card_daqu3 = 23
        self.adverse_razon_daqu3[0] = 99

        # VALORES ESPECIALES
        attributes = ["CO01END011IN", "CO01END045RO", "CO02NUM003TO", "CO01END023CC", "COQ1END002HP",
                      "CO00DEM026", "CO01END015RO", "COQ1END007IN", "CO01END036CO", "CO01NUM002CT",
                      "CO01END010RO", "CO01END028IN", "CO01END061VE", "CO01END008RO", "CO01END025RO",
                      "CO01END007IN", "CO01END007HP", "CO02END008HP", "CO01END007HP", "CO01END013CO",
                      "CO01END007VE", "COQ1END003IN", "CO01END046VE", "CO01END030RO", "COQ1END001TO",
                      "COQ1END004IN", "COQ1END008HP", "CO01END006CC", "CO01NUM001CT"]

        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Dimensioning
        if self.data["CO01END011IN"] > 113:
            self.data["CO01END011IN"] = 113

        if self.data["CO01END045RO"] > 10.44:
            self.data["CO01END045RO"] = 10.44

        if self.data["CO02NUM003TO"] > 23:
            self.data["CO02NUM003TO"] = 23

        if self.data["CO01END023CC"] > 0.3:
            self.data["CO01END023CC"] = 0.3

        if self.data["COQ1END002HP"] > 2227:
            self.data["COQ1END002HP"] = 2227

        if self.data["CO00DEM026"] > 6:
            self.data["CO00DEM026"] = 6

        if self.data["CO01END015RO"] > 21.6605:
            self.data["CO01END015RO"] = 21.6605

        if self.data["COQ1END007IN"] > 4642.325:
            self.data["COQ1END007IN"] = 4642.325

        if self.data["CO01END036CO"] > 4.77049999999999:
            self.data["CO01END036CO"] = 4.77049999999999

        if self.data["CO01NUM002CT"] > 4:
            self.data["CO01NUM002CT"] = 4

        if self.data["CO01END010RO"] > 21.88:
            self.data["CO01END010RO"] = 21.88

        if self.data["CO01END028IN"] > 5.87049999999999:
            self.data["CO01END028IN"] = 5.87049999999999

        if self.data["CO01END061VE"] > 66.8815:
            self.data["CO01END061VE"] = 66.8815

        if self.data["CO01END008RO"] > 33.08:
            self.data["CO01END008RO"] = 33.08

        if self.data["CO01END025RO"] > 21.34:
            self.data["CO01END025RO"] = 21.34

        if self.data["CO01END007IN"] > 379.6365:
            self.data["CO01END007IN"] = 379.6365

        if self.data["CO01END007HP"] > 340.58:
            self.data["CO01END007HP"] = 340.58

        if self.data["CO02END008HP"] > 2.8:
            self.data["CO02END008HP"] = 2.8

        if self.data["CO01END007HP"] > 340.58:
            self.data["CO01END007HP"] = 340.58

        if self.data["CO01END013CO"] > 5.14:
            self.data["CO01END013CO"] = 5.14

        if self.data["CO01END007VE"] > 111.6785:
            self.data["CO01END007VE"] = 111.6785

        if self.data["COQ1END003IN"] > 116038.5:
            self.data["COQ1END003IN"] = 116038.5

        if self.data["CO01END046VE"] > 2.38:
            self.data["CO01END046VE"] = 2.38

        if self.data["CO01END030RO"] > 21.09:
            self.data["CO01END030RO"] = 21.09

        if self.data["COQ1END001TO"] > 61480.8235:
            self.data["COQ1END001TO"] = 61480.8235

        if self.data["COQ1END004IN"] > 136409:
            self.data["COQ1END004IN"] = 136409

        if self.data["COQ1END008HP"] > 150000:
            self.data["COQ1END008HP"] = 150000

        if self.data["CO01END006CC"] > 0.29:
            self.data["CO01END006CC"] = 0.29

        if self.data["CO01NUM001CT"] > 6:
            self.data["CO01NUM001CT"] = 6

        # Binary Attributes
        if 0 <= self.data["CO01END011IN"] <= 20.41:
            Q3_S23_CO01END011IN_2 = 1
        else:
            Q3_S23_CO01END011IN_2 = 0

        if 0 <= self.data["CO01END045RO"] <= 1.59:
            Q3_S23_CO01END045RO_2 = 1
        else:
            Q3_S23_CO01END045RO_2 = 0

        if 0 <= self.data["CO02NUM003TO"] <= 6:
            Q3_S23_CO02NUM003TO_2 = 1
        else:
            Q3_S23_CO02NUM003TO_2 = 0

        if 0.25 < self.data["CO01END023CC"] <= 0.3:
            Q3_S23_CO01END023CC_5 = 1
        else:
            Q3_S23_CO01END023CC_5 = 0

        if 0 <= self.data["COQ1END002HP"] <= 585.2:
            Q3_S23_COQ1END002HP_2 = 1
        else:
            Q3_S23_COQ1END002HP_2 = 0

        if self.data["CO00DEM026"] == 6:
            Q3_S23_CO00DEM026_5 = 1
        else:
            Q3_S23_CO00DEM026_5 = 0

        if 8.90150000000001 < self.data["CO01END015RO"] <= 14.55:
            Q3_S23_CO01END015RO_4 = 1
        else:
            Q3_S23_CO01END015RO_4 = 0

        if 1162 < self.data["COQ1END007IN"] <= 4642.325:
            Q3_S23_COQ1END007IN_5 = 1
        else:
            Q3_S23_COQ1END007IN_5 = 0

        if 1.57 < self.data["CO01END036CO"] <= 3.26:
            Q3_S23_CO01END036CO_4 = 1
        else:
            Q3_S23_CO01END036CO_4 = 0

        if 0 <= self.data["CO01NUM002CT"] <= 0:
            Q3_S23_CO01NUM002CT_2 = 1
        else:
            Q3_S23_CO01NUM002CT_2 = 0

        if 14.73 < self.data["CO01END010RO"] <= 21.88:
            Q3_S23_CO01END010RO_4 = 1
        else:
            Q3_S23_CO01END010RO_4 = 0

        if 1.51 < self.data["CO01END028IN"] <= 5.87049999999999:
            Q3_S23_CO01END028IN_5 = 1
        else:
            Q3_S23_CO01END028IN_5 = 0

        if 64.8675 < self.data["CO01END061VE"] <= 66.8815:
            Q3_S23_CO01END061VE_4 = 1
        else:
            Q3_S23_CO01END061VE_4 = 0

        if 0 <= self.data["CO01END008RO"] <= 5.887:
            Q3_S23_CO01END008RO_2 = 1
        else:
            Q3_S23_CO01END008RO_2 = 0

        if 14.44 < self.data["CO01END025RO"] <= 21.34:
            Q3_S23_CO01END025RO_5 = 1
        else:
            Q3_S23_CO01END025RO_5 = 0

        if 201.94 < self.data["CO01END007IN"] <= 302.516:
            Q3_S23_CO01END007IN_4 = 1
        else:
            Q3_S23_CO01END007IN_4 = 0

        if 0 <= self.data["CO01END007HP"] <= 88.94:
            Q3_S23_CO01END007HP_2 = 1
        else:
            Q3_S23_CO01END007HP_2 = 0

        if 1.61 < self.data["CO02END008HP"] <= 2.8:
            Q3_S23_CO02END008HP_5 = 1
        else:
            Q3_S23_CO02END008HP_5 = 0

        if 310.61 < self.data["CO01END007HP"] <= 340.58:
            Q3_S23_CO01END007HP_5 = 1
        else:
            Q3_S23_CO01END007HP_5 = 0

        if 0 <= self.data["CO01END013CO"] <= 0.64:
            Q3_S23_CO01END013CO_2 = 1
        else:
            Q3_S23_CO01END013CO_2 = 0

        if 96.3375 < self.data["CO01END007VE"] <= 111.6785:
            Q3_S23_CO01END007VE_4 = 1
        else:
            Q3_S23_CO01END007VE_4 = 0

        if 0 <= self.data["COQ1END003IN"] <= 17192:
            Q3_S23_COQ1END003IN_2 = 1
        else:
            Q3_S23_COQ1END003IN_2 = 0

        if 1.47 < self.data["CO01END046VE"] <= 2.38:
            Q3_S23_CO01END046VE_4 = 1
        else:
            Q3_S23_CO01END046VE_4 = 0

        if 0 <= self.data["CO01END030RO"] <= 2.11:
            Q3_S23_CO01END030RO_2 = 1
        else:
            Q3_S23_CO01END030RO_2 = 0

        if self.data["COQ1END001TO"] < 0:
            Q3_S23_COQ1END001TO_1 = 1
        else:
            Q3_S23_COQ1END001TO_1 = 0

        if 67897.5 < self.data["COQ1END004IN"] <= 94763.25:
            Q3_S23_COQ1END004IN_4 = 1
        else:
            Q3_S23_COQ1END004IN_4 = 0

        if 116000 < self.data["COQ1END008HP"] <= 150000:
            Q3_S23_COQ1END008HP_4 = 1
        else:
            Q3_S23_COQ1END008HP_4 = 0

        if 0 <= self.data["CO01END006CC"] <= 0.05:
            Q3_S23_CO01END006CC_2 = 1
        else:
            Q3_S23_CO01END006CC_2 = 0

        if self.data["CO01NUM001CT"] < 0:
            Q3_S23_CO01NUM001CT_1 = 1
        else:
            Q3_S23_CO01NUM001CT_1 = 0

        if 94763.25 < self.data["COQ1END004IN"] <= 136409:
            Q3_S23_COQ1END004IN_5 = 1
        else:
            Q3_S23_COQ1END004IN_5 = 0

        Q3_S23_EXPONENTE = (2.47639 +
                            Q3_S23_COQ1END004IN_5 * 0.26192 +
                            Q3_S23_CO01NUM001CT_1 * -0.23989 +
                            Q3_S23_CO01END006CC_2 * -0.19223 +
                            Q3_S23_COQ1END008HP_4 * 0.18105 +
                            Q3_S23_COQ1END004IN_4 * 0.16832 +
                            Q3_S23_COQ1END001TO_1 * 0.19762 +
                            Q3_S23_CO01END030RO_2 * -0.14731 +
                            Q3_S23_CO01END046VE_4 * 0.14106 +
                            Q3_S23_COQ1END003IN_2 * -0.15243 +
                            Q3_S23_CO01END007VE_4 * 0.14548 +
                            Q3_S23_CO01END013CO_2 * -0.10435 +
                            Q3_S23_CO01END007HP_5 * 0.16269 +
                            Q3_S23_CO02END008HP_5 * 0.12096 +
                            Q3_S23_CO01END007HP_2 * -0.11556 +
                            Q3_S23_CO01END007IN_4 * 0.14285 +
                            Q3_S23_CO01END025RO_5 * 0.10716 +
                            Q3_S23_CO01END008RO_2 * -0.11238 +
                            Q3_S23_CO01END061VE_4 * 0.10956 +
                            Q3_S23_CO01END028IN_5 * 0.10182 +
                            Q3_S23_CO01END010RO_4 * 0.11009 +
                            Q3_S23_CO01NUM002CT_2 * -0.14913 +
                            Q3_S23_CO01END036CO_4 * 0.12342 +
                            Q3_S23_COQ1END007IN_5 * 0.10884 +
                            Q3_S23_CO01END015RO_4 * 0.08223 +
                            Q3_S23_CO00DEM026_5 * 0.09363 +
                            Q3_S23_COQ1END002HP_2 * -0.07948 +
                            Q3_S23_CO01END023CC_5 * 0.09187 +
                            Q3_S23_CO02NUM003TO_2 * -0.13356 +
                            Q3_S23_CO01END045RO_2 * -0.08061 +
                            Q3_S23_CO01END011IN_2 * -0.05662)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S23_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0
        self.cal_salida_pesos_daqu3()

    def score_card24_daqu3(self):
        """
        Computes Score Card 24
        """
        # NOTEC NODO=5 and GRUPO = 6
        self.inicializa_variables()
        self.score_card_daqu3 = 24
        self.adverse_razon_daqu3[0] = 99

        # VALORES ESPECIALES
        # Caracteristicas personalizadas Quanto 3:
        attributes = ["CO02NUM002TO", "CO01ACP007CT", "CO01END009RO", "CO01END008RO", "CO01END028HP",
                      "CO01END005CC", "CO01END007VE", "CO01END023CO", "CO01END021HP", "CO01END023OT",
                      "COQ1END003TC", "COQ1NUM002TC", "COQ1END003IN", "COQ1END018TC", "COQ1END014TC",
                      "COQ1END001TO"]
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Caracteristicas hibridas
        self.cuotatotal_daqu3()
        if self.q3_cuotatotal == 999:
            self.q3_cuotatotal = -1.0

        if self.q3_prcuotatotalro == 999:
            self.q3_prcuotatotalro = -1.0

        self.exposicion_daqu3()
        if self.q3_prexposicionro == 999:
            self.q3_prexposicionro = -1.0

        # Acotacion
        Q3_S24_COQ1END003TC_A = self.data["COQ1END003TC"]

        if self.data["CO02NUM002TO"] > 29:
            self.data["CO02NUM002TO"] = 29

        if self.q3_cuotatotal > 62.210175:
            self.q3_cuotatotal = 62.210175

        if self.data["COQ1END003TC"] > 22500:
            self.data["COQ1END003TC"] = 22500

        if self.data["COQ1NUM002TC"] > 123:
            self.data["COQ1NUM002TC"] = 123

        if self.q3_prcuotatotalro > 0.9391005:
            self.q3_prcuotatotalro = 0.9391005

        if self.data["COQ1END018TC"] > 4314.6683333665:
            self.data["COQ1END018TC"] = 4314.6683333665

        if self.data["COQ1END014TC"] > 110161.35:
            self.data["COQ1END014TC"] = 110161.35

        if self.data["COQ1END001TO"] > 61480.8235:
            self.data["COQ1END001TO"] = 61480.8235

        if self.data["CO01ACP007CT"] > 2:
            self.data["CO01ACP007CT"] = 2

        if self.data["CO01END009RO"] > 114.5615:
            self.data["CO01END009RO"] = 114.5615

        if self.data["CO01END008RO"] > 33.08:
            self.data["CO01END008RO"] = 33.08

        if self.data["CO01END028HP"] > 3.88:
            self.data["CO01END028HP"] = 3.88

        if self.q3_prexposicionro > 0.91380075:
            self.q3_prexposicionro = 0.91380075

        if self.data["CO01END005CC"] > 0.45:
            self.data["CO01END005CC"] = 0.45

        if self.data["COQ1END003IN"] > 116038.5:
            self.data["COQ1END003IN"] = 116038.5

        if self.data["CO01END007VE"] > 111.6785:
            self.data["CO01END007VE"] = 111.6785

        if self.data["CO01END023CO"] > 5.56:
            self.data["CO01END023CO"] = 5.56

        if self.data["CO01END021HP"] > 256.1205:
            self.data["CO01END021HP"] = 256.1205

        if self.data["CO01END023OT"] > 2.62:
            self.data["CO01END023OT"] = 2.62

        # binarias: Creacion
        if self.data["COQ1END014TC"] < 0:
            Q3_S24_COQ1END014TC_1 = 1
        else:
            Q3_S24_COQ1END014TC_1 = 0

        if 0 <= self.data["COQ1END001TO"] <= 1408.4135:
            Q3_S24_COQ1END001TO_2 = 1
        else:
            Q3_S24_COQ1END001TO_2 = 0

        if self.data["CO01ACP007CT"] < 0:
            Q3_S24_CO01ACP007CT_1 = 1
        else:
            Q3_S24_CO01ACP007CT_1 = 0

        if self.data["CO01END009RO"] < 0:
            Q3_S24_CO01END009RO_1 = 1
        else:
            Q3_S24_CO01END009RO_1 = 0

        if 0 <= self.data["CO01END008RO"] <= 11.51:
            Q3_S24_CO01END008RO_2 = 1
        else:
            Q3_S24_CO01END008RO_2 = 0

        if 0 <= self.data["CO01END028HP"] <= 1.11:
            Q3_S24_CO01END028HP_2 = 1
        else:
            Q3_S24_CO01END028HP_2 = 0

        if 0 <= self.q3_prexposicionro <= 0.11305:
            Q3_S24_PREXPOSICIONRO_2 = 1
        else:
            Q3_S24_PREXPOSICIONRO_2 = 0

        if 0 <= self.data["CO01END005CC"] <= 0:
            Q3_S24_CO01END005CC_2 = 1
        else:
            Q3_S24_CO01END005CC_2 = 0

        if 76000 < self.data["COQ1END003IN"] <= 134000:
            Q3_S24_COQ1END003IN_4 = 1
        else:
            Q3_S24_COQ1END003IN_4 = 0

        if 70.58 < self.data["CO01END007VE"] <= 130.69:
            Q3_S24_CO01END007VE_4 = 1
        else:
            Q3_S24_CO01END007VE_4 = 0

        if 0 <= self.data["CO01END023CO"] <= 1.14:
            Q3_S24_CO01END023CO_2 = 1
        else:
            Q3_S24_CO01END023CO_2 = 0

        if self.data["CO01END021HP"] < 0:
            Q3_S24_CO01END021HP_1 = 1
        else:
            Q3_S24_CO01END021HP_1 = 0

        if 0 <= self.data["CO01END023OT"] <= 0.08:
            Q3_S24_CO01END023OT_2 = 1
        else:
            Q3_S24_CO01END023OT_2 = 0

        # Categoricas: Creacion

        if self.data["CO00DEM026"] == 5 or self.data["CO00DEM026"] == 6:
            Q3_S24_ESTRATO56 = 1
        else:
            Q3_S24_ESTRATO56 = 0

        Q3_SUMA_CUOTA_TOT = self.calcula_suma_cuota_tot()
        Q3_S24_SUMACUOTA_TOT = 0

        if 0 <= Q3_SUMA_CUOTA_TOT <= 1939:
            Q3_S24_SUMACUOTA_TOT = 1

        if 1939 < Q3_SUMA_CUOTA_TOT <= 3347:
            Q3_S24_SUMACUOTA_TOT = 2

        if 3347 < Q3_SUMA_CUOTA_TOT <= 5462:
            Q3_S24_SUMACUOTA_TOT = 3

        if Q3_SUMA_CUOTA_TOT > 5462:
            Q3_S24_SUMACUOTA_TOT = 4

        if Q3_SUMA_CUOTA_TOT < 0:
            Q3_S24_SUMACUOTA_TOT = 5

        Q3_MAXIMO_CUPO_TOT = self.calcula_maximo_cupo_tot()

        if Q3_MAXIMO_CUPO_TOT < 0:
            Q3_MAXIMO_CUPO_TOT = -2

        if Q3_MAXIMO_CUPO_TOT == Q3_S24_COQ1END003TC_A:
            Q3_S24_MAX_CUPOTC = 1
        else:
            Q3_S24_MAX_CUPOTC = 0

        Q3_S24_PRCUOTATOTALRO = round(self.q3_prcuotatotalro, 3)  # ROUNDED
        self.q3_prcuotatotalro = float(Q3_S24_PRCUOTATOTALRO)  # ROUNDED

        Q3_S24_EXPONENTE = (2.35793 +
                            Q3_S24_ESTRATO56 * 0.09507 +
                            Q3_S24_SUMACUOTA_TOT * 0.05095 +
                            Q3_S24_MAX_CUPOTC * -0.08088 +
                            self.data["CO02NUM002TO"] * 0.01187 +
                            self.q3_cuotatotal * 0.00474 +
                            self.data["COQ1END003TC"] * 0.00000818 +
                            self.data["COQ1NUM002TC"] * 0.00102 +
                            self.q3_prcuotatotalro * -0.11541 +
                            self.data["COQ1END018TC"] * 0.00001723 +
                            Q3_S24_COQ1END014TC_1 * 0.44723 +
                            Q3_S24_COQ1END001TO_2 * -0.18191 +
                            Q3_S24_CO01ACP007CT_1 * -0.23936 +
                            Q3_S24_CO01END009RO_1 * -0.20096 +
                            Q3_S24_CO01END008RO_2 * -0.20864 +
                            Q3_S24_CO01END028HP_2 * -0.16045 +
                            Q3_S24_PREXPOSICIONRO_2 * 0.20077 +
                            Q3_S24_CO01END005CC_2 * -0.18685 +
                            Q3_S24_COQ1END003IN_4 * 0.2279 +
                            Q3_S24_CO01END007VE_4 * 0.11686 +
                            Q3_S24_CO01END023CO_2 * -0.07294 +
                            Q3_S24_CO01END021HP_1 * -0.04952 +
                            Q3_S24_CO01END023OT_2 * -0.14662)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S24_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card25_daqu3(self):
        """
        Computes Score Card 25
        """
        self.inicializa_variables()
        self.score_card_daqu3 = 25
        self.adverse_razon_daqu3[0] = 99

        if self.data["CO02EXP001TO"] == 999:
            self.data["CO02EXP001TO"] = 1

        if self.data["CO01END005HP"] == 999:
            self.data["CO01END005HP"] = 1

        if self.data["CO01END013IN"] == 999:
            self.data["CO01END013IN"] = 1

        if self.data["CO01END015RO"] == 999:
            self.data["CO01END015RO"] = 1

        if self.data["CO01END041RO"] == 999:
            self.data["CO01END041RO"] = 1

        if self.data["CO01END065IN"] == 999:
            self.data["CO01END065IN"] = 1

        if self.data["CO02END007IN"] == 999:
            self.data["CO02END007IN"] = 1

        if self.data["CO02EXP001TO"] > 234:
            self.data["CO02EXP001TO"] = 234

        if self.data["CO01END005HP"] > 0.74:
            self.data["CO01END005HP"] = 0.74

        if self.data["CO01END013IN"] > 0.32:
            self.data["CO01END013IN"] = 0.32

        if self.data["CO01END015RO"] > 2.33:
            self.data["CO01END015RO"] = 2.33

        if self.data["CO01END041RO"] > 1.67:
            self.data["CO01END041RO"] = 1.67

        if self.data["CO01END065IN"] > 0.4025:
            self.data["CO01END065IN"] = 0.4025

        if self.data["CO02END007IN"] > 26.2525:
            self.data["CO02END007IN"] = 26.2525

        if 0 <= self.data["CO01END005HP"] <= 0.6:
            Q3_S25_CO01END005HP_2 = 1.0
        else:
            Q3_S25_CO01END005HP_2 = 0.0

        if 0 <= self.data["CO01END013IN"] <= 0.14:
            Q3_S25_CO01END013IN_2 = 1.0
        else:
            Q3_S25_CO01END013IN_2 = 0.0

        if 0 <= self.data["CO01END015RO"] <= 1.95:
            Q3_S25_CO01END015RO_2 = 1.0
        else:
            Q3_S25_CO01END015RO_2 = 0.0

        if 1.29 < self.data["CO01END041RO"] <= 1.67:
            Q3_S25_CO01END041RO_3 = 1.0
        else:
            Q3_S25_CO01END041RO_3 = 0.0

        if 0.37 < self.data["CO01END065IN"] <= 0.4025:
            Q3_S25_CO01END065IN_4 = 1.0
        else:
            Q3_S25_CO01END065IN_4 = 0.0

        if 0 <= self.data["CO02END007IN"] <= 8.06:
            Q3_S25_CO02END007IN_2 = 1.0
        else:
            Q3_S25_CO02END007IN_2 = 0.0

        Q3_S25_EXPONENTE = (
                0.6179 +
                self.data["CO02EXP001TO"] * 0.00041802 +
                Q3_S25_CO01END005HP_2 * -0.26676 +
                Q3_S25_CO01END013IN_2 * -0.20392 +
                Q3_S25_CO01END015RO_2 * -0.10499 +
                Q3_S25_CO01END041RO_3 * 0.12044 +
                Q3_S25_CO01END065IN_4 * 0.13786 +
                Q3_S25_CO02END007IN_2 * -0.15005
        )

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S25_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card26_daqu3(self):
        """
        Computes Score Card 26
        """
        self.inicializa_variables()
        self.score_card_daqu3 = 26
        self.adverse_razon_daqu3[0] = 99

        if self.data["CO02EXP001TO"] == 999:
            self.data["CO02EXP001TO"] = -1

        if self.data["CO01NUM002CT"] == 999:
            self.data["CO01NUM002CT"] = -1

        if self.data["CO01END017CC"] == 999:
            self.data["CO01END017CC"] = -1

        if self.data["CO01END036CC"] == 999:
            self.data["CO01END036CC"] = -1

        if self.data["CO01END029RO"] == 999:
            self.data["CO01END029RO"] = -1

        if self.data["CO01END023CC"] == 999:
            self.data["CO01END023CC"] = -1

        if self.data["CO01END056IN"] == 999:
            self.data["CO01END056IN"] = -1

        if self.data["CO01END020RO"] == 999:
            self.data["CO01END020RO"] = -1

        if self.data["CO01END027RO"] == 999:
            self.data["CO01END027RO"] = -1

        if self.data["CO02END002CB"] == 999:
            self.data["CO02END002CB"] = -1

        if self.data["CO01END013IN"] == 999:
            self.data["CO01END013IN"] = -1

        if self.data["CO02NUM043RO"] == 999:
            self.data["CO02NUM043RO"] = -1

        Q3_CAST = self.calcula_cast_scodaqu3()

        if Q3_CAST == 999:
            Q3_CAST = -1

        if Q3_CAST > 1:
            Q3_CAST = 1

        if self.data["CO02EXP001TO"] > 247:
            self.data["CO02EXP001TO"] = 247

        if self.data["CO01NUM002CT"] > 1:
            self.data["CO01NUM002CT"] = 1

        if self.data["CO01END017CC"] > 0.1:
            self.data["CO01END017CC"] = 0.1

        if self.data["CO01END036CC"] > 0.13:
            self.data["CO01END036CC"] = 0.13

        if self.data["CO01END029RO"] > 4:
            self.data["CO01END029RO"] = 4

        if self.data["CO01END023CC"] > 0.14:
            self.data["CO01END023CC"] = 0.14

        if self.data["CO01END056IN"] > 0.44:
            self.data["CO01END056IN"] = 0.44

        if self.data["CO01END020RO"] > 2.52449999999999:
            self.data["CO01END020RO"] = 2.52449999999999

        if self.data["CO01END027RO"] > 0.03:
            self.data["CO01END027RO"] = 0.03

        if self.data["CO02END002CB"] > 26.2545:
            self.data["CO02END002CB"] = 26.2545

        if self.data["CO01END013IN"] > 0.43:
            self.data["CO01END013IN"] = 0.43

        if self.data["CO02NUM043RO"] > 100:
            self.data["CO02NUM043RO"] = 100

        if self.data["CO01NUM002CT"] < 0:
            Q3_S26_CO01NUM002CT_1 = 1
        else:
            Q3_S26_CO01NUM002CT_1 = 0

        if 0 <= self.data["CO01END017CC"] <= 0.06:
            Q3_S26_CO01END017CC_2 = 1
        else:
            Q3_S26_CO01END017CC_2 = 0

        if 0 <= self.data["CO01END036CC"] <= 0.09:
            Q3_S26_CO01END036CC_2 = 1
        else:
            Q3_S26_CO01END036CC_2 = 0

        if 3.6075 < self.data["CO01END029RO"] <= 4:
            Q3_S26_CO01END029RO_3 = 1
        else:
            Q3_S26_CO01END029RO_3 = 0

        if 0 <= self.data["CO01END023CC"] <= 0.06:
            Q3_S26_CO01END023CC_2 = 1
        else:
            Q3_S26_CO01END023CC_2 = 0

        if 0 <= self.data["CO01END056IN"] <= 0.31:
            Q3_S26_CO01END056IN_2 = 1
        else:
            Q3_S26_CO01END056IN_2 = 0

        if 0 <= self.data["CO01END020RO"] <= 1.03:
            Q3_S26_CO01END020RO_2 = 1
        else:
            Q3_S26_CO01END020RO_2 = 0

        if 0 < self.data["CO01END027RO"] <= 0.03:
            Q3_S26_CO01END027RO_3 = 1
        else:
            Q3_S26_CO01END027RO_3 = 0

        if 23.268 < self.data["CO02END002CB"] <= 26.2545:
            Q3_S26_CO02END002CB_4 = 1
        else:
            Q3_S26_CO02END002CB_4 = 0

        if 0 <= self.data["CO01END013IN"] <= 0.3:
            Q3_S26_CO01END013IN_2 = 1
        else:
            Q3_S26_CO01END013IN_2 = 0

        if 50 < self.data["CO02NUM043RO"] <= 100:
            Q3_S26_CO02NUM043RO_3 = 1
        else:
            Q3_S26_CO02NUM043RO_3 = 0

        Q3_MAXIMO_CUPO_TOT = self.calcula_maximo_cupo_tot()

        if Q3_MAXIMO_CUPO_TOT < 0:
            Q3_MAXIMO_CUPO_TOT = -2

        if Q3_MAXIMO_CUPO_TOT == self.data["COQ1END003HP"]:
            Q3_S26_MAXCUPO_HP = 1
        else:
            Q3_S26_MAXCUPO_HP = 0

        if Q3_MAXIMO_CUPO_TOT == self.data["COQ1END003MC"]:
            Q3_S26_MAXCUPO_MC = 1
        else:
            Q3_S26_MAXCUPO_MC = 0

        if self.data["CO00DEM026"] == 4 or self.data["CO00DEM026"] == 5 or self.data["CO00DEM026"] == 6:
            Q3_S26_ESTRATO456 = 1
        else:
            Q3_S26_ESTRATO456 = 0

        Q3_S26_EXPONENTE = (
                0.88458 +
                Q3_S26_MAXCUPO_HP * 0.11174 +
                Q3_S26_MAXCUPO_MC * -0.12214 +
                Q3_S26_ESTRATO456 * 0.11382 +
                Q3_CAST * -0.03294 +
                self.data["CO02EXP001TO"] * 0.00043003 +
                Q3_S26_CO01NUM002CT_1 * -0.19529 +
                Q3_S26_CO01END017CC_2 * 0.21932 +
                Q3_S26_CO01END036CC_2 * -0.10621 +
                Q3_S26_CO01END029RO_3 * 0.0823 +
                Q3_S26_CO01END023CC_2 * -0.17287 +
                Q3_S26_CO01END056IN_2 * -0.07331 +
                Q3_S26_CO01END020RO_2 * -0.04902 +
                Q3_S26_CO01END027RO_3 * -0.10396 +
                Q3_S26_CO02END002CB_4 * 0.10685 +
                Q3_S26_CO01END013IN_2 * -0.06174 +
                Q3_S26_CO02NUM043RO_3 * 0.05819)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S26_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card27_daqu3(self):
        """
        Computes Score Card 27
        """
        self.inicializa_variables()
        self.score_card_daqu3 = 27
        self.adverse_razon_daqu3[0] = 99

        if self.data["CO01ACP007CT"] == 999:
            self.data["CO01ACP007CT"] = -1
        if self.data["CO01END023IN"] == 999:
            self.data["CO01END023IN"] = -1
        if self.data["CO01MOR008CC"] == 999:
            self.data["CO01MOR008CC"] = -1
        if self.data["CO01END005CC"] == 999:
            self.data["CO01END005CC"] = -1
        if self.data["CO01END014RO"] == 999:
            self.data["CO01END014RO"] = -1
        if self.data["CO01ACP007CT"] == 999:
            self.data["CO01ACP007CT"] = -1
        if self.data["CO01END002IN"] == 999:
            self.data["CO01END002IN"] = -1
        if self.data["CO01END023IN"] == 999:
            self.data["CO01END023IN"] = -1
        if self.data["CO01END024RO"] == 999:
            self.data["CO01END024RO"] = -1
        if self.data["CO02END004CB"] == 999:
            self.data["CO02END004CB"] = -1
        if self.data["CO01END090RO"] == 999:
            self.data["CO01END090RO"] = -1
        if self.data["CO01END023RO"] == 999:
            self.data["CO01END023RO"] = -1
        if self.data["CO01ACP007AH"] == 999:
            self.data["CO01ACP007AH"] = -1
            # REMARK*    ACOTACION */
        if self.data["CO01ACP007AH"] > 2:
            self.data["CO01ACP007AH"] = 2
        if self.data["CO01END023RO"] > 0.63:
            self.data["CO01END023RO"] = 0.63
        if self.data["CO01END090RO"] > 77.895:
            self.data["CO01END090RO"] = 77.895
        if self.data["CO02END004CB"] > 33.97:
            self.data["CO02END004CB"] = 33.97
        if self.data["CO01END024RO"] > 8.18:
            self.data["CO01END024RO"] = 8.18
        if self.data["CO01END023IN"] > 1.18:
            self.data["CO01END023IN"] = 1.18
        if self.data["CO01END002IN"] > 12.23:
            self.data["CO01END002IN"] = 12.23
        if self.data["CO01ACP007CT"] > 1:
            self.data["CO01ACP007CT"] = 1
        if self.data["CO01END014RO"] > 7.65:
            self.data["CO01END014RO"] = 7.65
        if self.data["CO01END005CC"] > 0.15:
            self.data["CO01END005CC"] = 0.15
        if self.data["CO01MOR008CC"] > 2:
            self.data["CO01MOR008CC"] = 2
        if self.data["CO01END023IN"] > 1.18:
            self.data["CO01END023IN"] = 1.18
        if self.data["CO01ACP007CT"] > 1:
            self.data["CO01ACP007CT"] = 1
            # REMARK*    BINARIAS: CREACION */
        if 1 < self.data["CO01ACP007AH"] <= 2:
            Q3_S27_CO01ACP007AH_4 = 1
        else:
            Q3_S27_CO01ACP007AH_4 = 0
        if 0.38 < self.data["CO01END023RO"] <= 0.63:
            Q3_S27_CO01END023RO_4 = 1
        else:
            Q3_S27_CO01END023RO_4 = 0
        if 63.9525 < self.data["CO01END090RO"] <= 77.895:
            Q3_S27_CO01END090RO_4 = 1
        else:
            Q3_S27_CO01END090RO_4 = 0
        if 22.245 < self.data["CO02END004CB"] <= 33.97:
            Q3_S27_CO02END004CB_3 = 1
        else:
            Q3_S27_CO02END004CB_3 = 0
        if 5.63 < self.data["CO01END024RO"] <= 8.18:
            Q3_S27_CO01END024RO_5 = 1
        else:
            Q3_S27_CO01END024RO_5 = 0
        if 0.65 < self.data["CO01END023IN"] <= 1.04:
            Q3_S27_CO01END023IN_4 = 1
        else:
            Q3_S27_CO01END023IN_4 = 0
        if 0 <= self.data["CO01END002IN"] <= 3.76:
            Q3_S27_CO01END002IN_2 = 1
        else:
            Q3_S27_CO01END002IN_2 = 0
        if self.data["CO01ACP007CT"] < 0:
            Q3_S27_CO01ACP007CT_1 = 1
        else:
            Q3_S27_CO01ACP007CT_1 = 0
        if 0 <= self.data["CO01END014RO"] <= 2.65:
            Q3_S27_CO01END014RO_2 = 1
        else:
            Q3_S27_CO01END014RO_2 = 0
        if 0 <= self.data["CO01END005CC"] <= 0.05:
            Q3_S27_CO01END005CC_2 = 1
        else:
            Q3_S27_CO01END005CC_2 = 0
        if 0 <= self.data["CO01MOR008CC"] <= 0:
            Q3_S27_CO01MOR008CC_2 = 1
        else:
            Q3_S27_CO01MOR008CC_2 = 0
        if 1.04 < self.data["CO01END023IN"] <= 1.18:
            Q3_S27_CO01END023IN_5 = 1
        else:
            Q3_S27_CO01END023IN_5 = 0
        if 0 < self.data["CO01ACP007CT"] <= 1:
            Q3_S27_CO01ACP007CT_3 = 1
        else:
            Q3_S27_CO01ACP007CT_3 = 0
            # REMARK*    /* CATEGORICAS: CREACION */
        if self.data["COQ1END003MC"] == -1:
            Q3_S27_MICROCREDITO = 0
        else:
            Q3_S27_MICROCREDITO = 1
        if self.data["CO00DEM026"] == 4 or self.data["CO00DEM026"] == 5 or self.data["CO00DEM026"] == 6:
            Q3_S27_ESTRATO456 = 1
        else:
            Q3_S27_ESTRATO456 = 0

        Q3_S27_EXPONENTE = (1.093 +
                            Q3_S27_CO01ACP007CT_3 * 0.22464 +
                            Q3_S27_CO01END023IN_5 * 0.15963 +
                            Q3_S27_CO01MOR008CC_2 * 0.25191 +
                            Q3_S27_CO01END005CC_2 * -0.2724 +
                            Q3_S27_CO01END014RO_2 * -0.1242 +
                            Q3_S27_CO01ACP007CT_1 * -0.19213 +
                            Q3_S27_ESTRATO456 * 0.17291 +
                            Q3_S27_CO01END002IN_2 * -0.11284 +
                            Q3_S27_CO01END023IN_4 * 0.1668 +
                            Q3_S27_CO01END024RO_5 * 0.17961 +
                            Q3_S27_MICROCREDITO * -0.13877 +
                            Q3_S27_CO02END004CB_3 * 0.14414 +
                            Q3_S27_CO01END090RO_4 * 0.14816 +
                            Q3_S27_CO01END023RO_4 * 0.12828 +
                            Q3_S27_CO01ACP007AH_4 * -0.12645)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S27_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card28_daqu3(self):
        """
        Computes Score Card 28
        """
        self.inicializa_variables()
        self.score_card_daqu3 = 28
        self.adverse_razon_daqu3[0] = 99

        if self.data["CO01END030RO"] == 999:
            self.data["CO01END030RO"] = -1
        if self.data["CO01ACP007CT"] == 999:
            self.data["CO01ACP007CT"] = -1
        if self.data["CO01EXP001HP"] == 999:
            self.data["CO01EXP001HP"] = -1
        if self.data["CO02NUM018TO"] == 999:
            self.data["CO02NUM018TO"] = -1
        if self.data["CO01END023RO"] == 999:
            self.data["CO01END023RO"] = -1
        if self.data["CO02END040RO"] == 999:
            self.data["CO02END040RO"] = -1
        if self.data["CO01END023CC"] == 999:
            self.data["CO01END023CC"] = -1
        if self.data["CO01ACP007CT"] == 999:
            self.data["CO01ACP007CT"] = -1
        if self.data["CO01END015RO"] == 999:
            self.data["CO01END015RO"] = -1
        if self.data["CO02END012CB"] == 999:
            self.data["CO02END012CB"] = -1
            # REMARK*    Caracteristicas personalizadas Quanto 3:
        if self.data["COQ1END003TC"] == 999:
            self.data["COQ1END003TC"] = -1
        if self.data["COQ1NUM001HP"] == 999:
            self.data["COQ1NUM001HP"] = -1
        if self.data["COQ1END010TC"] == 999:
            self.data["COQ1END010TC"] = -1
        if self.data["COQ1END008IN"] == 999:
            self.data["COQ1END008IN"] = -1
        if self.data["COQ1END003HP"] == 999:
            self.data["COQ1END003HP"] = -1
        if self.data["COQ1END003IN"] == 999:
            self.data["COQ1END003IN"] = -1
            # REMARK*    Acotacion */
        if self.data["CO02END012CB"] > 141.67:
            self.data["CO02END012CB"] = 141.67
        if self.data["COQ1END008IN"] > 28992:
            self.data["COQ1END008IN"] = 28992
        if self.data["CO01END015RO"] > 9.074:
            self.data["CO01END015RO"] = 9.074
        if self.data["CO01ACP007CT"] > 1:
            self.data["CO01ACP007CT"] = 1
        if self.data["CO01END023CC"] > 0.16:
            self.data["CO01END023CC"] = 0.16
        if self.data["CO02END040RO"] > 92.338:
            self.data["CO02END040RO"] = 92.338
        if self.data["COQ1NUM001HP"] > 4:
            self.data["COQ1NUM001HP"] = 4
        if self.data["COQ1END003TC"] > 11010:
            self.data["COQ1END003TC"] = 11010
        if self.data["CO01END023RO"] > 1.322:
            self.data["CO01END023RO"] = 1.322
        if self.data["COQ1END010TC"] > 31675.2:
            self.data["COQ1END010TC"] = 31675.2
        if self.data["CO02NUM018TO"] > 1:
            self.data["CO02NUM018TO"] = 1
        if self.data["CO01EXP001HP"] > 180:
            self.data["CO01EXP001HP"] = 180
        if self.data["CO01ACP007CT"] > 1:
            self.data["CO01ACP007CT"] = 1
        if self.data["CO01END030RO"] > 9.11199999999999:
            self.data["CO01END030RO"] = 9.11199999999999
        if self.data["COQ1END003IN"] > 30000:
            self.data["COQ1END003IN"] = 30000
        if self.data["COQ1END003HP"] > 72023.4:
            self.data["COQ1END003HP"] = 72023.4
            # REMARK*    Binarias: Creacion */
        if 0 <= self.data["CO02END012CB"] <= 8.536:
            Q3_S28_CO02END012CB_2 = 1
        else:
            Q3_S28_CO02END012CB_2 = 0
        if 0 <= self.data["COQ1END008IN"] <= 6000:
            Q3_S28_COQ1END008IN_2 = 1
        else:
            Q3_S28_COQ1END008IN_2 = 0
        if 3.78 < self.data["CO01END015RO"] <= 7.17:
            Q3_S28_CO01END015RO_4 = 1
        else:
            Q3_S28_CO01END015RO_4 = 0
        if 0 <= self.data["CO01ACP007CT"] <= 0:
            Q3_S28_CO01ACP007CT_2 = 1
        else:
            Q3_S28_CO01ACP007CT_2 = 0
        if 0 <= self.data["CO01END023CC"] <= 0.05:
            Q3_S28_CO01END023CC_2 = 1
        else:
            Q3_S28_CO01END023CC_2 = 0
        if 0 <= self.data["CO02END040RO"] <= 9.63:
            Q3_S28_CO02END040RO_2 = 1
        else:
            Q3_S28_CO02END040RO_2 = 0
        if 0 <= self.data["COQ1NUM001HP"] <= 3:
            Q3_S28_COQ1NUM001HP_2 = 1
        else:
            Q3_S28_COQ1NUM001HP_2 = 0
        if 8000 < self.data["COQ1END003TC"] <= 11010:
            Q3_S28_COQ1END003TC_5 = 1
        else:
            Q3_S28_COQ1END003TC_5 = 0
        if 0 <= self.data["CO01END023RO"] <= 0.27:
            Q3_S28_CO01END023RO_2 = 1
        else:
            Q3_S28_CO01END023RO_2 = 0
        if 27189.3 < self.data["COQ1END010TC"] <= 31675.2:
            Q3_S28_COQ1END010TC_5 = 1
        else:
            Q3_S28_COQ1END010TC_5 = 0
        if 0 <= self.data["CO01EXP001HP"] <= 33:
            Q3_S28_CO01EXP001HP_2 = 1
        else:
            Q3_S28_CO01EXP001HP_2 = 0
        if 0 < self.data["CO01ACP007CT"] <= 1:
            Q3_S28_CO01ACP007CT_3 = 1
        else:
            Q3_S28_CO01ACP007CT_3 = 0
        if 8.916 < self.data["CO01END030RO"] <= 9.11199999999999:
            Q3_S28_CO01END030RO_5 = 1
        else:
            Q3_S28_CO01END030RO_5 = 0
        if 28594.6 < self.data["COQ1END003IN"] <= 30000:
            Q3_S28_COQ1END003IN_4 = 1
        else:
            Q3_S28_COQ1END003IN_4 = 0
        if 59883 < self.data["COQ1END003HP"] <= 72023.4:
            Q3_S28_COQ1END003HP_3 = 1
        else:
            Q3_S28_COQ1END003HP_3 = 0

        Q3_S28_EXPONENTE = (
                1.40575 +
                Q3_S28_COQ1END003HP_3 * 0.37955 +
                Q3_S28_COQ1END003IN_4 * 0.385 +
                Q3_S28_CO01END030RO_5 * 0.31265 +
                Q3_S28_CO01ACP007CT_3 * 0.39974 +
                Q3_S28_CO01EXP001HP_2 * -0.30808 +
                self.data["CO02NUM018TO"] * -0.48205 +
                Q3_S28_COQ1END010TC_5 * 0.36253 +
                Q3_S28_CO01END023RO_2 * -0.11395 +
                Q3_S28_COQ1END003TC_5 * 0.19549 +
                Q3_S28_COQ1NUM001HP_2 * 0.0665 +
                Q3_S28_CO02END040RO_2 * -0.16491 +
                Q3_S28_CO01END023CC_2 * -0.23533 +
                Q3_S28_CO01ACP007CT_2 * 0.16372 +
                Q3_S28_CO01END015RO_4 * 0.17047 +
                Q3_S28_COQ1END008IN_2 * -0.13796 +
                Q3_S28_CO02END012CB_2 * -0.20352)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S28_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card29_daqu3(self):
        """
        Computes Score Card 29
        """
        # TEC. Y NODO=2 Y GRUPO = 2
        self.inicializa_variables()
        self.score_card_daqu3 = 29
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO02EXP001TO", "CO02NUM018TO", "CO01ACP007CT", "CO01END005CC", "CO01END006IN",
                      "CO01END007HP", "CO01END023IN", "CO01END024RO", "CO01END030RO", "CO01END057RO",
                      "CO02END004CB", "CO00DEM006", "COQ1END002HP"]

        # Scpecial Attributes
        # Caracteristicas personalizadas Quanto 3:
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Acotacion
        if self.data["CO02EXP001TO"] > 259:
            self.data["CO02EXP001TO"] = 259

        if self.data["CO02NUM018TO"] > 1:
            self.data["CO02NUM018TO"] = 1

        if self.data["CO01END023IN"] > 0.66:
            self.data["CO01END023IN"] = 0.66

        if self.data["CO01END030RO"] > 4.02:
            self.data["CO01END030RO"] = 4.02

        if self.data["CO01END057RO"] > 10.569:
            self.data["CO01END057RO"] = 10.569

        if self.data["COQ1END002HP"] > 531:
            self.data["COQ1END002HP"] = 531

        if self.data["CO01END005CC"] > 0.21:
            self.data["CO01END005CC"] = 0.21

        if self.data["CO01ACP007CT"] > 1:
            self.data["CO01ACP007CT"] = 1

        if self.data["CO01END006IN"] > 0.64:
            self.data["CO01END006IN"] = 0.64

        if self.data["CO01END007HP"] > 74.3659999999999:
            self.data["CO01END007HP"] = 74.3659999999999

        if self.data["CO01END024RO"] > 6.04:
            self.data["CO01END024RO"] = 6.04

        if self.data["CO02END004CB"] > 69.409:
            self.data["CO02END004CB"] = 69.409

        # binarias: Creacion
        if self.data["CO01ACP007CT"] < 0:
            Q3_S29_CO01ACP007CT_1 = 1
        else:
            Q3_S29_CO01ACP007CT_1 = 0

        if 0 <= self.data["CO01END005CC"] <= 0.04:
            Q3_S29_CO01END005CC_2 = 1
        else:
            Q3_S29_CO01END005CC_2 = 0

        if 0 <= self.data["CO01END006IN"] <= 0.2:
            Q3_S29_CO01END006IN_2 = 1
        else:
            Q3_S29_CO01END006IN_2 = 0

        if 0.2 < self.data["CO01END006IN"] <= 0.45:
            Q3_S29_CO01END006IN_3 = 1

        else:
            Q3_S29_CO01END006IN_3 = 0

        if 0 <= self.data["CO01END007HP"] <= 66.32:
            Q3_S29_CO01END007HP_2 = 1
        else:
            Q3_S29_CO01END007HP_2 = 0

        if 0.59 < self.data["CO01END023IN"] <= 0.66:
            Q3_S29_CO01END023IN_5 = 1
        else:
            Q3_S29_CO01END023IN_5 = 0

        if 0 <= self.data["CO01END024RO"] <= 1.31:
            Q3_S29_CO01END024RO_2 = 1

        else:
            Q3_S29_CO01END024RO_2 = 0

        if 3.82 < self.data["CO01END030RO"] <= 4.02:
            Q3_S29_CO01END030RO_5 = 1
        else:
            Q3_S29_CO01END030RO_5 = 0

        if 8.03 < self.data["CO01END057RO"] <= 10.569:
            Q3_S29_CO01END057RO_5 = 1
        else:
            Q3_S29_CO01END057RO_5 = 0

        if 0 <= self.data["CO02END004CB"] <= 10.03:
            Q3_S29_CO02END004CB_2 = 1
        else:
            Q3_S29_CO02END004CB_2 = 0

        if 512 < self.data["COQ1END002HP"] <= 531:
            Q3_S29_COQ1END002HP_3 = 1
        else:
            Q3_S29_COQ1END002HP_3 = 0

        # Categoricas: Creacion
        if self.data["CO01NUM002CC"] > 0:
            Q3_S29_TELECOM = 1
        else:
            Q3_S29_TELECOM = 0

        if self.data["COQ1END003MC"] == -1:
            Q3_S29_MICROCREDITO = 0
        else:
            Q3_S29_MICROCREDITO = 1

        if Q3_S29_TELECOM == 0 and Q3_S29_MICROCREDITO == 1:
            Q3_S29_NOCC_MIC = 1
        else:
            Q3_S29_NOCC_MIC = 0

        Q3_S29_CO00DEM006_C = 0.0
        if self.data["CO00DEM006"] < 0 or self.data["CO00DEM006"] == 999:
            Q3_S29_CO00DEM006_C = 1.0
        else:
            if self.data["CO00DEM006"] == 1:
                Q3_S29_CO00DEM006_C = 2.0

            else:
                if self.data["CO00DEM006"] == 0:
                    Q3_S29_CO00DEM006_C = 3.0

        Q3_S29_EXPONENTE = (0.84678 +
                            self.data["CO02EXP001TO"] * 0.00037953 +
                            self.data["CO02NUM018TO"] * -0.22156 +
                            Q3_S29_NOCC_MIC * -0.16327 +
                            Q3_S29_CO01ACP007CT_1 * -0.20026 +
                            Q3_S29_CO01END005CC_2 * -0.15529 +
                            Q3_S29_CO01END006IN_2 * -0.18045 +
                            Q3_S29_CO01END006IN_3 * -0.06627 +
                            Q3_S29_CO01END007HP_2 * -0.1552 +
                            Q3_S29_CO01END023IN_5 * 0.13447 +
                            Q3_S29_CO01END024RO_2 * -0.10523 +
                            Q3_S29_CO01END030RO_5 * 0.127 +
                            Q3_S29_CO01END057RO_5 * 0.06731 +
                            Q3_S29_CO02END004CB_2 * -0.12154 +
                            Q3_S29_COQ1END002HP_3 * 0.19682 +
                            Q3_S29_CO00DEM006_C * 0.08611)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S29_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1
        self.cal_salida_pesos_daqu3()

    def score_card30_daqu3(self):
        """
        Computes Score Card 30
        """
        # TEC. Y NODO=2 Y GRUPO = 2
        self.inicializa_variables()
        self.score_card_daqu3 = 30
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO02NUM002TO", "CO02NUM018TO", "CO01ACP007CT", "CO01END005CO", "CO01END006OT",
                      "CO01END006RO", "CO01END008RO", "CO01END013CC", "CO01END036IN", "CO01END038RO",
                      "CO02END042RO", "CO02NUM086MX", "CO00DEM006", "CO00DEM026", "COQ1END003IN",
                      "COQ1END014TC"]

        # Scpecial Attributes
        # Caracteristicas personalizadas Quanto 3:
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Acotacion
        if self.data["CO02NUM002TO"] > 9:
            self.data["CO02NUM002TO"] = 9

        if self.data["CO02NUM018TO"] > 1:
            self.data["CO02NUM018TO"] = 1

        if self.data["CO01ACP007CT"] > 1:
            self.data["CO01ACP007CT"] = 1

        if self.data["CO01END038RO"] > 6.18:
            self.data["CO01END038RO"] = 6.18

        if self.data["COQ1END003IN"] > 20000:
            self.data["COQ1END003IN"] = 20000

        if self.data["CO01END005CO"] > 1.0685:
            self.data["CO01END005CO"] = 1.0685

        if self.data["CO01END006OT"] > 1.15:
            self.data["CO01END006OT"] = 1.15

        if self.data["CO01END006RO"] > 0.69:
            self.data["CO01END006RO"] = 0.69

        if self.data["CO01END008RO"] > 6.18:
            self.data["CO01END008RO"] = 6.18

        if self.data["CO01END013CC"] > 0.17:
            self.data["CO01END013CC"] = 0.17

        if self.data["CO01END036IN"] > 1.75:
            self.data["CO01END036IN"] = 1.75

        if self.data["CO02END042RO"] > 74.4585:
            self.data["CO02END042RO"] = 74.4585

        if self.data["CO02NUM086MX"] > 50:
            self.data["CO02NUM086MX"] = 50

        if self.data["COQ1END014TC"] > 11059.5:
            self.data["COQ1END014TC"] = 11059.5

        # Binarias: Creacion
        if self.data["CO01ACP007CT"] == 999 or self.data["CO01ACP007CT"] < 0:
            Q3_S30_CO01ACP007CT_1 = 1
        else:
            Q3_S30_CO01ACP007CT_1 = 0

        if 0 < self.data["CO01ACP007CT"] <= 1:
            Q3_S30_CO01ACP007CT_3 = 1
        else:
            Q3_S30_CO01ACP007CT_3 = 0

        if 0 <= self.data["CO01END005CO"] <= 0.46:
            Q3_S30_CO01END005CO_2 = 1
        else:
            Q3_S30_CO01END005CO_2 = 0

        if 0 <= self.data["CO01END006OT"] <= 0.4:
            Q3_S30_CO01END006OT_2 = 1
        else:
            Q3_S30_CO01END006OT_2 = 0

        if 0 <= self.data["CO01END006RO"] <= 0.29:
            Q3_S30_CO01END006RO_2 = 1
        else:
            Q3_S30_CO01END006RO_2 = 0

        if 0 <= self.data["CO01END008RO"] <= 1.88:
            Q3_S30_CO01END008RO_2 = 1
        else:
            Q3_S30_CO01END008RO_2 = 0

        if 0 <= self.data["CO01END013CC"] <= 0.04:
            Q3_S30_CO01END013CC_2 = 1
        else:
            Q3_S30_CO01END013CC_2 = 0

        if 0 <= self.data["CO01END036IN"] <= 0.55:
            Q3_S30_CO01END036IN_2 = 1
        else:
            Q3_S30_CO01END036IN_2 = 0

        if 4.91 < self.data["CO01END038RO"] <= 6.18:
            Q3_S30_CO01END038RO_5 = 1
        else:
            Q3_S30_CO01END038RO_5 = 0

        if 0 <= self.data["CO02END042RO"] <= 30.462:
            Q3_S30_CO02END042RO_2 = 1
        else:
            Q3_S30_CO02END042RO_2 = 0

        if self.data["CO02NUM086MX"] == 999 or self.data["CO02NUM086MX"] < 0:
            Q3_S30_CO02NUM086MX_1 = 1
        else:
            Q3_S30_CO02NUM086MX_1 = 0

        if 19890.5 < self.data["COQ1END003IN"] <= 20000:
            Q3_S30_COQ1END003IN_5 = 1
        else:
            Q3_S30_COQ1END003IN_5 = 0

        if 0 <= self.data["COQ1END014TC"] <= 2900:
            Q3_S30_COQ1END014TC_2 = 1
        else:
            Q3_S30_COQ1END014TC_2 = 0

        # Categoricas: Creacion
        Q3_MAXIMO_CUPO_TOT = self.calcula_maximo_cupo_tot()
        if Q3_MAXIMO_CUPO_TOT == self.data["COQ1END003MC"]:
            Q3_S30_MAX_CUPOMC = 1
        else:
            Q3_S30_MAX_CUPOMC = 0

        Q3_S30_CO00DEM006_C = 0.0
        if self.data["CO00DEM006"] < 0 or self.data["CO00DEM006"] == 999:
            Q3_S30_CO00DEM006_C = 1.0
        else:
            if self.data["CO00DEM006"] == 1:
                Q3_S30_CO00DEM006_C = 2.0
            else:
                if self.data["CO00DEM006"] == 0:
                    Q3_S30_CO00DEM006_C = 3.0

        Q3_S30_CO00DEM026_C = 0.0
        if self.data["CO00DEM026"] < 0 or self.data["CO00DEM026"] == 999:
            Q3_S30_CO00DEM026_C = 1.0
        else:
            if self.data["CO00DEM026"] in (0, 1):
                Q3_S30_CO00DEM026_C = 2.0
            else:
                if self.data["CO00DEM026"] == 2:
                    Q3_S30_CO00DEM026_C = 3.0
                else:
                    if self.data["CO00DEM026"] == 3:
                        Q3_S30_CO00DEM026_C = 4.0
                    else:
                        if self.data["CO00DEM026"] in (4, 5, 6):
                            Q3_S30_CO00DEM026_C = 5.0

        Q3_S30_EXPONENTE = (0.87421 +
                            self.data["CO02NUM002TO"] * 0.02197 +
                            self.data["CO02NUM018TO"] * -0.34633 +
                            Q3_S30_MAX_CUPOMC * -0.19369 +
                            Q3_S30_CO01ACP007CT_1 * -0.13983 +
                            Q3_S30_CO01ACP007CT_3 * 0.18801 +
                            Q3_S30_CO01END005CO_2 * -0.18915 +
                            Q3_S30_CO01END006OT_2 * -0.15808 +
                            Q3_S30_CO01END006RO_2 * -0.10178 +
                            Q3_S30_CO01END008RO_2 * -0.06647 +
                            Q3_S30_CO01END013CC_2 * -0.22782 +
                            Q3_S30_CO01END036IN_2 * -0.12242 +
                            Q3_S30_CO01END038RO_5 * 0.1188 +
                            Q3_S30_CO02END042RO_2 * -0.10779 +
                            Q3_S30_CO02NUM086MX_1 * 0.14855 +
                            Q3_S30_COQ1END003IN_5 * 0.2821 +
                            Q3_S30_COQ1END014TC_2 * -0.10761 +
                            Q3_S30_CO00DEM006_C * 0.1164 +
                            Q3_S30_CO00DEM026_C * 0.04221)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S30_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0
        self.cal_salida_pesos_daqu3()

    def score_card31_daqu3(self):
        """
        Computes Score Card 31
        """
        self.inicializa_variables()
        self.score_card_daqu3 = 31
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO00DEM006", "CO01END005CO", "CO01END007RO", "CO01END007VE", "CO01END013RO",
                      "CO01END015RO", "CO01END018CC", "CO01END028RO", "CO01END030RO", "CO01END045IN",
                      "CO01END055IN", "CO01MOR001OT", "CO01NUM002CT", "CO01NUM005HP", "CO02END037RO"]

        # Scpecial Attributes
        # Caracteristicas personalizadas Quanto 3:
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Caracteristicas hibridas:
        Q3_CAST = self.calcula_cast_scodaqu3()
        if Q3_CAST == 999:
            Q3_CAST = -1.0

        # Acotacion
        if Q3_CAST > 2:
            Q3_CAST = 2

        if self.data["CO01END007RO"] > 95.258:
            self.data["CO01END007RO"] = 95.258

        if self.data["CO01END007VE"] > 45.8119999999999:
            self.data["CO01END007VE"] = 45.8119999999999

        if self.data["CO01END015RO"] > 14.506:
            self.data["CO01END015RO"] = 14.506

        if self.data["CO01END055IN"] > 3.4:
            self.data["CO01END055IN"] = 3.4

        if self.data["CO01NUM002CT"] > 2:
            self.data["CO01NUM002CT"] = 2

        if self.data["CO01NUM005HP"] > 1:
            self.data["CO01NUM005HP"] = 1

        if self.data["COQ1END008IN"] > 40286:
            self.data["COQ1END008IN"] = 40286

        if self.data["COQ1END002IN"] > 1573:
            self.data["COQ1END002IN"] = 1573

        # Binarias: Creacion
        if 0 <= self.data["CO01END005CO"] <= 0.69:
            Q3_S31_CO01END005CO_2 = 1
        else:
            Q3_S31_CO01END005CO_2 = 0

        if 4.572 < self.data["CO01END007RO"] <= 54.064:
            Q3_S31_CO01END007RO_3 = 1
        else:
            Q3_S31_CO01END007RO_3 = 0

        if 54.064 < self.data["CO01END007RO"] <= 79.05:
            Q3_S31_CO01END007RO_4 = 1
        else:
            Q3_S31_CO01END007RO_4 = 0

        if 79.05 < self.data["CO01END007RO"] <= 95.258:
            Q3_S31_CO01END007RO_5 = 1
        else:
            Q3_S31_CO01END007RO_5 = 0

        if 35.29 < self.data["CO01END007VE"] <= 45.8119999999999:
            Q3_S31_CO01END007VE_3 = 1
        else:
            Q3_S31_CO01END007VE_3 = 0

        if 0 <= self.data["CO01END013RO"] <= 0.26:
            Q3_S31_CO01END013RO_2 = 1
        else:
            Q3_S31_CO01END013RO_2 = 0

        if 9.1 < self.data["CO01END015RO"] <= 14.506:
            Q3_S31_CO01END015RO_5 = 1
        else:
            Q3_S31_CO01END015RO_5 = 0

        if 0 <= self.data["CO01END018CC"] <= 0.04:
            Q3_S31_CO01END018CC_2 = 1
        else:
            Q3_S31_CO01END018CC_2 = 0

        if 0.53 < self.data["CO01END028RO"] <= 0.98:
            Q3_S31_CO01END028RO_4 = 1
        else:
            Q3_S31_CO01END028RO_4 = 0

        if 0 <= self.data["CO01END030RO"] <= 1.05:
            Q3_S31_CO01END030RO_2 = 1
        else:
            Q3_S31_CO01END030RO_2 = 0

        if 0 <= self.data["CO01END045IN"] <= 1.53:
            Q3_S31_CO01END045IN_2 = 1
        else:
            Q3_S31_CO01END045IN_2 = 0

        if 2.3 < self.data["CO01END055IN"] <= 3.4:
            Q3_S31_CO01END055IN_5 = 1
        else:
            Q3_S31_CO01END055IN_5 = 0

        if 0 <= self.data["CO01MOR001OT"] <= 0:
            Q3_S31_CO01MOR001OT_2 = 1
        else:
            Q3_S31_CO01MOR001OT_2 = 0

        if 0 <= self.data["CO01NUM002CT"] <= 0:
            Q3_S31_CO01NUM002CT_2 = 1
        else:
            Q3_S31_CO01NUM002CT_2 = 0

        if 0 < self.data["CO01NUM002CT"] <= 1:
            Q3_S31_CO01NUM002CT_3 = 1
        else:
            Q3_S31_CO01NUM002CT_3 = 0

        if 1 < self.data["CO01NUM002CT"] <= 2:
            Q3_S31_CO01NUM002CT_4 = 1
        else:
            Q3_S31_CO01NUM002CT_4 = 0

        if 0 < self.data["CO01NUM005HP"] <= 1:
            Q3_S31_CO01NUM005HP_3 = 1
        else:
            Q3_S31_CO01NUM005HP_3 = 0

        if 0 <= self.data["CO02END037RO"] <= 0:
            Q3_S31_CO02END037RO_2 = 1
        else:
            Q3_S31_CO02END037RO_2 = 0

        if 0 <= self.data["COQ1END002IN"] <= 367.1:
            Q3_S31_COQ1END002IN_2 = 1
        else:
            Q3_S31_COQ1END002IN_2 = 0

        if 18386.7 < self.data["COQ1END008IN"] <= 39695.83333355:
            Q3_S31_COQ1END008IN_4 = 1
        else:
            Q3_S31_COQ1END008IN_4 = 0

        if 39695.83333355 < self.data["COQ1END008IN"] <= 40286:
            Q3_S31_COQ1END008IN_5 = 1
        else:
            Q3_S31_COQ1END008IN_5 = 0

        # Categoricas: Creacion
        Q3_MAXIMO_CUPO_TOT = self.calcula_maximo_cupo_tot()

        if Q3_MAXIMO_CUPO_TOT < 0:
            Q3_MAXIMO_CUPO_TOT = -2

        Q3_S31_CO00DEM006_C = 0.0
        if self.data["CO00DEM006"] < 0 or self.data["CO00DEM006"] == 999:
            Q3_S31_CO00DEM006_C = 1.0
        else:
            if self.data["CO00DEM006"] == 1:
                Q3_S31_CO00DEM006_C = 2.0
            else:
                if self.data["CO00DEM006"] == 0:
                    Q3_S31_CO00DEM006_C = 3.0

        if self.data["COQ1END003MC"] == -1:
            Q3_S31_MICROCREDITO = 0
        else:
            Q3_S31_MICROCREDITO = 1

        if 25872 <= Q3_MAXIMO_CUPO_TOT <= 634000:
            Q3_S31_CUPOALTO = 1
        else:
            Q3_S31_CUPOALTO = 0

        Q3_S31_EXPONENTE = (1.33883 +
                            Q3_S31_CO00DEM006_C * 0.0793 +
                            Q3_CAST * -0.12011 +
                            Q3_S31_MICROCREDITO * -0.19423 +
                            Q3_S31_CUPOALTO * 0.07042 +
                            Q3_S31_CO01END005CO_2 * -0.23321 +
                            Q3_S31_CO01END007RO_3 * 0.10002 +
                            Q3_S31_CO01END007RO_4 * 0.29018 +
                            Q3_S31_CO01END007RO_5 * 0.33839 +
                            Q3_S31_CO01END007VE_3 * 0.30233 +
                            Q3_S31_CO01END013RO_2 * -0.10887 +
                            Q3_S31_CO01END015RO_5 * 0.19455 +
                            Q3_S31_CO01END018CC_2 * -0.25395 +
                            Q3_S31_CO01END028RO_4 * 0.11187 +
                            Q3_S31_CO01END030RO_2 * -0.09827 +
                            Q3_S31_CO01END045IN_2 * -0.07329 +
                            Q3_S31_CO01END055IN_5 * 0.11469 +
                            Q3_S31_CO01MOR001OT_2 * -0.37769 +
                            Q3_S31_CO01NUM002CT_2 * 0.1658 +
                            Q3_S31_CO01NUM002CT_3 * 0.27867 +
                            Q3_S31_CO01NUM002CT_4 * 0.3948 +
                            Q3_S31_CO01NUM005HP_3 * 0.07341 +
                            Q3_S31_CO02END037RO_2 * -0.23303 +
                            Q3_S31_COQ1END002IN_2 * -0.15684 +
                            Q3_S31_COQ1END008IN_4 * 0.21394 +
                            Q3_S31_COQ1END008IN_5 * 0.42656)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S31_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1

        self.cal_salida_pesos_daqu3()

    def score_card32_daqu3(self):
        """
        Computes Score Card 32
        """
        self.inicializa_variables()
        self.score_card_daqu3 = 32
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO01END066IN", "CO01END090HP", "CO01END013CC", "CO01END036CO", "CO01END005IN",
                      "CO01EXP001HP", "CO01END007HP", "CO02NUM043CB", "CO02NUM019TO", "CO02NUM018TO",
                      "CO02EXP001TO", "CO01NUM001RO", "CO01END066HP", "COQ1END014TC", "COQ1END002IN",
                      "COQ1END002HP"]

        # Scpecial Attributes
        # Caracteristicas personalizadas Quanto 3:
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Caracteristicas hibridas:
        Q3_CAST_RO = self.calcula_cast_ro()
        if Q3_CAST_RO == 999:
            Q3_CAST_RO = -1.0

        # Acotacion
        if self.data["COQ1END002IN"] > 650.199999999999:
            self.data["COQ1END002IN"] = 650.199999999999

        if self.data["CO01END066HP"] > 0.85:
            self.data["CO01END066HP"] = 0.85

        if self.data["COQ1END014TC"] > 12080.8:
            self.data["COQ1END014TC"] = 12080.8

        if self.data["CO01END066IN"] > 0.93:
            self.data["CO01END066IN"] = 0.93

        if self.data["CO01END090HP"] > 1.91:
            self.data["CO01END090HP"] = 1.91

        if self.data["CO01END013CC"] > 0.18:
            self.data["CO01END013CC"] = 0.18

        if self.data["CO01END036CO"] > 0.63:
            self.data["CO01END036CO"] = 0.63

        if self.data["CO01END005IN"] > 1.51:
            self.data["CO01END005IN"] = 1.51

        if self.data["CO01EXP001HP"] > 151:
            self.data["CO01EXP001HP"] = 151

        if self.data["COQ1END002HP"] > 584.199999999999:
            self.data["COQ1END002HP"] = 584.199999999999

        if self.data["CO01END007HP"] > 81.17:
            self.data["CO01END007HP"] = 81.17

        if self.data["CO02NUM043CB"] > 79.17:
            self.data["CO02NUM043CB"] = 79.17

        if self.data["CO02NUM019TO"] > 1:
            self.data["CO02NUM019TO"] = 1

        if self.data["CO02NUM018TO"] > 1:
            self.data["CO02NUM018TO"] = 1

        if self.data["CO02EXP001TO"] > 282:
            self.data["CO02EXP001TO"] = 282

        if self.data["CO01NUM001RO"] > 9:
            self.data["CO01NUM001RO"] = 9

        if Q3_CAST_RO > 1:
            Q3_CAST_RO = 1

        # Binarias: Creacion
        if 519 < self.data["COQ1END002IN"] <= 650.199999999999:
            Q3_S32_COQ1END002IN_4 = 1
        else:
            Q3_S32_COQ1END002IN_4 = 0

        if 0.74 < self.data["CO01END066HP"] <= 0.85:
            Q3_S32_CO01END066HP_3 = 1
        else:
            Q3_S32_CO01END066HP_3 = 0

        if 0 <= self.data["COQ1END014TC"] <= 1300:
            Q3_S32_COQ1END014TC_2 = 1
        else:
            Q3_S32_COQ1END014TC_2 = 0

        if 0.58 < self.data["CO01END066IN"] <= 0.93:
            Q3_S32_CO01END066IN_4 = 1
        else:
            Q3_S32_CO01END066IN_4 = 0

        if 1.537 < self.data["CO01END090HP"] <= 1.91:
            Q3_S32_CO01END090HP_3 = 1
        else:
            Q3_S32_CO01END090HP_3 = 0

        if 0 <= self.data["CO01END013CC"] <= 0.05:
            Q3_S32_CO01END013CC_2 = 1
        else:
            Q3_S32_CO01END013CC_2 = 0

        if 0 <= self.data["CO01END036CO"] <= 0.59:
            Q3_S32_CO01END036CO_2 = 1
        else:
            Q3_S32_CO01END036CO_2 = 0

        if self.data["CO01END005IN"] < 0:
            Q3_S32_CO01END005IN_1 = 1
        else:
            Q3_S32_CO01END005IN_1 = 0

        if 77 < self.data["CO01EXP001HP"] <= 151:
            Q3_S32_CO01EXP001HP_4 = 1
        else:
            Q3_S32_CO01EXP001HP_4 = 0

        if 0 <= self.data["COQ1END002HP"] <= 339:
            Q3_S32_COQ1END002HP_2 = 1
        else:
            Q3_S32_COQ1END002HP_2 = 0

        if 0 <= self.data["CO01END007HP"] <= 79.41:
            Q3_S32_CO01END007HP_2 = 1
        else:
            Q3_S32_CO01END007HP_2 = 0

        # Cateristicas: Creacion
        if self.data["CO00DEM026"] in (4, 5, 6):
            Q3_S32_ESTRATO456 = 1
        else:
            Q3_S32_ESTRATO456 = 0

        Q3_SUMA_CUOTA_TOT = self.calcula_suma_cuota_tot()
        Q3_S32_SUMACUOTA_TOT = 0.0
        if 0 <= Q3_SUMA_CUOTA_TOT <= 265:
            Q3_S32_SUMACUOTA_TOT = 1.0

        if 265 < Q3_SUMA_CUOTA_TOT <= 466:
            Q3_S32_SUMACUOTA_TOT = 2.0

        if 466 < Q3_SUMA_CUOTA_TOT <= 763:
            Q3_S32_SUMACUOTA_TOT = 3.0

        if Q3_SUMA_CUOTA_TOT > 763:
            Q3_S32_SUMACUOTA_TOT = 4.0

        if Q3_SUMA_CUOTA_TOT < 0:
            Q3_S32_SUMACUOTA_TOT = 0.0

        Q3_S32_EXPONENTE = (1.04144 +
                            Q3_S32_SUMACUOTA_TOT * 0.02072 +
                            Q3_CAST_RO * -0.1825 +
                            Q3_S32_ESTRATO456 * 0.11108 +
                            self.data["CO01NUM001RO"] * 0.0246 +
                            self.data["CO02EXP001TO"] * 0.00069811 +
                            self.data["CO02NUM018TO"] * -0.27935 +
                            self.data["CO02NUM019TO"] * 0.13907 +
                            self.data["CO02NUM043CB"] * -0.00178 +
                            Q3_S32_CO01END007HP_2 * -0.30905 +
                            Q3_S32_COQ1END002HP_2 * -0.24968 +
                            Q3_S32_CO01EXP001HP_4 * 0.1134 +
                            Q3_S32_CO01END005IN_1 * 0.16714 +
                            Q3_S32_CO01END036CO_2 * -0.19178 +
                            Q3_S32_CO01END013CC_2 * -0.26027 +
                            Q3_S32_CO01END090HP_3 * 0.18434 +
                            Q3_S32_CO01END066IN_4 * 0.19696 +
                            Q3_S32_COQ1END014TC_2 * -0.11498 +
                            Q3_S32_CO01END066HP_3 * 0.09884 +
                            Q3_S32_COQ1END002IN_4 * 0.16702)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S32_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card33_daqu3(self):
        """
        Computes Score Card 33
        """
        # TEC. Y NODO=3 Y GRUPO = 2
        self.inicializa_variables()
        self.score_card_daqu3 = 33
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO02EXP001TO", "CO02NUM002TO", "CO02NUM018TO", "CO01END008RO", "CO01END018VE",
                      "CO01END018CC", "CO01END025RO", "CO01END045VE", "CO01END006CC", "CO02END002IN",
                      "CO01END092RO", "CO01NUM002CT", "CO01END075RO", "CO01END035VE", "COQ1END003IN"]

        # Scpecial Attributes
        # Caracteristicas personalizadas Quanto 3:
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Acotacion
        if self.data["CO01END035VE"] > 1.26:
            self.data["CO01END035VE"] = 1.26

        if self.data["CO01END075RO"] > 100:
            self.data["CO01END075RO"] = 100

        if self.data["CO01NUM002CT"] > 2:
            self.data["CO01NUM002CT"] = 2

        if self.data["CO01END092RO"] > 120.524:
            self.data["CO01END092RO"] = 120.524

        if self.data["CO02END002IN"] > 37.916:
            self.data["CO02END002IN"] = 37.916

        if self.data["CO01END008RO"] > 19.856:
            self.data["CO01END008RO"] = 19.856

        if self.data["CO01END006CC"] > 0.21:
            self.data["CO01END006CC"] = 0.21

        if self.data["CO01END045VE"] > 1.18:
            self.data["CO01END045VE"] = 1.18

        if self.data["CO01END025RO"] > 12.44:
            self.data["CO01END025RO"] = 12.44

        if self.data["CO01END018CC"] > 0.21:
            self.data["CO01END018CC"] = 0.21

        if self.data["COQ1END003IN"] > 35000:
            self.data["COQ1END003IN"] = 35000

        if self.data["CO01END018VE"] > 1.24:
            self.data["CO01END018VE"] = 1.24

        if self.data["CO01NUM002CT"] > 2:
            self.data["CO01NUM002CT"] = 2

        if self.data["CO01END008RO"] > 19.856:
            self.data["CO01END008RO"] = 19.856

        if self.data["CO02NUM018TO"] > 1:
            self.data["CO02NUM018TO"] = 1

        if self.data["CO02NUM002TO"] > 16:
            self.data["CO02NUM002TO"] = 16

        if self.data["CO02EXP001TO"] > 312.0225:
            self.data["CO02EXP001TO"] = 312.0225

        # Binarias: Creacion
        if 0 <= self.data["CO01END075RO"] <= 12.4:
            Q3_S33_CO01END075RO_2 = 1
        else:
            Q3_S33_CO01END075RO_2 = 0

        if self.data["CO01END035VE"] < 0:
            Q3_S33_CO01END035VE_1 = 1
        else:
            Q3_S33_CO01END035VE_1 = 0

        if 0 < self.data["CO01NUM002CT"] <= 1:
            Q3_S33_CO01NUM002CT_3 = 1
        else:
            Q3_S33_CO01NUM002CT_3 = 0

        if 0 <= self.data["CO01END092RO"] <= 6.41:
            Q3_S33_CO01END092RO_2 = 1
        else:
            Q3_S33_CO01END092RO_2 = 0

        if 0 <= self.data["CO02END002IN"] <= 3.619:
            Q3_S33_CO02END002IN_2 = 1
        else:
            Q3_S33_CO02END002IN_2 = 0

        if 2.69 < self.data["CO01END008RO"] <= 6.91:
            Q3_S33_CO01END008RO_3 = 1
        else:
            Q3_S33_CO01END008RO_3 = 0

        if 0.2 < self.data["CO01END006CC"] <= 0.21:
            Q3_S33_CO01END006CC_5 = 1
        else:
            Q3_S33_CO01END006CC_5 = 0

        if 1.08 < self.data["CO01END045VE"] <= 1.18:
            Q3_S33_CO01END045VE_3 = 1
        else:
            Q3_S33_CO01END045VE_3 = 0

        if 8.58 < self.data["CO01END025RO"] <= 12.44:
            Q3_S33_CO01END025RO_5 = 1
        else:
            Q3_S33_CO01END025RO_5 = 0

        if 0 <= self.data["CO01END018CC"] <= 0.03:
            Q3_S33_CO01END018CC_2 = 1
        else:
            Q3_S33_CO01END018CC_2 = 0

        if 17080 < self.data["COQ1END003IN"] <= 33327.4:
            Q3_S33_COQ1END003IN_4 = 1
        else:
            Q3_S33_COQ1END003IN_4 = 0

        if 0 <= self.data["CO01END018VE"] <= 0.7:
            Q3_S33_CO01END018VE_2 = 1
        else:
            Q3_S33_CO01END018VE_2 = 0

        if 1 < self.data["CO01NUM002CT"] <= 2:
            Q3_S33_CO01NUM002CT_4 = 1
        else:
            Q3_S33_CO01NUM002CT_4 = 0

        if 0 <= self.data["CO01END008RO"] <= 2.69:
            Q3_S33_CO01END008RO_2 = 1
        else:
            Q3_S33_CO01END008RO_2 = 0

        if self.data["CO01END008RO"] < 0:
            Q3_S33_CO01END008RO_1 = 1
        else:
            Q3_S33_CO01END008RO_1 = 0

        if 33327.4 < self.data["COQ1END003IN"] <= 35000:
            Q3_S33_COQ1END003IN_5 = 1
        else:
            Q3_S33_COQ1END003IN_5 = 0

        Q3_S33_EXPONENTE = (1.68968 +
                            self.data["CO02EXP001TO"] * 0.0001405 +
                            self.data["CO02NUM002TO"] * 0.0015 +
                            self.data["CO02NUM018TO"] * -0.50002 +
                            Q3_S33_COQ1END003IN_5 * 0.41912 +
                            Q3_S33_CO01END008RO_2 * -0.23706 +
                            Q3_S33_CO01END008RO_1 * -0.06037 +
                            Q3_S33_CO01NUM002CT_4 * 0.34512 +
                            Q3_S33_CO01END018VE_2 * -0.17342 +
                            Q3_S33_COQ1END003IN_4 * 0.18499 +
                            Q3_S33_CO01END018CC_2 * -0.20575 +
                            Q3_S33_CO01END025RO_5 * 0.14241 +
                            Q3_S33_CO01END045VE_3 * 0.15267 +
                            Q3_S33_CO01END006CC_5 * 0.12324 +
                            Q3_S33_CO01END008RO_3 * -0.11298 +
                            Q3_S33_CO02END002IN_2 * -0.14978 +
                            Q3_S33_CO01END092RO_2 * -0.09919 +
                            Q3_S33_CO01NUM002CT_3 * 0.22034 +
                            Q3_S33_CO01END075RO_2 * 0.07826 +
                            Q3_S33_CO01END035VE_1 * -0.06758)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S33_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card34_daqu3(self):
        """
        Computes Score Card 34
        """
        self.inicializa_variables()
        self.score_card_daqu3 = 34
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO01END035VE", "CO01END007VE", "CO01END046CO", "CO01END018HP", "CO01END025RO",
                      "CO01END031IN", "CO01END013CC", "CO01END037RO", "CO01END023VE", "CO01END007IN",
                      "CO01NUM001CT", "CO02NUM003TO", "COQ1END014TC", "COQ1END003IN", "COQ1END002IN",
                      "COQ1END001TO"]

        # Scpecial Attributes
        # Caracteristicas personalizadas Quanto 3:
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Acotacion

        if self.data["CO01END035VE"] > 2.64:
            self.data["CO01END035VE"] = 2.64

        if self.data["CO01END007VE"] > 97.09:
            self.data["CO01END007VE"] = 97.09

        if self.data["COQ1END014TC"] > 102600:
            self.data["COQ1END014TC"] = 102600

        if self.data["CO01END046CO"] > 1.182:
            self.data["CO01END046CO"] = 1.182

        if self.data["CO01END018HP"] > 1.482:
            self.data["CO01END018HP"] = 1.482

        if self.data["CO01END025RO"] > 18.258:
            self.data["CO01END025RO"] = 18.258

        if self.data["CO01END031IN"] > 198.058:
            self.data["CO01END031IN"] = 198.058

        if self.data["COQ1END002IN"] > 3247.69999999999:
            self.data["COQ1END002IN"] = 3247.69999999999

        if self.data["CO01END013CC"] > 0.24:
            self.data["CO01END013CC"] = 0.24

        if self.data["COQ1END003IN"] > 90000:
            self.data["COQ1END003IN"] = 90000

        if self.data["CO01END037RO"] > 158.942:
            self.data["CO01END037RO"] = 158.942

        if self.data["CO01END023VE"] > 2.51:
            self.data["CO01END023VE"] = 2.51

        if self.data["COQ1END001TO"] > 40007.688:
            self.data["COQ1END001TO"] = 40007.688

        if self.data["CO01END007IN"] > 278.058:
            self.data["CO01END007IN"] = 278.058

        if self.data["CO01NUM001CT"] > 6:
            self.data["CO01NUM001CT"] = 6

        if self.data["CO02NUM003TO"] > 20:
            self.data["CO02NUM003TO"] = 20

        # Binarias: Creacion
        if 1 < self.data["CO01END035VE"] <= 1.9165:
            Q3_S34_CO01END035VE_3 = 1
        else:
            Q3_S34_CO01END035VE_3 = 0

        if 73.412 < self.data["CO01END007VE"] <= 97.09:
            Q3_S34_CO01END007VE_5 = 1
        else:
            Q3_S34_CO01END007VE_5 = 0

        if 0 <= self.data["COQ1END014TC"] <= 3000:
            Q3_S34_COQ1END014TC_2 = 1
        else:
            Q3_S34_COQ1END014TC_2 = 0

        if 0 <= self.data["CO01END046CO"] <= 1.17:
            Q3_S34_CO01END046CO_2 = 1
        else:
            Q3_S34_CO01END046CO_2 = 0

        if 0 <= self.data["CO01END018HP"] <= 1.48:
            Q3_S34_CO01END018HP_2 = 1
        else:
            Q3_S34_CO01END018HP_2 = 0

        if 10.8805 < self.data["CO01END025RO"] <= 18.258:
            Q3_S34_CO01END025RO_5 = 1
        else:
            Q3_S34_CO01END025RO_5 = 0

        if 166.044 < self.data["CO01END031IN"] <= 198.058:
            Q3_S34_CO01END031IN_5 = 1
        else:
            Q3_S34_CO01END031IN_5 = 0

        if 0 <= self.data["COQ1END002IN"] <= 338:
            Q3_S34_COQ1END002IN_2 = 1
        else:
            Q3_S34_COQ1END002IN_2 = 0

        if 56000 < self.data["COQ1END014TC"] <= 102600:
            Q3_S34_COQ1END014TC_5 = 1
        else:
            Q3_S34_COQ1END014TC_5 = 0

        if 0 <= self.data["CO01END013CC"] <= 0.03:
            Q3_S34_CO01END013CC_2 = 1
        else:
            Q3_S34_CO01END013CC_2 = 0

        if 36920 < self.data["COQ1END003IN"] <= 61133.2:
            Q3_S34_COQ1END003IN_4 = 1
        else:
            Q3_S34_COQ1END003IN_4 = 0

        if 122.398 < self.data["CO01END037RO"] <= 158.942:
            Q3_S34_CO01END037RO_5 = 1
        else:
            Q3_S34_CO01END037RO_5 = 0

        if 61133.2 < self.data["COQ1END003IN"] <= 90000:
            Q3_S34_COQ1END003IN_5 = 1
        else:
            Q3_S34_COQ1END003IN_5 = 0

        if 1.84 < self.data["CO01END023VE"] <= 2.51:
            Q3_S34_CO01END023VE_4 = 1
        else:
            Q3_S34_CO01END023VE_4 = 0

        if self.data["COQ1END001TO"] < 0:
            Q3_S34_COQ1END001TO_1 = 1
        else:
            Q3_S34_COQ1END001TO_1 = 0

        if 130.535 < self.data["CO01END007IN"] <= 181.2615:
            Q3_S34_CO01END007IN_4 = 1
        else:
            Q3_S34_CO01END007IN_4 = 0

        if self.data["CO01NUM001CT"] < 0:
            Q3_S34_CO01NUM001CT_1 = 1
        else:
            Q3_S34_CO01NUM001CT_1 = 0

        if 181.2615 < self.data["CO01END007IN"] <= 278.058:
            Q3_S34_CO01END007IN_5 = 1
        else:
            Q3_S34_CO01END007IN_5 = 0

        # Categoricas: Creacion
        if self.data["CO00DEM026"] in (4, 5, 6):
            Q3_S34_ESTRATO456 = 1
        else:
            Q3_S34_ESTRATO456 = 0

        Q3_MAXIMO_CUPO_TOT = self.calcula_maximo_cupo_tot()

        Q3_S34_MAXCUPO_TOT = 0.0

        if Q3_MAXIMO_CUPO_TOT < 0:
            Q3_MAXIMO_CUPO_TOT = -2

        if 0 <= Q3_MAXIMO_CUPO_TOT <= 10300:
            Q3_S34_MAXCUPO_TOT = 1

        if 10300 < Q3_MAXIMO_CUPO_TOT <= 26000:
            Q3_S34_MAXCUPO_TOT = 2

        if 26000 < Q3_MAXIMO_CUPO_TOT <= 50000:
            Q3_S34_MAXCUPO_TOT = 3

        if Q3_MAXIMO_CUPO_TOT > 50000:
            Q3_S34_MAXCUPO_TOT = 4

        if Q3_MAXIMO_CUPO_TOT == self.data["COQ1END003MC"]:
            Q3_S34_MAXCUPO_MC = 1
        else:
            Q3_S34_MAXCUPO_MC = 0

        Q3_S34_EXPONENTE = (1.99044 +
                            Q3_S34_MAXCUPO_TOT * 0.07419 +
                            Q3_S34_MAXCUPO_MC * -0.53571 +
                            Q3_S34_ESTRATO456 * 0.09665 +
                            self.data["CO02NUM003TO"] * 0.00817 +
                            Q3_S34_CO01END007IN_5 * 0.29888 +
                            Q3_S34_CO01NUM001CT_1 * -0.22369 +
                            Q3_S34_CO01END007IN_4 * 0.19398 +
                            Q3_S34_COQ1END001TO_1 * 0.3495 +
                            Q3_S34_CO01END023VE_4 * 0.23414 +
                            Q3_S34_COQ1END003IN_5 * 0.16229 +
                            Q3_S34_CO01END037RO_5 * 0.21957 +
                            Q3_S34_COQ1END003IN_4 * 0.21014 +
                            Q3_S34_CO01END013CC_2 * -0.38717 +
                            Q3_S34_COQ1END014TC_5 * 0.1698 +
                            Q3_S34_COQ1END002IN_2 * -0.23802 +
                            Q3_S34_CO01END031IN_5 * 0.17024 +
                            Q3_S34_CO01END025RO_5 * 0.21153 +
                            Q3_S34_CO01END018HP_2 * -0.21214 +
                            Q3_S34_CO01END046CO_2 * -0.13953 +
                            Q3_S34_COQ1END014TC_2 * -0.1359 +
                            Q3_S34_CO01END007VE_5 * 0.14447 +
                            Q3_S34_CO01END035VE_3 * 0.11021)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S34_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1
        self.cal_salida_pesos_daqu3()

    def score_card35_daqu3(self):
        """
        Computes Score Card 35
        """
        # TEC NODO=4 Y GRUPO = 1
        self.inicializa_variables()
        self.score_card_daqu3 = 35
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO02NUM002TO", "CO01NUM001CT", "CO01END036HP", "CO01END023CO", "CO01END006IN",
                      "CO02END007HP", "CO02END010HP", "CO01END018VE", "CO01END007HP", "CO01END013CC",
                      "CO01END005CC", "CO01END008RO", "COQ1END003TC", "COQ1EXP003HP", "COQ1END008IN",
                      "COQ1END002MC", "COQ1END001TO", "COQ1END003HP"]

        # Scpecial Attributes
        # Caracteristicas personalizadas Quanto 3:
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Acotacion
        if self.data["CO01END008RO"] > 9.71:
            self.data["CO01END008RO"] = 9.71

        if self.data["COQ1END003TC"] > 6000:
            self.data["COQ1END003TC"] = 6000

        if self.data["CO01END013CC"] > 0.19:
            self.data["CO01END013CC"] = 0.19

        if self.data["CO01END005CC"] > 0.27:
            self.data["CO01END005CC"] = 0.27

        if self.data["CO01END013CC"] > 0.19:
            self.data["CO01END013CC"] = 0.19

        if self.data["COQ1END002MC"] > 227:
            self.data["COQ1END002MC"] = 227

        if self.data["CO01END007HP"] > 116.921:
            self.data["CO01END007HP"] = 116.921

        if self.data["CO01END018VE"] > 0.85:
            self.data["CO01END018VE"] = 0.85

        if self.data["COQ1EXP003HP"] > 181:
            self.data["COQ1EXP003HP"] = 181

        if self.data["CO02END010HP"] > 2.00549999999999:
            self.data["CO02END010HP"] = 2.00549999999999

        if self.data["CO02END007HP"] > 2.09:
            self.data["CO02END007HP"] = 2.09

        if self.data["CO01END006IN"] > 1.19549999999999:
            self.data["CO01END006IN"] = 1.19549999999999

        if self.data["CO01END023CO"] > 1.59:
            self.data["CO01END023CO"] = 1.59

        if self.data["CO01END036HP"] > 1.38:
            self.data["CO01END036HP"] = 1.38

        if self.data["COQ1END001TO"] > 4026.66:
            self.data["COQ1END001TO"] = 4026.66

        if self.data["COQ1END003HP"] > 60000:
            self.data["COQ1END003HP"] = 60000

        if self.data["COQ1END008IN"] > 22000:
            self.data["COQ1END008IN"] = 22000

        if self.data["CO01NUM001CT"] > 3:
            self.data["CO01NUM001CT"] = 3

        if self.data["CO02NUM002TO"] > 14:
            self.data["CO02NUM002TO"] = 14

        # binarias: Creacion
        if 0 <= self.data["CO01END008RO"] <= 1.609:
            Q3_S35_CO01END008RO_2 = 1
        else:
            Q3_S35_CO01END008RO_2 = 0

        if 4779.50000000001 < self.data["COQ1END003TC"] <= 6000:
            Q3_S35_COQ1END003TC_5 = 1
        else:
            Q3_S35_COQ1END003TC_5 = 0

        if 0.13 < self.data["CO01END013CC"] <= 0.19:
            Q3_S35_CO01END013CC_5 = 1
        else:
            Q3_S35_CO01END013CC_5 = 0

        if 0 <= self.data["CO01END005CC"] <= 0.05:
            Q3_S35_CO01END005CC_2 = 1
        else:
            Q3_S35_CO01END005CC_2 = 0

        if self.data["CO01END013CC"] < 0:
            Q3_S35_CO01END013CC_1 = 1
        else:
            Q3_S35_CO01END013CC_1 = 0

        if self.data["COQ1END002MC"] < 0:
            Q3_S35_COQ1END002MC_1 = 1
        else:
            Q3_S35_COQ1END002MC_1 = 0

        if 0 <= self.data["CO01END007HP"] <= 38.7:
            Q3_S35_CO01END007HP_2 = 1
        else:
            Q3_S35_CO01END007HP_2 = 0

        if 0.55 < self.data["CO01END018VE"] <= 0.85:
            Q3_S35_CO01END018VE_3 = 1
        else:
            Q3_S35_CO01END018VE_3 = 0

        if 180 < self.data["COQ1EXP003HP"] <= 181:
            Q3_S35_COQ1EXP003HP_4 = 1
        else:
            Q3_S35_COQ1EXP003HP_4 = 0

        if 1.95 < self.data["CO02END010HP"] <= 2.00549999999999:
            Q3_S35_CO02END010HP_4 = 1
        else:
            Q3_S35_CO02END010HP_4 = 0

        if 1.6 < self.data["CO02END007HP"] <= 2.09:
            Q3_S35_CO02END007HP_4 = 1
        else:
            Q3_S35_CO02END007HP_4 = 0

        if 0 <= self.data["CO01END006IN"] <= 0.39:
            Q3_S35_CO01END006IN_2 = 1
        else:
            Q3_S35_CO01END006IN_2 = 0

        if 0 <= self.data["CO01END023CO"] <= 0.26:
            Q3_S35_CO01END023CO_2 = 1
        else:
            Q3_S35_CO01END023CO_2 = 0

        if 0 <= self.data["CO01END036HP"] <= 0.85:
            Q3_S35_CO01END036HP_2 = 1
        else:
            Q3_S35_CO01END036HP_2 = 0

        if self.data["COQ1END001TO"] < 0:
            Q3_S35_COQ1END001TO_1 = 1
        else:
            Q3_S35_COQ1END001TO_1 = 0

        if 54795 < self.data["COQ1END003HP"] <= 60000:
            Q3_S35_COQ1END003HP_3 = 1
        else:
            Q3_S35_COQ1END003HP_3 = 0

        if 20000 < self.data["COQ1END008IN"] <= 22000:
            Q3_S35_COQ1END008IN_5 = 1
        else:
            Q3_S35_COQ1END008IN_5 = 0

        if self.data["CO01NUM001CT"] < 0:
            Q3_S35_CO01NUM001CT_1 = 1
        else:
            Q3_S35_CO01NUM001CT_1 = 0

        # Categoricas: Creacion
        if self.data["CO00DEM026"] in (4, 5, 6):
            Q3_S35_ESTRATO456 = 1
        else:
            Q3_S35_ESTRATO456 = 0

        Q3_S35_NUMERO_TC = 0.0
        if 0 < self.data["COQ1NUM002TC"] <= 1:
            Q3_S35_NUMERO_TC = 1.0

        if 1 < self.data["COQ1NUM002TC"] <= 3:
            Q3_S35_NUMERO_TC = 2.0

        if 3 < self.data["COQ1NUM002TC"] <= 6:
            Q3_S35_NUMERO_TC = 3.0

        if self.data["COQ1NUM002TC"] > 6:
            Q3_S35_NUMERO_TC = 4.0

        if self.data["COQ1NUM002TC"] < 0:
            Q3_S35_NUMERO_TC = 0.0

        Q3_S35_EXPONENTE = (1.03008 +
                            Q3_S35_NUMERO_TC * 0.0267 +
                            Q3_S35_ESTRATO456 * 0.12979 +
                            self.data["CO02NUM002TO"] * 0.0175 +
                            Q3_S35_CO01NUM001CT_1 * -0.18776 +
                            Q3_S35_COQ1END008IN_5 * 0.23726 +
                            Q3_S35_COQ1END003HP_3 * 0.17472 +
                            Q3_S35_COQ1END001TO_1 * 0.29053 +
                            Q3_S35_CO01END036HP_2 * -0.21284 +
                            Q3_S35_CO01END023CO_2 * -0.15714 +
                            Q3_S35_CO01END006IN_2 * -0.18575 +
                            Q3_S35_CO02END007HP_4 * 0.17396 +
                            Q3_S35_CO02END010HP_4 * 0.16174 +
                            Q3_S35_COQ1EXP003HP_4 * -0.18064 +
                            Q3_S35_CO01END018VE_3 * 0.15914 +
                            Q3_S35_CO01END007HP_2 * -0.14469 +
                            Q3_S35_COQ1END002MC_1 * 0.13462 +
                            Q3_S35_CO01END013CC_1 * 0.21285 +
                            Q3_S35_CO01END005CC_2 * -0.12665 +
                            Q3_S35_CO01END013CC_5 * 0.1507 +
                            Q3_S35_COQ1END003TC_5 * 0.14226 +
                            Q3_S35_CO01END008RO_2 * -0.1915)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S35_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card36_daqu3(self):
        """
        Computes Score Card 36
        """
        # TEC Y NODO=4 Y GRUPO = 2
        self.inicializa_variables()
        self.score_card_daqu3 = 36
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO02NUM018TO", "CO01END005HP", "CO01END006CO", "CO01END007IN", "CO01END012RO",
                      "CO01END013CC", "CO01END025RO", "CO01END026VE", "CO01END028VE", "CO01NUM001CT",
                      "CO02END002CB", "CO02END003HP", "CO02END037RO", "CO00DEM006", "COQ1END003IN",
                      "COQ1END014TC", "COQ1EXP004HP", "COQ1END009HP", "COQ1END010IN"]

        # Scpecial Attributes
        # Caracteristicas personalizadas Quanto 3:
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Acotacion
        if self.data["CO02NUM018TO"] > 1:
            self.data["CO02NUM018TO"] = 1

        if self.data["CO02NUM018TO"] > 1:
            self.data["CO02NUM018TO"] = 1

        if self.data["CO01END005HP"] > 2.35:
            self.data["CO01END005HP"] = 2.35

        if self.data["CO01END007IN"] > 106.76:
            self.data["CO01END007IN"] = 106.76

        if self.data["CO01END012RO"] > 0.64:
            self.data["CO01END012RO"] = 0.64

        if self.data["CO01END025RO"] > 14.801:
            self.data["CO01END025RO"] = 14.801

        if self.data["CO01NUM001CT"] > 5:
            self.data["CO01NUM001CT"] = 5

        if self.data["CO02END002CB"] > 38.6199999999999:
            self.data["CO02END002CB"] = 38.6199999999999

        if self.data["CO02END003HP"] > 11.0665:
            self.data["CO02END003HP"] = 11.0665

        if self.data["COQ1END003IN"] > 47807.9999999999:
            self.data["COQ1END003IN"] = 47807.9999999999

        if self.data["COQ1EXP004HP"] > 180.5:
            self.data["COQ1EXP004HP"] = 180.5

        if self.data["CO01END026VE"] > 47.492:
            self.data["CO01END026VE"] = 47.492

        if self.data["CO01END028VE"] > 1.82:
            self.data["CO01END028VE"] = 1.82

        # binarias: Creacion
        if 1.87 < self.data["CO01END005HP"] <= 2.35:
            Q3_S36_CO01END005HP_4 = 1
        else:
            Q3_S36_CO01END005HP_4 = 0

        if 0 <= self.data["CO01END006CO"] <= 0.55:
            Q3_S36_CO01END006CO_2 = 1
        else:
            Q3_S36_CO01END006CO_2 = 0

        if 19.03 < self.data["CO01END007IN"] <= 77.08:
            Q3_S36_CO01END007IN_3 = 1
        else:
            Q3_S36_CO01END007IN_3 = 0

        if 77.08 < self.data["CO01END007IN"] <= 95.283:
            Q3_S36_CO01END007IN_4 = 1
        else:
            Q3_S36_CO01END007IN_4 = 0

        if 95.283 < self.data["CO01END007IN"] <= 106.76:
            Q3_S36_CO01END007IN_5 = 1
        else:
            Q3_S36_CO01END007IN_5 = 0

        if 0 <= self.data["CO01END012RO"] <= 0:
            Q3_S36_CO01END012RO_2 = 1
        else:
            Q3_S36_CO01END012RO_2 = 0

        if 0.14 < self.data["CO01END012RO"] <= 0.64:
            Q3_S36_CO01END012RO_4 = 1
        else:
            Q3_S36_CO01END012RO_4 = 0

        if 0 <= self.data["CO01END013CC"] <= 0.05:
            Q3_S36_CO01END013CC_2 = 1
        else:
            Q3_S36_CO01END013CC_2 = 0

        if 0.05 < self.data["CO01END013CC"] <= 0.11:
            Q3_S36_CO01END013CC_3 = 1
        else:
            Q3_S36_CO01END013CC_3 = 0

        if 8.17 < self.data["CO01END025RO"] <= 14.801:
            Q3_S36_CO01END025RO_5 = 1
        else:
            Q3_S36_CO01END025RO_5 = 0

        if 12.632 < self.data["CO01END026VE"] <= 47.492:
            Q3_S36_CO01END026VE_3 = 1
        else:
            Q3_S36_CO01END026VE_3 = 0

        if 1.22 < self.data["CO01END028VE"] <= 1.82:
            Q3_S36_CO01END028VE_4 = 1
        else:
            Q3_S36_CO01END028VE_4 = 0

        if 0 <= self.data["CO01NUM001CT"] <= 1:
            Q3_S36_CO01NUM001CT_2 = 1
        else:
            Q3_S36_CO01NUM001CT_2 = 0

        if 1 < self.data["CO01NUM001CT"] <= 3:
            Q3_S36_CO01NUM001CT_3 = 1
        else:
            Q3_S36_CO01NUM001CT_3 = 0

        if 3 < self.data["CO01NUM001CT"] <= 4:
            Q3_S36_CO01NUM001CT_4 = 1
        else:
            Q3_S36_CO01NUM001CT_4 = 0

        if 4 < self.data["CO01NUM001CT"] <= 5:
            Q3_S36_CO01NUM001CT_5 = 1
        else:
            Q3_S36_CO01NUM001CT_5 = 0

        if 10.508 < self.data["CO02END002CB"] <= 38.6199999999999:
            Q3_S36_CO02END002CB_5 = 1
        else:
            Q3_S36_CO02END002CB_5 = 0

        if 3.55 < self.data["CO02END003HP"] <= 11.0665:
            Q3_S36_CO02END003HP_3 = 1
        else:
            Q3_S36_CO02END003HP_3 = 0

        if 0 <= self.data["CO02END037RO"] <= 0:
            Q3_S36_CO02END037RO_2 = 1
        else:
            Q3_S36_CO02END037RO_2 = 0

        if 35000 < self.data["COQ1END003IN"] <= 47807.9999999999:
            Q3_S36_COQ1END003IN_5 = 1
        else:
            Q3_S36_COQ1END003IN_5 = 0

        if 0 <= self.data["COQ1END014TC"] <= 2000:
            Q3_S36_COQ1END014TC_2 = 1
        else:
            Q3_S36_COQ1END014TC_2 = 0

        if 180.433333332 < self.data["COQ1EXP004HP"] <= 180.5:
            Q3_S36_COQ1EXP004HP_4 = 1
        else:
            Q3_S36_COQ1EXP004HP_4 = 0

        if 0 <= self.data["COQ1END009HP"] <= 668:
            Q3_S36_COQ1END009HP_2 = 1
        else:
            Q3_S36_COQ1END009HP_2 = 0

        if 0 <= self.data["COQ1END010IN"] <= 10774:
            Q3_S36_COQ1END010IN_2 = 1
        else:
            Q3_S36_COQ1END010IN_2 = 0

        if 10774 < self.data["COQ1END010IN"] <= 45835.7:
            Q3_S36_COQ1END010IN_3 = 1
        else:
            Q3_S36_COQ1END010IN_3 = 0

        # CATEGORICAS CREACION
        if self.data["COQ1END003MC"] == -1:
            Q3_S36_MICROCREDITO = 0
        else:
            Q3_S36_MICROCREDITO = 1

        Q3_S36_CO00DEM006_C = 0.0
        if self.data["CO00DEM006"] < 0 or self.data["CO00DEM006"] == 999:
            Q3_S36_CO00DEM006_C = 1.0
        elif self.data["CO00DEM006"] == 1:
            Q3_S36_CO00DEM006_C = 2.0
        elif self.data["CO00DEM006"] == 0:
            Q3_S36_CO00DEM006_C = 3.0

        Q3_S36_EXPONENTE = (1.58861 +
                            self.data["CO02NUM018TO"] * -0.42298 +
                            Q3_S36_MICROCREDITO * -0.23153 +
                            Q3_S36_CO01END005HP_4 * 0.18451 +
                            Q3_S36_CO01END006CO_2 * -0.11458 +
                            Q3_S36_CO01END007IN_3 * 0.10702 +
                            Q3_S36_CO01END007IN_4 * 0.21648 +
                            Q3_S36_CO01END007IN_5 * 0.25858 +
                            Q3_S36_CO01END012RO_2 * 0.103 +
                            Q3_S36_CO01END012RO_4 * -0.16229 +
                            Q3_S36_CO01END013CC_2 * -0.29413 +
                            Q3_S36_CO01END013CC_3 * -0.12339 +
                            Q3_S36_CO01END025RO_5 * 0.15713 +
                            Q3_S36_CO01END026VE_3 * 0.12393 +
                            Q3_S36_CO01END028VE_4 * 0.18789 +
                            Q3_S36_CO01NUM001CT_2 * 0.1132 +
                            Q3_S36_CO01NUM001CT_3 * 0.26179 +
                            Q3_S36_CO01NUM001CT_4 * 0.28219 +
                            Q3_S36_CO01NUM001CT_5 * 0.3964 +
                            Q3_S36_CO02END002CB_5 * 0.10769 +
                            Q3_S36_CO02END003HP_3 * 0.12251 +
                            Q3_S36_CO02END037RO_2 * -0.13338 +
                            Q3_S36_COQ1END003IN_5 * 0.20315 +
                            Q3_S36_COQ1END014TC_2 * -0.1441 +
                            Q3_S36_COQ1EXP004HP_4 * -0.16573 +
                            Q3_S36_COQ1END009HP_2 * -0.20899 +
                            Q3_S36_COQ1END010IN_2 * -0.16876 +
                            Q3_S36_COQ1END010IN_3 * -0.11091 +
                            Q3_S36_CO00DEM006_C * 0.07753)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S36_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0
        self.cal_salida_pesos_daqu3()

    def score_card37_daqu3(self):
        """
        Computes Score Card 37
        """
        # TEC. Y NODO=4 Y GRUPO = 3
        self.inicializa_variables()
        self.score_card_daqu3 = 37
        self.adverse_razon_daqu3[0] = 99

        attributes = ["COQ1END003IN", "COQ1END004IN", "COQ1END003TC", "COQ1END009IN", "COQ1NUM003TC",
                      "CO02NUM002TO", "CO01END001VE", "CO01END006CO", "CO01END006HP", "CO01END006OT",
                      "CO01END007IN", "CO01END013CC", "CO01END015RO", "CO01END018IN", "CO01END023VE",
                      "CO01END026IN", "CO01END028VE", "CO01END038RO", "CO01END045RO", "CO02END003HP"]

        # Scpecial Attributes
        # Caracterissticas del set estandar:
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Caracteristicas hibridas:
        self.cuotatotal_daqu3()
        if self.q3_prcuotatotalro == 999:
            self.q3_prcuotatotalro = -1.0

        Q3_QTOTAB = self.qtotab_daqu3()
        Q3_QTOT = self.qtot_daqu3()

        if Q3_QTOT > 0:
            Q3_PROQTOTAB = round(Q3_QTOTAB / Q3_QTOT, 4)  # ROUNDED
        else:
            Q3_PROQTOTAB = -1.0

        if Q3_PROQTOTAB == 999:
            pass

        Q3_CAST = self.calcula_cast_scodaqu3()
        if Q3_CAST == 999:
            Q3_CAST = -1.0

        # Acotacion
        if self.data["COQ1END003IN"] > 120000:
            self.data["COQ1END003IN"] = 120000

        if self.data["COQ1END004IN"] > 140000:
            self.data["COQ1END004IN"] = 140000

        if self.data["COQ1END003TC"] > 26900:
            self.data["COQ1END003TC"] = 26900

        if self.data["COQ1END009IN"] > 27009:
            self.data["COQ1END009IN"] = 27009

        if self.data["COQ1NUM003TC"] > 5:
            self.data["COQ1NUM003TC"] = 5

        if self.q3_prcuotatotalro > 0.86641125:
            self.q3_prcuotatotalro = 0.86641125

        if Q3_CAST > 1:
            Q3_CAST = 1

        if self.data["CO02NUM002TO"] > 32:
            self.data["CO02NUM002TO"] = 32

        if self.data["CO01END001VE"] > 97.1095:
            self.data["CO01END001VE"] = 97.1095

        if self.data["CO01END006CO"] > 5.4965:
            self.data["CO01END006CO"] = 5.4965

        if self.data["CO01END006HP"] > 3.6:
            self.data["CO01END006HP"] = 3.6

        if self.data["CO01END006OT"] > 5.29:
            self.data["CO01END006OT"] = 5.29

        if self.data["CO01END007IN"] > 445.9465:
            self.data["CO01END007IN"] = 445.9465

        if self.data["CO01END013CC"] > 0.27:
            self.data["CO01END013CC"] = 0.27

        if self.data["CO01END015RO"] > 21.54:
            self.data["CO01END015RO"] = 21.54

        if self.data["CO01END018IN"] > 5.0859999999999:
            self.data["CO01END018IN"] = 5.0859999999999

        if self.data["CO01END023VE"] > 2.99:
            self.data["CO01END023VE"] = 2.99

        if self.data["CO01END026IN"] > 98.6565:
            self.data["CO01END026IN"] = 98.6565

        if self.data["CO01END028VE"] > 3.09:
            self.data["CO01END028VE"] = 3.09

        if self.data["CO01END038RO"] > 35.29:
            self.data["CO01END038RO"] = 35.29

        if self.data["CO01END045RO"] > 12.563:
            self.data["CO01END045RO"] = 12.563

        if self.data["CO02END003HP"] > 13.31:
            self.data["CO02END003HP"] = 13.31

        # binarias: Creacion
        if 83.558 < self.data["CO01END001VE"] <= 97.1095:

            Q3_S37_CO01END001VE_4 = 1
        else:
            Q3_S37_CO01END001VE_4 = 0

        if 0 <= self.data["CO01END006CO"] <= 0.6375:

            Q3_S37_CO01END006CO_2 = 1
        else:
            Q3_S37_CO01END006CO_2 = 0

        if 0 <= self.data["CO01END006HP"] <= 1.51:
            Q3_S37_CO01END006HP_2 = 1
        else:
            Q3_S37_CO01END006HP_2 = 0

        if 0 <= self.data["CO01END006OT"] <= 1.246:
            Q3_S37_CO01END006OT_2 = 1
        else:
            Q3_S37_CO01END006OT_2 = 0

        if 32.29 < self.data["CO01END007IN"] <= 203.06:
            Q3_S37_CO01END007IN_3 = 1
        else:
            Q3_S37_CO01END007IN_3 = 0

        if 203.06 < self.data["CO01END007IN"] <= 277.3735:
            Q3_S37_CO01END007IN_4 = 1
        else:
            Q3_S37_CO01END007IN_4 = 0

        if 277.3735 < self.data["CO01END007IN"] <= 445.9465:
            Q3_S37_CO01END007IN_5 = 1
        else:
            Q3_S37_CO01END007IN_5 = 0

        if 0 <= self.data["CO01END013CC"] <= 0:
            Q3_S37_CO01END013CC_2 = 1
        else:
            Q3_S37_CO01END013CC_2 = 0

        if 0 < self.data["CO01END013CC"] <= 0.14:
            Q3_S37_CO01END013CC_3 = 1
        else:
            Q3_S37_CO01END013CC_3 = 0

        if 13.13 < self.data["CO01END015RO"] <= 21.54:
            Q3_S37_CO01END015RO_5 = 1
        else:
            Q3_S37_CO01END015RO_5 = 0

        if 0 <= self.data["CO01END018IN"] <= 0.82:
            Q3_S37_CO01END018IN_2 = 1
        else:
            Q3_S37_CO01END018IN_2 = 0

        if 1.58 < self.data["CO01END023VE"] <= 2.6:
            Q3_S37_CO01END023VE_4 = 1
        else:
            Q3_S37_CO01END023VE_4 = 0

        if 46.955 < self.data["CO01END026IN"] <= 98.6565:
            Q3_S37_CO01END026IN_5 = 1
        else:
            Q3_S37_CO01END026IN_5 = 0

        if 1.07 < self.data["CO01END028VE"] <= 1.56:
            Q3_S37_CO01END028VE_3 = 1
        else:
            Q3_S37_CO01END028VE_3 = 0

        if 0 < self.data["CO01END038RO"] <= 6.55:
            Q3_S37_CO01END038RO_2 = 1
        else:
            Q3_S37_CO01END038RO_2 = 0

        if 0 <= self.data["CO01END045RO"] <= 2.26:
            Q3_S37_CO01END045RO_2 = 1
        else:
            Q3_S37_CO01END045RO_2 = 0

        if 5.73 < self.data["CO02END003HP"] <= 13.31:
            Q3_S37_CO02END003HP_4 = 1
        else:
            Q3_S37_CO02END003HP_4 = 0

        if 0 <= self.data["COQ1END003IN"] <= 14032.2:
            Q3_S37_COQ1END003IN_2 = 1
        else:
            Q3_S37_COQ1END003IN_2 = 0

        if 14600 < self.data["COQ1END004IN"] <= 39600:
            Q3_S37_COQ1END004IN_3 = 1
        else:
            Q3_S37_COQ1END004IN_3 = 0

        if 3000 < self.data["COQ1END003TC"] <= 13800:
            Q3_S37_COQ1END003TC_3 = 1
        else:
            Q3_S37_COQ1END003TC_3 = 0

        if 0 <= self.data["COQ1END009IN"] <= 738.9:
            Q3_S37_COQ1END009IN_2 = 1
        else:
            Q3_S37_COQ1END009IN_2 = 0

        # Categoricas: Creacion
        Q3_S37_CO00DEM006_C = 0.0
        if self.data["CO00DEM006"] < 0 or self.data["CO00DEM006"] == 999:
            Q3_S37_CO00DEM006_C = 1
        elif self.data["CO00DEM006"] == 1:
            Q3_S37_CO00DEM006_C = 2
        elif self.data["CO00DEM006"] == 0:
            Q3_S37_CO00DEM006_C = 3

        Q3_S37_PRCUOTATOTALRO = round(self.q3_prcuotatotalro, 3)  # ROUNDED
        self.q3_prcuotatotalro = float(Q3_S37_PRCUOTATOTALRO)

        Q3_S37_EXPONENTE = (2.27644 +
                            Q3_CAST * -0.23415 +
                            self.data["CO02NUM002TO"] * 0.01652 +
                            self.data["COQ1NUM003TC"] * 0.04207 +
                            self.q3_prcuotatotalro * -0.15736 +
                            Q3_S37_CO01END001VE_4 * 0.19005 +
                            Q3_S37_CO01END006CO_2 * -0.16119 +
                            Q3_S37_CO01END006HP_2 * -0.22137 +
                            Q3_S37_CO01END006OT_2 * -0.09884 +
                            Q3_S37_CO01END007IN_3 * 0.14442 +
                            Q3_S37_CO01END007IN_4 * 0.35423 +
                            Q3_S37_CO01END007IN_5 * 0.35011 +
                            Q3_S37_CO01END013CC_2 * -0.30994 +
                            Q3_S37_CO01END013CC_3 * -0.11818 +
                            Q3_S37_CO01END015RO_5 * 0.13218 +
                            Q3_S37_CO01END018IN_2 * -0.11693 +
                            Q3_S37_CO01END023VE_4 * 0.15731 +
                            Q3_S37_CO01END026IN_5 * 0.13497 +
                            Q3_S37_CO01END028VE_3 * 0.12721 +
                            Q3_S37_CO01END038RO_2 * -0.15091 +
                            Q3_S37_CO01END045RO_2 * -0.09806 +
                            Q3_S37_CO02END003HP_4 * 0.13015 +
                            Q3_S37_COQ1END003IN_2 * -0.17834 +
                            Q3_S37_COQ1END004IN_3 * -0.14488 +
                            Q3_S37_COQ1END003TC_3 * -0.08676 +
                            Q3_S37_COQ1END009IN_2 * -0.12984 +
                            Q3_S37_CO00DEM006_C * 0.11587)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S37_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0
        self.cal_salida_pesos_daqu3()

    def score_card38_daqu3(self):
        """
        Computes Score Card 38
        """
        # TIPO5. Y GRUPO = 1
        self.inicializa_variables()
        self.score_card_daqu3 = 38
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO02NUM029TO", "CO02NUM003TO"]

        # Scpecial Attributes
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Acotacion
        if self.data["CO02NUM029TO"] > 2:
            self.data["CO02NUM029TO"] = 2

        if self.data["CO02NUM003TO"] > 2:
            self.data["CO02NUM003TO"] = 2

        # binarias: Creacion
        if 28 < self.data["CO02EXP003TO"] <= 36:
            Q3_S38_CO02EXP003TO_4 = 1
        else:
            Q3_S38_CO02EXP003TO_4 = 0

        if 36 < self.data["CO02EXP003TO"]:
            Q3_S38_CO02EXP003TO_5 = 1
        else:
            Q3_S38_CO02EXP003TO_5 = 0

        if 0 <= self.data["CO02EXP004TO"] <= 3:
            Q3_S38_CO02EXP004TO_2 = 1
        else:
            Q3_S38_CO02EXP004TO_2 = 0

        if 27 < self.data["CO02EXP004TO"]:
            Q3_S38_CO02EXP004TO_5 = 1
        else:
            Q3_S38_CO02EXP004TO_5 = 0

        if self.data["CO02NUM003TO"] < 0:
            Q3_S38_CO02NUM003TO_1 = 1
        else:
            Q3_S38_CO02NUM003TO_1 = 0

        Q3_S38_EXPONENTE = (0.29711 +
                            self.data["CO02NUM029TO"] * 0.01869 +
                            Q3_S38_CO02EXP003TO_4 * -0.02027 +
                            Q3_S38_CO02EXP003TO_5 * -0.05166 +
                            Q3_S38_CO02EXP004TO_2 * 0.02172 +
                            Q3_S38_CO02EXP004TO_5 * -0.09452 +
                            Q3_S38_CO02NUM003TO_1 * 0.05102)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S38_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card39_daqu3(self):
        """
        Computes Score Card 39
        """
        # TIPO5. Y GRUPO = 2
        self.inicializa_variables()
        self.score_card_daqu3 = 39
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO02NUM042AH", "CO02NUM004TO", "CO02NUM003TO", "CO01NUM001AH", "CO01ACP017AH"]

        # Scpecial Attributes
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Acotacion
        if self.data["CO02NUM042AH"] > 100:
            self.data["CO02NUM042AH"] = 100

        if self.data["CO02NUM004TO"] > 1:
            self.data["CO02NUM004TO"] = 1

        if self.data["CO02NUM003TO"] > 2:
            self.data["CO02NUM003TO"] = 2

        if self.data["CO01NUM001AH"] > 3:
            self.data["CO01NUM001AH"] = 3

        if self.data["CO01ACP017AH"] > 45:
            self.data["CO01ACP017AH"] = 45

        # binarias: Creacion
        if self.data["CO02NUM042AH"] < 0:
            Q3_S39_CO02NUM042AH_1 = 1
        else:
            Q3_S39_CO02NUM042AH_1 = 0

        if 0 <= self.data["CO02NUM004TO"] <= 0:
            Q3_S39_CO02NUM004TO_2 = 1
        else:
            Q3_S39_CO02NUM004TO_2 = 0

        if 1 < self.data["CO02NUM003TO"] <= 2:
            Q3_S39_CO02NUM003TO_4 = 1
        else:
            Q3_S39_CO02NUM003TO_4 = 0

        if self.data["CO02NUM003TO"] < 0:
            Q3_S39_CO02NUM003TO_1 = 1
        else:
            Q3_S39_CO02NUM003TO_1 = 0

        if 2 < self.data["CO02EXP006TO"] <= 11:
            Q3_S39_CO02EXP006TO_4 = 1
        else:
            Q3_S39_CO02EXP006TO_4 = 0

        if 2 < self.data["CO02EXP004TO"]:
            Q3_S39_CO02EXP004TO_4 = 1
        else:
            Q3_S39_CO02EXP004TO_4 = 0

        if 0 <= self.data["CO02EXP004TO"] <= 0:
            Q3_S39_CO02EXP004TO_2 = 1
        else:
            Q3_S39_CO02EXP004TO_2 = 0

        if 1 < self.data["CO01NUM001AH"] <= 2:
            Q3_S39_CO01NUM001AH_3 = 1
        else:
            Q3_S39_CO01NUM001AH_3 = 0

        if 34 < self.data["CO01ACP017AH"] <= 45:
            Q3_S39_CO01ACP017AH_4 = 1
        else:
            Q3_S39_CO01ACP017AH_4 = 0

        if self.data["CO00DEM006"] == 0:
            Q3_S39_CO00DEM006_2 = 1
        else:
            Q3_S39_CO00DEM006_2 = 0

        Q3_S39_EXPONENTE = (0.46206 +
                            Q3_S39_CO00DEM006_2 * 0.10941 +
                            Q3_S39_CO01ACP017AH_4 * -0.03192 +
                            Q3_S39_CO01NUM001AH_3 * 0.03471 +
                            Q3_S39_CO02EXP004TO_2 * 0.09038 +
                            Q3_S39_CO02EXP004TO_4 * -0.1457 +
                            Q3_S39_CO02EXP006TO_4 * 0.03675 +
                            Q3_S39_CO02NUM003TO_1 * -0.03783 +
                            Q3_S39_CO02NUM003TO_4 * 0.02832 +
                            Q3_S39_CO02NUM004TO_2 * 0.10459 +
                            Q3_S39_CO02NUM042AH_1 * -0.05512)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S39_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card40_daqu3(self):
        """
        Computes Score Card 40
        """
        # TIPO5. Y GRUPO = 3
        self.inicializa_variables()
        self.score_card_daqu3 = 40
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO02NUM043AH", "CO02NUM042CB", "CO02EXP004TO", "CO02EXP003TO", "CO01NUM002AH",
                      "CO01ACP017AH"]

        # Scpecial Attributes
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Acotacion
        if self.data["CO02NUM043AH"] > 100:
            self.data["CO02NUM043AH"] = 100

        if self.data["CO02NUM042CB"] > 100:
            self.data["CO02NUM042CB"] = 100

        if self.data["CO01NUM002AH"] > 2:
            self.data["CO01NUM002AH"] = 2

        if self.data["CO01ACP017AH"] > 45:
            self.data["CO01ACP017AH"] = 45

        Q3_S40_CO00DEM003VS_D = self.data["CO00DEM003"]
        if Q3_S40_CO00DEM003VS_D > 56:
            Q3_S40_CO00DEM003VS_D = 56

        # binarias: Creacion
        if 50 < self.data["CO02NUM043AH"] <= 100:
            Q3_S40_CO02NUM043AH_4 = 1
        else:
            Q3_S40_CO02NUM043AH_4 = 0

        if 0 < self.data["CO02NUM042CB"] <= 50:
            Q3_S40_CO02NUM042CB_3 = 1
        else:
            Q3_S40_CO02NUM042CB_3 = 0

        if 1 < self.data["CO02EXP004TO"] <= 5:
            Q3_S40_CO02EXP004TO_3 = 1
        else:
            Q3_S40_CO02EXP004TO_3 = 0

        if 0 <= self.data["CO02EXP004TO"] <= 1:
            Q3_S40_CO02EXP004TO_2 = 1
        else:
            Q3_S40_CO02EXP004TO_2 = 0

        if 186 < self.data["CO02EXP003TO"]:
            Q3_S40_CO02EXP003TO_4 = 1
        else:
            Q3_S40_CO02EXP003TO_4 = 0

        if 0 <= self.data["CO02EXP003TO"] <= 4:
            Q3_S40_CO02EXP003TO_2 = 1
        else:
            Q3_S40_CO02EXP003TO_2 = 0

        if self.data["CO01NUM002AH"] < 0:
            Q3_S40_CO01NUM002AH_1 = 1
        else:
            Q3_S40_CO01NUM002AH_1 = 0

        if 43 < self.data["CO01ACP017AH"] <= 45:
            Q3_S40_CO01ACP017AH_3 = 1
        else:
            Q3_S40_CO01ACP017AH_3 = 0

        Q3_S40_EXPONENTE = (0.46716 +
                            Q3_S40_CO00DEM003VS_D * 0.00074883 +
                            Q3_S40_CO01ACP017AH_3 * -0.05821 +
                            Q3_S40_CO01NUM002AH_1 * -0.05522 +
                            Q3_S40_CO02EXP003TO_2 * 0.0304 +
                            Q3_S40_CO02EXP003TO_4 * -0.1166 +
                            Q3_S40_CO02EXP004TO_2 * 0.19569 +
                            Q3_S40_CO02EXP004TO_3 * 0.04249 +
                            Q3_S40_CO02NUM042CB_3 * -0.02846 +
                            Q3_S40_CO02NUM043AH_4 * -0.05921)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S40_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()

    def score_card41_daqu3(self):
        """
        Computes Score Card 41
        """
        # if POBLACION = .TIPO5. y GRUPO = 4:
        self.inicializa_variables()
        self.score_card_daqu3 = 41
        self.adverse_razon_daqu3[0] = 99

        attributes = ["CO02NUM004TO", "CO02NUM003TO", "CO02EXP001TO"]

        # Scpecial Attributes
        for key in attributes:
            if self.data_o[key] == 999:
                self.data[key] = -1.0

        # Acotacion
        if self.data["CO02NUM004TO"] > 2:
            self.data["CO02NUM004TO"] = 2

        if self.data["CO02NUM003TO"] > 2:
            self.data["CO02NUM003TO"] = 2

        if self.data["CO02EXP001TO"] > 325:
            self.data["CO02EXP001TO"] = 325

        Q3_S41_CO00DEM003VS_D = self.data["CO00DEM003"]
        if Q3_S41_CO00DEM003VS_D > 73:
            Q3_S41_CO00DEM003VS_D = 73

        # Binarias: Creacion
        if 0 <= self.data["CO02NUM004TO"] <= 0:
            Q3_S41_CO02NUM004TO_2 = 1
        else:
            Q3_S41_CO02NUM004TO_2 = 0

        if 0 < self.data["CO02NUM003TO"] <= 2:
            Q3_S41_CO02NUM003TO_3 = 1
        else:
            Q3_S41_CO02NUM003TO_3 = 0

        # Categoricas: Creacion
        if self.data["CO00DEM026"] in (5, 6):
            Q3_S41_ESTRATO56 = 1
        else:
            Q3_S41_ESTRATO56 = 0

        Q3_S41_EXPONENTE = (0.35834 +
                            Q3_S41_CO00DEM003VS_D * 0.00323 +
                            self.data["CO02EXP001TO"] * 0.00038999 +
                            Q3_S41_ESTRATO56 * 0.26029 +
                            Q3_S41_CO02NUM003TO_3 * 0.06 +
                            Q3_S41_CO02NUM004TO_2 * 0.05762)

        self.q3_ingreso = round(2.7182818284590452 ** Q3_S41_EXPONENTE, 2)  # ROUNDED

        if self.q3_ingreso < 1:
            self.q3_ingreso = 1.0

        self.cal_salida_pesos_daqu3()


if __name__ == "__main__":
    data = {"VLR_SMLMV_CARACT": 875000}
    q3 = Quanto3(data)
    exit(0)
