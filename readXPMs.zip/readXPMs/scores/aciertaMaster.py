from typing import Dict, List, Union

try:
    import cPickle as pickle
except ImportError:
    import pickle
from copy import deepcopy
import traceback
try:
    import sklearn
except ImportError as error:
    tb = traceback.format_exc()
    # raise ImportError("{}: {}".format(error, tb))
from scores.dependencies.AM_Financiero import get_score


class aciertaMaster(object):

    def __init__(self):
        self._models = {}
        with open("MODELO_SVM_SEG_01A.pkl", "r") as model01a:
            self._models["1"] = pickle.load(model01a)
        with open("MODELO_SVM_SEG_02A.pkl", "r") as model02a:
            self._models["2"] = pickle.load(model02a)
        with open("MODELO_SVM_SEG_03A.pkl", "r") as model03a:
            self._models["3"] = pickle.load(model03a)
        with open("MODELO_SVM_SEG_06A.pkl", "r") as model06a:
            self._models["6"] = pickle.load(model06a)
        with open("MODELO_SVM_SEG_07A.pkl", "r") as model07a:
            self._models["7.9"] = pickle.load(model07a)
        with open("MODELO_SVM_SEG_10A.pkl", "r") as model10a:
            self._models["10"] = pickle.load(model10a)
        with open("MODELO_SVM_SEG_13A.pkl", "r") as model13a:
            self._models["13"] = pickle.load(model13a)
        with open("MODELO_SVM_SEG_15IA.pkl", "r") as model151a:
            self._models["15.1"] = pickle.load(model151a)
        with open("MODELO_SVM_SEG_15IIA.pkl", "r") as model152a:
            self._models["15.2"] = pickle.load(model152a)
        with open("MODELO_SVM_SEG_16A.pkl", "r") as model16a:
            self._models["16"] = pickle.load(model16a)

    def __call__(self, data):
        data_mod = deepcopy(data)
        score_code = 'Acierta Master'
        sub_score = '000'
        reporte = get_score(data_mod, score_code, sub_score, self._models)
        return reporte
