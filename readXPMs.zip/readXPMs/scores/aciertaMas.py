import numpy as np
import traceback
from copy import deepcopy
import time

def truncate(x,d):
	return int(x*(10.0**d))/(10.0**d)

#--------------------------------------------------------------------------------------------------------------#
#  FUNCION HIBRIDAS : REALIZA EL CALCULO DE LAS CARACTERISTICAS HIBRIDAS 
#                     QTOTAB,QTOT,SOLOREAL,MOB_SOLOREAL,NEW_EVER12048_P,RECMORA_USA
#--------------------------------------------------------------------------------------------------------------#

def hibridas(data):
#--------------------------------------------
# variables para QTOTAB
#--------------------------------------------
	if data['CO01NUM002CC'] < 0: 
		AUX_CO01NUM002CC = 0 
	else:   
		AUX_CO01NUM002CC = data['CO01NUM002CC']

	if data['CO01NUM002RO'] < 0 :
		AUX_CO01NUM002RO = 0
	else:
		AUX_CO01NUM002RO = data['CO01NUM002RO']

	if data['CO01NUM002IN'] < 0 : 
		AUX_CO01NUM002IN = 0 
	else:
		AUX_CO01NUM002IN = data['CO01NUM002IN']

	if data['CO01NUM002OT'] < 0 : 
		AUX_CO01NUM002OT = 0 
	else:
		AUX_CO01NUM002OT = data['CO01NUM002OT']

	if data['CO01NUM002CO'] < 0 : 
		AUX_CO01NUM002CO = 0 
	else:
		AUX_CO01NUM002CO = data['CO01NUM002CO']

	if data['CO01NUM002VE'] < 0 : 
		AUX_CO01NUM002VE = 0 
	else: 
		AUX_CO01NUM002VE = data['CO01NUM002VE']
   
	if data['CO01NUM002HP'] < 0 : 
		AUX_CO01NUM002HP = 0
	else: 
		AUX_CO01NUM002HP = data['CO01NUM002HP']

	QTOTAB = AUX_CO01NUM002CC + AUX_CO01NUM002RO + AUX_CO01NUM002IN + AUX_CO01NUM002OT + AUX_CO01NUM002CO + AUX_CO01NUM002VE + AUX_CO01NUM002HP
#--------------------------------------------
# variables para QTOT
#--------------------------------------------
	if data['CO01NUM001CC'] < 0 : 
		AUX_CO01NUM001CC = 0 
	else:
		AUX_CO01NUM001CC = data['CO01NUM001CC']
		
	if data['CO01NUM001RO'] < 0 : 
		AUX_CO01NUM001RO = 0 
	else:
		AUX_CO01NUM001RO = data['CO01NUM001RO']
		
	if data['CO01NUM001IN'] < 0 : 
		AUX_CO01NUM001IN = 0 
	else:
		AUX_CO01NUM001IN = data['CO01NUM001IN']
		
	if data['CO01NUM001OT'] < 0 : 
		AUX_CO01NUM001OT = 0 
	else:
		AUX_CO01NUM001OT = data['CO01NUM001OT']
		
	if data['CO01NUM001CO'] < 0 : 
		AUX_CO01NUM001CO = 0 
	else:
		AUX_CO01NUM001CO = data['CO01NUM001CO']
		
	if data['CO01NUM001VE'] < 0 : 
		AUX_CO01NUM001VE = 0 
	else:
		AUX_CO01NUM001VE = data['CO01NUM001VE']
		
	if data['CO01NUM001HP'] < 0 : 
		AUX_CO01NUM001HP = 0 
	else:
		AUX_CO01NUM001HP = data['CO01NUM001HP']
	
	QTOT = AUX_CO01NUM001CC + AUX_CO01NUM001RO + AUX_CO01NUM001IN + AUX_CO01NUM001OT + AUX_CO01NUM001CO + AUX_CO01NUM001VE + AUX_CO01NUM001HP

#--------------------------------------------
# variables para SOLOREAL
#--------------------------------------------
	if AUX_CO01NUM001OT + AUX_CO01NUM001CC == QTOT : 
		SOLOREAL = 1 
	else:
		SOLOREAL = 0
#--------------------------------------------
# variables para MOB_SOLOREAL
#--------------------------------------------
	if data['CO01EXP001CC'] < 0 : 
		AUX_CO01EXP001CC = 0 
	else: 
		AUX_CO01EXP001CC = data['CO01EXP001CC']
	
	if data['CO01EXP001OT'] < 0 : 
		AUX_CO01EXP001OT = 0 
	else: 
		AUX_CO01EXP001OT = data['CO01EXP001OT']
	
	MOB_SOLOREAL= max(AUX_CO01EXP001CC, AUX_CO01EXP001OT)
#--------------------------------------------
# variables para new_ever12048_p
#--------------------------------------------
	if data['CO01MOR037RO'] < 0 :
		A_CO01MOR037RO = 0
	else:
		A_CO01MOR037RO = data['CO01MOR037RO']

	if data['CO01MOR037IN'] < 0 :
		A_CO01MOR037IN = 0
	else:
		A_CO01MOR037IN = data['CO01MOR037IN']

	if data['CO01MOR037OT'] < 0 :
		A_CO01MOR037OT = 0
	else:
		A_CO01MOR037OT = data['CO01MOR037OT']

	if data['CO01MOR037VE'] < 0 :
		A_CO01MOR037VE = 0
	else:
		A_CO01MOR037VE = data['CO01MOR037VE']

	if data['CO01MOR037CC'] < 0 :
		A_CO01MOR037CC = 0
	else:
		A_CO01MOR037CC = data['CO01MOR037CC']

	if data['CO01MOR037HP'] < 0 :
		A_CO01MOR037HP = 0
	else:
		A_CO01MOR037HP = data['CO01MOR037HP']

	if data['CO01MOR044RO'] < 0 :
		A_CO01MOR044RO = 0
	else:
		A_CO01MOR044RO = data['CO01MOR044RO']

	if data['CO01MOR044IN'] < 0 :
		A_CO01MOR044IN = 0
	else:
		A_CO01MOR044IN = data['CO01MOR044IN']

	if data['CO01MOR044OT'] < 0 :
		A_CO01MOR044OT = 0
	else:
		A_CO01MOR044OT = data['CO01MOR044OT']

	if data['CO01MOR044CO'] < 0 :
		A_CO01MOR044CO = 0
	else:
		A_CO01MOR044CO = data['CO01MOR044CO']

	if data['CO01MOR044VE'] < 0 :
		A_CO01MOR044VE = 0
	else:
		A_CO01MOR044VE = data['CO01MOR044VE']

	if data['CO01MOR044CC'] < 0 :
		A_CO01MOR044CC = 0
	else:
		A_CO01MOR044CC = data['CO01MOR044CC']

	if data['CO01MOR044HP'] < 0 :
		A_CO01MOR044HP = 0
	else:
		A_CO01MOR044HP = data['CO01MOR044HP']

	if data['CO01MOR051RO'] < 0 :
		A_CO01MOR051RO = 0
	else:
		A_CO01MOR051RO = data['CO01MOR051RO']

	if data['CO01MOR051IN'] < 0 :
		A_CO01MOR051IN = 0
	else:
		A_CO01MOR051IN = data['CO01MOR051IN']

	if data['CO01MOR051OT'] < 0 :
		A_CO01MOR051OT = 0
	else:
		A_CO01MOR051OT = data['CO01MOR051OT']

	if data['CO01MOR051VE'] < 0 :
		A_CO01MOR051VE = 0
	else:
		A_CO01MOR051VE = data['CO01MOR051VE']

	if data['CO01MOR051CC'] < 0 :
		A_CO01MOR051CC = 0
	else:
		A_CO01MOR051CC = data['CO01MOR051CC']

	if data['CO01MOR051HP'] < 0 :
		A_CO01MOR051HP = 0
	else:
		A_CO01MOR051HP = data['CO01MOR051HP']

	if data['CO01MOR058RO'] < 0 :
		A_CO01MOR058RO = 0
	else:
		A_CO01MOR058RO = data['CO01MOR058RO']

	if data['CO01MOR058IN'] < 0 :
		A_CO01MOR058IN = 0
	else:
		A_CO01MOR058IN = data['CO01MOR058IN']

	if data['CO01MOR058OT'] < 0 :
		A_CO01MOR058OT = 0
	else:
		A_CO01MOR058OT = data['CO01MOR058OT']

	if data['CO01MOR058CO'] < 0 :
		A_CO01MOR058CO = 0
	else:
		A_CO01MOR058CO = data['CO01MOR058CO']

	if data['CO01MOR058VE'] < 0 :
		A_CO01MOR058VE = 0
	else:
		A_CO01MOR058VE = data['CO01MOR058VE']

	if data['CO01MOR058CC'] < 0 :
		A_CO01MOR058CC = 0
	else:
		A_CO01MOR058CC = data['CO01MOR058CC']

	if data['CO01MOR058HP'] < 0 :
		A_CO01MOR058HP = 0
	else:
		A_CO01MOR058HP = data['CO01MOR058HP']

	if data['CO01MOR065RO'] < 0 :
		A_CO01MOR065RO = 0
	else:
		A_CO01MOR065RO = data['CO01MOR065RO']

	if data['CO01MOR065IN'] < 0 :
		A_CO01MOR065IN = 0
	else:
		A_CO01MOR065IN = data['CO01MOR065IN']

	if data['CO01MOR065OT'] < 0 :
		A_CO01MOR065OT = 0
	else:
		A_CO01MOR065OT = data['CO01MOR065OT']

	if data['CO01MOR065VE'] < 0 :
		A_CO01MOR065VE = 0
	else:
		A_CO01MOR065VE = data['CO01MOR065VE']

	if data['CO01MOR065CC'] < 0 :
		A_CO01MOR065CC = 0
	else:
		A_CO01MOR065CC = data['CO01MOR065CC']

	if data['CO01MOR065HP'] < 0 :
		A_CO01MOR065HP = 0
	else:
		A_CO01MOR065HP = data['CO01MOR065HP']

	if data['CO01MOR072RO'] < 0 :
		A_CO01MOR072RO = 0
	else:
		A_CO01MOR072RO = data['CO01MOR072RO']

	if data['CO01MOR072IN'] < 0 :
		A_CO01MOR072IN = 0
	else:
		A_CO01MOR072IN = data['CO01MOR072IN']

	if data['CO01MOR072OT'] < 0 :
		A_CO01MOR072OT = 0
	else:
		A_CO01MOR072OT = data['CO01MOR072OT']

	if data['CO01MOR072CO'] < 0 :
		A_CO01MOR072CO = 0
	else:
		A_CO01MOR072CO = data['CO01MOR072CO']

	if data['CO01MOR072VE'] < 0 :
		A_CO01MOR072VE = 0
	else:
		A_CO01MOR072VE = data['CO01MOR072VE']

	if data['CO01MOR072CC'] < 0 :
		A_CO01MOR072CC = 0
	else:
		A_CO01MOR072CC = data['CO01MOR072CC']

	if data['CO01MOR072HP'] < 0 :
		A_CO01MOR072HP = 0
	else:
		A_CO01MOR072HP = data['CO01MOR072HP']

	if data['CO01MOR005RO'] < 0 :
		A_CO01MOR005RO = 0
	else:
		A_CO01MOR005RO = data['CO01MOR005RO']

	if data['CO01MOR005IN'] < 0 :
		A_CO01MOR005IN = 0
	else:
		A_CO01MOR005IN = data['CO01MOR005IN']

	if data['CO01MOR005OT'] < 0 :
		A_CO01MOR005OT = 0
	else:
		A_CO01MOR005OT = data['CO01MOR005OT']

	if data['CO01MOR005VE'] < 0 :
		A_CO01MOR005VE = 0
	else:
		A_CO01MOR005VE = data['CO01MOR005VE']

	if data['CO01MOR005CC'] < 0 :
		A_CO01MOR005CC = 0
	else:
		A_CO01MOR005CC = data['CO01MOR005CC']

	if data['CO01MOR005HP'] < 0 :
		A_CO01MOR005HP = 0
	else:
		A_CO01MOR005HP = data['CO01MOR005HP']

	EVER1206_P    = A_CO01MOR037RO + A_CO01MOR037IN + A_CO01MOR037OT + A_CO01MOR037VE + A_CO01MOR037CC + A_CO01MOR037HP
	EVER12012_P   = A_CO01MOR044RO + A_CO01MOR044IN + A_CO01MOR044OT + A_CO01MOR044CO + A_CO01MOR044VE + A_CO01MOR044CC + A_CO01MOR044HP
	EVER12018_P   = A_CO01MOR051RO + A_CO01MOR051IN + A_CO01MOR051OT + A_CO01MOR051VE + A_CO01MOR051CC + A_CO01MOR051HP
	EVER12024_P   = A_CO01MOR058RO + A_CO01MOR058IN + A_CO01MOR058OT + A_CO01MOR058CO + A_CO01MOR058VE + A_CO01MOR058CC + A_CO01MOR058HP
	EVER12036_P   = A_CO01MOR065RO + A_CO01MOR065IN + A_CO01MOR065OT + A_CO01MOR065VE + A_CO01MOR065CC + A_CO01MOR065HP
	EVER12048_P   = A_CO01MOR072RO + A_CO01MOR072IN + A_CO01MOR072OT + A_CO01MOR072CO + A_CO01MOR072VE + A_CO01MOR072CC + A_CO01MOR072HP
	CO01MOR005_TO = A_CO01MOR005RO + A_CO01MOR005IN + A_CO01MOR005OT + A_CO01MOR005VE + A_CO01MOR005CC + A_CO01MOR005HP
	NEW_EVER12048_P = CO01MOR005_TO + EVER1206_P + EVER12012_P + EVER12018_P + EVER12024_P + EVER12036_P + EVER12048_P
#--------------------------------------------
# variables recmora_usa
#--------------------------------------------

	if data['CO01MOR075RO'] < 0 : 
		A_CO01MOR075RO= 999 
	else: 
		A_CO01MOR075RO = data['CO01MOR075RO']

	if data['CO01MOR075IN'] < 0 : 
		A_CO01MOR075IN= 999 
	else: 
		A_CO01MOR075IN = data['CO01MOR075IN']

	if data['CO01MOR075OT'] < 0 : 
		A_CO01MOR075OT= 999 
	else: 
		A_CO01MOR075OT = data['CO01MOR075OT']
	
	if data['CO01MOR075CO'] < 0 : 
		A_CO01MOR075CO= 999 
	else: 
		A_CO01MOR075CO = data['CO01MOR075CO']
	
	if data['CO01MOR075VE'] < 0 : 
		A_CO01MOR075VE= 999 
	else: 
		A_CO01MOR075VE = data['CO01MOR075VE']
		
	if data['CO01MOR075CC'] < 0 : 
		A_CO01MOR075CC= 999 
	else: 
		A_CO01MOR075CC = data['CO01MOR075CC']
	
	if data['CO01MOR075HP'] < 0 : 
		A_CO01MOR075HP= 999 
	else: A_CO01MOR075HP = data['CO01MOR075HP']
	
	RECMORA30 = min(A_CO01MOR075RO, A_CO01MOR075IN, A_CO01MOR075OT, A_CO01MOR075CO, A_CO01MOR075VE, A_CO01MOR075CC, A_CO01MOR075HP)
	
	
	if data['CO01MOR076RO'] < 0 : 
		A_CO01MOR076RO = 999 
	else: 
		A_CO01MOR076RO = data['CO01MOR076RO']
	
	if data['CO01MOR076IN'] < 0 : 
		A_CO01MOR076IN = 999 
	else: 
		A_CO01MOR076IN = data['CO01MOR076IN'] 
	
	if data['CO01MOR076OT'] < 0 : 
		A_CO01MOR076OT = 999 
	else: 
		A_CO01MOR076OT = data['CO01MOR076OT']
	
	if data['CO01MOR076CO'] < 0 : 
		A_CO01MOR076CO = 999 
	else: 
		A_CO01MOR076CO = data['CO01MOR076CO']
	
	if data['CO01MOR076VE'] < 0 : 
		A_CO01MOR076VE = 999 
	else: 
		A_CO01MOR076VE = data['CO01MOR076VE']
	
	if data['CO01MOR076CC'] < 0 : 
		A_CO01MOR076CC = 999 
	else: 
		A_CO01MOR076CC = data['CO01MOR076CC'] 
	
	if data['CO01MOR076HP'] < 0 : 
		A_CO01MOR076HP = 999 
	else: 
		A_CO01MOR076HP = data['CO01MOR076HP']
	
	RECMORA60 = min(A_CO01MOR076RO, A_CO01MOR076IN, A_CO01MOR076OT, A_CO01MOR076CO, A_CO01MOR076VE, A_CO01MOR076CC, A_CO01MOR076HP)
	
	
	if data['CO01MOR077RO'] < 0 : 
		A_CO01MOR077RO = 999  
	else:
		A_CO01MOR077RO = data['CO01MOR077RO']
	
	if data['CO01MOR077IN'] < 0 : 
		A_CO01MOR077IN = 999  
	else: 
		A_CO01MOR077IN = data['CO01MOR077IN']
	
	if data['CO01MOR077OT'] < 0 : 
		A_CO01MOR077OT = 999
	else:
		A_CO01MOR077OT = data['CO01MOR077OT']
	
	if data['CO01MOR077CO'] < 0 : 
		A_CO01MOR077CO = 999  
	else: 
		A_CO01MOR077CO = data['CO01MOR077CO']
		
	if data['CO01MOR077VE'] < 0 : 
		A_CO01MOR077VE = 999  
	else: 
		A_CO01MOR077VE = data['CO01MOR077VE']
	
	if data['CO01MOR077CC'] < 0 : 
		A_CO01MOR077CC = 999  
	else: 
		A_CO01MOR077CC = data['CO01MOR077CC']

	if data['CO01MOR077HP'] < 0 : 
		A_CO01MOR077HP = 999  
	else: 
		A_CO01MOR077HP = data['CO01MOR077HP']
	
	RECMORA90 = min(A_CO01MOR077RO, A_CO01MOR077IN, A_CO01MOR077OT, A_CO01MOR077CO, A_CO01MOR077VE, A_CO01MOR077CC, A_CO01MOR077HP)
	
	if data['CO01MOR078RO'] < 0 : 
		A_CO01MOR078RO = 999  
	else:
		A_CO01MOR078RO = data['CO01MOR078RO']
		
	if data['CO01MOR078IN'] < 0 : 
		A_CO01MOR078IN = 999  
	else:
		A_CO01MOR078IN = data['CO01MOR078IN']
	
	if data['CO01MOR078CO'] < 0 : 
		A_CO01MOR078CO = 999  
	else: 
		A_CO01MOR078CO = data['CO01MOR078CO']
	
	if data['CO01MOR078VE'] < 0 : 
		A_CO01MOR078VE = 999  
	else: 
		A_CO01MOR078VE = data['CO01MOR078VE']
	
	if data['CO01MOR078HP'] < 0 : 
		A_CO01MOR078HP = 999  
	else: 
		A_CO01MOR078HP = data['CO01MOR078HP']

	if data['CO01MOR078OT'] < 0 : 
		A_CO01MOR078OT = 999  
	else: 
		A_CO01MOR078OT = data['CO01MOR078OT']

	if data['CO01MOR078CC'] < 0 : 
		A_CO01MOR078CC = 999  
	else: 
		A_CO01MOR078CC = data['CO01MOR078CC']


	RECMORA120 = min(A_CO01MOR078RO, A_CO01MOR078IN, A_CO01MOR078OT, A_CO01MOR078CO, A_CO01MOR078VE, A_CO01MOR078CC, A_CO01MOR078HP)

	#*-------------------------*

	if data['CO01MOR079RO'] < 0:
		AUX_CO01MOR079RO = 999
	else:
		AUX_CO01MOR079RO = data['CO01MOR079RO']

	if data['CO01MOR079IN'] < 0:
		AUX_CO01MOR079IN = 999
	else:
		AUX_CO01MOR079IN = data['CO01MOR079IN']
	
	if data['CO01MOR079OT'] < 0:
		AUX_CO01MOR079OT = 999
	else:
		AUX_CO01MOR079OT = data['CO01MOR079OT']
	
	if data['CO01MOR079CO'] < 0:
		AUX_CO01MOR079CO = 999
	else:
		AUX_CO01MOR079CO = data['CO01MOR079CO']
	
	if data['CO01MOR079VE'] < 0:
		AUX_CO01MOR079VE = 999
	else:
		AUX_CO01MOR079VE = data['CO01MOR079VE']

	if data['CO01MOR079CC'] < 0:
		AUX_CO01MOR079CC = 999
	else:
		AUX_CO01MOR079CC = data['CO01MOR079CC']
	
	if data['CO01MOR079HP'] < 0:
		AUX_CO01MOR079HP = 999
	else:
		AUX_CO01MOR079HP = data['CO01MOR079HP']
	
	RECMORA_CC = min(AUX_CO01MOR079RO, AUX_CO01MOR079IN, AUX_CO01MOR079OT, AUX_CO01MOR079CO, AUX_CO01MOR079VE, AUX_CO01MOR079CC, AUX_CO01MOR079HP)
	RECMORA = min(RECMORA30, RECMORA60, RECMORA90, RECMORA120)
	RECMORACC=min(RECMORA30, RECMORA60, RECMORA90, RECMORA120,RECMORA_CC)
	#*-------------------------*

	if data['CO02NUM018TO']>=1 and (data['CO02NUM018TO'] != data['CO01NUM018CO']) and RECMORA > 0:
		RECMORA_USA = 0
	else:
		RECMORA_USA = RECMORA
	
	if RECMORA_CC == 0 and RECMORA_USA > 0:
		RECMORA_USA = 0

	#if RECMORA_CC<RECMORA:
	#	RECMORA=RECMORA_CC	
#--------------------------------------------#
#calcula variable RECMORA_CC_USA
#--------------------------------------------#
	if data['CO02NUM018TO'] >= 1 and (data['CO02NUM018TO']!=data['CO01NUM018CO']) and RECMORACC > 0:
		RECMORA_CC_USA = 0
	else:
		RECMORA_CC_USA = RECMORACC
	#print("CO02NUM018TO "+str(data["CO02NUM018TO"])+" CO01NUM018CO "+str(data['CO01NUM018CO'])+" RECMORA_CC "+str(RECMORA_CC)+" RECMORA "+str(RECMORA)+" RECMORA_CC_USA "+str(RECMORA_CC_USA))
#--------------------------------------------#
#calcula variable QTOT90
#--------------------------------------------#

	if data['CO01MOR004RO'] < 0:
		AUX_CO01MOR004RO = 0
	else:
		AUX_CO01MOR004RO = data['CO01MOR004RO']

	if data['CO01MOR004IN'] < 0:
		AUX_CO01MOR004IN = 0
	else:
		AUX_CO01MOR004IN = data['CO01MOR004IN']

	if data['CO01MOR004VE'] < 0:
		AUX_CO01MOR004VE = 0
	else:
		AUX_CO01MOR004VE = data['CO01MOR004VE']

	if data['CO01MOR004HP'] < 0:
		AUX_CO01MOR004HP = 0
	else:
		AUX_CO01MOR004HP = data['CO01MOR004HP']

	if data['CO01MOR004CC'] < 0:
		AUX_CO01MOR004CC = 0
	else:
		AUX_CO01MOR004CC = data['CO01MOR004CC']

	if data['CO01MOR004OT'] < 0:
		AUX_CO01MOR004OT = 0
	else:
		AUX_CO01MOR004OT = data['CO01MOR004OT']

	if data['CO01MOR004CO'] < 0:
		AUX_CO01MOR004CO = 0
	else:
		AUX_CO01MOR004CO = data['CO01MOR004CO']

	QTOT90 = AUX_CO01MOR004RO + AUX_CO01MOR004IN + AUX_CO01MOR004VE + AUX_CO01MOR004HP + AUX_CO01MOR004CC + AUX_CO01MOR004OT + AUX_CO01MOR004CO

#---------------------------------------
# calcula variable EVER9048_P
#---------------------------------------
	if data['CO01MOR071RO'] < 0:
		AUX_CO01MOR071RO = 0
	else:
		AUX_CO01MOR071RO = data['CO01MOR071RO']

	if data['CO01MOR071IN'] < 0:
		AUX_CO01MOR071IN = 0
	else:
		AUX_CO01MOR071IN = data['CO01MOR071IN']

	if data['CO01MOR071OT'] < 0:
		AUX_CO01MOR071OT = 0
	else:
		AUX_CO01MOR071OT = data['CO01MOR071OT']

	if data['CO01MOR071VE'] < 0:
		AUX_CO01MOR071VE = 0
	else:
		AUX_CO01MOR071VE = data['CO01MOR071VE']

	if data['CO01MOR071CC'] < 0:
		AUX_CO01MOR071CC = 0
	else:
		AUX_CO01MOR071CC = data['CO01MOR071CC']

	if data['CO01MOR071HP'] < 0:
		AUX_CO01MOR071HP = 0
	else:
		AUX_CO01MOR071HP = data['CO01MOR071HP']

	EVER9048_P = AUX_CO01MOR071RO+ AUX_CO01MOR071IN+ AUX_CO01MOR071OT+ AUX_CO01MOR071VE+ AUX_CO01MOR071CC+ AUX_CO01MOR071HP
#---------------------------------------#
# calculo de la variable TO_01END004
#---------------------------------------#
	if data['CO01END004RO'] < 0:
		AUX_CO01END004RO = 0
	else:
		AUX_CO01END004RO = data['CO01END004RO']

	if data['CO01END004IN'] < 0:
		AUX_CO01END004IN = 0
	else:
		AUX_CO01END004IN = data['CO01END004IN']

	if data['CO01END004VE'] < 0:
		AUX_CO01END004VE = 0
	else:
		AUX_CO01END004VE = data['CO01END004VE']

	if data['CO01END004HP'] < 0:
		AUX_CO01END004HP = 0
	else:
		AUX_CO01END004HP = data['CO01END004HP']

	if data['CO01END004CC'] < 0:
		AUX_CO01END004CC = 0
	else:
		AUX_CO01END004CC = data['CO01END004CC']

	if data['CO01END004OT'] < 0:
		AUX_CO01END004OT = 0
	else:
		AUX_CO01END004OT = data['CO01END004OT']

	if data['CO01END004CO'] < 0:
		AUX_CO01END004CO = 0
	else:
		AUX_CO01END004CO = data['CO01END004CO']

	AUX=[AUX_CO01END004RO, AUX_CO01END004IN, AUX_CO01END004VE, AUX_CO01END004HP, AUX_CO01END004CC, AUX_CO01END004OT, AUX_CO01END004CO]
	TO_01END004=np.mean(AUX)

#---------------------------------------#
#calculo de variable MMAXHIST
#---------------------------------------#
	if data['CO01MOR009RO'] < 0:
		AUX_CO01MOR009RO = 0
	else:
		AUX_CO01MOR009RO = data['CO01MOR009RO']

	if data['CO01MOR009IN'] < 0:
		AUX_CO01MOR009IN = 0
	else:
		AUX_CO01MOR009IN = data['CO01MOR009IN']

	if data['CO01MOR009VE'] < 0:
		AUX_CO01MOR009VE = 0
	else:
		AUX_CO01MOR009VE = data['CO01MOR009VE']

	if data['CO01MOR009HP'] < 0:
		AUX_CO01MOR009HP = 0
	else:
		AUX_CO01MOR009HP = data['CO01MOR009HP']

	if data['CO01MOR009CC']< 0:
		AUX_CO01MOR009CC = 0
	else:
		AUX_CO01MOR009CC = data['CO01MOR009CC']

	if data['CO01MOR009OT'] < 0:
		AUX_CO01MOR009OT = 0
	else:
		AUX_CO01MOR009OT = data['CO01MOR009OT']

	if data['CO01MOR009CO'] < 0:
		AUX_CO01MOR009CO = 0
	else:
		AUX_CO01MOR009CO = data['CO01MOR009CO']

	MMAXHIST = max(AUX_CO01MOR009RO, AUX_CO01MOR009IN, AUX_CO01MOR009VE, AUX_CO01MOR009HP, AUX_CO01MOR009CC, AUX_CO01MOR009OT, AUX_CO01MOR009CO)
#------------------------------------------#
#calculo de variable S3_OPEN6D01
#------------------------------------------#
	if data['CO01ACP002RO'] < 0:
		AUX_CO01ACP002RO = 0
	else:
		AUX_CO01ACP002RO = data['CO01ACP002RO']

	if data['CO01ACP002IN'] < 0:
		AUX_CO01ACP002IN = 0
	else:
		AUX_CO01ACP002IN = data['CO01ACP002IN']

	if data['CO01ACP002OT'] < 0:
		AUX_CO01ACP002OT = 0
	else:
		AUX_CO01ACP002OT = data['CO01ACP002OT']

	if data['CO01ACP002VE'] < 0:
		AUX_CO01ACP002VE = 0
	else:
		AUX_CO01ACP002VE = data['CO01ACP002VE']

	if data['CO01ACP002CC'] < 0:
		AUX_CO01ACP002CC = 0
	else:
		AUX_CO01ACP002CC = data['CO01ACP002CC']

	if data['CO01ACP002CO'] < 0:
		AUX_CO01ACP002CO = 0
	else:
		AUX_CO01ACP002CO = data['CO01ACP002CO']

	if data['CO01ACP002HP'] < 0:
		AUX_CO01ACP002HP = 0
	else:
		AUX_CO01ACP002HP = data['CO01ACP002HP']

	OPEN6 = AUX_CO01ACP002RO + AUX_CO01ACP002IN + AUX_CO01ACP002OT + AUX_CO01ACP002VE + AUX_CO01ACP002CO + AUX_CO01ACP002CC + AUX_CO01ACP002HP

#------------------------------------------#
#calculo de variable  S3_SALDOMOD01
#------------------------------------------#

	if data['CO01END003RO'] < 0:
		AUX_CO01END003RO = 0
	else:
		AUX_CO01END003RO = data['CO01END003RO']

	if data['CO01END003IN'] < 0:
		AUX_CO01END003IN = 0
	else:
		AUX_CO01END003IN = data['CO01END003IN']

	if data['CO01END003OT'] < 0:
		AUX_CO01END003OT = 0
	else:
		AUX_CO01END003OT = data['CO01END003OT']
 
	if data['CO01END003VE'] < 0:
		AUX_CO01END003VE = 0
	else:
		AUX_CO01END003VE = data['CO01END003VE']

	if data['CO01END003CC'] < 0:
		AUX_CO01END003CC = 0
	else:
		AUX_CO01END003CC = data['CO01END003CC']

	if data['CO01END003CO'] < 0:
		AUX_CO01END003CO = 0
	else:
		AUX_CO01END003CO = data['CO01END003CO']

	if data['CO01END003HP'] < 0:
		AUX_CO01END003HP = 0
	else:
		AUX_CO01END003HP = data['CO01END003HP']

	SALDOMO = AUX_CO01END003RO + AUX_CO01END003IN + AUX_CO01END003OT + AUX_CO01END003VE + AUX_CO01END003CC + AUX_CO01END003CO + AUX_CO01END003HP

#------------------------------------------#
#Calcular variable S4_EVER6024_PD01
#------------------------------------------#
	if data['CO01MOR056RO'] < 0 :
		AUX_CO01MOR056RO = 0 
	else: 
		AUX_CO01MOR056RO = data['CO01MOR056RO']

	if data['CO01MOR056IN'] < 0 : 
		AUX_CO01MOR056IN = 0 
	else: 
		AUX_CO01MOR056IN = data['CO01MOR056IN']

	if data['CO01MOR056OT'] < 0 :
		AUX_CO01MOR056OT = 0 
	else: 
		AUX_CO01MOR056OT = data['CO01MOR056OT']

	if data['CO01MOR056VE'] < 0 : 
		AUX_CO01MOR056VE = 0
	else: 
		AUX_CO01MOR056VE = data['CO01MOR056VE']

	if data['CO01MOR056CC'] < 0 : 
		AUX_CO01MOR056CC = 0 
	else: 
		AUX_CO01MOR056CC = data['CO01MOR056CC']

	if data['CO01MOR056HP'] < 0 :
		AUX_CO01MOR056HP = 0 
	else: 
		AUX_CO01MOR056HP = data['CO01MOR056HP']

	EVER6024_P = AUX_CO01MOR056RO+ AUX_CO01MOR056IN+ AUX_CO01MOR056OT+ AUX_CO01MOR056VE+ AUX_CO01MOR056CC+ AUX_CO01MOR056HP

#------------------------------------------#
#Calcular variable S4_QALDIAD01
#------------------------------------------#
	if data['CO01MOR001RO'] < 0 : 
		AUX_CO01MOR001RO = 0 
	else:
		AUX_CO01MOR001RO = data['CO01MOR001RO']

	if data['CO01MOR001IN'] < 0 : 
		AUX_CO01MOR001IN = 0 
	else:
		AUX_CO01MOR001IN = data['CO01MOR001IN']

	if data['CO01MOR001OT'] < 0 : 
		AUX_CO01MOR001OT = 0 
	else:
		AUX_CO01MOR001OT = data['CO01MOR001OT']
 
	if data['CO01MOR001VE'] < 0 : 
		AUX_CO01MOR001VE = 0 
	else: 
		AUX_CO01MOR001VE = data['CO01MOR001VE']

	if data['CO01MOR001CC'] < 0 :
		AUX_CO01MOR001CC = 0 
	else:
		AUX_CO01MOR001CC = data['CO01MOR001CC']

	if data['CO01MOR001CO'] < 0 : 
		AUX_CO01MOR001CO = 0 
	else: 
		AUX_CO01MOR001CO = data['CO01MOR001CO']

	if data['CO01MOR001HP'] < 0 : 
		AUX_CO01MOR001HP = 0 
	else:
		AUX_CO01MOR001HP = data['CO01MOR001HP']

	QALDIA = AUX_CO01MOR001RO + AUX_CO01MOR001IN+ AUX_CO01MOR001OT+ AUX_CO01MOR001VE+ AUX_CO01MOR001CC+ AUX_CO01MOR001CO+ AUX_CO01MOR001HP

#------------------------------------------#
#Calcular variable MMAXACTUAL
#------------------------------------------#

	if data['CO01MOR008RO'] < 0 : 
		AUX_CO01MOR008RO = 0 
	else:
		AUX_CO01MOR008RO = data['CO01MOR008RO']

	if data['CO01MOR008IN'] < 0 : 
		AUX_CO01MOR008IN = 0 
	else:
		AUX_CO01MOR008IN = data['CO01MOR008IN']

	if data['CO01MOR008VE'] < 0 : 
		AUX_CO01MOR008VE = 0 
	else:
		AUX_CO01MOR008VE = data['CO01MOR008VE']

	if data['CO01MOR008HP'] < 0 : 
		AUX_CO01MOR008HP = 0 
	else:
		AUX_CO01MOR008HP = data['CO01MOR008HP']

	if data['CO01MOR008CC'] < 0 : 
		AUX_CO01MOR008CC = 0 
	else: 
		AUX_CO01MOR008CC = data['CO01MOR008CC']

	if data['CO01MOR008OT'] < 0 : 
		AUX_CO01MOR008OT = 0 
	else:
		AUX_CO01MOR008OT = data['CO01MOR008OT']

	if data['CO01MOR008CO'] < 0 : 
		AUX_CO01MOR008CO = 0 
	else:
		AUX_CO01MOR008CO = data['CO01MOR008CO']

	MMAXACTUAL = max(AUX_CO01MOR008RO, AUX_CO01MOR008IN, AUX_CO01MOR008VE, AUX_CO01MOR008HP, AUX_CO01MOR008CC, AUX_CO01MOR008OT, AUX_CO01MOR008CO,AUX_CO01MOR008CO)

#------------------------------------------#
#Calcular variable S4_TO_01END003D01
#------------------------------------------#
	if data['CO01END003RO'] < 0 : 
		AUX_CO01END003RO = 0 
	else:
		AUX_CO01END003RO = data['CO01END003RO']

	if data['CO01END003IN'] < 0 : 
		AUX_CO01END003IN = 0 
	else:
		AUX_CO01END003IN = data['CO01END003IN']

	if data['CO01END003VE'] < 0 : 
		AUX_CO01END003VE = 0 
	else:
		AUX_CO01END003VE = data['CO01END003VE']

	if data['CO01END003HP'] < 0 : 
		AUX_CO01END003HP = 0 
	else:
		AUX_CO01END003HP = data['CO01END003HP']

	if data['CO01END003CC'] < 0 : 
		AUX_CO01END003CC = 0 
	else:
		AUX_CO01END003CC = data['CO01END003CC']

	if data['CO01END003OT'] < 0 : 
		AUX_CO01END003OT = 0 
	else: 
		AUX_CO01END003OT = data['CO01END003OT']

	if data['CO01END003CO'] < 0 : 
		AUX_CO01END003CO = 0 
	else: 
		AUX_CO01END003CO = data['CO01END003CO']

	TO_01END003 = AUX_CO01END003RO + AUX_CO01END003IN + AUX_CO01END003VE + AUX_CO01END003HP + AUX_CO01END003OT + AUX_CO01END003CO

#------------------------------------------#
#calcular variable S5_EVER3024_PD01
#------------------------------------------#
	if data['CO01MOR055RO'] < 0 : 
		AUX_CO01MOR055RO = 0 
	else: 
		AUX_CO01MOR055RO = data['CO01MOR055RO']

	if data['CO01MOR055IN'] < 0 : 
		AUX_CO01MOR055IN = 0 
	else: 
		AUX_CO01MOR055IN = data['CO01MOR055IN']
 

	if data['CO01MOR055OT'] < 0 : 
		AUX_CO01MOR055OT = 0 
	else:  
		AUX_CO01MOR055OT = data['CO01MOR055OT']

	if data['CO01MOR055VE'] < 0 : 
		AUX_CO01MOR055VE = 0 
	else: 
		AUX_CO01MOR055VE = data['CO01MOR055VE']

	if data['CO01MOR055CC'] < 0 : 
		AUX_CO01MOR055CC = 0 
	else: 
		AUX_CO01MOR055CC = data['CO01MOR055CC']

	if data['CO01MOR055HP'] < 0 : 
		AUX_CO01MOR055HP = 0 
	else: 
		AUX_CO01MOR055HP = data['CO01MOR055HP']


	EVER3024_P = AUX_CO01MOR055RO + AUX_CO01MOR055IN + AUX_CO01MOR055OT + AUX_CO01MOR055VE + AUX_CO01MOR055CC + AUX_CO01MOR055HP

#------------------------------------------#
#calcular variable SMOB6
#------------------------------------------#

	if data['CO01EXP007RO'] < 0 : 
		A_CO01EXP007RO = 0 
	else: 
		A_CO01EXP007RO = data['CO01EXP007RO']

	if data['CO01EXP007IN'] < 0 : 
		A_CO01EXP007IN = 0 
	else:  
		A_CO01EXP007IN = data['CO01EXP007IN']

	if data['CO01EXP007OT'] < 0 : 
		A_CO01EXP007OT = 0 
	else:  
		A_CO01EXP007OT = data['CO01EXP007OT']

	if data['CO01EXP007VE'] < 0 : 
		A_CO01EXP007VE = 0 
	else: 
		A_CO01EXP007VE = data['CO01EXP007VE']

	if data['CO01EXP007CC'] < 0 : 
		A_CO01EXP007CC = 0 
	else: 
		A_CO01EXP007CC = data['CO01EXP007CC']

	if data['CO01EXP007CO'] < 0 : 
		A_CO01EXP007CO = 0 
	else:  
		A_CO01EXP007CO = data['CO01EXP007CO']

	if data['CO01EXP007HP'] < 0:
		A_CO01EXP007HP = 0
	else:
		A_CO01EXP007HP = data['CO01EXP007HP']

	MOB6 = A_CO01EXP007RO + A_CO01EXP007IN+ A_CO01EXP007OT+ A_CO01EXP007VE+ A_CO01EXP007CC+ A_CO01EXP007CO+ A_CO01EXP007HP

#------------------------------------------#
#calcular variable OPEN12
#------------------------------------------#
	if data['CO01ACP003RO'] < 0:
		A_CO01ACP003RO = 0
	else: 
		A_CO01ACP003RO = data['CO01ACP003RO']

	if data['CO01ACP003IN'] < 0:
		A_CO01ACP003IN = 0 
	else:
		A_CO01ACP003IN = data['CO01ACP003IN']

	if data['CO01ACP003OT'] < 0:
		A_CO01ACP003OT = 0 
	else:
		A_CO01ACP003OT = data['CO01ACP003OT']

	if data['CO01ACP003VE'] < 0:
		A_CO01ACP003VE = 0 
	else:
		A_CO01ACP003VE = data['CO01ACP003VE']

	if data['CO01ACP003CC'] < 0:
		A_CO01ACP003CC = 0 
	else:
		A_CO01ACP003CC = data['CO01ACP003CC']

	if data['CO01ACP003CO'] < 0:
		A_CO01ACP003CO = 0 
	else:
		A_CO01ACP003CO = data['CO01ACP003CO']

	if data['CO01ACP003HP'] < 0:
		A_CO01ACP003HP = 0 
	else:
		A_CO01ACP003HP = data['CO01ACP003HP']

	OPEN12 = A_CO01ACP003RO + A_CO01ACP003IN+ A_CO01ACP003OT+ A_CO01ACP003VE+ A_CO01ACP003CO+ A_CO01ACP003CC+ A_CO01ACP003HP


#------------------------------------------#
#  RETORNA CARACTERISTICAS HIBRIDAS
#------------------------------------------#
	return QTOTAB,QTOT,SOLOREAL,MOB_SOLOREAL,EVER1206_P,EVER12012_P,EVER12018_P,EVER12024_P,EVER12036_P,EVER12048_P,CO01MOR005_TO,NEW_EVER12048_P,RECMORA30,RECMORA60,RECMORA120,RECMORA_CC,RECMORA,RECMORA_USA,QTOT90,EVER9048_P,TO_01END004,MMAXHIST,OPEN6,SALDOMO,EVER6024_P,QALDIA,MMAXACTUAL,TO_01END003,EVER3024_P,MOB6,OPEN12,RECMORA_CC_USA

#--------------------------------------------------------------------------------------------------------------#
#  FUNCION EXCLUCIONES : REALIZA LAS EXCLUSIONES 
#                        --> CLIENTES DifERENTES A PERSONA NATURAL : 70 , SCORE 0   
#                        --> CLIENTES TIPO 5  : 71 , SCORE 0
#                        --> CLIENTES TIPO 1 SIN DESEMPENO : 72 , SCORE 0
#                        --> CLIENTES FALLECIDOS : 73 , SCORE 3
#                        --> CLIENTES QUE SOLO SON CODEUDORES : 74 , SCORE 4
#                        --> CLIENTES CON TODAS SUS CUENTAS EN DEFAULT : 75 , SCORE 1 
#                        --> CLIENTES CON EXPERIENCIA MENOR O IGUAL A 6 MESES SOLO REAL : 76 , SCORE 7                       
#--------------------------------------------------------------------------------------------------------------#

def exclusiones(data,qtotab,qtot,soloreal,mob_soloreal):
	EXCLUSION = 0
	SCORE_FINAL = 0
	if data.get('TIPOID') in [2, 3]:
	#EXCLUSION CLIENTES DifERENTES A PERSONAS NATURALES
		EXCLUSION=70
		SCORE_FINAL=0
	else:
		if data['CO01NUM001RO'] == -1  and data['CO01NUM001IN'] == -1 and data['CO01NUM001VE'] == -1 and data['CO01NUM001HP'] == -1 and data['CO01NUM001CC'] == -1 and data['CO01NUM001OT'] == -1 and data['CO01NUM001CO'] == -1 and data['CO01NUM001AH'] == -1 and data['CO01NUM001CT'] == -1 :
			EXCLUSION = 71
			SCORE_FINAL = 0
		else:
			if ( data['CO01NUM001AH'] > 0 or data['CO01NUM001CT'] > 0 ) and data['CO01NUM001RO'] == -1 and data['CO01NUM001IN'] == -1 and data['CO01NUM001VE'] == -1 and data['CO01NUM001HP'] == -1 and data['CO01NUM001CC'] == -1 and data['CO01NUM001OT'] == -1 and data['CO01NUM001CO'] == -1 :
				EXCLUSION = 72
				SCORE_FINAL = 0
			else:
				if data['CO00DEM001'] == 1 or data['CO00DEM002'] == 1 :
					EXCLUSION = 73
					SCORE_FINAL = 3
				else:
					if data['CO01NUM001RO'] == -1 and data['CO01NUM001IN'] == -1 and data['CO01NUM001VE'] == -1 and data['CO01NUM001HP'] == -1 and data['CO01NUM001CC'] == -1 and data['CO01NUM001OT'] == -1 and data['CO01NUM001CO'] != -1 :
						EXCLUSION = 74
						SCORE_FINAL = 4
					else:
						if (data['CO02NUM018TO'] + data['CO02NUM020TO'] > 0) and (data['CO02NUM018TO'] + data['CO02NUM020TO']) == qtotab:
							EXCLUSION = 75
							SCORE_FINAL = 1
						else:
							if soloreal == 1 and mob_soloreal <=6 :
								EXCLUSION = 76
								SCORE_FINAL = 7
	#reporte={}
	#reporte['TIPOID']=int(data['TIPOID'])
	#reporte['CONUMIDE']=data['CONUMIDE']
	return EXCLUSION,SCORE_FINAL#,reporte

#--------------------------------------------------------------------------------------------------------------#
#  FUNCION scorecard : ESCOGE A QUE SEGMENTO DE LA POBLACION PERTENECE EL CONSULTADO PARA APLICAR   
#                      LA FORMULA DEL SCORE
#--------------------------------------------------------------------------------------------------------------#

def scorecard(data,QTOTAB,QTOT,SOLOREAL,MOB_SOLOREAL,EVER1206_P,EVER12012_P,EVER12018_P,EVER12024_P,EVER12036_P,EVER12048_P,CO01MOR005_TO,NEW_EVER12048_P,RECMORA30,RECMORA60,RECMORA120,RECMORA_CC,RECMORA,RECMORA_USA,QTOT90,EVER9048_P,TO_01END004,MMAXHIST,OPEN6,SALDOMO,EVER6024_P,QALDIA,MMAXACTUAL,TO_01END003,EVER3024_P,MOB6,OPEN12,RECMORA_CC_USA):
	if SOLOREAL == 1 :
		scoreR=segmento1(data,TO_01END004,RECMORA_USA,RECMORA60)

	if SOLOREAL == 0 and NEW_EVER12048_P >= 1 :
		scoreR=segmento2(data,RECMORA_CC_USA,QTOT90,EVER9048_P)

	if SOLOREAL == 0 and NEW_EVER12048_P < 1 and data['CO02EXP001TO'] < 25 :
		scoreR=segmento3(data,MMAXHIST,OPEN6,SALDOMO,QTOTAB)

	if SOLOREAL == 0 and NEW_EVER12048_P < 1 and data['CO02EXP001TO'] >= 25 and RECMORA_USA < 7 :
		scoreR=segmento4(data,EVER6024_P,QALDIA,RECMORA_USA,MMAXACTUAL,TO_01END003)

	if SOLOREAL == 0 and NEW_EVER12048_P < 1 and data['CO02EXP001TO'] >= 25 and RECMORA_USA >= 7 and data['CO02EXP002TO'] < 7 :
		scoreR=segmento5(data,EVER3024_P,MOB6,OPEN12,TO_01END004)

	if SOLOREAL == 0 and NEW_EVER12048_P < 1  and data['CO02EXP001TO'] >= 25 and RECMORA_USA >= 7 and data['CO02EXP002TO'] >= 7 :
		scoreR=segmento6(data,RECMORA_USA)

	return scoreR

#--------------------------------------------------------------------------------------------------------------#
#  FUNCION segmento1 : REALIZA EL CALCULO DEL SCORE PARA POBLACION DEL SEGMENTO 1   
#--------------------------------------------------------------------------------------------------------------#
def segmento1(data,to_01end004,recmora_usa,recmora60):
	
	if data['CO00DEM016'] in {-1, 56, 48, 21, 3, 28, 12, 17, 5, 13}:
		S1_CO00DEM016D01 = 1
	else:
		S1_CO00DEM016D01 = 0

#calcula variable S1_CO00DEM016D02
	if data['CO00DEM016'] in {60, 31, 25, 27, 29, 23, 1, 15, 26, 11, 19, 44, 52, 40, 68, 50, 72, 54, 64}:
		S1_CO00DEM016D02 = 1
	else:
		S1_CO00DEM016D02 = 0

#calcula variable S1_CO00DEM016D03
	if data['CO00DEM016'] in {24, 7, 46, 9}:
		S1_CO00DEM016D03 = 1
	else:
		S1_CO00DEM016D03 = 0

#calcula variable S1_CO02END001CBD01

	if data['CO02END001CB'] < 0:
		S1_CO02END001CBD01 = 1
	else:
		S1_CO02END001CBD01 = 0

#calcula variable S1_CO02END001CBD02

	if data['CO02END001CB'] >= 0 and data['CO02END001CB'] <13:
		S1_CO02END001CBD02 = 1
	else:
		S1_CO02END001CBD02 = 0

#calcula variable S1_CO02END001CBD03
	if data['CO02END001CB'] >= 13 and data['CO02END001CB'] < 36:
		S1_CO02END001CBD03 = 1
	else:
		S1_CO02END001CBD03 = 0

#calcula variable S1_CO02END001CBD04
	if data['CO02END001CB'] >= 36:
		S1_CO02END001CBD04 = 1
	else:
		S1_CO02END001CBD04 = 0

#calcula variable S1_CO01END017CCD01
	if data['CO01END017CC'] < 0:
		S1_CO01END017CCD01=1
	else: 
		S1_CO01END017CCD01=0

#calcula variable S1_CO01END017CCD02
	if 0<=data['CO01END017CC']<0.01:
		S1_CO01END017CCD02=1
	else: 
		S1_CO01END017CCD02=0

#calcula variable S1_CO01END017CCD03
	if 0.01<=data['CO01END017CC']<0.2:
		S1_CO01END017CCD03=1
	else:
		S1_CO01END017CCD03=0

#calcula variable S1_CO01END017CCD04
	if 0.2<=data['CO01END017CC']:
		S1_CO01END017CCD04=1
	else:
		S1_CO01END017CCD04=0

#calcula variable S1_CO01END018CCD01
	if data['CO01END018CC'] < 0:
		S1_CO01END018CCD01=1
	else:
		S1_CO01END018CCD01=0

#calcula variable S1_CO01END018CCD02
	if 0<=data['CO01END018CC']<0.24:
		S1_CO01END018CCD02=1
	else:
		S1_CO01END018CCD02=0

#calcula variable S1_CO01END018CCD03
	if 0.24<=data['CO01END018CC']:
		S1_CO01END018CCD03=1
	else:
		S1_CO01END018CCD03=0

#calcula variable S1_CO01END027CCD01
	if data['CO01END027CC'] < 0:
		S1_CO01END027CCD01=1
	else:
		S1_CO01END027CCD01=0

#calcula variable S1_CO01END027CCD02
	if 0<=data['CO01END027CC']<0.01:
		S1_CO01END027CCD02=1
	else:
		S1_CO01END027CCD02=0

#calcula variable S1_CO01END027CCD03
	if 0.01<=data['CO01END027CC']<0.06:
		S1_CO01END027CCD03=1
	else:
		S1_CO01END027CCD03=0

#calcula variable S1_CO01END027CCD04
	if 0.06<=data['CO01END027CC']<0.4:
		S1_CO01END027CCD04=1
	else:
		S1_CO01END027CCD04=0

#calcula variable S1_CO01END027CCD05
	if 0.4<=data['CO01END027CC']:
		S1_CO01END027CCD05=1
	else:
		S1_CO01END027CCD05=0

#calcula variable S1_CO01END027OTD01
	if data['CO01END027OT'] < 0:
		S1_CO01END027OTD01=1
	else:
		S1_CO01END027OTD01=0

#calcula variable S1_CO01END027OTD02
	if 0<=data['CO01END027OT']<0.01:
		S1_CO01END027OTD02=1
	else:
		S1_CO01END027OTD02=0

#calcula variable S1_CO01END027OTD03
	if 0.01<=data['CO01END027OT']<0.26:
		S1_CO01END027OTD03=1
	else:
		S1_CO01END027OTD03=0

#calcula variable S1_CO01END027OTD04
	if 0.26<=data['CO01END027OT']:
		S1_CO01END027OTD04=1
	else:
		S1_CO01END027OTD04=0

	if 0<=to_01end004<0.01:
		S1_TO_01END004D01=1
	else:
		S1_TO_01END004D01=0

#calcula variable S1_TO_01END004D02
	if 0.01<=to_01end004<0.0414285714:
		S1_TO_01END004D02=1
	else:
		S1_TO_01END004D02=0

#calcula variable S1_TO_01END004D03
	if 0.0414285714<=to_01end004:
		S1_TO_01END004D03=1
	else:
		S1_TO_01END004D03=0

#calcula variable S1_CO01MOR090CCD01
	if data['CO01MOR090CC'] < 0:
		S1_CO01MOR090CCD01=1
	else:
		S1_CO01MOR090CCD01=0

#calcula variable S1_CO01MOR090CCD02
	if 0<=data['CO01MOR090CC']<3.79:
		S1_CO01MOR090CCD02=1
	else:
		S1_CO01MOR090CCD02=0

#calcula variable S1_CO01MOR090CCD03
	if 3.79<=data['CO01MOR090CC']:
		S1_CO01MOR090CCD03=1
	else:
		S1_CO01MOR090CCD03=0

#calcula variable S1_CO01MOR022OTD01
	if data['CO01MOR022OT'] < 0:
		S1_CO01MOR022OTD01=1
	else:
		S1_CO01MOR022OTD01=0

#calcula variable S1_CO01MOR022OTD02
	if 0<= data['CO01MOR022OT'] <1:
		S1_CO01MOR022OTD02=1
	else:
		S1_CO01MOR022OTD02=0

#calcula variable S1_CO01MOR022OTD03
	if 1<=data['CO01MOR022OT']:
		S1_CO01MOR022OTD03=1
	else:
		S1_CO01MOR022OTD03=0

#calcula variable S1_CO01MOR101OTD01
	if data['CO01MOR101OT'] < 0:
		S1_CO01MOR101OTD01=1
	else:
		S1_CO01MOR101OTD01=0

#calcula variable S1_CO01MOR101OTD02
	if 0<=data['CO01MOR101OT']<3.55:
		S1_CO01MOR101OTD02=1
	else:
		S1_CO01MOR101OTD02=0

#calcula variable S1_CO01MOR101OTD03
	if 3.55<=data['CO01MOR101OT']<90.7:
		S1_CO01MOR101OTD03=1
	else:
		S1_CO01MOR101OTD03=0

#calcula variable S1_CO01MOR101OTD04
	if 90.7<=data['CO01MOR101OT']:
		S1_CO01MOR101OTD04=1
	else:
		S1_CO01MOR101OTD04=0

#calcula variable S1_RECMORA_USAD01
	if 999 <= recmora_usa <= 999:
		S1_RECMORA_USAD01=1
	else:
		S1_RECMORA_USAD01=0

#calcula variable S1_RECMORA_USAD02
	if 0 <= recmora_usa < 1:
		S1_RECMORA_USAD02=1
	else:
		S1_RECMORA_USAD02=0

	if 1<= recmora_usa <2 : 
		S1_RECMORA_USAD03=1 
	else:
		S1_RECMORA_USAD03=0

	if 2<=recmora_usa<7 : 
		S1_RECMORA_USAD04=1 
	else:
		S1_RECMORA_USAD04=0

	if 7<=recmora_usa<999 : 
		S1_RECMORA_USAD05=1 
	else: 
		S1_RECMORA_USAD05=0

	if 999<=recmora60<=999 : 
		S1_RECMORA60D01=1 
	else:
		S1_RECMORA60D01=0

	if 0<=recmora60<999 :  
		S1_RECMORA60D02=1 
	else: 
		S1_RECMORA60D02=0

	if data['CO01MOR005CC'] < 0 : 
		S1_CO01MOR005CCD01=1 
	else: 
		S1_CO01MOR005CCD01=0

	if 0<=data['CO01MOR005CC']<1 : 
		S1_CO01MOR005CCD02=1 
	else: 
		S1_CO01MOR005CCD02=0

	if 1<=data['CO01MOR005CC'] : 
		S1_CO01MOR005CCD03=1 
	else: 
		S1_CO01MOR005CCD03=0

	if data['CO01MOR017CC'] < 0 : 
		S1_CO01MOR017CCD01=1 
	else: 
		S1_CO01MOR017CCD01=0 

	if 0<=data['CO01MOR017CC']<1 : 
		S1_CO01MOR017CCD02=1 
	else: 
		S1_CO01MOR017CCD02=0 

	if 1<=data['CO01MOR017CC'] : 
		S1_CO01MOR017CCD03=1 
	else: 
		S1_CO01MOR017CCD03=0

	if data['CO01MOR033CC'] < 0 : 
		S1_CO01MOR033CCD01=1 
	else: 
		S1_CO01MOR033CCD01=0

	if 0<=data['CO01MOR033CC']<1 : 
		S1_CO01MOR033CCD02=1 
	else: 
		S1_CO01MOR033CCD02=0

	if 1<=data['CO01MOR033CC'] : 
		S1_CO01MOR033CCD03=1 
	else: 
		S1_CO01MOR033CCD03=0
	if data['CO01MOR034CC'] < 0 : 
		S1_CO01MOR034CCD01=1 
	else: 
		S1_CO01MOR034CCD01=0 
	
	if 0<=data['CO01MOR034CC']<1 : 
		S1_CO01MOR034CCD02=1 
	else: 
		S1_CO01MOR034CCD02=0 
	
	if 1<=data['CO01MOR034CC']<2 : 
		S1_CO01MOR034CCD03=1 
	else: 
		S1_CO01MOR034CCD03=0 
	
	if 2<=data['CO01MOR034CC'] : 
		S1_CO01MOR034CCD04=1 
	else: 
		S1_CO01MOR034CCD04=0

	if data['CO01MOR035OT'] < 0 :
		S1_CO01MOR035OTD01=1 
	else: 
		S1_CO01MOR035OTD01=0 
		
	if 0<=data['CO01MOR035OT']<1  :
		S1_CO01MOR035OTD02=1 
	else: 
		S1_CO01MOR035OTD02=0 
	
	if 1<=data['CO01MOR035OT']  :
		S1_CO01MOR035OTD03=1 
	else:   
		S1_CO01MOR035OTD03=0

	if data['CO01MOR043OT'] < 0 : 
		S1_CO01MOR043OTD01=1 
	else: 
		S1_CO01MOR043OTD01=0 
	
	if 0<=data['CO01MOR043OT']<1 : 
		S1_CO01MOR043OTD02=1 
	else: 
		S1_CO01MOR043OTD02=0 
	
	if 1<=data['CO01MOR043OT'] : 
		S1_CO01MOR043OTD03=1 
	else: 
		S1_CO01MOR043OTD03=0

	if 0<=data['CO02NUM028TO']<1 : 
		S1_CO02NUM028TOD01=1 
	else: 
		S1_CO02NUM028TOD01=0 
	
	if 1<=data['CO02NUM028TO'] : 
		S1_CO02NUM028TOD02=1 
	else: 
		S1_CO02NUM028TOD02=0

	if data['CO01NUM050AH'] < 0 :  
		S1_CO01NUM050AHD01=1 
	else: 
		S1_CO01NUM050AHD01=0 
	
	if 0<=data['CO01NUM050AH']<1 :  
		S1_CO01NUM050AHD02=1 
	else: 
		S1_CO01NUM050AHD02=0 
	
	if 1<=data['CO01NUM050AH'] : 
		S1_CO01NUM050AHD03=1 
	else: 
		S1_CO01NUM050AHD03=0

	if 0<=data['CO02NUM018TO']<1 : 
		S1_CO02NUM018TOD01=1 
	else: 
		S1_CO02NUM018TOD01=0 
	
	if 1<=data['CO02NUM018TO'] : 
		S1_CO02NUM018TOD02=1 
	else: 
		S1_CO02NUM018TOD02=0
	if data['CO00DEM003'] < 18 or data['CO00DEM003'] < 0 : 
		S1_CO00DEM003 = 18 
	elif data['CO00DEM003']>=65 : 
		S1_CO00DEM003=65 
	else: 
		S1_CO00DEM003 = data['CO00DEM003']

	if data['CO02EXP003TO']<0 : 
		S1_CO02EXP003TO=0 
	else: 
		if data['CO02EXP003TO']>=180: 
			S1_CO02EXP003TO=180 
		else: 
			S1_CO02EXP003TO = data['CO02EXP003TO']
#---------------------------------------------- 
	fX=+0.893\
		+( -0.4403 * S1_CO00DEM016D01)\
		+( 0*        S1_CO00DEM016D02)\
		+( 0.0879 *  S1_CO00DEM016D03)\
		+( 0 *       S1_CO02END001CBD01)\
		+( -0.179 *  S1_CO02END001CBD02)\
		+( 0 *       S1_CO02END001CBD03)\
		+( 0 *       S1_CO02END001CBD04)\
		+( 0 *       S1_CO01END017CCD01)\
		+( 0.3417 *  S1_CO01END017CCD02)\
		+( 0 *       S1_CO01END017CCD03)\
		+( 0 *       S1_CO01END017CCD04)\
		+( 0 *       S1_CO01END018CCD01)\
		+( -0.6231 * S1_CO01END018CCD02)\
		+( -0.7548 * S1_CO01END018CCD03)\
		+( 0 *       S1_CO01END027CCD01)\
		+( 0 *       S1_CO01END027CCD02)\
		+( 0 *       S1_CO01END027CCD03)\
		+( -0.6592 * S1_CO01END027CCD04)\
		+( -0.808 *  S1_CO01END027CCD05)\
		+( 0 *       S1_CO01END027OTD01)\
		+( 0.3973 *  S1_CO01END027OTD02)\
		+( 0 *       S1_CO01END027OTD03)\
		+( 0 *       S1_CO01END027OTD04)\
		+( 0 *       S1_TO_01END004D01)\
		+( -0.4327 * S1_TO_01END004D02)\
		+( -0.5018 * S1_TO_01END004D03)\
		+( 0  *      S1_CO01MOR090CCD01)\
		+( 0.7099 *  S1_CO01MOR090CCD02)\
		+( 0 *       S1_CO01MOR090CCD03)\
		+( 0 *       S1_CO01MOR022OTD01)\
		+( 0 *       S1_CO01MOR022OTD02)\
		+( -0.1913 * S1_CO01MOR022OTD03)\
		+( 0 *       S1_CO01MOR101OTD01)\
		+( 0 *       S1_CO01MOR101OTD02)\
		+( 0 *       S1_CO01MOR101OTD03)\
		+( -0.6861 * S1_CO01MOR101OTD04)\
		+( 0 *       S1_RECMORA_USAD01)\
		+( -2.3669 * S1_RECMORA_USAD02)\
		+( -1.2914 *   S1_RECMORA_USAD03 )\
		+( 0 *         S1_RECMORA_USAD04 )\
		+( 0 *         S1_RECMORA_USAD05 )\
		+( 0 *         S1_RECMORA60D01 )\
		+( -0.2625 *   S1_RECMORA60D02 )\
		+( 0 *         S1_CO01MOR005CCD01 )\
		+( 0.1256 *    S1_CO01MOR005CCD02 )\
		+( 0 *         S1_CO01MOR005CCD03 )\
		+( 0 *         S1_CO01MOR017CCD01 )\
		+( 0 *         S1_CO01MOR017CCD02 )\
		+( -0.5659 *   S1_CO01MOR017CCD03 )\
		+( 0 *         S1_CO01MOR033CCD01 )\
		+( -0.4971 *   S1_CO01MOR033CCD02 )\
		+( 0 *         S1_CO01MOR033CCD03 )\
		+( 0 *         S1_CO01MOR034CCD01 )\
		+( 0 *         S1_CO01MOR034CCD02 )\
		+( 0 *         S1_CO01MOR034CCD03 )\
		+( -0.6163 *   S1_CO01MOR034CCD04 )\
		+( 0 *         S1_CO01MOR035OTD01 )\
		+( 0 *         S1_CO01MOR035OTD02 )\
		+( -0.7125 *   S1_CO01MOR035OTD03 )\
		+( 0 *         S1_CO01MOR043OTD01 )\
		+( 0.3236 *    S1_CO01MOR043OTD02 )\
		+( 0 *         S1_CO01MOR043OTD03 )\
		+( 0 *         S1_CO02NUM028TOD01 )\
		+( -1.0632 *   S1_CO02NUM028TOD02 )\
		+( 0 *         S1_CO01NUM050AHD01 )\
		+( 0 *         S1_CO01NUM050AHD02 )\
		+( 0.2277 *    S1_CO01NUM050AHD03 )\
		+( 0 *         S1_CO02NUM018TOD01 )\
		+( -1.2199 *   S1_CO02NUM018TOD02 )\
		+( 0.00997 *   S1_CO00DEM003 )\
		+( 0.00275 *   S1_CO02EXP003TO )
#----------------------------------------------
#calcula score_alineado
	redo=truncate(fX,5)
	score_alineado = truncate((68.784667 * redo ) + 589.447003,1)
	score_alineado=int(score_alineado)
#calcula score final
	if score_alineado <=150:
		ScoreFinal = 150

	if 150<= score_alineado <=950: 
		ScoreFinal = score_alineado

	if score_alineado >950: 
		ScoreFinal = 950
#----------------------------------------------
	reporte={}
	#reporte['TIPOID']=int(data['TIPOID'])
	#reporte['CONUMIDE']=data['CONUMIDE']
	reporte['scoreValue']=ScoreFinal
	reporte['scoreSegment']=1
	#reporte['TO_01END004']=int(to_01end004)
	#reporte['RECMORA_USA']=int(recmora_usa)
	#reporte['RECMORA60']=int(recmora60)
	#reporte['S1_CO00DEM016D01']=int(S1_CO00DEM016D01)
	#reporte['S1_CO00DEM016D03']=int(S1_CO00DEM016D03)
	#reporte['S1_CO02END001CBD02']=int(S1_CO02END001CBD02)
	#reporte['S1_CO01END017CCD02']=int(S1_CO01END017CCD02)
	#reporte['S1_CO01END018CCD02']=int(S1_CO01END018CCD02)
	#reporte['S1_CO01END018CCD03']=int(S1_CO01END018CCD03)
	#reporte['S1_CO01END027CCD04']=int(S1_CO01END027CCD04)
	#reporte['S1_CO01END027CCD05']=int(S1_CO01END027CCD05)
	#reporte['S1_CO01END027OTD02']=int(S1_CO01END027OTD02)
	#reporte['S1_TO_01END004D02']= int(S1_TO_01END004D02)
	#reporte['S1_TO_01END004D03']= int(S1_TO_01END004D03)
	#reporte['S1_CO01MOR090CCD02']=int(S1_CO01MOR090CCD02)
	#reporte['S1_CO01MOR022OTD03']=int(S1_CO01MOR022OTD03)
	#reporte['S1_CO01MOR101OTD04']=int(S1_CO01MOR101OTD04)
	#reporte['S1_RECMORA_USAD02']= int(S1_RECMORA_USAD02)
	#reporte['S1_RECMORA_USAD03']= int(S1_RECMORA_USAD03)
	#reporte['S1_RECMORA60D02']=int(S1_RECMORA60D02)
	#reporte['S1_CO01MOR005CCD02']=int(S1_CO01MOR005CCD02)
	#reporte['S1_CO01MOR017CCD03']=int(S1_CO01MOR017CCD03)
	#reporte['S1_CO01MOR033CCD02']=int(S1_CO01MOR033CCD02)
	#reporte['S1_CO01MOR034CCD04']=int(S1_CO01MOR034CCD04)
	#reporte['S1_CO01MOR035OTD03']=int(S1_CO01MOR035OTD03)
	#reporte['S1_CO01MOR043OTD02']=int(S1_CO01MOR043OTD02)
	#reporte['S1_CO02NUM028TOD02']=int(S1_CO02NUM028TOD02)
	#reporte['S1_CO01NUM050AHD03']=int(S1_CO01NUM050AHD03)
	#reporte['S1_CO02NUM018TOD02']=int(S1_CO02NUM018TOD02)
	#reporte['S1_CO00DEM003']=int(S1_CO00DEM003)
	#reporte['S1_CO02EXP003TO']=int(S1_CO02EXP003TO)
	return reporte
#--------------------------------------------------------------------------------------------------------------#
#  FUNCION segmento2 : REALIZA EL CALCULO DEL SCORE PARA POBLACION DEL SEGMENTO 2   
#--------------------------------------------------------------------------------------------------------------#
def segmento2(data,recmora_cc_usa,qtot90,ever9048_p):
	
#calcula variable S2_CO01NUM050AHD01
	if data['CO01NUM050AH'] < 0:
		S2_CO01NUM050AHD01 = 1
	else:
		S2_CO01NUM050AHD01 = 0
#calcula variable S2_CO01NUM050AHD02
	if 0 <= data['CO01NUM050AH'] < 1:
		S2_CO01NUM050AHD02 = 1
	else:
		S2_CO01NUM050AHD02 = 0
#calcula variable S2_CO01NUM050AHD03
	if 1 <= data['CO01NUM050AH'] < 2:
		S2_CO01NUM050AHD03 = 1
	else:
		S2_CO01NUM050AHD03 = 0
#calcula variable S2_CO01NUM050AHD04
	if 2 <= data['CO01NUM050AH']:
		S2_CO01NUM050AHD04 = 1
	else:
		S2_CO01NUM050AHD04 = 0
#calcula variable S2_CO01END004IND01
	if data['CO01END004IN'] < 0:
		S2_CO01END004IND01 = 1
	else:
		S2_CO01END004IND01 = 0
#calcula variable S2_CO01END004IND02
	if 0 <= data['CO01END004IN'] < 0.1:
		S2_CO01END004IND02 = 1
	else:
		S2_CO01END004IND02 = 0
#calcula variable S2_CO01END004IND03
	if 0.1 <= data['CO01END004IN'] < 2.22:
		S2_CO01END004IND03 = 1
	else:
		S2_CO01END004IND03 = 0
#calcula variable S2_CO01END004IND04
	if 2.22 <= data['CO01END004IN']:
		S2_CO01END004IND04 = 1
	else:
		S2_CO01END004IND04 = 0
#calcula variable S2_CO01END012OTD01
	if data['CO01END012OT'] < 0:
		S2_CO01END012OTD01 = 1
	else:
		S2_CO01END012OTD01 = 0
#calcula variable S2_CO01END012OTD02
	if 0 <= data['CO01END012OT'] < 0.19:
		S2_CO01END012OTD02 = 1
	else:
		S2_CO01END012OTD02 = 0
#calcula variable S2_CO01END012OTD03
	if 0.19 <= data['CO01END012OT']:
		S2_CO01END012OTD03 = 1
	else:
		S2_CO01END012OTD03 = 0
#calcula variable S2_CO01NUM049CCD01
	if data['CO01NUM049CC'] < 0:
		S2_CO01NUM049CCD01 = 1
	else:
		S2_CO01NUM049CCD01 = 0
#calcula variable S2_CO01NUM049CCD02
	if 0 <= data['CO01NUM049CC'] < 1:
		S2_CO01NUM049CCD02 = 1
	else:
		S2_CO01NUM049CCD02 = 0
#calcula variable S2_CO01NUM049CCD03
	if 1 <= data['CO01NUM049CC']:
		S2_CO01NUM049CCD03 = 1
	else:
		S2_CO01NUM049CCD03 = 0
#calcula variable S2_CO01END089ROD01
	if data['CO01END089RO'] < 0:
		S2_CO01END089ROD01 = 1
	else:
		S2_CO01END089ROD01 = 0
#calcula variable S2_CO01END089ROD02
	if -1 < data['CO01END089RO'] < 44.38:
		S2_CO01END089ROD02 = 1
	else:
		S2_CO01END089ROD02 = 0
#calcula variable S2_CO01END089ROD03
	if 44.38 <= data['CO01END089RO'] < 75.32:
		S2_CO01END089ROD03 = 1
	else:
		S2_CO01END089ROD03 = 0
#calcula variable S2_CO01END089ROD04
	if 75.32 <= data['CO01END089RO'] < 95.61:
		S2_CO01END089ROD04 = 1
	else:
		S2_CO01END089ROD04 = 0
#calcula variable S2_CO01END089ROD05
	if 95.61 <= data['CO01END089RO']:
		S2_CO01END089ROD05 = 1
	else:
		S2_CO01END089ROD05 = 0
#calcula variable S2_CO02END017CBD01
	if data['CO02END017CB'] < 0:
		S2_CO02END017CBD01 = 1
	else:
		S2_CO02END017CBD01 = 0
#calcula variable S2_CO02END017CBD02
	if 0 <= data['CO02END017CB'] < 9.14:
		S2_CO02END017CBD02 = 1
	else:
		S2_CO02END017CBD02 = 0
#calcula variable S2_CO02END017CBD03
	if 9.14 <= data['CO02END017CB'] < 89.85:
		S2_CO02END017CBD03 = 1
	else:
		S2_CO02END017CBD03 = 0
#calcula variable S2_CO02END017CBD04
	if 89.85 <= data['CO02END017CB']:
		S2_CO02END017CBD04 = 1
	else:
		S2_CO02END017CBD04 = 0
#calcula variable S2_CO01ACP009OTD01
	if data['CO01ACP009OT'] <0 :
		S2_CO01ACP009OTD01 = 1
	else:
		S2_CO01ACP009OTD01 = 0
#calcula variable S2_CO01ACP009OTD02
	if 0 <= data['CO01ACP009OT'] < 1:
		S2_CO01ACP009OTD02 = 1
	else:
		S2_CO01ACP009OTD02 = 0
#calcula variable S2_CO01ACP009OTD03
	if 1 <= data['CO01ACP009OT']:
		S2_CO01ACP009OTD03 = 1
	else:
		S2_CO01ACP009OTD03 = 0

	if recmora_cc_usa == 0:
		S2_RECMORA_CC_USAD01 = 1
	else:
		S2_RECMORA_CC_USAD01 = 0
#calcula variable S2_RECMORA_CC_USAD02
	if 0 < recmora_cc_usa <= 2:
		S2_RECMORA_CC_USAD02 = 1
	else:
		S2_RECMORA_CC_USAD02 = 0
#calcula variable S2_RECMORA_CC_USAD03
	if 2 < recmora_cc_usa <= 5:
		S2_RECMORA_CC_USAD03 = 1
	else:
		S2_RECMORA_CC_USAD03 = 0

	#calcula variable S2_RECMORA_CC_USAD04
	if 5 < recmora_cc_usa <= 10:
		S2_RECMORA_CC_USAD04 = 1
	else:
		S2_RECMORA_CC_USAD04 = 0

#calcula variable S2_RECMORA_CC_USAD05
	if 10 < recmora_cc_usa:
		S2_RECMORA_CC_USAD05 = 1
	else:
		S2_RECMORA_CC_USAD05 = 0
#calcula variable S2_CO01MOR080CCD01
	if data['CO01MOR080CC'] <0 :
		S2_CO01MOR080CCD01 = 1
	else:
		S2_CO01MOR080CCD01 = 0
#calcula variable S2_CO01MOR080CCD02
	if 0 <= data['CO01MOR080CC'] < 15.53:
		S2_CO01MOR080CCD02 = 1
	else:
		S2_CO01MOR080CCD02 = 0
#calcula variable S2_CO01MOR080CCD03
	if 15.53 <= data['CO01MOR080CC'] < 89.81:
		S2_CO01MOR080CCD03 = 1
	else:
		S2_CO01MOR080CCD03 = 0
#calcula variable S2_CO01MOR080CCD04
	if 89.81 <= data['CO01MOR080CC']:
		S2_CO01MOR080CCD04 = 1
	else:
		S2_CO01MOR080CCD04 = 0

	#calcula variable S2_CO02EXP001TO

	if data['CO02EXP001TO'] < 0 :
		S2_CO02EXP001TO = 0
	else: 
		S2_CO02EXP001TO = data['CO02EXP001TO']


	if 0 <= ever9048_p < 2:
		S2_EVER9048_PD01 = 1
	else:
		S2_EVER9048_PD01 = 0

#calcula variable S2_EVER9048_PD02 
	if 2 <= ever9048_p:
		S2_EVER9048_PD02 = 1
	else: 
		S2_EVER9048_PD02 = 0
	

	S2_QTOT90 = qtot90

#calcula FX

	fX = -0.687310435155339\
		+ ( 0 * S2_CO01NUM050AHD01 )\
		+ ( 0 * S2_CO01NUM050AHD02 )\
		+ ( 0.0949668643306164 * S2_CO01NUM050AHD03 )\
		+ ( 0.120011105505764  * S2_CO01NUM050AHD04 )\
		+ ( 0 * S2_CO01END004IND01 )\
		+ ( 0.153119666761014  * S2_CO01END004IND02 )\
		+ ( 0 * S2_CO01END004IND03 )\
		+ ( -1.58740371767762  * S2_CO01END004IND04 )\
		+ ( 0 * S2_CO01END012OTD01 )\
		+ ( 0 * S2_CO01END012OTD02 )\
		+ ( -0.525726539018678* S2_CO01END012OTD03 )\
		+ ( 0 * S2_CO01NUM049CCD01 )\
		+ ( 0 * S2_CO01NUM049CCD02 )\
		+ ( -1.54131581810944  * S2_CO01NUM049CCD03 )\
		+ ( 0 * S2_CO01END089ROD01 )\
		+ ( 0.404046663477819  * S2_CO01END089ROD02 )\
		+ ( 0.0740434181165722 * S2_CO01END089ROD03 )\
		+ ( 0 * S2_CO01END089ROD04 )\
		+ ( -0.562829092330773 * S2_CO01END089ROD05 )\
		+ ( 0 * S2_CO02END017CBD01 )\
		+ ( 0.265616350953963  * S2_CO02END017CBD02 )\
		+ ( 0 * S2_CO02END017CBD03 )\
		+ ( 0 * S2_CO02END017CBD04 )\
		+ ( 0 * S2_CO01ACP009OTD01 )\
		+ ( 0 * S2_CO01ACP009OTD02 )\
		+ ( 0.291160139691878 * S2_CO01ACP009OTD03 )\
		+ ( -1.76331745103009  * S2_RECMORA_CC_USAD01 )\
		+ ( 0 * S2_RECMORA_CC_USAD02 )\
		+ ( 1.03987306059893 * S2_RECMORA_CC_USAD03 )\
		+ ( 1.50222460644882 * S2_RECMORA_CC_USAD04 )\
		+ ( 1.79778413378043 * S2_RECMORA_CC_USAD05 )\
		+ ( 0 * S2_CO01MOR080CCD01 )\
		+ ( 0 * S2_CO01MOR080CCD02 )\
		+ ( 0 * S2_CO01MOR080CCD03 )\
		+ ( 0.270573472023925 * S2_CO01MOR080CCD04 )\
		+ ( -0.908174190097898 * S2_QTOT90 )\
		+ ( 0.00158013079437067 * S2_CO02EXP001TO )\
		+ ( 0 * S2_EVER9048_PD01 )\
		+ ( -0.400483012032249 * S2_EVER9048_PD02 )
#----------------------------------------------

#calcula ScoreAlineado
	redo=truncate(fX,5)
	ScoreAlineado=truncate((71.715984 * redo) + 579.641970,1)
	ScoreAlineado=int(ScoreAlineado)
#calcula ScoreFinal
	if ScoreAlineado<=150:
		ScoreFinal=150

	if 150<= ScoreAlineado <=950:
		ScoreFinal = ScoreAlineado

	if ScoreAlineado > 950:
		ScoreFinal = 950

	reporte={}
	#reporte['TIPOID']=int(data['TIPOID'])
	#reporte['CONUMIDE']=data['CONUMIDE']
	reporte['scoreValue']=ScoreFinal
	reporte['scoreSegment']=2
	#reporte['RECMORA_CC_USA']=int(recmora_cc_usa) 
	#reporte['QTOT90']=int(qtot90)
	#reporte['EVER9048_P']=int(ever9048_p)
	#reporte['S2_CO01NUM050AHD03']=int(S2_CO01NUM050AHD03)
	#reporte['S2_CO01NUM050AHD04']=int(S2_CO01NUM050AHD04)
	#reporte['S2_CO01END004IND02']=int(S2_CO01END004IND02)
	#reporte['S2_CO01END004IND04']=int(S2_CO01END004IND04)
	#reporte['S2_CO01END012OTD03']=int(S2_CO01END012OTD03)
	#reporte['S2_CO01NUM049CCD03']=int(S2_CO01NUM049CCD03)
	#reporte['S2_CO01END089ROD02']=int(S2_CO01END089ROD02)
	#reporte['S2_CO01END089ROD03']=int(S2_CO01END089ROD03)
	#reporte['S2_CO01END089ROD05']=int(S2_CO01END089ROD05)
	#reporte['S2_CO02END017CBD02']=int(S2_CO02END017CBD02)
	#reporte['S2_CO01ACP009OTD03']=int(S2_CO01ACP009OTD03)
	#reporte['S2_RECMORA_CC_USAD01']=int(S2_RECMORA_CC_USAD01)
	#reporte['S2_RECMORA_CC_USAD03']=int(S2_RECMORA_CC_USAD03)
	#reporte['S2_RECMORA_CC_USAD04']=int(S2_RECMORA_CC_USAD04)
	#reporte['S2_RECMORA_CC_USAD05']=int(S2_RECMORA_CC_USAD05)
	#reporte['S2_CO01MOR080CCD04']=int(S2_CO01MOR080CCD04)
	#reporte['S2_QTOT90']=int(S2_QTOT90)
	#reporte['S2_CO02EXP001TO']=int(S2_CO02EXP001TO)
	#reporte['S2_EVER9048_PD02']=int(S2_EVER9048_PD02)
	return reporte
#--------------------------------------------------------------------------------------------------------------#
#  FUNCION segmento3 : REALIZA EL CALCULO DEL SCORE PARA POBLACION DEL SEGMENTO 3   
#--------------------------------------------------------------------------------------------------------------#
def segmento3(data,mmaxhist,open6,saldomo,qtotab):
	
	#calcula variable S3_CO02EXP008CCD01
	if data['CO02EXP008CC'] < 0:
		S3_CO02EXP008CCD01 = 1
	else:
		S3_CO02EXP008CCD01 = 0

#calcula variable S3_CO02EXP008CCD02
	if data['CO02EXP008CC'] == 0:
		S3_CO02EXP008CCD02 = 1
	else:
		S3_CO02EXP008CCD02 = 0

#calcula variable S3_CO02EXP008CCD03
	if 0 < data['CO02EXP008CC']:
		S3_CO02EXP008CCD03 = 1
	else:
		S3_CO02EXP008CCD03 = 0

#calcula variable S3_CO01EXP008COD01
	if data['CO01EXP008CO'] < 0:
		S3_CO01EXP008COD01 = 1
	else:
		S3_CO01EXP008COD01 = 0

#calcula variable S3_CO01EXP008COD02
	if 0 <= data['CO01EXP008CO']:
		S3_CO01EXP008COD02 = 1
	else:
		S3_CO01EXP008COD02 = 0

#calcula variable S3_CO00DEM003
	if data['CO00DEM003'] < 18 or data['CO00DEM003'] < -1:
		S3_CO00DEM003 = 18
	else:
		if data['CO00DEM003'] > 65:
			S3_CO00DEM003 = 65
		else:
			S3_CO00DEM003 = data['CO00DEM003']

#calcula variable S3_CO01MOR008IND01
	if data['CO01MOR008IN'] < 0:
		S3_CO01MOR008IND01 = 1
	else:
		S3_CO01MOR008IND01 = 0

#calcula variable S3_CO01MOR008IND02
	if 0 <= data['CO01MOR008IN'] < 1:
		S3_CO01MOR008IND02 = 1
	else:
		S3_CO01MOR008IND02 = 0

#calcula variable S3_CO01MOR008IND03
	if 1 <= data['CO01MOR008IN']:
		S3_CO01MOR008IND03 = 1
	else:
		S3_CO01MOR008IND03 = 0

#calcula variable S3_CO01MOR009IND01
	if data['CO01MOR009IN'] < 0:
		S3_CO01MOR009IND01 = 1
	else:
		S3_CO01MOR009IND01 = 0

#calcula variable S3_CO01MOR009IND02
	if 0 <= data['CO01MOR009IN'] < 1:
		S3_CO01MOR009IND02 = 1
	else:
		S3_CO01MOR009IND02 = 0

#calcula variable S3_CO01MOR009IND03
	if 1 <= data['CO01MOR009IN']:
		S3_CO01MOR009IND03 = 1
	else:
		S3_CO01MOR009IND03 = 0

#calcula variable S3_CO01NUM042IND01
	if data['CO01NUM042IN'] < 0:
		S3_CO01NUM042IND01 = 1
	else:
		S3_CO01NUM042IND01 = 0

#calcula variable S3_CO01NUM042IND02
	if 0 <= data['CO01NUM042IN'] < 1:
		S3_CO01NUM042IND02 = 1
	else:
		S3_CO01NUM042IND02 = 0

#calcula variable S3_CO01NUM042IND03
	if 1 <= data['CO01NUM042IN']:
		S3_CO01NUM042IND03 = 1
	else:
		S3_CO01NUM042IND03 = 0

#calcula variable MMAXHIST
	if mmaxhist ==0:
		S3_MMAXHISTD01 = 1
	else:
		S3_MMAXHISTD01 = 0

#calcula variable S3_MMAXHISTD02
	if 1 <= mmaxhist < 2:
		S3_MMAXHISTD02 = 1
	else:
		S3_MMAXHISTD02 = 0

#calcula variable S3_MMAXHISTD03
	if 2 <= mmaxhist < 3:
		S3_MMAXHISTD03 = 1
	else:
		S3_MMAXHISTD03 = 0

#calcula variable S3_MMAXHISTD04
	if 3 <= mmaxhist <= 8:
		S3_MMAXHISTD04 = 1
	else:
		S3_MMAXHISTD04 = 0

#calcula variable S3_OPEN6D01
	if 0 <= open6 < 1:
		S3_OPEN6D01=1
	else:
		S3_OPEN6D01=0

#calcula variable S3_OPEN6D02
	if 1 <= open6 < 2:
		S3_OPEN6D02 = 1
	else:
		S3_OPEN6D02 = 0

#calcula variable S3_OPEN6D03
	if 2 <= open6 < 3:
		S3_OPEN6D03 = 1
	else:
		S3_OPEN6D03 = 0

#calcula variable S3_OPEN6D04
	if 3 <= open6:
		S3_OPEN6D04 = 1
	else:
		S3_OPEN6D04 = 0

#calcula variable S3_CO01NUM001OTD01
	if data['CO01NUM001OT'] < 0:
		S3_CO01NUM001OTD01 = 1
	else:
		S3_CO01NUM001OTD01 = 0

#calcula variable S3_CO01NUM001OTD02
	if 1 <= data['CO01NUM001OT']:
		S3_CO01NUM001OTD02 = 1
	else:
		S3_CO01NUM001OTD02 = 0

#calcula variable S3_CO01END020ROD01
	if data['CO01END020RO'] < 0:
		S3_CO01END020ROD01 = 1
	else:
		S3_CO01END020ROD01 = 0

#calcula variable S3_CO01END020ROD02
	if -1 < data['CO01END020RO'] < 0.12:
		S3_CO01END020ROD02 = 1
	else:
		S3_CO01END020ROD02 = 0

#calcula variable S3_CO01END020ROD03
	if 0.12 <= data['CO01END020RO'] < 0.39:
		S3_CO01END020ROD03 = 1
	else:
		S3_CO01END020ROD03 = 0

#calcula variable S3_CO01END020ROD04
	if 0.39 <= data['CO01END020RO'] < 1:
		S3_CO01END020ROD04 = 1
	else:
		S3_CO01END020ROD04 = 0

#calcula variable S3_CO01END020ROD05
	if 1 <= data['CO01END020RO']:
		S3_CO01END020ROD05 = 1
	else:
		S3_CO01END020ROD05 = 0

#calcula variable S3_CO01END080ROD01
	if data['CO01END080RO'] < 0:
		S3_CO01END080ROD01 = 1
	else:
		S3_CO01END080ROD01 = 0

#calcula variable S3_CO01END080ROD02
	if 0 <= data['CO01END080RO'] < 77.38:
		S3_CO01END080ROD02 = 1
	else:
		S3_CO01END080ROD02 = 0

#calcula variable S3_CO01END080ROD03
	if 77.38 <= data['CO01END080RO']:
		S3_CO01END080ROD03 = 1
	else:
		S3_CO01END080ROD03 = 0

#calcula variable S3_CO01END085ROD01
	if data['CO01END085RO'] < 0:
		S3_CO01END085ROD01 = 1
	else:
		S3_CO01END085ROD01 = 0

#calcula variable S3_CO01END085ROD02
	if 0 <= data['CO01END085RO'] < 1:
		S3_CO01END085ROD02 = 1
	else:
		S3_CO01END085ROD02 = 0

#calcula variable S3_CO01END085ROD03
	if 1 <= data['CO01END085RO']:
		S3_CO01END085ROD03 = 1
	else:
		S3_CO01END085ROD03 = 0

	if 0 == saldomo: 
		S3_SALDOMOD01 = 1
	else:
		S3_SALDOMOD01 = 0

#calcula variable S3_SALDOMOD02
	if 0 < saldomo < 0.4:
		S3_SALDOMOD02 = 1
	else:
		S3_SALDOMOD02 = 0

#calcula variable S3_SALDOMOD03
	if 0.4 <= saldomo:
		S3_SALDOMOD03 = 1
	else:
		S3_SALDOMOD03 = 0

#calcula variable S3_QTOTABD01
	if qtotab < 2:
		S3_QTOTABD01 = 1
	else: 
		S3_QTOTABD01 = 0

#calcula variable S3_QTOTABD02
	if 2<=qtotab < 3:
		S3_QTOTABD02 = 1
	else:
		S3_QTOTABD02 = 0

#calcula variable S3_QTOTABD03
	if 3 <= qtotab < 4:
		S3_QTOTABD03 = 1
	else:
		S3_QTOTABD03 = 0

#calcula variable S3_QTOTABD04
	if 4<=qtotab:
		S3_QTOTABD04 = 1
	else:
		S3_QTOTABD04 = 0

#calcula variable S3_CO01END006ROD01
	if data['CO01END006RO'] < 0:
		S3_CO01END006ROD01 = 1
	else:
		S3_CO01END006ROD01 = 0

#calcula variable S3_CO01END006ROD02
	if -1 < data['CO01END006RO'] < 0.08:
		S3_CO01END006ROD02 = 1
	else:
		S3_CO01END006ROD02 = 0

#calcula variable S3_CO01END006ROD03
	if 0.08 <= data['CO01END006RO'] < 0.16:
		S3_CO01END006ROD03 = 1
	else:
		S3_CO01END006ROD03 = 0

#calcula variable S3_CO01END006ROD04
	if 0.16<=data['CO01END006RO']:
		S3_CO01END006ROD04 = 1
	else:
		S3_CO01END006ROD04 = 0

#calcula variable S3_CO02EXP001TO
	if data['CO02EXP001TO'] < 0:
		S3_CO02EXP001TO = 0
	else:
		S3_CO02EXP001TO = data['CO02EXP001TO']


	fX =+ 0.90877952206659 \
		+ ( 0 * S3_CO02EXP008CCD01 )\
		+ ( 0 * S3_CO02EXP008CCD02 )\
		+ ( -0.492783931675702 * S3_CO02EXP008CCD03 )\
		+ ( 0 * S3_CO01EXP008COD01 )\
		+ ( -0.224381219217488 * S3_CO01EXP008COD02 )\
		+ ( 0.0150554692462039 * S3_CO00DEM003 )\
		+ ( 0 * S3_CO01MOR008IND01 )\
		+ ( 0.210734252647839 * S3_CO01MOR008IND02 )\
		+ ( 0 * S3_CO01MOR008IND03 )\
		+ ( 0 * S3_CO01MOR009IND01 )\
		+ ( 0 * S3_CO01MOR009IND02 )\
		+ ( -0.462003844750069 * S3_CO01MOR009IND03 )\
		+ ( 0 * S3_CO01NUM042IND01 )\
		+ ( 0 * S3_CO01NUM042IND02 )\
		+ ( 0.197497551135911 * S3_CO01NUM042IND03 )\
		+ ( 0 * S3_MMAXHISTD01 )\
		+ ( -1.34598421228623 * S3_MMAXHISTD02 )\
		+ ( -1.96392698481601 * S3_MMAXHISTD03 )\
		+ ( -2.34547440524126 * S3_MMAXHISTD04 )\
		+ ( 0 * S3_OPEN6D01 )\
		+ ( 0 * S3_OPEN6D02 )\
		+ ( 0 * S3_OPEN6D03 )\
		+ ( -0.456803661869319 * S3_OPEN6D04 )\
		+ ( 0 * S3_CO01NUM001OTD01 )\
		+ ( -0.232307431178125 * S3_CO01NUM001OTD02 )\
		+ ( 0 * S3_CO01END020ROD01 )\
		+ ( -0.743609481989403 * S3_CO01END020ROD02 )\
		+ ( 0 * S3_CO01END020ROD03 )\
		+ ( 0 * S3_CO01END020ROD04 )\
		+ ( 0.527490692805977 * S3_CO01END020ROD05 )\
		+ ( 0 * S3_CO01END080ROD01 )\
		+ ( 0.434597194919375 * S3_CO01END080ROD02 )\
		+ ( 0 * S3_CO01END080ROD03 )\
		+ ( 0 * S3_CO01END085ROD01 )\
		+ ( 0 * S3_CO01END085ROD02 )\
		+ ( -0.919711175500004 * S3_CO01END085ROD03 )\
		+ ( 0 * S3_SALDOMOD01 )\
		+ ( -0.85355556945344 * S3_SALDOMOD02 )\
		+ ( -1.65124647082393 * S3_SALDOMOD03 )\
		+ ( 0.34092307200629 * S3_QTOTABD01 )\
		+ ( 0 * S3_QTOTABD02 )\
		+ ( 0 * S3_QTOTABD03 )\
		+ ( 0 * S3_QTOTABD04 )\
		+ ( 0 * S3_CO01END006ROD01 )\
		+ ( 0 * S3_CO01END006ROD02 )\
		+ ( 0 * S3_CO01END006ROD03 )\
		+ ( -0.447784556294255 * S3_CO01END006ROD04 )\
		+ ( 0.0403751042186628 * S3_CO02EXP001TO )
#----------------------------------------------------------
#Calculo del score alineado
	redo=truncate(fX,5)
	ScoreAlineado = truncate((64.572324 * redo) + 600.404381,1)
	ScoreAlineado=int(ScoreAlineado)
#Calculo del score final
	if ScoreAlineado <=150:
		ScoreFinal = 150 

	if 150<= ScoreAlineado <=950:
		ScoreFinal = ScoreAlineado

	if ScoreAlineado >950:
		ScoreFinal = 950
	reporte={}
	#reporte['TIPOID']=int(data['TIPOID'])
	#reporte['CONUMIDE']=data['CONUMIDE']
	reporte['scoreValue']=ScoreFinal
	reporte['scoreSegment']=3
	#reporte['MMAXHIST']=int(mmaxhist)
	#reporte['OPEN6']=int(open6)
	#reporte['SALDOMO']=int(saldomo)
	#reporte['QTOTAB']=int(qtotab )
	#reporte['S3_CO02EXP008CCD03']=int(S3_CO02EXP008CCD03)
	#reporte['S3_CO01EXP008COD02']=int(S3_CO01EXP008COD02)
	#reporte['S3_CO00DEM003']=int(S3_CO00DEM003)
	#reporte['S3_CO01MOR008IND02']=int(S3_CO01MOR008IND02)
	#reporte['S3_CO01MOR009IND03']=int(S3_CO01MOR009IND03)
	#reporte['S3_CO01NUM042IND03']=int(S3_CO01NUM042IND03)
	#reporte['S3_MMAXHISTD02']=int(S3_MMAXHISTD02)
	#reporte['S3_MMAXHISTD03']=int(S3_MMAXHISTD03)
	#reporte['S3_MMAXHISTD04']=int(S3_MMAXHISTD04)
	#reporte['S3_OPEN6D04']=int(S3_OPEN6D04)
	#reporte['S3_CO01NUM001OTD02']=int(S3_CO01NUM001OTD02)
	#reporte['S3_CO01END020ROD02']=int(S3_CO01END020ROD02)
	#reporte['S3_CO01END020ROD05']=int(S3_CO01END020ROD05)
	#reporte['S3_CO01END080ROD02']=int(S3_CO01END080ROD02)
	#reporte['S3_CO01END085ROD03']=int(S3_CO01END085ROD03)
	#reporte['S3_SALDOMOD02']=int(S3_SALDOMOD02)
	#reporte['S3_SALDOMOD03']=int(S3_SALDOMOD03)
	#reporte['S3_QTOTABD01']=int(S3_QTOTABD01)
	#reporte['S3_CO01END006ROD04']=int(S3_CO01END006ROD04)
	#reporte['S3_CO02EXP001TO']=int(S3_CO02EXP001TO)
	return reporte
#--------------------------------------------------------------------------------------------------------------#
#  FUNCION segmento4 : REALIZA EL CALCULO DEL SCORE PARA POBLACION DEL SEGMENTO 4   
#--------------------------------------------------------------------------------------------------------------#
def segmento4(data,ever6024_p,qaldia,recmora_cc_usa,mmaxactual,to_01end003):
	
#Calcular variable S4_CO02EXP001TO
	if data['CO02EXP001TO'] >= 284 : 
		S4_CO02EXP001TO=284 
	else: 
		S4_CO02EXP001TO = data['CO02EXP001TO']

#Calcular variable S4_CO01MOR083CCD01 

	if data['CO01MOR083CC'] < 0 : 
		S4_CO01MOR083CCD01 = 1
	else: 
		S4_CO01MOR083CCD01 = 0

#Calcular variable S4_CO01MOR083CCD02

	if 0<=data['CO01MOR083CC'] < 1 : 
		S4_CO01MOR083CCD02 = 1
	else:
		S4_CO01MOR083CCD02 = 0

#Calcular variable S4_CO01MOR083CCD03

	if 1<=data['CO01MOR083CC'] : 
		S4_CO01MOR083CCD03 = 1
	else:
		S4_CO01MOR083CCD03 = 0

	if 0<=ever6024_p < 1 :
		S4_EVER6024_PD01 = 1
	else:
		S4_EVER6024_PD01 = 0
#Calcular variable S4_EVER6024_PD02

	if ( 1 <= ever6024_p < 2) :
		S4_EVER6024_PD02 = 1
	else:
		S4_EVER6024_PD02 = 0

#Calcular variable S4_EVER6024_PD03

	if 2<=ever6024_p : 
		S4_EVER6024_PD03 = 1
	else:
		S4_EVER6024_PD03 = 0

#Calcular variable S4_CO01MOR098IND01

	if data['CO01MOR098IN'] < 0 :
		S4_CO01MOR098IND01 = 1
	else:  
		S4_CO01MOR098IND01 = 0

#Calcular variable S4_CO01MOR098IND02

	if 0<=data['CO01MOR098IN'] < 69.94 :
		S4_CO01MOR098IND02 = 1
	else: 
		S4_CO01MOR098IND02 = 0

#Calcular variable S4_CO01MOR098IND03

	if ( 69.94<=data['CO01MOR098IN'] < 89.23 ) :
		S4_CO01MOR098IND03 = 1
	else: 
		S4_CO01MOR098IND03 = 0

#Calcular variable S4_CO01MOR098IND04

	if ( 89.23<=data['CO01MOR098IN'] < 99.14 ) : 
		S4_CO01MOR098IND04 = 1
	else: 
		S4_CO01MOR098IND04 = 0

#Calcular variable S4_CO01MOR098IND05

	if 99.14 <= data['CO01MOR098IN'] : 
		S4_CO01MOR098IND05 = 1
	else:  
		S4_CO01MOR098IND05 = 0

	if ( 0 <= qaldia < 1 ): 
		S4_QALDIAD01 = 1 
	else: 
		S4_QALDIAD01 = 0

#Calcular variable S4_QALDIAD02

	if ( 1 <= qaldia < 2 ) : 
		S4_QALDIAD02 = 1 
	else:
		S4_QALDIAD02 = 0

#Calcular variable S4_QALDIAD03

	if ( 2 <=qaldia < 5 ) : 
		S4_QALDIAD03 = 1 
	else: 
		S4_QALDIAD03 = 0

#Calcular variable S4_QALDIAD04
	if 5 <=qaldia : 
		S4_QALDIAD04 = 1 
	else:
		S4_QALDIAD04 = 0

#Calcular variable S4_RECMORACC_USAD01
	if ( 0 <= recmora_cc_usa < 1 ): 
		S4_RECMORACC_USAD01 = 1
	else:
		S4_RECMORACC_USAD01 = 0

#Calcular variable S4_RECMORACC_USAD02

	if 1<=recmora_cc_usa < 2 : 
		S4_RECMORACC_USAD02 = 1
	else:
		S4_RECMORACC_USAD02 = 0

#Calcular variable S4_RECMORACC_USAD03

	if ( 2 <= recmora_cc_usa < 5 ) : 
		S4_RECMORACC_USAD03 = 1
	else:
		S4_RECMORACC_USAD03 = 0

#Calcular variable S4_RECMORACC_USAD04

	if 5<=recmora_cc_usa : 
		S4_RECMORACC_USAD04 = 1
	else:
		S4_RECMORACC_USAD04 = 0

#Calcular variable S4_MMAXACTUALD01

	if mmaxactual == 0 : 
		S4_MMAXACTUALD01 = 1
	else: 
		S4_MMAXACTUALD01 = 0

#Calcular variable S4_MMAXACTUALD02

	if ( 1 <= mmaxactual < 2 ) : 
		S4_MMAXACTUALD02 = 1
	else: 
		S4_MMAXACTUALD02 = 0

#Calcular variable S4_MMAXACTUALD03

	if ( 2 <= mmaxactual < 3 ) : 
		S4_MMAXACTUALD03 = 1
	else:
		S4_MMAXACTUALD03 = 0

#Calcular variable S4_MMAXACTUALD04 

	if ( 3 <= mmaxactual <= 8 ) : 
		S4_MMAXACTUALD04 = 1
	else:
		S4_MMAXACTUALD04 = 0

#Calcular variable S4_CO01MOR008IND01

	if data['CO01MOR008IN'] < 0 : 
		S4_CO01MOR008IND01 = 1
	else: 
		S4_CO01MOR008IND01 = 0

#Calcular variable S4_CO01MOR008IND02

	if data['CO01MOR008IN'] == 0 : 
		S4_CO01MOR008IND02 = 1
	else: 
		S4_CO01MOR008IND02 = 0

#Calcular variable S4_CO01MOR008IND03

	if 1 <= data['CO01MOR008IN'] : 
		S4_CO01MOR008IND03 = 1
	else:
		S4_CO01MOR008IND03 = 0

#Calcular variable S4_CO01MOR009VED01

	if data['CO01MOR009VE'] < 0 : 
		S4_CO01MOR009VED01 = 1
	else:
		S4_CO01MOR009VED01 = 0

#Calcular variable S4_CO01MOR009VED02

	if data['CO01MOR009VE'] == 0 : 
		S4_CO01MOR009VED02 = 1
	else:
		S4_CO01MOR009VED02 = 0

#Calcular variable S4_CO01MOR009VED03

	if ( 1 <= data['CO01MOR009VE'] <= 8 ) : 
		S4_CO01MOR009VED03 = 1
	else:
		S4_CO01MOR009VED03 = 0

#Calcular variable S4_CO01MOR009COD01

	if data['CO01MOR009CO'] < 0 : 
		S4_CO01MOR009COD01 = 1
	else:
		S4_CO01MOR009COD01 = 0

#Calcular variable S4_CO01MOR009COD02

	if data['CO01MOR009CO'] == 0 : 
		S4_CO01MOR009COD02 = 1
	else:
		S4_CO01MOR009COD02 = 0

#Calcular variable S4_CO01MOR009COD03

	if ( 1 <=data['CO01MOR009CO'] < 5 ): 
		S4_CO01MOR009COD03 = 1
	else:
		S4_CO01MOR009COD03 = 0

#Calcular variable S4_CO01MOR009COD04

	if ( 5 <= data['CO01MOR009CO'] <= 8 ) : 
		S4_CO01MOR009COD04 = 1
	else:
		S4_CO01MOR009COD04 = 0

#Calcular variable S4_CO01MOR009CCD01

	if data['CO01MOR009CC'] < 0 : 
		S4_CO01MOR009CCD01 = 1
	else: 
		S4_CO01MOR009CCD01 = 0

#Calcular variable S4_CO01MOR009CCD02 

	if data['CO01MOR009CC'] == 0 : 
		S4_CO01MOR009CCD02 = 1
	else:
		S4_CO01MOR009CCD02 = 0

#Calcular variable S4_CO01MOR009CCD03 

	if ( 1 <= data['CO01MOR009CC'] < 3 ): 
		S4_CO01MOR009CCD03 = 1
	else: 
		S4_CO01MOR009CCD03 = 0

#Calcular variable S4_CO01MOR009CCD04 

	if ( 3 <= data['CO01MOR009CC'] <= 8 ): 
		S4_CO01MOR009CCD04 = 1
	else: 
		S4_CO01MOR009CCD04 = 0


#Calcular variable S4_CO01END017CCD01 

	if data['CO01END017CC'] < 0 : 
		S4_CO01END017CCD01 = 1
	else: 
		S4_CO01END017CCD01 = 0

#Calcular variable  S4_CO01END017CCD02 

	if ( 0 <= data['CO01END017CC'] < 0.08 ) : 
		S4_CO01END017CCD02 = 1
	else: 
		S4_CO01END017CCD02 = 0

#Calcular variable S4_CO01END017CCD03 

	if  0.08 <= data['CO01END017CC'] : 
		S4_CO01END017CCD03 = 1
	else: 
		S4_CO01END017CCD03 = 0


#Calcular variable S4_CO01END022COD01 

	if data['CO01END022CO'] < 0 : 
		S4_CO01END022COD01 = 1
	else:
		S4_CO01END022COD01 = 0

#Calcular variable S4_CO01END022COD02 

	if ( 0 <= data['CO01END022CO'] < 0.08 ) : 
		S4_CO01END022COD02 = 1
	else: 
		S4_CO01END022COD02 = 0

#Calcular variable S4_CO01END022COD03 

	if ( 0.08 <= data['CO01END022CO'] < 0.69 ): 
		S4_CO01END022COD03 = 1
	else:
		S4_CO01END022COD03 = 0

#Calcular variable S4_CO01END022COD04 

	if 0.69 <= data['CO01END022CO'] : 
		S4_CO01END022COD04 = 1
	else: 
		S4_CO01END022COD04 = 0

#Calcular variable S4_CO01END080ROD01 

	if data['CO01END080RO'] < 0 : 
		S4_CO01END080ROD01 = 1
	else: 
		S4_CO01END080ROD01 = 0

#Calcular variable S4_CO01END080ROD02 

	if 0 <= data['CO01END080RO'] < 30.07: 
		S4_CO01END080ROD02 = 1
	else: 
		S4_CO01END080ROD02 = 0

#Calcular variable S4_CO01END080ROD03 

	if ( 30.07<=data['CO01END080RO'] < 62.33 ) : 
		S4_CO01END080ROD03 = 1
	else: 
		S4_CO01END080ROD03 = 0

#Calcular variable S4_CO01END080ROD04 

	if ( 62.33<=data['CO01END080RO'] < 87.29 ): 
		S4_CO01END080ROD04 = 1
	else: 
		S4_CO01END080ROD04 = 0

#Calcular variable S4_CO01END080ROD05 

	if 87.29<=data['CO01END080RO'] : 
		S4_CO01END080ROD05 = 1
	else:
		S4_CO01END080ROD05 = 0

#Calcular variable S4_CO01END087ROD01 

	if data['CO01END087RO'] == -1 : 
		S4_CO01END087ROD01 = 1
	else:
		S4_CO01END087ROD01 = 0

#Calcular variable S4_CO01END087ROD02 

	if ( 0 <= data['CO01END087RO'] < 37.35 ) : 
		S4_CO01END087ROD02 = 1
	else: 
		S4_CO01END087ROD02 = 0

#Calcular variable S4_CO01END087ROD03 

	if ( 37.35<=data['CO01END087RO'] < 67.23 ): 
		S4_CO01END087ROD03 = 1
	else:
		S4_CO01END087ROD03 = 0

#Calcular variable S4_CO01END087ROD04 

	if ( 67.23 <= data['CO01END087RO'] < 88.57 ): 
		S4_CO01END087ROD04 = 1
	else: 
		S4_CO01END087ROD04 = 0

#Calcular variable S4_CO01END087ROD05 

	if 88.57 <= data['CO01END087RO'] : 
		S4_CO01END087ROD05 = 1
	else: 
		S4_CO01END087ROD05 = 0

#Calcular variable S4_CO02end018CBD01 

	if data['CO02END018CB'] < 0 : 
		S4_CO02END018CBD01 = 1
	else:
		S4_CO02END018CBD01 = 0

#Calcular variable S4_CO02END018CBD02 

	if ( 0 <= data['CO02END018CB'] < 0.74 ): 
		S4_CO02END018CBD02 = 1
	else:
		S4_CO02END018CBD02 = 0

#Calcular variable S4_CO02end018CBD03 

	if 0.74<=data['CO02END018CB'] : 
		S4_CO02END018CBD03 = 1
	else:
		S4_CO02END018CBD03 = 0


	if ( 0 <= to_01end003 < 0.01 ) : 
		S4_TO_01END003D01 = 1
	else:
		S4_TO_01END003D01 = 0

#Calcular variable S4_ TO_01END003D02 

	if ( 0.01<= to_01end003 < 0.18 ): 
		S4_TO_01END003D02 = 1
	else:
		S4_TO_01END003D02 = 0

#Calcular variable S4_ TO_01END003D03 

	if ( 0.18 <= to_01end003 < 0.55 ): 
		S4_TO_01END003D03 = 1
	else:
		S4_TO_01END003D03 = 0

#Calcular variable S4_ TO_01END003D04 

	if ( 0.55<= to_01end003 < 1.49 ): 
		S4_TO_01END003D04 = 1
	else:
		S4_TO_01END003D04 = 0

#Calcular variable S4_ TO_01END003D05 

	if 1.49 <= to_01end003 : 
		S4_TO_01END003D05 = 1
	else:
		S4_TO_01END003D05 = 0

#Calcular variable S4_CO01EXP006CCD01 

	if data['CO01EXP006CC'] < 0 : 
		S4_CO01EXP006CCD01 = 1
	else:
		S4_CO01EXP006CCD01 = 0

#Calcular variable S4_CO01EXP006CCD02 

	if (-1 < data['CO01EXP006CC'] < 12 ) : 
		S4_CO01EXP006CCD02 = 1
	else:
		S4_CO01EXP006CCD02 = 0

#Calcular variable S4_CO01EXP006CCD03 

	if ( 12 <= data['CO01EXP006CC'] < 24 ): 
		S4_CO01EXP006CCD03 = 1
	else: 
		S4_CO01EXP006CCD03 = 0

#Calcular variable S4_CO01EXP006CCD04 

	if ( 24 <=data['CO01EXP006CC'] < 36 ): 
		S4_CO01EXP006CCD04 = 1
	else: 
		S4_CO01EXP006CCD04 = 0

#Calcular variable S4_CO01EXP006CCD05 

	if 36<=data['CO01EXP006CC'] : 
		S4_CO01EXP006CCD05 = 1
	else:
		S4_CO01EXP006CCD05 = 0

#Calcular variable S4_CO02EXP008OTD01 

	if data['CO02EXP008OT'] == -1 : 
		S4_CO02EXP008OTD01 = 1
	else:
		S4_CO02EXP008OTD01 = 0


#Calcular variable S4_CO02EXP008OTD02 
	if 0==data['CO02EXP008OT'] : 
		S4_CO02EXP008OTD02 = 1
	else:
		S4_CO02EXP008OTD02 = 0

#Calcular variable S4_CO02EXP008OTD03 

	if 0 < data['CO02EXP008OT'] : 
		S4_CO02EXP008OTD03 = 1
	else:
		S4_CO02EXP008OTD03 = 0

#Calcular variable S4_CO01EXP006ROD01 

	if data['CO01EXP006RO'] < 0 : 
		S4_CO01EXP006ROD01 = 1
	else:
		S4_CO01EXP006ROD01 = 0

#Calcular variable S4_CO01EXP006ROD02 

	if ( 0 <=data['CO01EXP006RO'] < 12 ) : 
		S4_CO01EXP006ROD02 = 1
	else:
		S4_CO01EXP006ROD02 = 0

#Calcular variable S4_CO01EXP006ROD03

	if ( 12 <=data['CO01EXP006RO'] < 24 ): 
		S4_CO01EXP006ROD03 = 1
	else:
		S4_CO01EXP006ROD03 = 0

#Calcular variable S4_CO01EXP006ROD04 

	if 24<=data['CO01EXP006RO'] : 
		S4_CO01EXP006ROD04 = 1
	else:
		S4_CO01EXP006ROD04 = 0

#Calcular variable S4_CO01EXP001IND01 

	if data['CO01EXP001IN'] < 0 : 
		S4_CO01EXP001IND01 = 1
	else:
		S4_CO01EXP001IND01 = 0

#Calcular variable S4_CO01EXP001IND02 

	if ( 0 <= data['CO01EXP001IN'] < 25 ): 
		S4_CO01EXP001IND02 = 1
	else:
		S4_CO01EXP001IND02 = 0

#Calcular variable S4_CO01EXP001IND03 

	if ( 25 <= data['CO01EXP001IN'] < 57 ): 
		S4_CO01EXP001IND03 = 1
	else:
		S4_CO01EXP001IND03 = 0

#Calcular variable S4_CO01EXP001IND04 

	if ( 57 <= data['CO01EXP001IN'] < 117 ): 
		S4_CO01EXP001IND04 = 1
	else:
		S4_CO01EXP001IND04 = 0

#Calcular variable S4_CO01EXP001IND05 

	if 117<=data['CO01EXP001IN'] : 
		S4_CO01EXP001IND05 = 1
	else:
		S4_CO01EXP001IND05 = 0

#Calcular variable S4_CO02ACP002TOD01 

	if data['CO02ACP002TO'] < 0 : 
		S4_CO02ACP002TOD01 = 1
	else:
		S4_CO02ACP002TOD01 = 0

#Calcular variable S4_CO02ACP002TOD02 

	if ( 0 <=data['CO02ACP002TO'] < 2 ): 
		S4_CO02ACP002TOD02 = 1
	else:
		S4_CO02ACP002TOD02 = 0


#Calcular variable S4_CO02ACP002TOD03 

	if ( 2 <= data['CO02ACP002TO'] < 7 ) : 
		S4_CO02ACP002TOD03 = 1
	else:
		S4_CO02ACP002TOD03 = 0

#Calcular variable S4_CO02ACP002TOD04 

	if ( 7 <= data['CO02ACP002TO'] < 20 ): 
		S4_CO02ACP002TOD04 = 1
	else:  
		S4_CO02ACP002TOD04 = 0

#Calcular variable S4_CO02ACP002TOD05 

	if 20<=data['CO02ACP002TO']: 
		S4_CO02ACP002TOD05 = 1
	else:  
		S4_CO02ACP002TOD05 = 0

#Calcular variable S4_CO00DEM016D01 

	if data['CO00DEM016'] in { 21, 3, 12, 48, 28, 5, 13 }: 
		S4_CO00DEM016D01 = 1 
	else: 
		S4_CO00DEM016D01 = 0

#Calcular variable S4_CO00DEM016D02 

	if data['CO00DEM016'] in { 50, 60, 17, 11, 54, 44, 52, 46, 29, 56, 23, 64, 27, 19, 40, 68, 72, -1 }: 
		S4_CO00DEM016D02 = 1 
	else: 
		S4_CO00DEM016D02 = 0

#Calcular variable S4_CO00DEM016D03 

	if data['CO00DEM016'] in { 31, 15, 25, 24, 9, 26, 1, 7 }: 
		S4_CO00DEM016D03 = 1 
	else: 
		S4_CO00DEM016D03 = 0


	fX   = + 0.44091207312642 \
		+ ( 0.00245917709975207 * S4_CO02EXP001TO ) \
		+ ( 0                   * S4_CO01MOR083CCD01 )\
		+ ( 0                   * S4_CO01MOR083CCD02 )\
		+ ( -0.103816291401002  * S4_CO01MOR083CCD03 )\
		+ ( 0                   * S4_EVER6024_PD01 )\
		+ ( 0                   * S4_EVER6024_PD02 )\
		+ ( -0.751566677942849  * S4_EVER6024_PD03 )\
		+ ( 0                   * S4_CO01MOR098IND01 )\
		+ ( 0                   * S4_CO01MOR098IND02 )\
		+ ( 0                   * S4_CO01MOR098IND03 )\
		+ ( 0                   * S4_CO01MOR098IND04 )\
		+ ( 0.14257048929448    * S4_CO01MOR098IND05 )\
		+ ( -0.357616499672217  * S4_QALDIAD01 )\
		+ ( 0                   * S4_QALDIAD02 )\
		+ ( 0                   * S4_QALDIAD03 )\
		+ ( 0                   * S4_QALDIAD04 )\
		+ ( 0                   * S4_RECMORACC_USAD01 )\
		+ ( 0                   * S4_RECMORACC_USAD02 )\
		+ ( 0                   * S4_RECMORACC_USAD03 )\
		+ ( 0.84779837422091    * S4_RECMORACC_USAD04 )\
		+ ( 0                   * S4_MMAXACTUALD01 )\
		+ ( 0                   * S4_MMAXACTUALD02 )\
		+ ( -1.61423706876104   * S4_MMAXACTUALD03 )\
		+ ( -2.31650699035707   * S4_MMAXACTUALD04 )\
		+ ( 0                   * S4_CO01MOR008IND01 )\
		+ ( 0                   * S4_CO01MOR008IND02 )\
		+ ( -0.696535508107526  * S4_CO01MOR008IND03 )\
		+ ( 0                   * S4_CO01MOR009VED01 )\
		+ ( 0                   * S4_CO01MOR009VED02 )\
		+ ( -0.457773631655222  * S4_CO01MOR009VED03 )\
		+ ( 0                   * S4_CO01MOR009COD01 )\
		+ ( 0.0614591072800547  * S4_CO01MOR009COD02 )\
		+ ( 0                   * S4_CO01MOR009COD03 )\
		+ ( 0                   * S4_CO01MOR009COD04 )\
		+ ( 0                   * S4_CO01MOR009CCD01 )\
		+ ( 0.198850445829027   * S4_CO01MOR009CCD02 )\
		+ ( 0                   * S4_CO01MOR009CCD03 )\
		+ ( 0                   * S4_CO01MOR009CCD04 )\
		+ ( 0                   * S4_CO01END017CCD01 )\
		+ ( 0                   * S4_CO01END017CCD02 )\
		+ ( -0.390179751031714  * S4_CO01END017CCD03 )\
		+ ( 0                   * S4_CO01END022COD01 )\
		+ ( 0                   * S4_CO01END022COD02 )\
		+ ( 0                   * S4_CO01END022COD03 )\
		+ ( -0.478694481644643  * S4_CO01END022COD04 )\
		+ ( 0                   * S4_CO01END080ROD01 )\
		+ ( 0.10482393350723    * S4_CO01END080ROD02 )\
		+ ( 0                   * S4_CO01END080ROD03 )\
		+ ( 0                   * S4_CO01END080ROD04 )\
		+ ( 0                   * S4_CO01END080ROD05 )\
		+ ( 0                   * S4_CO01END087ROD01 )\
		+ ( 0.558026071201328   * S4_CO01END087ROD02 )\
		+ ( 0.231585101637374   * S4_CO01END087ROD03 )\
		+ ( 0                   * S4_CO01END087ROD04 )\
		+ ( -0.418658416246951  * S4_CO01END087ROD05 )\
		+ ( 0                   * S4_CO02END018CBD01 )\
		+ ( 0.0940887733704908  * S4_CO02END018CBD02 )\
		+ ( 0                   * S4_CO02END018CBD03 )\
		+ ( 0                   * S4_TO_01END003D01 )\
		+ ( 0                   * S4_TO_01END003D02 )\
		+ ( 0                   * S4_TO_01END003D03 )\
		+ ( 0                   * S4_TO_01END003D04 )\
		+ ( -0.660760531515201  * S4_TO_01END003D05 )\
		+ ( 0                   * S4_CO01EXP006CCD01 )\
		+ ( -0.482468151025489  * S4_CO01EXP006CCD02 )\
		+ ( 0                   * S4_CO01EXP006CCD03 )\
		+ ( 0                   * S4_CO01EXP006CCD04 )\
		+ ( 0                   * S4_CO01EXP006CCD05 )\
		+ ( 0                   * S4_CO02EXP008OTD01 )\
		+ ( 0                   * S4_CO02EXP008OTD02 )\
		+ ( -0.360043377681863  * S4_CO02EXP008OTD03 )\
		+ ( 0                   * S4_CO01EXP006ROD01 )\
		+ ( -0.424782115797859  * S4_CO01EXP006ROD02 )\
		+ ( 0                   * S4_CO01EXP006ROD03 )\
		+ ( 0                   * S4_CO01EXP006ROD04 )\
		+ ( 0                   * S4_CO01EXP001IND01 )\
		+ ( -0.187938628903349  * S4_CO01EXP001IND02 )\
		+ ( 0                   * S4_CO01EXP001IND03 )\
		+ ( 0                   * S4_CO01EXP001IND04 )\
		+ ( 0                   * S4_CO01EXP001IND05 )\
		+ ( 0                   * S4_CO02ACP002TOD01 )\
		+ ( 0.140033302135679   * S4_CO02ACP002TOD02 )\
		+ ( 0                   * S4_CO02ACP002TOD03 )\
		+ ( 0                   * S4_CO02ACP002TOD04 )\
		+ ( 0                   * S4_CO02ACP002TOD05 )\
		+ ( -0.38602731908189   * S4_CO00DEM016D01 )\
		+ ( 0                   * S4_CO00DEM016D02 )\
		+ ( 0                   * S4_CO00DEM016D03 )
#--------------------------------------------------------
#Calculo del score alineado
	redo=truncate(fX,5)
	ScoreAlineado = truncate((69.596510 * redo) + 579.461647,1)
	ScoreAlineado=int(ScoreAlineado)
	
#Calculo del score final
	
	if ScoreAlineado <=150:
		ScoreFinal = 150 

	if 150<= ScoreAlineado <=950:
		ScoreFinal = ScoreAlineado

	if ScoreAlineado >950:
		ScoreFinal = 950
	reporte={}
	#reporte['TIPOID']=int(data['TIPOID'])
	#reporte['CONUMIDE']=data['CONUMIDE']
	reporte['scoreValue']=ScoreFinal
	reporte['scoreSegment']=4
	#reporte['EVER6024_P']=int(ever6024_p)
	#reporte['QALDIA']=int(qaldia)
	#reporte['RECMORA_CC_USA']=int(recmora_cc_usa)
	#reporte['MMAXACTUAL']=int(mmaxactual)
	#reporte['TO_01END003']=int(to_01end003)
	#reporte['S4_CO02EXP001TO']=int(S4_CO02EXP001TO)
	#reporte['S4_CO01MOR083CCD03']=int(S4_CO01MOR083CCD03)
	#reporte['S4_EVER6024_PD03']=int(S4_EVER6024_PD03)
	#reporte['S4_CO01MOR098IND05']=int(S4_CO01MOR098IND05)
	#reporte['S4_QALDIAD01']=int(S4_QALDIAD01)
	#reporte['S4_RECMORACC_USAD04']=int(S4_RECMORACC_USAD04)
	#reporte['S4_MMAXACTUALD03']=int(S4_MMAXACTUALD03)
	#reporte['S4_MMAXACTUALD04']=int(S4_MMAXACTUALD04)
	#reporte['S4_CO01MOR008IND03']=int(S4_CO01MOR008IND03)
	#reporte['S4_CO01MOR009VED03']=int(S4_CO01MOR009VED03)
	#reporte['S4_CO01MOR009COD02']=int(S4_CO01MOR009COD02)
	#reporte['S4_CO01MOR009CCD02']=int(S4_CO01MOR009CCD02)
	#reporte['S4_CO01END017CCD03']=int(S4_CO01END017CCD03)
	#reporte['S4_CO01END022COD04']=int(S4_CO01END022COD04)
	#reporte['S4_CO01END080ROD02']=int(S4_CO01END080ROD02)
	#reporte['S4_CO01END087ROD02']=int(S4_CO01END087ROD02)
	#reporte['S4_CO01END087ROD03']=int(S4_CO01END087ROD03)
	#reporte['S4_CO01END087ROD05']=int(S4_CO01END087ROD05)
	#reporte['S4_CO02END018CBD02']=int(S4_CO02END018CBD02)
	#reporte['S4_TO_01END003D05']=int(S4_TO_01END003D05)
	#reporte['S4_CO01EXP006CCD02']=int(S4_CO01EXP006CCD02)
	#reporte['S4_CO02EXP008OTD03']=int(S4_CO02EXP008OTD03)
	#reporte['S4_CO01EXP006ROD02']=int(S4_CO01EXP006ROD02)
	#reporte['S4_CO01EXP001IND02']=int(S4_CO01EXP001IND02)
	#reporte['S4_CO02ACP002TOD02']=int(S4_CO02ACP002TOD02)
	#reporte['S4_CO00DEM016D01']=int(S4_CO00DEM016D01)
	return reporte
#--------------------------------------------------------------------------------------------------------------#
#  FUNCION segmento5 : REALIZA EL CALCULO DEL SCORE PARA POBLACION DEL SEGMENTO 5   
#--------------------------------------------------------------------------------------------------------------#
def segmento5(data,ever3024_p,mob6,open12,to_01end004):
	
#calcular variable S5_CO00DEM003

	if ( data['CO00DEM003'] < 18 or data['CO00DEM003'] < 0 ) : 
		S5_CO00DEM003 = 18 
	else: 
		if data['CO00DEM003'] > 65 : 
			S5_CO00DEM003 = 65 
		else:
			S5_CO00DEM003 = data['CO00DEM003']

#calcular variable S5_CO00DEM016D01

	if data['CO00DEM016'] in (54,68,72,40,50,3,21,48,12,56,5,17,28,64,60,13,-1) : 
		S5_CO00DEM016D01 = 1
	else:
		S5_CO00DEM016D01 = 0

#calcular variable S5_CO00DEM016D02 

	if data['CO00DEM016'] in (11,52,31,25,15,29,27,23,24,26,1,19,44,9,46,7) : 
		S5_CO00DEM016D02 = 1
	else: 
		S5_CO00DEM016D02 = 0

#calcular variable S5_CO02ACP002TOD01 

	if data['CO02ACP002TO'] < 0 : 
		S5_CO02ACP002TOD01 = 1
	else: 
		S5_CO02ACP002TOD01 = 0

#calcular variable S5_CO02ACP002TOD02 

	if ( 0 <= data['CO02ACP002TO'] < 6 ): 
		S5_CO02ACP002TOD02 = 1
	else: 
		S5_CO02ACP002TOD02 = 0

#calcular variable S5_CO02ACP002TOD03 

	if ( 6 <=data['CO02ACP002TO'] < 17 ): 
		S5_CO02ACP002TOD03 = 1
	else: 
		S5_CO02ACP002TOD03 = 0


#calcular variable S5_CO02ACP002TOD04 

	if 17<=data['CO02ACP002TO'] : 
		S5_CO02ACP002TOD04 = 1
	else: 
		S5_CO02ACP002TOD04 = 0

#calcular variable S5_CO02END019CBD01 

	if data['CO02END019CB'] < 0 : 
		S5_CO02END019CBD01 = 1
	else: 
		S5_CO02END019CBD01 = 0

#calcular variable S5_CO02END019CBD02 

	if 0 == data['CO02END019CB'] : 
		S5_CO02END019CBD02 = 1
	else: 
		S5_CO02END019CBD02 = 0

#calcular variable S5_CO02END019CBD03 

	if 0 < data['CO02END019CB'] : 
		S5_CO02END019CBD03 = 1
	else: 
		S5_CO02END019CBD03 = 0

#calcular variable S5_CO02NUM043CBD01 

	if ( 0 <=data['CO02NUM043CB'] < 33.34 ): 
		S5_CO02NUM043CBD01 = 1
	else:  
		S5_CO02NUM043CBD01 = 0

#calcular variable S5_CO02NUM043CBD02 

	if ( 33.34 <= data['CO02NUM043CB'] < 66.68 ): 
		S5_CO02NUM043CBD02 = 1
	else: 
		S5_CO02NUM043CBD02 = 0

#calcular variable S5_CO02NUM043CBD03 

	if 66.68<=data['CO02NUM043CB'] : 
		S5_CO02NUM043CBD03 = 1
	else:  
		S5_CO02NUM043CBD03 = 0

#calcular variable S5_CO01END017CCD01 

	if data['CO01END017CC'] < 0 : 
		S5_CO01END017CCD01 = 1
	else:  
		S5_CO01END017CCD01 = 0

#calcular variable S5_CO01END017CCD02 

	if 0 ==data['CO01END017CC'] : 
		S5_CO01END017CCD02 = 1
	else:  
		S5_CO01END017CCD02 = 0


#calcular variable S5_CO01END017CCD03 

	if 0 < data['CO01END017CC'] : 
		S5_CO01END017CCD03 = 1
	else:  
		S5_CO01END017CCD03 = 0


#calcular variable S5_CO01EXP001CCD01 

	if data['CO01EXP001CC'] < 0 : 
		S5_CO01EXP001CCD01 = 1
	else:  
		S5_CO01EXP001CCD01 = 0

#calcular variable S5_CO01EXP001CCD02
	if 0<=data['CO01EXP001CC'] < 12 : 
		S5_CO01EXP001CCD02 = 1
	else: 
		S5_CO01EXP001CCD02 = 0


#calcular variable S5_CO01EXP001CCD03 

	if ( 12 <= data['CO01EXP001CC'] < 36 ) : 
		S5_CO01EXP001CCD03 = 1
	else:  
		S5_CO01EXP001CCD03 = 0


#calcular variable S5_CO01EXP001CCD04 

	if ( 36 <=data['CO01EXP001CC'] < 72 ) : 
		S5_CO01EXP001CCD04 = 1
	else:  
		S5_CO01EXP001CCD04 = 0

#calcular variable S5_CO01EXP001CCD05 

	if 72<=data['CO01EXP001CC'] : 
		S5_CO01EXP001CCD05 = 1
	else:  
		S5_CO01EXP001CCD05 = 0

#calcular variable S5_CO01END007COD01 

	if data['CO01END007CO'] < 0 : 
		S5_CO01END007COD01 = 1
	else:  
		S5_CO01END007COD01 = 0

#calcular variable S5_CO01END007COD02 

	if ( 0 <=data['CO01END007CO'] < 5.76 ): 
		S5_CO01END007COD02 = 1
	else:  
		S5_CO01END007COD02 = 0

#calcular variable S5_CO01END007COD03 

	if ( 5.76 <=data['CO01END007CO'] < 12.25 ): 
		S5_CO01END007COD03 = 1
	else:  
		S5_CO01END007COD03 = 0

#calcular variable S5_CO01END007COD04 

	if ( 12.25 <= data['CO01END007CO'] < 30.15 ): 
		S5_CO01END007COD04 = 1
	else:  
		S5_CO01END007COD04 = 0

#calcular variable S5_CO01END007COD05 

	if ( 30.15 <= data['CO01END007CO'] ): 
		S5_CO01END007COD05 = 1
	else:  
		S5_CO01END007COD05 = 0

#calcular variable S5_CO01END021COD01 

	if data['CO01END021CO'] < 0 : 
		S5_CO01END021COD01 = 1
	else:  
		S5_CO01END021COD01 = 0

#calcular variable S5_CO01END021COD02 

	if ( 0 <= data['CO01END021CO'] < 2.68 ) : 
		S5_CO01END021COD02 = 1
	else: 
		S5_CO01END021COD02 = 0

#calcular variable S5_CO01END021COD03 

	if ( 2.68 <= data['CO01END021CO'] < 6.47 ): 
		S5_CO01END021COD03 = 1
	else:  
		S5_CO01END021COD03 = 0

#calcular variable S5_CO01END021COD04 

	if ( 6.47<=data['CO01END021CO'] < 15.54 ): 
		S5_CO01END021COD04 = 1
	else:  
		S5_CO01END021COD04 = 0

#calcular variable S5_CO01END021COD05 

	if 15.54<=data['CO01END021CO'] : 
		S5_CO01END021COD05 = 1
	else:  
		S5_CO01END021COD05 = 0

#calcular variable S5_CO01EXP006CTD01 

	if data['CO01EXP006CT'] < 0 : 
		S5_CO01EXP006CTD01 = 1
	else:  
		S5_CO01EXP006CTD01 = 0

#calcular variable S5_CO01EXP006CTD02 

	if ( 0 <= data['CO01EXP006CT'] < 24 ): 
		S5_CO01EXP006CTD02 = 1
	else:  
		S5_CO01EXP006CTD02 = 0

#calcular variable S5_CO01EXP006CTD03 

	if ( 24 <= data['CO01EXP006CT'] < 72 ): 
		S5_CO01EXP006CTD03 = 1
	else:  
		S5_CO01EXP006CTD03 = 0

#calcular variable S5_CO01EXP006CTD04 

	if 72<=data['CO01EXP006CT'] : 
		S5_CO01EXP006CTD04 = 1
	else:  
		S5_CO01EXP006CTD04 = 0


	if ( 0 <= ever3024_p < 1 ): 
		S5_EVER3024_PD01 = 1
	else: 
		S5_EVER3024_PD01 = 0

#calcular variable S5_EVER3024_PD02 

	if ( 1 <=ever3024_p < 2 ) : 
		S5_EVER3024_PD02 = 1
	else: 
		S5_EVER3024_PD02 = 0

#calcular variable S5_EVER3024_PD03 

	if 2<=ever3024_p : 
		S5_EVER3024_PD03 = 1
	else: 
		S5_EVER3024_PD03 = 0

#calcular variable S5_CO01END018IND01 

	if data['CO01END018IN'] < 0 : 
		S5_CO01END018IND01 = 1
	else: 
		S5_CO01END018IND01 = 0

#calcular variable S5_CO01END018IND02 

	if ( 0 <=data['CO01END018IN'] < 0.64 )  : 
		S5_CO01END018IND02 = 1
	else: 
		S5_CO01END018IND02 = 0

#calcular variable S5_CO01END018IND03 

	if 0.64 <= data['CO01END018IN'] : 
		S5_CO01END018IND03 = 1
	else:  
		S5_CO01END018IND03 = 0

#calcular variable S5_CO01MOR068IND01 

	if data['CO01MOR068IN'] < 0 : 
		S5_CO01MOR068IND01 = 1
	else: 
		S5_CO01MOR068IND01 = 0

#calcular variable S5_CO01MOR068IND02 

	if ( 0 <= data['CO01MOR068IN'] < 1 ): 
		S5_CO01MOR068IND02 = 1
	else:  
		S5_CO01MOR068IND02 = 0

#calcular variable S5_CO01MOR068IND03 

	if 1<=data['CO01MOR068IN'] : 
		S5_CO01MOR068IND03 = 1
	else:  
		S5_CO01MOR068IND03 = 0

#calcular variable S5_CO01NUM002IND01 

	if data['CO01NUM002IN'] <=0 : 
		S5_CO01NUM002IND01 = 1
	else:  
		S5_CO01NUM002IND01 = 0

#calcular variable S5_CO01NUM002IND02 

	if ( 1 <=data['CO01NUM002IN'] < 3 ) : 
		S5_CO01NUM002IND02 = 1
	else:  
		S5_CO01NUM002IND02 = 0

#calcular variable S5_CO01NUM002IND03 

	if 3<=data['CO01NUM002IN'] : 
		S5_CO01NUM002IND03 = 1
	else: 
		S5_CO01NUM002IND03 = 0


	if ( 0 <= mob6 < 1 ): 
		S5_MOB6D01 = 1
	else:  
		S5_MOB6D01 = 0

#calcular variable  S5_MOB6D02 

	if ( 1 <=mob6 < 2 ): 
		S5_MOB6D02 = 1
	else: 
		S5_MOB6D02 = 0

#calcular variable S5_MOB6D03
	if ( 2 <= mob6 < 4 ): 
		S5_MOB6D03 = 1
	else: 
		S5_MOB6D03 = 0

#calcular variable S5_MOB6D04 

	if 4<=mob6 : 
		S5_MOB6D04 = 1
	else:  
		S5_MOB6D04 = 0

	if ( 0 <= open12 < 2 ): 
		S5_OPEN12D01 = 1
	else: 
		S5_OPEN12D01 = 0

#calcular variable S5_OPEN12D02 

	if ( 2 <= open12 < 3 ) : 
		S5_OPEN12D02 = 1
	else:  
		S5_OPEN12D02 = 0

#calcular variable S5_OPEN12D03 

	if 3<=open12 : 
		S5_OPEN12D03 = 1
	else: 
		S5_OPEN12D03 = 0

#calcular variable S5_CO01EXP003OTD01 

	if data['CO01EXP003OT'] < 0 : 
		S5_CO01EXP003OTD01 = 1
	else: 
		S5_CO01EXP003OTD01 = 0

#calcular variable S5_CO01EXP003OTD02 

	if ( -1 < data['CO01EXP003OT'] < 24 ): 
		S5_CO01EXP003OTD02 = 1
	else: 
		S5_CO01EXP003OTD02 = 0

#calcular variable S5_CO01EXP003OTD03 

	if 24<=data['CO01EXP003OT'] : 
		S5_CO01EXP003OTD03 = 1
	else:  
		S5_CO01EXP003OTD03 = 0

#calcular variable S5_CO01ACP001ROD01 

	if data['CO01ACP001RO'] < 0 : 
		S5_CO01ACP001ROD01 = 1
	else: 
		S5_CO01ACP001ROD01 = 0

#calcular variable S5_CO01ACP001ROD02 

	if ( 0 <=data['CO01ACP001RO'] < 1 ): 
		S5_CO01ACP001ROD02 = 1
	else:  
		S5_CO01ACP001ROD02 = 0

#calcular variable S5_CO01ACP001ROD03 

	if 1<=data['CO01ACP001RO'] : 
		S5_CO01ACP001ROD03 = 1
	else:  
		S5_CO01ACP001ROD03 = 0

#calcular variable S5_CO01END030ROD01 

	if data['CO01END030RO'] < 0 : 
		S5_CO01END030ROD01 = 1
	else: 
		S5_CO01END030ROD01 = 0

#calcular variable S5_CO01END030ROD02 

	if ( 0 <= data['CO01END030RO'] < 0.61 ) : 
		S5_CO01END030ROD02 = 1
	else: 
		S5_CO01END030ROD02 = 0

#calcular variable S5_CO01END030ROD03 

	if ( 0.61 <= data['CO01END030RO'] < 1.66 ) : 
		S5_CO01END030ROD03 = 1
	else: 
		S5_CO01END030ROD03 = 0

#calcular variable S5_CO01END030ROD04 

	if ( 1.66 <= data['CO01END030RO'] < 4.2 ) : 
		S5_CO01END030ROD04 = 1
	else: 
		S5_CO01END030ROD04 = 0

#calcular variable S5_CO01END030ROD05 

	if 4.2 <= data['CO01END030RO'] : 
		S5_CO01END030ROD05 = 1
	else: 
		S5_CO01END030ROD05 = 0

#calcular variable S5_CO01END071ROD01 

	if data['CO01END071RO'] < 0 : 
		S5_CO01END071ROD01 = 1
	else: 
		S5_CO01END071ROD01 = 0

#calcular variable S5_CO01END071ROD02 

	if ( 0 <=data['CO01END071RO'] < 25.56 ): 
		S5_CO01END071ROD02 = 1
	else: 
		S5_CO01END071ROD02 = 0

#calcular variable S5_CO01END071ROD03 

	if ( 25.56 <= data['CO01END071RO'] < 57.52 ): 
		S5_CO01END071ROD03 = 1
	else: 
		S5_CO01END071ROD03 = 0

#calcular variable S5_CO01END071ROD04 

	if ( 57.52 <= data['CO01END071RO'] < 86.94 ): 
		S5_CO01END071ROD04 = 1
	else: 
		S5_CO01END071ROD04 = 0

#calcular variable S5_CO01END071ROD05 

	if 86.94<=data['CO01END071RO'] : 
		S5_CO01END071ROD05 = 1
	else: 
		S5_CO01END071ROD05 = 0

#calcular variable S5_CO01END080ROD01 

	if data['CO01END080RO'] < 0 : 
		S5_CO01END080ROD01 = 1
	else:  
		S5_CO01END080ROD01 = 0

#calcular variable S5_CO01END080ROD02 

	if ( 0 <= data['CO01END080RO'] < 21.23 ) : 
		S5_CO01END080ROD02 = 1
	else: 
		S5_CO01END080ROD02 = 0

#calcular variable S5_CO01END080ROD03 

	if ( 21.23 <= data['CO01END080RO'] < 52.32 ) : 
		S5_CO01END080ROD03 = 1
	else: 
		S5_CO01END080ROD03 = 0

#calcular variable S5_CO01END080ROD04 

	if ( 52.32 <= data['CO01END080RO'] < 81.04 ) : 
		S5_CO01END080ROD04 = 1
	else: 
		S5_CO01END080ROD04 = 0

#calcular variable S5_CO01END080ROD05 

	if 81.04 <= data['CO01END080RO'] : 
		S5_CO01END080ROD05 = 1
	else:   
		S5_CO01END080ROD05 = 0

#calcular variable S5_CO02END045ROD01 

	if data['CO02END045RO'] < 0 : 
		S5_CO02END045ROD01 = 1
	else: 
		S5_CO02END045ROD01 = 0

#calcular variable S5_CO02END045ROD02 

	if ( 0 <= data['CO02END045RO'] < 12.9 ): 
		S5_CO02END045ROD02 = 1
	else: 
		S5_CO02END045ROD02 = 0

#calcular variable S5_CO02END045ROD03 

	if ( 12.9 <= data['CO02END045RO'] < 40 ) : 
		S5_CO02END045ROD03 = 1
	else: 
		S5_CO02END045ROD03 = 0

#calcular variable S5_CO02END045ROD04 

	if ( 40 <= data['CO02END045RO'] < 114.23 ): 
		S5_CO02END045ROD04 = 1
	else:  
		S5_CO02END045ROD04 = 0

#calcular variable S5_CO02END045ROD05 

	if 114.23<=data['CO02END045RO'] : 
		S5_CO02END045ROD05 = 1
	else:  
		S5_CO02END045ROD05 = 0

#calcular variable S5_TIENEHPD01

	if data['CO01NUM001HP'] < 0 : 
		AUX_CO01NUM001HP = 0 
	else: 
		AUX_CO01NUM001HP = data['CO01NUM001HP']


	if AUX_CO01NUM001HP > 0 : 
		TIENEHP = 1 
	else: 
		TIENEHP = 0


	if TIENEHP == 0 : 
		S5_TIENEHPD01 = 1 
	else:  
		S5_TIENEHPD01 = 0

#calcular variable S5_TIENEHPD02 

	if TIENEHP == 1 : 
		S5_TIENEHPD02 = 1 
	else: 
		S5_TIENEHPD02 = 0

	if ( 0 <= to_01end004 < 0.001 ) : 
		S5_TO_01END004D01 = 1 
	else: 
		S5_TO_01END004D01 = 0

#calcular variable S5_TO_01END004D02 

	if  0.001 <= to_01end004 : 
		S5_TO_01END004D02 = 1
	else: 
		S5_TO_01END004D02 = 0

#calcular variable S5_CO01END005VED01 

	if data['CO01END005VE'] < 0 : 
		S5_CO01END005VED01 = 1
	else: 
		S5_CO01END005VED01 = 0

#calcular variable S5_CO01END005VED02 

	if ( 0 <= data['CO01END005VE'] < 0.46 ) : 
		S5_CO01END005VED02 = 1
	else: 
		S5_CO01END005VED02 = 0

#calcular variable S5_CO01END005VED03 

	if  0.46 <= data['CO01END005VE'] : 
		S5_CO01END005VED03 = 1
	else:  
		S5_CO01END005VED03 = 0

#calcular variable S5_CO01EXP001AHD01 

	if data['CO01EXP001AH'] < 0 : 
		S5_CO01EXP001AHD01 = 1
	else: 
		S5_CO01EXP001AHD01 = 0

#calcular variable S5_CO01EXP001AHD02 

	if ( 0 <= data['CO01EXP001AH'] < 60 ): 
		S5_CO01EXP001AHD02 = 1
	else: 
		S5_CO01EXP001AHD02 = 0

#calcular variable S5_CO01EXP001AHD03 

	if ( 60 <= data['CO01EXP001AH'] < 120 ): 
		S5_CO01EXP001AHD03 = 1
	else: 
		S5_CO01EXP001AHD03 = 0

#calcular variable S5_CO01EXP001AHD04 

	if 120 <= data['CO01EXP001AH'] : 
		S5_CO01EXP001AHD04 = 1
	else: 
		S5_CO01EXP001AHD04 = 0

#calcular variable S5_CO02EXP013TOD01 

	if data['CO02EXP013TO'] < 0 : 
		S5_CO02EXP013TOD01 = 1
	else:  
		S5_CO02EXP013TOD01 = 0

#calcular variable S5_CO02EXP013TOD02 

	if ( 0 <= data['CO02EXP013TO'] < 25 ): 
		S5_CO02EXP013TOD02 = 1
	else: 
		S5_CO02EXP013TOD02 = 0

#calcular variable S5_CO02EXP013TOD03 

	if 25 <= data['CO02EXP013TO'] : 
		S5_CO02EXP013TOD03 = 1
	else: 
		S5_CO02EXP013TOD03 = 0

#calcular variable S5_CO02EXP002TO 

	if data['CO02EXP002TO'] < 0 :
		data['CO02EXP002TO'] = 0

	S5_CO02EXP002TO = data['CO02EXP002TO']



	fX   = + 1.56468472106833\
		+ ( 0.0108194566415718  * S5_CO00DEM003 )\
		+ ( 0                   * S5_CO00DEM016D01 )\
		+ ( 0.526065754782099   * S5_CO00DEM016D02 )\
		+ ( 0                   * S5_CO02ACP002TOD01 )\
		+ ( 0.218573179175477   * S5_CO02ACP002TOD02 )\
		+ ( 0                   * S5_CO02ACP002TOD03 )\
		+ ( 0                   * S5_CO02ACP002TOD04 )\
		+ ( 0                   * S5_CO02END019CBD01 )\
		+ ( 0.254079232057516   * S5_CO02END019CBD02 )\
		+ ( 0                   * S5_CO02END019CBD03 )\
		+ ( 0                   * S5_CO02NUM043CBD01 )\
		+ ( 0                   * S5_CO02NUM043CBD02 )\
		+ ( 0.158940918170394   * S5_CO02NUM043CBD03 )\
		+ ( 0                   * S5_CO01END017CCD01 )\
		+ ( 0                   * S5_CO01END017CCD02 )\
		+ ( -0.432585994699084  * S5_CO01END017CCD03 )\
		+ ( 0                   * S5_CO01EXP001CCD01 )\
		+ ( -0.513131320714189  * S5_CO01EXP001CCD02 )\
		+ ( 0                   * S5_CO01EXP001CCD03 )\
		+ ( 0                   * S5_CO01EXP001CCD04 )\
		+ ( 0                   * S5_CO01EXP001CCD05 )\
		+ ( 0                   * S5_CO01END007COD01 )\
		+ ( -0.368899589634825  * S5_CO01END007COD02 )\
		+ ( -0.223916388889647  * S5_CO01END007COD03 )\
		+ ( 0                   * S5_CO01END007COD04 )\
		+ ( 0                   * S5_CO01END007COD05 )\
		+ ( 0                   * S5_CO01END021COD01 )\
		+ ( 0                   * S5_CO01END021COD02 )\
		+ ( 0                   * S5_CO01END021COD03 )\
		+ ( 0                   * S5_CO01END021COD04 )\
		+ ( 0.185521215393334   * S5_CO01END021COD05 )\
		+ ( 0                   * S5_CO01EXP006CTD01 )\
		+ ( -0.172551087650533  * S5_CO01EXP006CTD02 )\
		+ ( 0                   * S5_CO01EXP006CTD03 )\
		+ ( 0                   * S5_CO01EXP006CTD04 )\
		+ ( 0                   * S5_EVER3024_PD01 )\
		+ ( -0.416390338916387  * S5_EVER3024_PD02 )\
		+ ( -0.708135536346337  * S5_EVER3024_PD03 )\
		+ ( 0                   * S5_CO01END018IND01 )\
		+ ( -0.185569300067401  * S5_CO01END018IND02 )\
		+ ( 0                   * S5_CO01END018IND03 )\
		+ ( 0                   * S5_CO01MOR068IND01 )\
		+ ( 0                   * S5_CO01MOR068IND02 )\
		+ ( 0.264195627242267   * S5_CO01MOR068IND03 )\
		+ ( 0                   * S5_CO01NUM002IND01 )\
		+ ( 0.0635146844632413  * S5_CO01NUM002IND02 )\
		+ ( 0                   * S5_CO01NUM002IND03 )\
		+ ( 0                   * S5_MOB6D01 )\
		+ ( 0                   * S5_MOB6D02 )\
		+ ( 0                   * S5_MOB6D03 )\
		+ ( -0.358894829770967  * S5_MOB6D04 )\
		+ ( 0                   * S5_OPEN12D01 )\
		+ ( 0                   * S5_OPEN12D02 )\
		+ ( -0.299634532554973  * S5_OPEN12D03 )\
		+ ( 0                   * S5_CO01EXP003OTD01 )\
		+ ( -0.319630941305853  * S5_CO01EXP003OTD02 )\
		+ ( 0                   * S5_CO01EXP003OTD03 )\
		+ ( 0                   * S5_CO01ACP001ROD01 )\
		+ ( 0                   * S5_CO01ACP001ROD02 )\
		+ ( -0.19097638131769   * S5_CO01ACP001ROD03 )\
		+ ( 0                   * S5_CO01END030ROD01 )\
		+ ( 0                   * S5_CO01END030ROD02 )\
		+ ( 0                   * S5_CO01END030ROD03 )\
		+ ( 0                   * S5_CO01END030ROD04 )\
		+ ( 0.230392085247235   * S5_CO01END030ROD05 )\
		+ ( 0                   * S5_CO01END071ROD01 )\
		+ ( 0.53098319426302    * S5_CO01END071ROD02 )\
		+ ( 0.337934784748864   * S5_CO01END071ROD03 )\
		+ ( 0                   * S5_CO01END071ROD04 )\
		+ ( -0.536642681785678  * S5_CO01END071ROD05 )\
		+ ( 0                   * S5_CO01END080ROD01 )\
		+ ( 0                   * S5_CO01END080ROD02 )\
		+ ( 0                   * S5_CO01END080ROD03 )\
		+ ( 0                   * S5_CO01END080ROD04 )\
		+ ( -0.0769414366141488 * S5_CO01END080ROD05 )\
		+ ( 0                   * S5_CO02END045ROD01 )\
		+ ( 0                   * S5_CO02END045ROD02 )\
		+ ( 0                   * S5_CO02END045ROD03 )\
		+ ( 0                   * S5_CO02END045ROD04 )\
		+ ( 0.176478867357001   * S5_CO02END045ROD05 )\
		+ ( 0                   * S5_TIENEHPD01 )\
		+ ( 0.27519037785524    * S5_TIENEHPD02 )\
		+ ( 0                   * S5_TO_01END004D01 )\
		+ ( -0.498168795186944  * S5_TO_01END004D02 )\
		+ ( 0                   * S5_CO01END005VED01 )\
		+ ( -0.227552709363299  * S5_CO01END005VED02 )\
		+ ( 0                   * S5_CO01END005VED03 )\
		+ ( 0                   * S5_CO01EXP001AHD01 )\
		+ ( 0                   * S5_CO01EXP001AHD02 )\
		+ ( 0                   * S5_CO01EXP001AHD03 )\
		+ ( 0.117544198388577   * S5_CO01EXP001AHD04 )\
		+ ( 0                   * S5_CO02EXP013TOD01 )\
		+ ( -0.222728628988525  * S5_CO02EXP013TOD02 )\
		+ ( 0                   * S5_CO02EXP013TOD03 )\
		+ ( 0.0162091910543464  * S5_CO02EXP002TO )
#-----------------------------------------------------------
#Calculo del score alineado
	redo=truncate(fX,5)
	ScoreAlineado = truncate((65.281402 * redo) + 599.942762,1)
	ScoreAlineado=int(ScoreAlineado)

#Calculo del score final.

	if ScoreAlineado <=150 : 
		ScoreFinal = 150

	if 150<= ScoreAlineado <=950 : 
		ScoreFinal = ScoreAlineado

	if ScoreAlineado >950 : 
		ScoreFinal = 950

	reporte={}
	#reporte['TIPOID']=int(data['TIPOID'])
	#reporte['CONUMIDE']=data['CONUMIDE']
	reporte['scoreValue']=ScoreFinal
	reporte['scoreSegment']=5
	#reporte['EVER3024_P']=int(ever3024_p)
	#reporte['MOB6']=int(mob6)
	#reporte['OPEN12']=int(open12)
	#reporte['TO_01END004']=int(to_01end004)
	#reporte['S5_CO00DEM003']=int(S5_CO00DEM003)
	#reporte['S5_CO00DEM016D02']=int(S5_CO00DEM016D02)
	#reporte['S5_CO02ACP002TOD02']=int(S5_CO02ACP002TOD02)
	#reporte['S5_CO02END019CBD02']=int(S5_CO02END019CBD02)
	#reporte['S5_CO02NUM043CBD03']=int(S5_CO02NUM043CBD03)
	#reporte['S5_CO01END017CCD03']=int(S5_CO01END017CCD03)
	#reporte['S5_CO01EXP001CCD02']=int(S5_CO01EXP001CCD02)
	#reporte['S5_CO01END007COD02']=int(S5_CO01END007COD02)
	#reporte['S5_CO01END007COD03']=int(S5_CO01END007COD03)
	#reporte['S5_CO01END021COD05']=int(S5_CO01END021COD05)
	#reporte['S5_CO01EXP006CTD02']=int(S5_CO01EXP006CTD02)
	#reporte['S5_EVER3024_PD02']=int(S5_EVER3024_PD02)
	#reporte['S5_EVER3024_PD03']=int(S5_EVER3024_PD03)
	#reporte['S5_CO01END018IND02']=int(S5_CO01END018IND02)
	#reporte['S5_CO01MOR068IND03']=int(S5_CO01MOR068IND03)
	#reporte['S5_CO01NUM002IND02']=int(S5_CO01NUM002IND02)
	#reporte['S5_MOB6D04']=int(S5_MOB6D04)
	#reporte['S5_OPEN12D03']=int(S5_OPEN12D03)
	#reporte['S5_CO01EXP003OTD02']=int(S5_CO01EXP003OTD02)
	#reporte['S5_CO01ACP001ROD03']=int(S5_CO01ACP001ROD03)
	#reporte['S5_CO01END030ROD05']=int(S5_CO01END030ROD05)
	#reporte['S5_CO01END071ROD02']=int(S5_CO01END071ROD02)
	#reporte['S5_CO01END071ROD03']=int(S5_CO01END071ROD03)
	#reporte['S5_CO01END071ROD05']=int(S5_CO01END071ROD05)
	#reporte['S5_CO01END080ROD05']=int(S5_CO01END080ROD05)
	#reporte['S5_CO02END045ROD05']=int(S5_CO02END045ROD05)
	#reporte['S5_TIENEHPD02']=int(S5_TIENEHPD02)
	#reporte['S5_TO_01END004D02']=int(S5_TO_01END004D02)
	#reporte['S5_CO01END005VED02']=int(S5_CO01END005VED02)
	#reporte['S5_CO01EXP001AHD04']=int(S5_CO01EXP001AHD04)
	#reporte['S5_CO02EXP013TOD02']=int(S5_CO02EXP013TOD02)
	#reporte['S5_CO02EXP002TO']=int(S5_CO02EXP002TO)

	return reporte
#--------------------------------------------------------------------------------------------------------------#
#  FUNCION segmento6 : REALIZA EL CALCULO DEL SCORE PARA POBLACION DEL SEGMENTO 6   
#--------------------------------------------------------------------------------------------------------------#
def segmento6(data,recmora_usa):
	
	#calcular variable S6_CO01MOR061IND01 


	if data['CO01MOR061IN'] < 0 : 
		S6_CO01MOR061IND01 = 1 
	else:  
		S6_CO01MOR061IND01 = 0
	
	#calcular variable S6_CO01MOR061IND02 
	
	if ( 0 <= data['CO01MOR061IN'] < 1 ): 
		S6_CO01MOR061IND02 = 1 
	else: 
		S6_CO01MOR061IND02 = 0
	
	#calcular variable S6_CO01MOR061IND03 
	
	if 1 <=data['CO01MOR061IN'] : 
		S6_CO01MOR061IND03 = 1 
	else: 
		S6_CO01MOR061IND03 = 0
	
	#calcular variable S6_TIENEHPD01
	
	if data['CO01NUM001HP'] < 0 : 
		A_CO01NUM001HP = 0 
	else: 
		A_CO01NUM001HP = data['CO01NUM001HP']
	
	if A_CO01NUM001HP > 0 : 
		TIENEHP = 1 
	else: 
		TIENEHP = 0
	
	if TIENEHP == 0 : 
		S6_TIENEHPD01 = 1 
	else: 
		S6_TIENEHPD01 = 0
	
	#calcular variable S6_TIENEHPD02 
	
	if TIENEHP == 1 : 
		S6_TIENEHPD02 = 1 
	else: 
		S6_TIENEHPD02 = 0
	
	
	#calcular variable S6_CO01NUM050AHD01 
	
	if data['CO01NUM050AH'] < 0 : 
		S6_CO01NUM050AHD01 = 1 
	else: 
		S6_CO01NUM050AHD01 = 0
	
	#calcular variable S6_CO01NUM050AHD02 
	
	if ( 0 <= data['CO01NUM050AH'] < 1 ): 
		S6_CO01NUM050AHD02 = 1 
	else: 
		S6_CO01NUM050AHD02 = 0
	
	#calcular variable S6_CO01NUM050AHD03 
	
	if ( 1 <= data['CO01NUM050AH'] < 2 ): 
		S6_CO01NUM050AHD03 = 1 
	else: 
		S6_CO01NUM050AHD03 = 0
	
	#calcular variable S6_CO01NUM050AHD04 
	
	if 2<=data['CO01NUM050AH'] : 
		S6_CO01NUM050AHD04 = 1 
	else: 
		S6_CO01NUM050AHD04 = 0
	
	#calcular variable S6_CO01NUM001OTD01 
	
	if data['CO01NUM001OT'] < 0 : 
		S6_CO01NUM001OTD01 = 1 
	else: 
		S6_CO01NUM001OTD01 = 0
	
	#calcular variable S6_CO01NUM001OTD02 
	
	if ( 0 <=data['CO01NUM001OT'] < 2 ): 
		S6_CO01NUM001OTD02 = 1 
	else: 
		S6_CO01NUM001OTD02 = 0
	
	
	#calcular variable S6_CO01NUM001OTD03 
	if 2<=data['CO01NUM001OT'] : 
		S6_CO01NUM001OTD03 = 1 
	else: 
		S6_CO01NUM001OTD03 = 0
	
	#calcular variable S6_CO02NUM035TOD01 
	
	if data['CO02NUM035TO'] < 0 : 
		S6_CO02NUM035TOD01 = 1 
	else: 
		S6_CO02NUM035TOD01 = 0
	
	#calcular variable S6_CO02NUM035TOD02 
	
	if ( 0 <=data['CO02NUM035TO'] < 1 ): 
		S6_CO02NUM035TOD02 = 1 
	else: 
		S6_CO02NUM035TOD02 = 0
	
	#calcular variable S6_CO02NUM035TOD03 
	
	if 1<=data['CO02NUM035TO'] : 
		S6_CO02NUM035TOD03 = 1 
	else: 
		S6_CO02NUM035TOD03 = 0
	
	#calcular variable S6_CO01END089ROD01 
	
	if data['CO01END089RO'] < 0 : 
		S6_CO01END089ROD01 = 1 
	else: 
		S6_CO01END089ROD01 = 0
	
	#calcular variable S6_CO01END089ROD02 
	
	if ( 0 <= data['CO01END089RO'] < 15.48 ): 
		S6_CO01END089ROD02 = 1 
	else: 
		S6_CO01END089ROD02 = 0
	
	#calcular variable S6_CO01END089ROD03 
	
	if ( 15.48 <= data['CO01END089RO'] < 42.91 ): 
		S6_CO01END089ROD03 = 1 
	else: 
		S6_CO01END089ROD03 = 0
	
	#calcular variable S6_CO01END089ROD04 
	
	if ( 42.91 <=data['CO01END089RO'] < 72 ): 
		S6_CO01END089ROD04 = 1 
	else: 
		S6_CO01END089ROD04 = 0
	
	#calcular variable S6_CO01END089ROD05 
	
	if 72 <= data['CO01END089RO'] : 
		S6_CO01END089ROD05 = 1 
	else: 
		S6_CO01END089ROD05 = 0
	
	#calcular variable S6_CO01EXP004AHD01 
	
	if data['CO01EXP004AH'] < 0 : 
		S6_CO01EXP004AHD01 = 1 
	else: 
		S6_CO01EXP004AHD01 = 0
	
	#calcular variable S6_CO01EXP004AHD02 
	
	if ( 0 <=data['CO01EXP004AH'] < 91 ): 
		S6_CO01EXP004AHD02 = 1 
	else: 
		S6_CO01EXP004AHD02 = 0
	
	#calcular variable S6_CO01EXP004AHD03 
	
	if 91<=data['CO01EXP004AH'] : 
		S6_CO01EXP004AHD03 = 1 
	else: 
		S6_CO01EXP004AHD03 = 0
	
	#calcular variable S6_CO01EXP008CCD01 
	
	if data['CO01EXP008CC'] < 0	: 
		S6_CO01EXP008CCD01 = 1 
	else:  
		S6_CO01EXP008CCD01 = 0
	
	#calcular variable S6_CO01EXP008CCD02 
	
	if ( 0 <=data['CO01EXP008CC'] < 1 ): 
		S6_CO01EXP008CCD02 = 1 
	else: 
		S6_CO01EXP008CCD02 = 0
	
	#calcular variable S6_CO01EXP008CCD03 
	
	if 1<=data['CO01EXP008CC'] : 
		S6_CO01EXP008CCD03 = 1 
	else: 
		S6_CO01EXP008CCD03 = 0
	
	#calcular variable S6_CO02EXP001TOD01
	if 0<=data['CO02EXP001TO'] < 63 : 
		S6_CO02EXP001TOD01 = 1 
	else: 
		S6_CO02EXP001TOD01 = 0
	#calcular variable S6_CO02EXP001TOD02 
	
	if ( 63 <=data['CO02EXP001TO'] < 113 ): 
		S6_CO02EXP001TOD02 = 1 
	else: 
		S6_CO02EXP001TOD02 = 0
	
	#calcular variable S6_CO02EXP001TOD03 
	
	if ( 113 <=data['CO02EXP001TO'] < 176 ): 
		S6_CO02EXP001TOD03 = 1 
	else: 
		S6_CO02EXP001TOD03 = 0
	
	#calcular variable S6_CO02EXP001TOD04 
	
	if 176<=data['CO02EXP001TO'] : 
		S6_CO02EXP001TOD04 = 1 
	else: 
		S6_CO02EXP001TOD04 = 0
	
	#calcular variable S6_CO02EXP002TOD01 
	
	if ( 0 <= data['CO02EXP002TO'] < 11 ): 
		S6_CO02EXP002TOD01 = 1 
	else: 
		S6_CO02EXP002TOD01 = 0
	
	#calcular variable S6_CO02EXP002TOD02 
	
	if ( 11 <=data['CO02EXP002TO'] < 14 ): 
		S6_CO02EXP002TOD02 = 1 
	else: 
		S6_CO02EXP002TOD02 = 0
	
	#calcular variable S6_CO02EXP002TOD03 
	
	if ( 14 <=data['CO02EXP002TO'] < 25 ): 
		S6_CO02EXP002TOD03 = 1 
	else: 
		S6_CO02EXP002TOD03 = 0
	
	#calcular variable S6_CO02EXP002TOD04 
	
	if 25<=data['CO02EXP002TO'] : 
		S6_CO02EXP002TOD04 = 1 
	else: 
		S6_CO02EXP002TOD04 = 0
	
	#calcular variable S6_CO01ACP005ROD01 
	
	if data['CO01ACP005RO'] < 0 : 
		S6_CO01ACP005ROD01 = 1 
	else: 
		S6_CO01ACP005ROD01 = 0
	
	#calcular variable S6_CO01ACP005ROD02 
	
	if ( 0 <= data['CO01ACP005RO'] < 1 ): 
		S6_CO01ACP005ROD02 = 1 
	else: 
		S6_CO01ACP005ROD02 = 0
	
	#calcular variable S6_CO01ACP005ROD03 
	
	if ( 1 <= data['CO01ACP005RO'] < 2 ): 
		S6_CO01ACP005ROD03 = 1 
	else: 
		S6_CO01ACP005ROD03 = 0
	
	#calcular variable S6_CO01ACP005ROD04 
	
	if 2<=data['CO01ACP005RO'] : 
		S6_CO01ACP005ROD04 = 1
	else: 
		S6_CO01ACP005ROD04 = 0
	
	#calcular variable S6_CO00DEM003 
	
	if ( data['CO00DEM003'] < 18 or data['CO00DEM003'] == -1 ) : 
		S6_CO00DEM003 = 18 
	else: 
		if data['CO00DEM003'] > 65 : 
			S6_CO00DEM003 = 65
		else: 
			S6_CO00DEM003 = data['CO00DEM003']
		
	#calcular variable S6_CO00DEM016D01 
	
	if data['CO00DEM016'] in {72, 21, 48, 3, 56, 17, 54, 13, 5, 28, 12, 50, 40, 46, 44, 68, 64, -1} : 
		S6_CO00DEM016D01 = 1 
	else: 
		S6_CO00DEM016D01 = 0
	
	#calcular variable S6_CO00DEM016D02 
	
	if data['CO00DEM016'] in {11, 31, 19, 52, 26, 25, 1, 24, 27, 23, 15, 29, 9, 60, 7} : 
		S6_CO00DEM016D02 = 1 
	else: 
		S6_CO00DEM016D02 = 0
	
	
	
	#calcular variable S6_RECMORA_USA 
	
	if recmora_usa > 48 : 
		S6_RECMORA_USA = 48 
	else: 
		S6_RECMORA_USA = recmora_usa
	
	
	#calcular variable S6_COACP002TO 
	
	if data['CO02ACP002TO'] < 0:
		S6_CO02ACP002TO = 120 
	elif data['CO02ACP002TO'] > 120: 
		S6_CO02ACP002TO = 120
	else: 
		S6_CO02ACP002TO = data['CO02ACP002TO']
	
	#Formula
	
	fX= + 1.56465163855671 \
		+ ( 0                    * S6_CO01MOR061IND01 )\
		+ ( 0                    * S6_CO01MOR061IND02 )\
		+ ( 0.368475351008228    * S6_CO01MOR061IND03 )\
		+ ( 0                    * S6_TIENEHPD01 )\
		+ ( 0.231949458167594    * S6_TIENEHPD02 )\
		+ ( 0                    * S6_CO01NUM050AHD01 )\
		+ ( -0.164220930244974   * S6_CO01NUM050AHD02 )\
		+ ( 0                    * S6_CO01NUM050AHD03 )\
		+ ( 0.205209165069356    * S6_CO01NUM050AHD04 )\
		+ ( 0                    * S6_CO01NUM001OTD01 )\
		+ ( -0.121928820978138   * S6_CO01NUM001OTD02 )\
		+ ( -0.18272459678512    * S6_CO01NUM001OTD03 )\
		+ ( 0                    * S6_CO02NUM035TOD01 )\
		+ ( 0                    * S6_CO02NUM035TOD02 )\
		+ ( 0.281243365170349    * S6_CO02NUM035TOD03 )\
		+ ( 0                    * S6_CO01END089ROD01 )\
		+ ( 0.782038427786106    * S6_CO01END089ROD02 )\
		+ ( 0.612062272041684    * S6_CO01END089ROD03 )\
		+ ( 0                    * S6_CO01END089ROD04 )\
		+ ( -0.2320748119477     * S6_CO01END089ROD05 )\
		+ ( 0                    * S6_CO01EXP004AHD01 )\
		+ ( 0                    * S6_CO01EXP004AHD02 )\
		+ ( 0.214297851279539    * S6_CO01EXP004AHD03 )\
		+ ( 0                    * S6_CO01EXP008CCD01 )\
		+ ( 0                    * S6_CO01EXP008CCD02 )\
		+ ( -0.314277493087763   * S6_CO01EXP008CCD03 )\
		+ ( -0.145567613459032   * S6_CO02EXP001TOD01 )\
		+ ( 0                    * S6_CO02EXP001TOD02 )\
		+ ( 0                    * S6_CO02EXP001TOD03 )\
		+ ( 0                    * S6_CO02EXP001TOD04 )\
		+ ( -0.158906835765915   * S6_CO02EXP002TOD01 )\
		+ ( 0                    * S6_CO02EXP002TOD02 )\
		+ ( 0                    * S6_CO02EXP002TOD03 )\
		+ ( 0                    * S6_CO02EXP002TOD04 )\
		+ ( 0                    * S6_CO01ACP005ROD01 )\
		+ ( 0                    * S6_CO01ACP005ROD02 )\
		+ ( 0                    * S6_CO01ACP005ROD03 )\
		+ ( -0.118476723429465   * S6_CO01ACP005ROD04 )\
		+ ( 0.0117561431547211   * S6_CO00DEM003 )\
		+ ( -0.496602545372193   * S6_CO00DEM016D01 )\
		+ ( 0                    * S6_CO00DEM016D02 )\
		+ ( 0.0202792909046278   * S6_RECMORA_USA )\
		+ ( -0.00174586613078062 * S6_CO02ACP002TO )
	#-----------------------------------------------------------
	#Calculo del score alineado.
	redo=truncate(fX,5)
	score_alineado = truncate((67.822252 * redo) + 595.304050,1)
	score_alineado=int(score_alineado)
	#Calculo del score final.
	
	if score_alineado <=150 : 
		ScoreFinal = 150
	
	if 150<= score_alineado <=950 : 
		ScoreFinal = score_alineado
	
	if score_alineado >950 : 
		ScoreFinal = 950
#-------------------------------------
	reporte={}
	#reporte['TIPOID']=int(data['TIPOID'])
	#reporte['CONUMIDE']=data['CONUMIDE']
	reporte['scoreValue']=ScoreFinal
	reporte['scoreSegment']=6
	#reporte['RECMORA_USA']=int(recmora_usa)
	#reporte['S6_CO01MOR061IND03']=int(S6_CO01MOR061IND03)
	#reporte['S6_TIENEHPD02']=int(S6_TIENEHPD02)
	#reporte['S6_CO01NUM050AHD02']=int(S6_CO01NUM050AHD02)
	#reporte['S6_CO01NUM050AHD04']=int(S6_CO01NUM050AHD04)
	#reporte['S6_CO01NUM001OTD02']=int(S6_CO01NUM001OTD02)
	#reporte['S6_CO01NUM001OTD03']=int(S6_CO01NUM001OTD03)
	#reporte['S6_CO02NUM035TOD03']=int(S6_CO02NUM035TOD03)
	#reporte['S6_CO01END089ROD02']=int(S6_CO01END089ROD02)
	#reporte['S6_CO01END089ROD03']=int(S6_CO01END089ROD03)
	#reporte['S6_CO01END089ROD05']=int(S6_CO01END089ROD05)
	#reporte['S6_CO01EXP004AHD03']=int(S6_CO01EXP004AHD03)
	#reporte['S6_CO01EXP008CCD03']=int(S6_CO01EXP008CCD03)
	#reporte['S6_CO02EXP001TOD01']=int(S6_CO02EXP001TOD01)
	#reporte['S6_CO02EXP002TOD01']=int(S6_CO02EXP002TOD01)
	#reporte['S6_CO01ACP005ROD04']=int(S6_CO01ACP005ROD04)
	#reporte['S6_CO00DEM003']=int(S6_CO00DEM003)
	#reporte['S6_CO00DEM016D01']=int(S6_CO00DEM016D01)
	#reporte['S6_RECMORA_USA']=int(S6_RECMORA_USA)
	#reporte['S6_CO02ACP002TO']=int(S6_CO02ACP002TO)
#------------------------------------
	return reporte
#----------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------#
#  principal 
#---------------------------------------------------------------------------------------------------------------------#


class aciertaMas(object):

	@staticmethod
	def __call__(data):
		data_mod = deepcopy(data)
		try:
			QTOTAB,QTOT,SOLOREAL,MOB_SOLOREAL,EVER1206_P,EVER12012_P,EVER12018_P,EVER12024_P,EVER12036_P,EVER12048_P,CO01MOR005_TO,NEW_EVER12048_P,RECMORA30,RECMORA60,RECMORA120,RECMORA_CC,RECMORA,RECMORA_USA,QTOT90,EVER9048_P,TO_01END004,MMAXHIST,OPEN6,SALDOMO,EVER6024_P,QALDIA,MMAXACTUAL,TO_01END003,EVER3024_P,MOB6,OPEN12,RECMORA_CC_USA=hibridas(data_mod)
		except Exception, error:
			tb = traceback.format_exc()
			assert False, "!!! Error: {}, {}".format(error, tb)
		a, b = exclusiones(data_mod, QTOTAB, QTOT, SOLOREAL, MOB_SOLOREAL)
		list_seg = []
		x = {}
		if a == 0:
			try:
				x = scorecard(data_mod,QTOTAB,QTOT,SOLOREAL,MOB_SOLOREAL,EVER1206_P,EVER12012_P,EVER12018_P,EVER12024_P,EVER12036_P,EVER12048_P,CO01MOR005_TO,NEW_EVER12048_P,RECMORA30,RECMORA60,RECMORA120,RECMORA_CC,RECMORA,RECMORA_USA,QTOT90,EVER9048_P,TO_01END004,MMAXHIST,OPEN6,SALDOMO,EVER6024_P,QALDIA,MMAXACTUAL,TO_01END003,EVER3024_P,MOB6,OPEN12,RECMORA_CC_USA)
				x['exclusionCode'] = [a]
			except Exception, error:
				tb = traceback.format_exc()
				assert False, "!!! Error: {}, {}".format(error, tb)
		else:
			x['scoreValue'] = b
			x['scoreSegment'] = 0
			x['exclusionCode'] = [a]
		x['TIPOID'] = data.get('TIPOID')
		x['scoreCode'] = '67'
		x['scoreName'] = 'PHD'
		x['scoreDate'] = int(round(time.time() * 1000))
		x['relation'] = '0'
		x['tradeHolderIndicator'] = '0'
		return x

 
