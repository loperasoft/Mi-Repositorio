import numpy as np
import time
import sys
import traceback
from copy import deepcopy

#--------------------------------------------------------------------------------------------------------------#
# score ACIERTA A                                                                                              #
#--------------------------------------------------------------------------------------------------------------# 

#--------------------------------------------------------------------------------------------------------------#
#  FUNCION HIBRIDAS : REALIZA EL CALCULO DE LAS CARACTERISTICAS HIBRIDAS                                       #
#                     QTOTAB,QTOT,SOLorEAL,MOB_SOLorEAL,NEW_EVER12048_P,RECMORA_USA                            #
#--------------------------------------------------------------------------------------------------------------#
#--------------------------------------------------------------------------------------------------------------#
# FUNCION QUE REALIZA EL LLAMADO DEL score
#--------------------------------------------------------------------------------------------------------------#

def hibridas(data,INPUT_SEG):

#--------------------------------------------
# variables para QTOTAB
#--------------------------------------------
	if data["CO01NUM002CC"] < 0: 
		AUX_CO01NUM002CC = 0 
	else:   
		AUX_CO01NUM002CC = data["CO01NUM002CC"]

	if data["CO01NUM002RO"] < 0 :
		AUX_CO01NUM002RO = 0
	else:
		AUX_CO01NUM002RO = data["CO01NUM002RO"]

	if data["CO01NUM002IN"] < 0 : 
		AUX_CO01NUM002IN = 0; 
	else:
		AUX_CO01NUM002IN = data["CO01NUM002IN"]

	if data["CO01NUM002OT"] < 0 : 
		AUX_CO01NUM002OT = 0 
	else: 
		AUX_CO01NUM002OT = data["CO01NUM002OT"]

	if data["CO01NUM002VE"] < 0 : 
		AUX_CO01NUM002VE = 0
	else: 
		AUX_CO01NUM002VE = data["CO01NUM002VE"]
   
	if data["CO01NUM002HP"]< 0 : 
		AUX_CO01NUM002HP = 0; 
	else: 
		AUX_CO01NUM002HP = data["CO01NUM002HP"]

	if data["CO01NUM002CO"]< 0 : 
		AUX_CO01NUM002CO = 0; 
	else: 
		AUX_CO01NUM002CO = data["CO01NUM002CO"]

	QTOTAB = AUX_CO01NUM002CC + AUX_CO01NUM002RO + AUX_CO01NUM002IN + AUX_CO01NUM002OT + AUX_CO01NUM002VE + AUX_CO01NUM002HP
	QTOTABHD = AUX_CO01NUM002CC + AUX_CO01NUM002RO + AUX_CO01NUM002IN + AUX_CO01NUM002OT + AUX_CO01NUM002CO + AUX_CO01NUM002VE + AUX_CO01NUM002HP
#------------------------------------------#
#Calcular variable MOR00
#------------------------------------------#
	if data["CO01MOR001RO"] < 0 : 
		AUX_CO01MOR001RO = 0 
	else:
		AUX_CO01MOR001RO = data["CO01MOR001RO"]

	if data["CO01MOR001IN"] < 0 : 
		AUX_CO01MOR001IN = 0 
	else:
		AUX_CO01MOR001IN = data["CO01MOR001IN"]

	if data["CO01MOR001OT"] < 0 : 
		AUX_CO01MOR001OT = 0 
	else:
		AUX_CO01MOR001OT = data["CO01MOR001OT"]
 
	if data["CO01MOR001VE"] < 0 : 
		AUX_CO01MOR001VE = 0 
	else: 
		AUX_CO01MOR001VE = data["CO01MOR001VE"]

	if data["CO01MOR001CC"] < 0 :
		AUX_CO01MOR001CC = 0 
	else:
		AUX_CO01MOR001CC = data["CO01MOR001CC"]

	if data["CO01MOR001HP"] < 0 : 
		AUX_CO01MOR001HP = 0 
	else:
		AUX_CO01MOR001HP = data["CO01MOR001HP"]

	MOR00 = AUX_CO01MOR001RO + AUX_CO01MOR001IN+ AUX_CO01MOR001OT+ AUX_CO01MOR001VE+ AUX_CO01MOR001CC+AUX_CO01MOR001HP

#------------------------------------------#
#Calcular variable MOR30
#------------------------------------------#
	if data["CO01MOR002RO"] < 0 : 
		AUX_CO01MOR002RO= 0 
	else: 
		AUX_CO01MOR002RO = data["CO01MOR002RO"]

	if data["CO01MOR002IN"] < 0 : 
		AUX_CO01MOR002IN= 0 
	else: 
		AUX_CO01MOR002IN = data["CO01MOR002IN"]

	if data["CO01MOR002VE"] < 0 : 
		AUX_CO01MOR002VE= 0 
	else: 
		AUX_CO01MOR002VE = data["CO01MOR002VE"]

	if data["CO01MOR002HP"] < 0 : 
		AUX_CO01MOR002HP= 0 
	else: 
		AUX_CO01MOR002HP = data["CO01MOR002HP"]

	if data["CO01MOR002OT"] < 0 : 
		AUX_CO01MOR002OT= 0 
	else: 
		AUX_CO01MOR002OT = data["CO01MOR002OT"]

	if data["CO01MOR002CC"] < 0 : 
		AUX_CO01MOR002CC= 0 
	else: 
		AUX_CO01MOR002CC = data["CO01MOR002CC"]

	MOR30 = AUX_CO01MOR002RO + AUX_CO01MOR002IN + AUX_CO01MOR002VE + AUX_CO01MOR002HP + AUX_CO01MOR002OT + AUX_CO01MOR002CC

#------------------------------------------#
#Calcular variable MOR60
#------------------------------------------#

	if data["CO01MOR003RO"] < 0 : 
		AUX_CO01MOR003RO= 0 
	else: 
		AUX_CO01MOR003RO = data["CO01MOR003RO"]

	if data["CO01MOR003IN"] < 0 : 
		AUX_CO01MOR003IN= 0 
	else: 
		AUX_CO01MOR003IN = data["CO01MOR003IN"]

	if data["CO01MOR003VE"] < 0 : 
		AUX_CO01MOR003VE= 0 
	else: 
		AUX_CO01MOR003VE = data["CO01MOR003VE"]

	if data["CO01MOR003HP"] < 0 : 
		AUX_CO01MOR003HP= 0 
	else: 
		AUX_CO01MOR003HP = data["CO01MOR003HP"]

	if data["CO01MOR003OT"] < 0 : 
		AUX_CO01MOR003OT= 0 
	else: 
		AUX_CO01MOR003OT = data["CO01MOR003OT"]

	if data["CO01MOR003CC"] < 0 : 
		AUX_CO01MOR003CC= 0 
	else: 
		AUX_CO01MOR003CC = data["CO01MOR003CC"]

	MOR60 = AUX_CO01MOR003RO + AUX_CO01MOR003IN + AUX_CO01MOR003VE + AUX_CO01MOR003HP + AUX_CO01MOR003OT + AUX_CO01MOR003CC

#------------------------------------------#
#Calcular variable MOR90
#------------------------------------------#

	if data["CO01MOR004RO"] < 0 : 
		AUX_CO01MOR004RO= 0 
	else: 
		AUX_CO01MOR004RO = data["CO01MOR004RO"]

	if data["CO01MOR004IN"] < 0 : 
		AUX_CO01MOR004IN= 0 
	else: 
		AUX_CO01MOR004IN = data["CO01MOR004IN"]

	if data["CO01MOR004VE"] < 0 : 
		AUX_CO01MOR004VE= 0 
	else: 
		AUX_CO01MOR004VE = data["CO01MOR004VE"]

	if data["CO01MOR004HP"] < 0 : 
		AUX_CO01MOR004HP= 0 
	else: 
		AUX_CO01MOR004HP = data["CO01MOR004HP"]

	if data["CO01MOR004OT"] < 0 : 
		AUX_CO01MOR004OT= 0 
	else: 
		AUX_CO01MOR004OT = data["CO01MOR004OT"]

	if data["CO01MOR004CC"] < 0 : 
		AUX_CO01MOR004CC= 0 
	else: 
		AUX_CO01MOR004CC = data["CO01MOR004CC"]

	MOR90 = AUX_CO01MOR004RO + AUX_CO01MOR004IN + AUX_CO01MOR004VE + AUX_CO01MOR004HP + AUX_CO01MOR004OT + AUX_CO01MOR004CC

#------------------------------------------#
#Calcular variable MOR120
#------------------------------------------#


	if data["CO01MOR005RO"] < 0 : 
		AUX_CO01MOR005RO= 0 
	else: 
		AUX_CO01MOR005RO = data["CO01MOR005RO"]

	if data["CO01MOR005IN"] < 0 : 
		AUX_CO01MOR005IN= 0 
	else: 
		AUX_CO01MOR005IN = data["CO01MOR005IN"]

	if data["CO01MOR005VE"] < 0 : 
		AUX_CO01MOR005VE= 0 
	else: 
		AUX_CO01MOR005VE = data["CO01MOR005VE"]

	if data["CO01MOR005HP"] < 0 : 
		AUX_CO01MOR005HP= 0 
	else: 
		AUX_CO01MOR005HP = data["CO01MOR005HP"]

	if data["CO01MOR005OT"] < 0 : 
		AUX_CO01MOR005OT= 0 
	else: 
		AUX_CO01MOR005OT = data["CO01MOR005OT"]

	if data["CO01MOR005CC"] < 0 : 
		AUX_CO01MOR005CC= 0 
	else: 
		AUX_CO01MOR005CC = data["CO01MOR005CC"]


	MOR120 = AUX_CO01MOR005RO + AUX_CO01MOR005IN + AUX_CO01MOR005VE + AUX_CO01MOR005HP + AUX_CO01MOR005OT + AUX_CO01MOR005CC

#--------------------------------------------
# Calcular variable  EXPOSICION
#--------------------------------------------

	if (data["CO01END007RO"] >= 0 or data["CO01END001IN"] >= 0 or data["CO01END001VE"] >= 0 or data["CO01END001HP"] >= 0 or data["CO01END001OT"] >= 0) :
		if data["CO01END007RO"] < 0 : 
			AUX_CO01END007RO = 0
		else:
			AUX_CO01END007RO = data["CO01END007RO"]
	
		if data["CO01END001IN"] < 0 : 
			AUX_CO01END001IN = 0 
		else: 
			AUX_CO01END001IN = data["CO01END001IN"]
	
		if data["CO01END001VE"] < 0 : 
			AUX_CO01END001VE = 0 
		else:
			AUX_CO01END001VE = data["CO01END001VE"]
	
		if data["CO01END001HP"] < 0: 
			AUX_CO01END001HP = 0 
		else: 
			AUX_CO01END001HP = data["CO01END001HP"]
	
		if data["CO01END001OT"] < 0 : 
			AUX_CO01END001OT = 0 
		else: 
			AUX_CO01END001OT = data["CO01END001OT"]
	
		EXPOSICION = (AUX_CO01END007RO + AUX_CO01END001IN + AUX_CO01END001VE + AUX_CO01END001HP + AUX_CO01END001OT)
	else:
		EXPOSICION = -1
#--------------------------------------------
# Calcular variable  PREXPOSICIONRO
#--------------------------------------------
	if EXPOSICION > 0 : 
		PREXPOSICIONRO_C = AUX_CO01END007RO / EXPOSICION
		PREXPOSICIONRO = round(PREXPOSICIONRO_C,4) 
	else:
		if EXPOSICION < 0 :
			PREXPOSICIONRO = -1 
		else:
			PREXPOSICIONRO = 0

#--------------------------------------------
# Calcular variable  PREXPOSICIONIN
#--------------------------------------------

	if EXPOSICION > 0 : 
		PREXPOSICIONIN_C = AUX_CO01END001IN / EXPOSICION
		PREXPOSICIONIN = round(PREXPOSICIONIN_C,4) 
	else: 
		if EXPOSICION < 0 : 
			PREXPOSICIONIN = -1 
		else: 
			PREXPOSICIONIN = 0

#--------------------------------------------
# Calcular variable  PREXPOSICIONVE
#--------------------------------------------

	if EXPOSICION > 0 : 
		PREXPOSICIONVE_C = AUX_CO01END001VE / EXPOSICION
		PREXPOSICIONVE = round(PREXPOSICIONVE_C,4) 
	else: 
		if EXPOSICION < 0 : 
			PREXPOSICIONVE = -1 
		else: 
			PREXPOSICIONVE = 0

#--------------------------------------------
# Calcular variable  PREXPOSICIONHP
#--------------------------------------------

	if EXPOSICION > 0 : 
		PREXPOSICIONHP_C = AUX_CO01END001HP / EXPOSICION 
		PREXPOSICIONHP = round(PREXPOSICIONHP_C,4) 
	else: 
		if EXPOSICION < 0 : 
			PREXPOSICIONHP = -1 
		else: 
			PREXPOSICIONHP = 0

#--------------------------------------------
# Calcular variable  PREXPOSICIONOT
#--------------------------------------------

	if EXPOSICION > 0 : 
		PREXPOSICIONOT_C = AUX_CO01END001OT / EXPOSICION
		PREXPOSICIONOT = round(PREXPOSICIONOT_C,4) 
	else: 
		if EXPOSICION < 0 : 
			PREXPOSICIONOT = -1 
		else: 
			PREXPOSICIONOT = 0

#--------------------------------------------
# Calcular variable  CUOTATOTAL
#--------------------------------------------

	if (data["CO01END005RO"] >= 0 or data["CO01END005IN"] >= 0 or data["CO01END005VE"] >= 0 or data["CO01END005HP"] >= 0 or data["CO01END005OT"] >= 0) : 
		if data["CO01END005RO"] < 0 : 
			AUX_CO01END005RO = 0 
		else:
			AUX_CO01END005RO = data["CO01END005RO"]
		
		if data["CO01END005IN"] < 0 : 
			AUX_CO01END005IN = 0 
		else:
			AUX_CO01END005IN = data["CO01END005IN"]
	
		if data["CO01END005VE"] < 0 : 
			AUX_CO01END005VE = 0 
		else: 
			AUX_CO01END005VE = data["CO01END005VE"]
	
		if data["CO01END005HP"] < 0 : 
			AUX_CO01END005HP = 0 
		else: 
			AUX_CO01END005HP = data["CO01END005HP"]
	
		if data["CO01END005OT"] < 0 : 
			AUX_CO01END005OT = 0 
		else: 
			AUX_CO01END005OT = data["CO01END005OT"]
	
		CUOTATOTAL = AUX_CO01END005RO + AUX_CO01END005IN + AUX_CO01END005VE + AUX_CO01END005HP + AUX_CO01END005OT
	else:
		CUOTATOTAL = -1
#--------------------------------------------
# Calcular variable  PRCUOTATOTALRO
#--------------------------------------------

	if CUOTATOTAL > 0 : 
		PRCUOTATOTALRO_C = AUX_CO01END005RO / CUOTATOTAL
		PRCUOTATOTALRO = round(PRCUOTATOTALRO_C, 4) 
	else:
		if CUOTATOTAL < 0 : 
			PRCUOTATOTALRO = -1 
		else: 
			PRCUOTATOTALRO = 0

#--------------------------------------------
# Calcular variable  PRCUOTATOTALIN
#--------------------------------------------

	if CUOTATOTAL > 0 : 
		PRCUOTATOTALIN_C = AUX_CO01END005IN / CUOTATOTAL 
		PRCUOTATOTALIN = round(PRCUOTATOTALIN_C,4) 
	else: 
		if CUOTATOTAL < 0 : 
			PRCUOTATOTALIN = -1 
		else: 
			PRCUOTATOTALIN = 0

#--------------------------------------------
# Calcular variable  PRCUOTATOTALVE
#--------------------------------------------

	if CUOTATOTAL > 0 : 
		PRCUOTATOTALVE_C = AUX_CO01END005VE / CUOTATOTAL 
		PRCUOTATOTALVE = round(PRCUOTATOTALVE_C,4) 
	else: 
		if CUOTATOTAL < 0 : 
			PRCUOTATOTALVE = -1 
		else: 
			PRCUOTATOTALVE = 0

#--------------------------------------------
# Calcular variable  PRCUOTATOTALHP
#--------------------------------------------

	if CUOTATOTAL > 0 : 
		PRCUOTATOTALHP_C = AUX_CO01END005HP / CUOTATOTAL
		PRCUOTATOTALHP = round(PRCUOTATOTALHP_C,4) 
	else: 
		if CUOTATOTAL < 0 : 
			PRCUOTATOTALHP = -1 
		else: 
			PRCUOTATOTALHP = 0

#--------------------------------------------
# Calcular variable  PRCUOTATOTALOT
#--------------------------------------------

	if CUOTATOTAL > 0 : 
		PRCUOTATOTALOT_C = AUX_CO01END005OT / CUOTATOTAL
		PRCUOTATOTALOT = round(PRCUOTATOTALOT_C,4) 
	else: 
		if CUOTATOTAL < 0 : 
			PRCUOTATOTALOT = -1 
		else: 
			PRCUOTATOTALOT = 0

	if (data["CO01NUM001RO"] > 0 or data["CO01NUM001IN"] > 0 or data["CO01NUM001VE"] > 0 or data["CO01NUM001HP"] > 0) : 
		FINANCIERO = 1 
	else: 
		FINANCIERO = 0

#--------------------------------------------
# Calcular variable REAL
#--------------------------------------------

	if (data["CO01NUM001OT"] > 0) : 
		REAL = 1
	else: 
		REAL = 0

#--------------------------------------------
# Calcular variable TELCOS
#--------------------------------------------

	if (data["CO01NUM001CC"] > 0) : 
		TELCOS = 1 
	else: 
		TELCOS = 0

#--------------------------------------------
# Calcular variable TIPOREL
#--------------------------------------------
	TIPOREL=''
	if (FINANCIERO == 1 and REAL == 0 and TELCOS == 0) : 
		TIPOREL = 'F'

	if (FINANCIERO == 1 and REAL == 1 and TELCOS == 0) :  
		TIPOREL = 'F-R'

	if (FINANCIERO == 1 and REAL == 1 and TELCOS == 1) :  
		TIPOREL = 'F-R-T'

	if (FINANCIERO == 1 and REAL == 0 and TELCOS == 1) :  
		TIPOREL = 'F-T'

#--------------------------------------------
# Calcular variable TIPORELD01 ,TIPORELD02
#                   TIPORELD03 ,TIPORELD04
#--------------------------------------------

	if TIPOREL == 'F' : 
		TIPORELD01 = 1 
	else: 
		TIPORELD01 = 0
	
	if TIPOREL == 'F-R' : 
		TIPORELD02 = 1 
	else: 
		TIPORELD02 = 0
	
	if TIPOREL == 'F-R-T' : 
		TIPORELD03 = 1 
	else: 
		TIPORELD03 = 0 
	
	if TIPOREL == 'F-T' : 
		TIPORELD04 = 1 
	else: 
		TIPORELD04 = 0

#--------------------------------------------
# Calcular variable CAST_RO ,CAST_IN
#                   CAST_OT 
#--------------------------------------------

	if data["CO01NUM018RO"] < 0 : 
		AUX_CO01NUM018RO = 0 
	else: 
		AUX_CO01NUM018RO = data["CO01NUM018RO"]
	
	if data["CO01NUM019RO"] < 0 : 
		AUX_CO01NUM019RO = 0 
	else: 
		AUX_CO01NUM019RO = data["CO01NUM019RO"]
	
	CAST_RO = AUX_CO01NUM018RO + AUX_CO01NUM019RO
	
	if data["CO01NUM018IN"] < 0 : 
		AUX_CO01NUM018IN = 0 
	else: 
		AUX_CO01NUM018IN = data["CO01NUM018IN"]
	
	if data["CO01NUM019IN"] < 0 : 
		AUX_CO01NUM019IN = 0 
	else: 
		AUX_CO01NUM019IN = data["CO01NUM019IN"]
	
	CAST_IN = AUX_CO01NUM018IN + AUX_CO01NUM019IN
	
	if data["CO01NUM018OT"] < 0 : 
		AUX_CO01NUM018OT = 0 
	else: 
		AUX_CO01NUM018OT = data["CO01NUM018OT"]
	
	if data["CO01NUM019OT"] < 0 : 
		AUX_CO01NUM019OT = 0 
	else: 
		AUX_CO01NUM019OT = data["CO01NUM019OT"]
	
	CAST_OT = AUX_CO01NUM018OT + AUX_CO01NUM019OT;

#--------------------------------------------
# Calcular variable CAST_VE ,CAST_CC
#                   CAST_HP 
#--------------------------------------------

	if data["CO01NUM018VE"] < 0 : 
		AUX_CO01NUM018VE = 0 
	else: 
		AUX_CO01NUM018VE = data["CO01NUM018VE"]
	
	if data["CO01NUM019VE"] < 0 : 
		AUX_CO01NUM019VE = 0 
	else: 
		AUX_CO01NUM019VE = data["CO01NUM019VE"]
	
	CAST_VE = AUX_CO01NUM018VE + AUX_CO01NUM019VE
	
	if data["CO01NUM018CC"] < 0 : 
		AUX_CO01NUM018CC = 0 
	else: 
		AUX_CO01NUM018CC = data["CO01NUM018CC"]
	
	if data["CO01NUM019CC"] < 0 : 
		AUX_CO01NUM019CC = 0 
	else: 
		AUX_CO01NUM019CC = data["CO01NUM019CC"]
	
	CAST_CC = AUX_CO01NUM018CC + AUX_CO01NUM019CC
	
	if data["CO01NUM018HP"] < 0 : 
		AUX_CO01NUM018HP = 0 
	else: 
		AUX_CO01NUM018HP = data["CO01NUM018HP"]
	
	if data["CO01NUM019HP"] < 0 : 
		AUX_CO01NUM019HP = 0 
	else: 
		AUX_CO01NUM019HP = data["CO01NUM019HP"]
	
	CAST_HP = AUX_CO01NUM018HP + AUX_CO01NUM019HP

#--------------------------------------------
# Calcular variable CAST
#--------------------------------------------

	CAST = CAST_RO + CAST_IN + CAST_OT + CAST_VE + CAST_CC + CAST_HP

#--------------------------------------------
# Calcular variable QTOT
#--------------------------------------------

	if data["CO01NUM001CC"] < 0 : 
		AUX_CO01NUM001CC = 0 
	else: 
		AUX_CO01NUM001CC = data["CO01NUM001CC"]
	
	if data["CO01NUM001RO"] < 0 : 
		AUX_CO01NUM001RO = 0 
	else: 
		AUX_CO01NUM001RO = data["CO01NUM001RO"]
	
	if data["CO01NUM001IN"] < 0 : 
		AUX_CO01NUM001IN = 0 
	else: 
		AUX_CO01NUM001IN = data["CO01NUM001IN"]
	
	if data["CO01NUM001OT"] < 0 : 
		AUX_CO01NUM001OT = 0 
	else: 
		AUX_CO01NUM001OT = data["CO01NUM001OT"]
	
	if data["CO01NUM001VE"] < 0 : 
		AUX_CO01NUM001VE = 0 
	else: 
		AUX_CO01NUM001VE = data["CO01NUM001VE"]
	
	if data["CO01NUM001HP"] < 0 : 
		AUX_CO01NUM001HP = 0 
	else: 
		AUX_CO01NUM001HP = data["CO01NUM001HP"]
	
	QTOT = AUX_CO01NUM001CC + AUX_CO01NUM001RO + AUX_CO01NUM001IN + AUX_CO01NUM001OT + AUX_CO01NUM001VE + AUX_CO01NUM001HP

#--------------------------------------------
# Calcular variable QTOTAB
#--------------------------------------------

	if data["CO01NUM002CC"] < 0 : 
		AUX_CO01NUM002CC = 0 
	else: 
		AUX_CO01NUM002CC = data["CO01NUM002CC"]
	
	if data["CO01NUM002RO"] < 0 : 
		AUX_CO01NUM002RO = 0 
	else: 
		AUX_CO01NUM002RO = data["CO01NUM002RO"]
	
	if data["CO01NUM002IN"] < 0 : 
		AUX_CO01NUM002IN = 0 
	else: 
		AUX_CO01NUM002IN = data["CO01NUM002IN"]
	
	if data["CO01NUM002OT"] < 0 : 
		AUX_CO01NUM002OT = 0 
	else: 
		AUX_CO01NUM002OT = data["CO01NUM002OT"]
	
	if data["CO01NUM002VE"] < 0 : 
		AUX_CO01NUM002VE = 0 
	else: 
		AUX_CO01NUM002VE = data["CO01NUM002VE"]
	
	if data["CO01NUM002HP"] < 0 : 
		AUX_CO01NUM002HP = 0 
	else: 
		AUX_CO01NUM002HP = data["CO01NUM002HP"]
	
	QTOTAB = AUX_CO01NUM002CC + AUX_CO01NUM002RO + AUX_CO01NUM002IN + AUX_CO01NUM002OT + AUX_CO01NUM002VE + AUX_CO01NUM002HP

#--------------------------------------------
# Calcular variable PROQTOTAB
#--------------------------------------------

	if QTOT != 0:  
		PROQTOTAB_C = QTOTAB / QTOT
		PROQTOTAB = round(PROQTOTAB_C,4) 
	else: 
		PROQTOTAB = -1

#--------------------------------------------
# Calcular variables ALL_CC, ALL_RO, ALL_IN
#                    ALL_HP, ALL_VE, ALL_OT
#--------------------------------------------

	if data["CO02NUM002TO"] > 0 and data["CO01NUM002CC"] == data["CO02NUM002TO"] : 
		ALL_CC = 1  
	else: 
		ALL_CC = 0

	if data["CO02NUM002TO"] > 0 and data["CO01NUM002RO"] == data["CO02NUM002TO"] : 
		ALL_RO = 1  
	else: 
		ALL_RO = 0

	if data["CO02NUM002TO"] > 0 and data["CO01NUM002IN"] == data["CO02NUM002TO"] : 
		ALL_IN = 1  
	else: 
		ALL_IN = 0

	if data["CO02NUM002TO"] > 0 and data["CO01NUM002HP"] == data["CO02NUM002TO"] : 
		ALL_HP = 1  
	else: 
		ALL_HP = 0

	if data["CO02NUM002TO"] > 0 and data["CO01NUM002VE"] == data["CO02NUM002TO"] : 
		ALL_VE = 1  
	else: 
		ALL_VE = 0

	if data["CO02NUM002TO"] > 0 and data["CO01NUM002OT"] == data["CO02NUM002TO"] : 
		ALL_OT = 1  
	else:
		ALL_OT = 0

#--------------------------------------------
# Calcular variable OPEN03
#--------------------------------------------

	if data["CO01ACP001RO"] < 0 : 
		AUX_CO01ACP001RO = 0 
	else: 
		AUX_CO01ACP001RO = data["CO01ACP001RO"]
	
	if data["CO01ACP001IN"] < 0 : 
		AUX_CO01ACP001IN = 0 
	else: 
		AUX_CO01ACP001IN = data["CO01ACP001IN"]
	
	if data["CO01ACP001OT"] < 0 : 
		AUX_CO01ACP001OT = 0 
	else: 
		AUX_CO01ACP001OT = data["CO01ACP001OT"] 
	
	if data["CO01ACP001VE"] < 0 : 
		AUX_CO01ACP001VE = 0 
	else: 
		AUX_CO01ACP001VE = data["CO01ACP001VE"] 
	
	if data["CO01ACP001CC"] < 0 : 
		AUX_CO01ACP001CC = 0 
	else: 
		AUX_CO01ACP001CC = data["CO01ACP001CC"] 
	
	if data["CO01ACP001HP"] < 0 : 
		AUX_CO01ACP001HP = 0 
	else: 
		AUX_CO01ACP001HP = data["CO01ACP001HP"]
	
	OPEN03 = AUX_CO01ACP001RO + AUX_CO01ACP001IN + AUX_CO01ACP001OT + AUX_CO01ACP001VE + AUX_CO01ACP001CC + AUX_CO01ACP001HP

#--------------------------------------------
# Calcular variable OPEN06
#--------------------------------------------

	if data["CO01ACP002RO"] < 0 : 
		AUX_CO01ACP002RO = 0 
	else: 
		AUX_CO01ACP002RO = data["CO01ACP002RO"] 
	
	if data["CO01ACP002IN"] < 0 : 
		AUX_CO01ACP002IN = 0 
	else: 
		AUX_CO01ACP002IN = data["CO01ACP002IN"] 
	
	if data["CO01ACP002OT"] < 0 : 
		AUX_CO01ACP002OT = 0 
	else: 
		AUX_CO01ACP002OT = data["CO01ACP002OT"] 
	
	if data["CO01ACP002VE"] < 0 : 
		AUX_CO01ACP002VE = 0 
	else: 
		AUX_CO01ACP002VE = data["CO01ACP002VE"] 
	
	if data["CO01ACP002CC"] < 0 : 
		AUX_CO01ACP002CC = 0 
	else: 
		AUX_CO01ACP002CC = data["CO01ACP002CC"] 
	
	if data["CO01ACP002HP"] < 0 : 
		AUX_CO01ACP002HP = 0 
	else: 
		AUX_CO01ACP002HP = data["CO01ACP002HP"]
	
	OPEN06 = AUX_CO01ACP002RO + AUX_CO01ACP002IN + AUX_CO01ACP002OT + AUX_CO01ACP002VE + AUX_CO01ACP002CC + AUX_CO01ACP002HP

#--------------------------------------------
# Calcular variable OPEN12
#--------------------------------------------

	if data["CO01ACP003RO"] < 0 : 
		AUX_CO01ACP003RO = 0
	else: 
		AUX_CO01ACP003RO = data["CO01ACP003RO"] 
	
	if data["CO01ACP003IN"] < 0 : 
		AUX_CO01ACP003IN = 0 
	else: 
		AUX_CO01ACP003IN = data["CO01ACP003IN"] 
	
	if data["CO01ACP003OT"] < 0 : 
		AUX_CO01ACP003OT = 0 
	else: 
		AUX_CO01ACP003OT = data["CO01ACP003OT"] 
	
	if data["CO01ACP003VE"] < 0 : 
		AUX_CO01ACP003VE = 0 
	else: 
		AUX_CO01ACP003VE = data["CO01ACP003VE"] 
	
	if data["CO01ACP003CC"] < 0 : 
		AUX_CO01ACP003CC = 0 
	else: 
		AUX_CO01ACP003CC = data["CO01ACP003CC"] 
	
	if data["CO01ACP003HP"] < 0 : 
		AUX_CO01ACP003HP = 0 
	else: 
		AUX_CO01ACP003HP = data["CO01ACP003HP"]
	
	OPEN12 = AUX_CO01ACP003RO + AUX_CO01ACP003IN + AUX_CO01ACP003OT + AUX_CO01ACP003VE + AUX_CO01ACP003CC + AUX_CO01ACP003HP

#--------------------------------------------
# Calcular variable OPEN18
#--------------------------------------------

	if data["CO01ACP004RO"] < 0 : 
		AUX_CO01ACP004RO = 0; 
	else: 
		AUX_CO01ACP004RO = data["CO01ACP004RO"]
	
	if data["CO01ACP004IN"] < 0 : 
		AUX_CO01ACP004IN = 0
	else: 
		AUX_CO01ACP004IN = data["CO01ACP004IN"]
	
	if data["CO01ACP004OT"] < 0 : 
		AUX_CO01ACP004OT = 0; 
	else: 
		AUX_CO01ACP004OT = data["CO01ACP004OT"]
	
	if data["CO01ACP004VE"] < 0 : 
		AUX_CO01ACP004VE = 0; 
	else: 
		AUX_CO01ACP004VE = data["CO01ACP004VE"]
	
	if data["CO01ACP004CC"] < 0 : 
		AUX_CO01ACP004CC = 0; 
	else: 
		AUX_CO01ACP004CC = data["CO01ACP004CC"]
	
	if data["CO01ACP004HP"] < 0 : 
		AUX_CO01ACP004HP = 0; 
	else: 
		AUX_CO01ACP004HP = data["CO01ACP004HP"]
	
	OPEN18 = AUX_CO01ACP004RO + AUX_CO01ACP004IN + AUX_CO01ACP004OT + AUX_CO01ACP004VE + AUX_CO01ACP004CC + AUX_CO01ACP004HP;

#--------------------------------------------
# Calcular variable OPEN24
#--------------------------------------------

	if data["CO01ACP005RO"] < 0 : 
		AUX_CO01ACP005RO = 0 
	else: 
		AUX_CO01ACP005RO = data["CO01ACP005RO"]
	
	if data["CO01ACP005IN"] < 0 : 
		AUX_CO01ACP005IN = 0 
	else: 
		AUX_CO01ACP005IN = data["CO01ACP005IN"]
	
	if data["CO01ACP005OT"] < 0 : 
		AUX_CO01ACP005OT = 0 
	else: 
		AUX_CO01ACP005OT = data["CO01ACP005OT"] 
	
	if data["CO01ACP005VE"] < 0 : 
		AUX_CO01ACP005VE = 0 
	else: 
		AUX_CO01ACP005VE = data["CO01ACP005VE"] 
	
	if data["CO01ACP005CC"] < 0 : 
		AUX_CO01ACP005CC = 0 
	else: 
		AUX_CO01ACP005CC = data["CO01ACP005CC"] 
	
	if data["CO01ACP005HP"] < 0 : 
		AUX_CO01ACP005HP = 0 
	else: 
		AUX_CO01ACP005HP = data["CO01ACP005HP"]
	
	OPEN24 = AUX_CO01ACP005RO + AUX_CO01ACP005IN + AUX_CO01ACP005OT + AUX_CO01ACP005VE + AUX_CO01ACP005CC + AUX_CO01ACP005HP

#--------------------------------------------
# Calcular variable OPEN36
#--------------------------------------------

	if data["CO01ACP006RO"] < 0 : 
		A_CO01ACP006RO = 0 
	else: 
		A_CO01ACP006RO = data["CO01ACP006RO"]
	
	if data["CO01ACP006IN"] < 0 : 
		A_CO01ACP006IN = 0 
	else: 
		A_CO01ACP006IN = data["CO01ACP006IN"] 
	
	if data["CO01ACP006OT"] < 0 : 
		A_CO01ACP006OT = 0 
	else: 
		A_CO01ACP006OT = data["CO01ACP006OT"]
	
	if data["CO01ACP006VE"] < 0 : 
		A_CO01ACP006VE = 0 
	else: 
		A_CO01ACP006VE = data["CO01ACP006VE"] 
	
	if data["CO01ACP006CC"] < 0 : 
		A_CO01ACP006CC = 0 
	else: 
		A_CO01ACP006CC = data["CO01ACP006CC"] 
	
	if data["CO01ACP006HP"] < 0 : 
		A_CO01ACP006HP = 0 
	else: 
		A_CO01ACP006HP = data["CO01ACP006HP"]
	
	OPEN36 = A_CO01ACP006RO + A_CO01ACP006IN + A_CO01ACP006OT + A_CO01ACP006VE + A_CO01ACP006CC + A_CO01ACP006HP

#--------------------------------------------
# Calcular variable OPEN48
#--------------------------------------------

	if data["CO01ACP007RO"] < 0 : 
		AUX_CO01ACP007RO = 0 
	else: 
		AUX_CO01ACP007RO = data["CO01ACP007RO"] 
	
	if data["CO01ACP007IN"] < 0 : 
		AUX_CO01ACP007IN = 0 
	else: 
		AUX_CO01ACP007IN = data["CO01ACP007IN"] 
	
	if data["CO01ACP007OT"] < 0 : 
		AUX_CO01ACP007OT = 0 
	else: 
		AUX_CO01ACP007OT = data["CO01ACP007OT"] 
	
	if data["CO01ACP007VE"] < 0 : 
		AUX_CO01ACP007VE = 0 
	else: 
		AUX_CO01ACP007VE = data["CO01ACP007VE"] 
	
	if data["CO01ACP007CC"] < 0 : 
		AUX_CO01ACP007CC = 0 
	else: 
		AUX_CO01ACP007CC = data["CO01ACP007CC"] 
	
	if data["CO01ACP007HP"] < 0 : 
		AUX_CO01ACP007HP = 0 
	else: 
		AUX_CO01ACP007HP = data["CO01ACP007HP"]
	
	OPEN48 = AUX_CO01ACP007RO + AUX_CO01ACP007IN + AUX_CO01ACP007OT + AUX_CO01ACP007VE + AUX_CO01ACP007CC + AUX_CO01ACP007HP

#--------------------------------------------
# Calcular variable RECMORA030
#--------------------------------------------

	if data["CO01MOR075RO"] < 0 : 
		AUX_CO01MOR075RO = 999 
	else: 
		AUX_CO01MOR075RO = data["CO01MOR075RO"]
	
	if data["CO01MOR075IN"] < 0 : 
		AUX_CO01MOR075IN = 999 
	else: 
		AUX_CO01MOR075IN = data["CO01MOR075IN"]
	
	if data["CO01MOR075OT"] < 0 : 
		AUX_CO01MOR075OT = 999 
	else: 
		AUX_CO01MOR075OT = data["CO01MOR075OT"]
	
	if data["CO01MOR075VE"] < 0 : 
		AUX_CO01MOR075VE = 999 
	else: 
		AUX_CO01MOR075VE = data["CO01MOR075VE"]
	
	if data["CO01MOR075CC"] < 0 : 
		AUX_CO01MOR075CC = 999 
	else: 
		AUX_CO01MOR075CC = data["CO01MOR075CC"]
	
	if data["CO01MOR075HP"] < 0 : 
		AUX_CO01MOR075HP = 999 
	else: 
		AUX_CO01MOR075HP = data["CO01MOR075HP"]
	
	RECMORA030 = min( AUX_CO01MOR075RO, AUX_CO01MOR075IN, AUX_CO01MOR075OT, AUX_CO01MOR075VE, AUX_CO01MOR075CC, AUX_CO01MOR075HP)

#--------------------------------------------
# Calcular variable RECMORA060
#--------------------------------------------

	if data["CO01MOR076RO"] < 0 : 
		AUX_CO01MOR076RO = 999 
	else: 
		AUX_CO01MOR076RO = data["CO01MOR076RO"]
	
	if data["CO01MOR076IN"] < 0 : 
		AUX_CO01MOR076IN = 999 
	else: 
		AUX_CO01MOR076IN = data["CO01MOR076IN"]
	
	if data["CO01MOR076OT"] < 0 : 
		AUX_CO01MOR076OT = 999 
	else: 
		AUX_CO01MOR076OT = data["CO01MOR076OT"]
	
	if data["CO01MOR076VE"] < 0 : 
		AUX_CO01MOR076VE = 999 
	else: 
		AUX_CO01MOR076VE = data["CO01MOR076VE"]
	
	if data["CO01MOR076CC"] < 0 : 
		AUX_CO01MOR076CC = 999 
	else: 
		AUX_CO01MOR076CC = data["CO01MOR076CC"]
	
	if data["CO01MOR076HP"] < 0 : 
		AUX_CO01MOR076HP = 999 
	else: 
		AUX_CO01MOR076HP = data["CO01MOR076HP"]
	
	RECMORA060 = min(AUX_CO01MOR076RO, AUX_CO01MOR076IN, AUX_CO01MOR076OT, AUX_CO01MOR076VE, AUX_CO01MOR076CC, AUX_CO01MOR076HP)

#--------------------------------------------
# Calcular variable RECMORA090
#--------------------------------------------

	if data["CO01MOR077RO"] < 0 : 
		AUX_CO01MOR077RO = 999 
	else: 
		AUX_CO01MOR077RO = data["CO01MOR077RO"] 
	
	if data["CO01MOR077IN"] < 0 : 
		AUX_CO01MOR077IN = 999 
	else: 
		AUX_CO01MOR077IN = data["CO01MOR077IN"]
	
	if data["CO01MOR077OT"] < 0 : 
		AUX_CO01MOR077OT = 999 
	else: 
		AUX_CO01MOR077OT = data["CO01MOR077OT"]
	
	if data["CO01MOR077VE"] < 0 : 
		AUX_CO01MOR077VE = 999 
	else: 
		AUX_CO01MOR077VE = data["CO01MOR077VE"]
	
	if data["CO01MOR077CC"] < 0 : 
		AUX_CO01MOR077CC = 999 
	else: 
		AUX_CO01MOR077CC = data["CO01MOR077CC"]
	
	if data["CO01MOR077HP"] < 0 : 
		AUX_CO01MOR077HP = 999 
	else: 
		AUX_CO01MOR077HP = data["CO01MOR077HP"]
	
	RECMORA090 = min(AUX_CO01MOR077RO, AUX_CO01MOR077IN, AUX_CO01MOR077OT, AUX_CO01MOR077VE, AUX_CO01MOR077CC, AUX_CO01MOR077HP)

#--------------------------------------------
# Calcular variable RECMORA120
#--------------------------------------------

	if data["CO01MOR078RO"] < 0 : 
		AUX_CO01MOR078RO = 999 
	else: 
		AUX_CO01MOR078RO = data["CO01MOR078RO"]
	
	if data["CO01MOR078IN"] < 0 : 
		AUX_CO01MOR078IN = 999 
	else: 
		AUX_CO01MOR078IN = data["CO01MOR078IN"]
	
	if data["CO01MOR078OT"] < 0 : 
		AUX_CO01MOR078OT = 999 
	else: 
		AUX_CO01MOR078OT = data["CO01MOR078OT"]
	
	if data["CO01MOR078VE"] < 0 : 
		AUX_CO01MOR078VE = 999 
	else: 
		AUX_CO01MOR078VE = data["CO01MOR078VE"]
	
	if data["CO01MOR078CC"] < 0 : 
		AUX_CO01MOR078CC = 999 
	else: 
		AUX_CO01MOR078CC = data["CO01MOR078CC"]
	
	if data["CO01MOR078HP"] < 0 : 
		AUX_CO01MOR078HP = 999 
	else: 
		AUX_CO01MOR078HP = data["CO01MOR078HP"]
	
	RECMORA120 = min(AUX_CO01MOR078RO, AUX_CO01MOR078IN, AUX_CO01MOR078OT, AUX_CO01MOR078VE, AUX_CO01MOR078CC, AUX_CO01MOR078HP)

#--------------------------------------------
# Calcular variable RECMORACC
#--------------------------------------------

	if data["CO01MOR079RO"] < 0 : 
		AUX_CO01MOR079RO = 999 
	else: 
		AUX_CO01MOR079RO = data["CO01MOR079RO"]
	
	if data["CO01MOR079IN"] < 0 : 
		AUX_CO01MOR079IN = 999 
	else: 
		AUX_CO01MOR079IN = data["CO01MOR079IN"]
	
	if data["CO01MOR079OT"] < 0 : 
		AUX_CO01MOR079OT = 999 
	else: 
		AUX_CO01MOR079OT = data["CO01MOR079OT"]
	
	if data["CO01MOR079VE"] < 0 : 
		AUX_CO01MOR079VE = 999 
	else: 
		AUX_CO01MOR079VE = data["CO01MOR079VE"]
	
	if data["CO01MOR079CC"] < 0 : 
		AUX_CO01MOR079CC = 999
	else: 
		AUX_CO01MOR079CC = data["CO01MOR079CC"]
	
	if data["CO01MOR079HP"] < 0 : 
		AUX_CO01MOR079HP = 999 
	else: 
		AUX_CO01MOR079HP = data["CO01MOR079HP"]
	
	RECMORACC = min(AUX_CO01MOR079RO, AUX_CO01MOR079IN, AUX_CO01MOR079OT, AUX_CO01MOR079VE, AUX_CO01MOR079CC, AUX_CO01MOR079HP)

#--------------------------------------------
# Calcular variable RECMORA001
#--------------------------------------------

	RECMORA001 = min(RECMORA030, RECMORA060, RECMORA090, RECMORA120, RECMORACC)

#--------------------------------------------
# Calcular variable RECMORA001
#--------------------------------------------

	RECMORA002 = min(RECMORA030, RECMORA060, RECMORA090, RECMORA120);

#--------------------------------------------
# Calcular variable RECMORA001VSA
#--------------------------------------------

	if (data["CO02NUM018TO"] >= 1 and data["CO02NUM018TO"] != data["CO01NUM018CO"] and RECMORA001 > 0) : 
		RECMORA001VSA = 0 
	else: 
		RECMORA001VSA = RECMORA001

#--------------------------------------------
# Calcular variable RECMORA002VSA
#--------------------------------------------

	if data["CO02NUM018TO"] >= 1 and data["CO02NUM018TO"] != data["CO01NUM018CO"] and RECMORA002 > 0 : 
		RECMORA002VSA = 0; 
	else: 
		RECMORA002VSA = RECMORA002; 
	
	if RECMORA001 == 0 and RECMORA002VSA > 0 : 
		RECMORA002VSA = 0

#--------------------------------------------
# Calcular variable EVER03006P
#--------------------------------------------

	if data["CO01MOR034RO"] < 0 : 
		AUX_CO01MOR034RO = 0 
	else: 
		AUX_CO01MOR034RO = data["CO01MOR034RO"]
	
	if data["CO01MOR034IN"] < 0 : 
		AUX_CO01MOR034IN = 0 
	else: 
		AUX_CO01MOR034IN = data["CO01MOR034IN"]
	
	if data["CO01MOR034OT"] < 0 : 
		AUX_CO01MOR034OT = 0 
	else: 
		AUX_CO01MOR034OT = data["CO01MOR034OT"]
	
	if data["CO01MOR034VE"] < 0 : 
		AUX_CO01MOR034VE = 0 
	else: 
		AUX_CO01MOR034VE = data["CO01MOR034VE"]
	
	if data["CO01MOR034CC"] < 0 : 
		AUX_CO01MOR034CC = 0 
	else: 
		AUX_CO01MOR034CC = data["CO01MOR034CC"]
	
	if data["CO01MOR034HP"] < 0 : 
		AUX_CO01MOR034HP = 0 
	else: 
		AUX_CO01MOR034HP = data["CO01MOR034HP"]
	
	EVER03006P = AUX_CO01MOR034RO + AUX_CO01MOR034IN + AUX_CO01MOR034OT + AUX_CO01MOR034VE + AUX_CO01MOR034CC + AUX_CO01MOR034HP

#--------------------------------------------
# Calcular variable EVER06006P
#--------------------------------------------

	if data["CO01MOR035RO"] < 0 : 
		AUX_CO01MOR035RO = 0 
	else: 
		AUX_CO01MOR035RO = data["CO01MOR035RO"]
	
	if data["CO01MOR035IN"] < 0 : 
		AUX_CO01MOR035IN = 0 
	else: 
		AUX_CO01MOR035IN = data["CO01MOR035IN"] 
	
	if data["CO01MOR035OT"] < 0 : 
		AUX_CO01MOR035OT = 0 
	else: 
		AUX_CO01MOR035OT = data["CO01MOR035OT"] 
	
	if data["CO01MOR035VE"] < 0 : 
		AUX_CO01MOR035VE = 0 
	else: 
		AUX_CO01MOR035VE = data["CO01MOR035VE"] 
	
	if data["CO01MOR035CC"] < 0 : 
		AUX_CO01MOR035CC = 0 
	else: 
		AUX_CO01MOR035CC = data["CO01MOR035CC"] 
	
	if data["CO01MOR035HP"] < 0 : 
		AUX_CO01MOR035HP = 0 
	else: 
		AUX_CO01MOR035HP = data["CO01MOR035HP"]
	
	EVER06006P = AUX_CO01MOR035RO + AUX_CO01MOR035IN + AUX_CO01MOR035OT + AUX_CO01MOR035VE + AUX_CO01MOR035CC + AUX_CO01MOR035HP

#--------------------------------------------
# Calcular variable EVER09006P
#--------------------------------------------

	if data["CO01MOR036RO"] < 0 : 
		AUX_CO01MOR036RO = 0 
	else:
		AUX_CO01MOR036RO = data["CO01MOR036RO"] 
	
	if data["CO01MOR036IN"] < 0 : 
		AUX_CO01MOR036IN = 0 
	else:
		AUX_CO01MOR036IN = data["CO01MOR036IN"] 
	
	if data["CO01MOR036OT"] < 0 : 
		AUX_CO01MOR036OT = 0 
	else:
		AUX_CO01MOR036OT = data["CO01MOR036OT"] 
	
	if data["CO01MOR036VE"] < 0 : 
		AUX_CO01MOR036VE = 0 
	else:
		AUX_CO01MOR036VE = data["CO01MOR036VE"] 
	
	if data["CO01MOR036CC"] < 0 : 
		AUX_CO01MOR036CC = 0 
	else:
		AUX_CO01MOR036CC = data["CO01MOR036CC"] 
	
	if data["CO01MOR036HP"] < 0 : 
		AUX_CO01MOR036HP = 0 
	else:
		AUX_CO01MOR036HP = data["CO01MOR036HP"]
	
	EVER09006P = AUX_CO01MOR036RO + AUX_CO01MOR036IN + AUX_CO01MOR036OT + AUX_CO01MOR036VE + AUX_CO01MOR036CC + AUX_CO01MOR036HP

#--------------------------------------------
# Calcular variable EVER12006P
#--------------------------------------------

	if data["CO01MOR037RO"] < 0 : 
		AUX_CO01MOR037RO = 0 
	else: 
		AUX_CO01MOR037RO = data["CO01MOR037RO"] 
	
	if data["CO01MOR037IN"] < 0 : 
		AUX_CO01MOR037IN = 0 
	else: 
		AUX_CO01MOR037IN = data["CO01MOR037IN"] 
	
	if data["CO01MOR037OT"] < 0 : 
		AUX_CO01MOR037OT = 0 
	else: 
		AUX_CO01MOR037OT = data["CO01MOR037OT"] 
	
	if data["CO01MOR037VE"] < 0 : 
		AUX_CO01MOR037VE = 0 
	else: 
		AUX_CO01MOR037VE = data["CO01MOR037VE"] 
	
	if data["CO01MOR037CC"] < 0 : 
		AUX_CO01MOR037CC = 0 
	else: 
		AUX_CO01MOR037CC = data["CO01MOR037CC"] 
	
	if data["CO01MOR037HP"] < 0 : 
		AUX_CO01MOR037HP = 0 
	else: 
		AUX_CO01MOR037HP = data["CO01MOR037HP"]
	
	EVER12006P = AUX_CO01MOR037RO + AUX_CO01MOR037IN + AUX_CO01MOR037OT + AUX_CO01MOR037VE + AUX_CO01MOR037CC + AUX_CO01MOR037HP

#--------------------------------------------
# Calcular variable EVERCC006P
#--------------------------------------------

	if data["CO01MOR038RO"] < 0 : 
		AUX_CO01MOR038RO = 0 
	else: 
		AUX_CO01MOR038RO = data["CO01MOR038RO"] 
	
	if data["CO01MOR038IN"] < 0 : 
		AUX_CO01MOR038IN = 0 
	else: 
		AUX_CO01MOR038IN = data["CO01MOR038IN"] 
	
	if data["CO01MOR038OT"] < 0 : 
		AUX_CO01MOR038OT = 0 
	else: 
		AUX_CO01MOR038OT = data["CO01MOR038OT"] 
	
	if data["CO01MOR038VE"] < 0 : 
		AUX_CO01MOR038VE = 0 
	else: 
		AUX_CO01MOR038VE = data["CO01MOR038VE"] 
	
	if data["CO01MOR038CC"] < 0 : 
		AUX_CO01MOR038CC = 0 
	else: 
		AUX_CO01MOR038CC = data["CO01MOR038CC"] 
	
	if data["CO01MOR038HP"] < 0 : 
		AUX_CO01MOR038HP = 0 
	else: 
		AUX_CO01MOR038HP = data["CO01MOR038HP"]
	
	EVERCC006P = AUX_CO01MOR038RO + AUX_CO01MOR038IN + AUX_CO01MOR038OT + AUX_CO01MOR038VE + AUX_CO01MOR038CC + AUX_CO01MOR038HP

#--------------------------------------------
# Calcular variables EVER03006E EVER06006E
#                    EVER09006E EVER12006E
#--------------------------------------------
	EVER03006E = EVER03006P - EVER06006P
	EVER06006E = EVER06006P - EVER09006P
	EVER09006E = EVER09006P - EVER12006P
	EVER12006E = EVER12006P - EVERCC006P

#--------------------------------------------
# Calcular variable EVER03012P
#--------------------------------------------

	if data["CO01MOR041RO"] < 0 : 
		AUX_CO01MOR041RO = 0 
	else: 
		AUX_CO01MOR041RO = data["CO01MOR041RO"] 
	
	if data["CO01MOR041IN"] < 0 : 
		AUX_CO01MOR041IN = 0 
	else: 
		AUX_CO01MOR041IN = data["CO01MOR041IN"] 
	
	if data["CO01MOR041OT"] < 0 : 
		AUX_CO01MOR041OT = 0 
	else: 
		AUX_CO01MOR041OT = data["CO01MOR041OT"] 
	
	if data["CO01MOR041VE"] < 0 : 
		AUX_CO01MOR041VE = 0 
	else: 
		AUX_CO01MOR041VE = data["CO01MOR041VE"] 
	
	if data["CO01MOR041CC"] < 0 : 
		AUX_CO01MOR041CC = 0 
	else: 
		AUX_CO01MOR041CC = data["CO01MOR041CC"] 
	
	if data["CO01MOR041HP"] < 0 : 
		AUX_CO01MOR041HP = 0 
	else: 
		AUX_CO01MOR041HP = data["CO01MOR041HP"]
		
	EVER03012P = AUX_CO01MOR041RO + AUX_CO01MOR041IN + AUX_CO01MOR041OT + AUX_CO01MOR041VE + AUX_CO01MOR041CC + AUX_CO01MOR041HP

#--------------------------------------------
# Calcular variable EVER06012P
#--------------------------------------------

	if data["CO01MOR042RO"] < 0 : 
		AUX_CO01MOR042RO = 0 
	else:
		AUX_CO01MOR042RO = data["CO01MOR042RO"] 
	
	if data["CO01MOR042IN"] < 0 : 
		AUX_CO01MOR042IN = 0 
	else:
		AUX_CO01MOR042IN = data["CO01MOR042IN"] 
	
	if data["CO01MOR042OT"] < 0 : 
		AUX_CO01MOR042OT = 0 
	else:
		AUX_CO01MOR042OT = data["CO01MOR042OT"] 
	
	if data["CO01MOR042VE"] < 0 : 
		AUX_CO01MOR042VE = 0 
	else:
		AUX_CO01MOR042VE = data["CO01MOR042VE"] 
	
	if data["CO01MOR042CC"] < 0 : 
		AUX_CO01MOR042CC = 0 
	else:
		AUX_CO01MOR042CC = data["CO01MOR042CC"] 
	
	if data["CO01MOR042HP"] < 0 : 
		AUX_CO01MOR042HP = 0
	else:
		AUX_CO01MOR042HP = data["CO01MOR042HP"]
	
	EVER06012P = AUX_CO01MOR042RO + AUX_CO01MOR042IN + AUX_CO01MOR042OT + AUX_CO01MOR042VE + AUX_CO01MOR042CC + AUX_CO01MOR042HP

#--------------------------------------------
# Calcular variable EVER09012P
#--------------------------------------------

	if data["CO01MOR043RO"] < 0 : 
		AUX_CO01MOR043RO = 0 
	else: 
		AUX_CO01MOR043RO = data["CO01MOR043RO"] 
	
	if data["CO01MOR043IN"] < 0 : 
		AUX_CO01MOR043IN = 0 
	else: 
		AUX_CO01MOR043IN = data["CO01MOR043IN"] 
	
	if data["CO01MOR043OT"] < 0 : 
		AUX_CO01MOR043OT = 0 
	else: 
		AUX_CO01MOR043OT = data["CO01MOR043OT"] 
	
	if data["CO01MOR043VE"] < 0 : 
		AUX_CO01MOR043VE = 0 
	else: 
		AUX_CO01MOR043VE = data["CO01MOR043VE"] 
	
	if data["CO01MOR043CC"] < 0 : 
		AUX_CO01MOR043CC = 0 
	else: 
		AUX_CO01MOR043CC = data["CO01MOR043CC"] 
	
	if data["CO01MOR043HP"] < 0 : 
		AUX_CO01MOR043HP = 0 
	else: 
		AUX_CO01MOR043HP = data["CO01MOR043HP"]
	
	EVER09012P = AUX_CO01MOR043RO + AUX_CO01MOR043IN + AUX_CO01MOR043OT + AUX_CO01MOR043VE + AUX_CO01MOR043CC + AUX_CO01MOR043HP

#--------------------------------------------
# Calcular variable EVER12012P
#--------------------------------------------

	if data["CO01MOR044RO"] < 0 : 
		AUX_CO01MOR044RO = 0 
	else: 
		AUX_CO01MOR044RO = data["CO01MOR044RO"]
	
	if data["CO01MOR044IN"] < 0 : 
		AUX_CO01MOR044IN = 0 
	else: 
		AUX_CO01MOR044IN = data["CO01MOR044IN"] 
	
	if data["CO01MOR044OT"] < 0 : 
		AUX_CO01MOR044OT = 0 
	else: 
		AUX_CO01MOR044OT = data["CO01MOR044OT"] 
	
	if data["CO01MOR044VE"] < 0 : 
		AUX_CO01MOR044VE = 0 
	else: 
		AUX_CO01MOR044VE = data["CO01MOR044VE"] 
	
	if data["CO01MOR044CC"] < 0 : 
		AUX_CO01MOR044CC = 0 
	else: 
		AUX_CO01MOR044CC = data["CO01MOR044CC"] 
	
	if data["CO01MOR044HP"] < 0 : 
		AUX_CO01MOR044HP = 0 
	else: 
		AUX_CO01MOR044HP = data["CO01MOR044HP"]
	
	EVER12012P = AUX_CO01MOR044RO + AUX_CO01MOR044IN + AUX_CO01MOR044OT + AUX_CO01MOR044VE + AUX_CO01MOR044CC + AUX_CO01MOR044HP

#--------------------------------------------
# Calcular variable EVERCC012P
#--------------------------------------------

	if data["CO01MOR045RO"] < 0 : 
		A_CO01MOR045RO = 0 
	else: 
		A_CO01MOR045RO = data["CO01MOR045RO"] 
	
	if data["CO01MOR045IN"] < 0 : 
		A_CO01MOR045IN = 0 
	else: 
		A_CO01MOR045IN = data["CO01MOR045IN"] 
	
	if data["CO01MOR045OT"] < 0 : 
		A_CO01MOR045OT = 0 
	else: 
		A_CO01MOR045OT = data["CO01MOR045OT"] 
	
	if data["CO01MOR045VE"] < 0 : 
		A_CO01MOR045VE = 0 
	else: 
		A_CO01MOR045VE = data["CO01MOR045VE"] 
	
	if data["CO01MOR045CC"] < 0 : 
		A_CO01MOR045CC = 0 
	else: 
		A_CO01MOR045CC = data["CO01MOR045CC"] 
	
	if data["CO01MOR045HP"] < 0 : 
		A_CO01MOR045HP = 0 
	else: 
		A_CO01MOR045HP = data["CO01MOR045HP"]
	
	EVERCC012P = A_CO01MOR045RO + A_CO01MOR045IN + A_CO01MOR045OT + A_CO01MOR045VE+ A_CO01MOR045CC+ A_CO01MOR045HP

#--------------------------------------------
# Calcula variables EVER03012E, EVER06012E
#                   EVER09012E, EVER12012E
#--------------------------------------------

	EVER03012E = EVER03012P - EVER06012P
	EVER06012E = EVER06012P - EVER09012P
	EVER09012E = EVER09012P - EVER12012P
	EVER12012E = EVER12012P - EVERCC012P

#--------------------------------------------
# Calcular variable EVER03018P
#--------------------------------------------
	if data["CO01MOR048RO"] < 0 : 
		AUX_CO01MOR048RO = 0 
	else: 
		AUX_CO01MOR048RO = data["CO01MOR048RO"] 
	
	if data["CO01MOR048IN"] < 0 : 
		AUX_CO01MOR048IN = 0 
	else: 
		AUX_CO01MOR048IN = data["CO01MOR048IN"] 
	
	if data["CO01MOR048OT"] < 0 : 
		AUX_CO01MOR048OT = 0 
	else: 
		AUX_CO01MOR048OT = data["CO01MOR048OT"] 
	
	if data["CO01MOR048VE"] < 0 : 
		AUX_CO01MOR048VE = 0 
	else: 
		AUX_CO01MOR048VE = data["CO01MOR048VE"] 
	
	if data["CO01MOR048CC"] < 0 : 
		AUX_CO01MOR048CC = 0 
	else: 
		AUX_CO01MOR048CC = data["CO01MOR048CC"]
	
	if data["CO01MOR048HP"] < 0 : 
		AUX_CO01MOR048HP = 0 
	else: 
		AUX_CO01MOR048HP = data["CO01MOR048HP"]
	
	EVER03018P = AUX_CO01MOR048RO + AUX_CO01MOR048IN + AUX_CO01MOR048OT + AUX_CO01MOR048VE + AUX_CO01MOR048CC + AUX_CO01MOR048HP
#--------------------------------------------
# Calcular variable EVER06018P
#--------------------------------------------

	if data["CO01MOR049RO"] < 0 : 
		AUX_CO01MOR049RO = 0 
	else: 
		AUX_CO01MOR049RO = data["CO01MOR049RO"] 
	
	if data["CO01MOR049IN"] < 0 : 
		AUX_CO01MOR049IN = 0 
	else: 
		AUX_CO01MOR049IN = data["CO01MOR049IN"] 
	
	if data["CO01MOR049OT"] < 0 : 
		AUX_CO01MOR049OT = 0 
	else: 
		AUX_CO01MOR049OT = data["CO01MOR049OT"] 
	
	if data["CO01MOR049VE"] < 0 : 
		AUX_CO01MOR049VE = 0 
	else: 
		AUX_CO01MOR049VE = data["CO01MOR049VE"] 
	
	if data["CO01MOR049CC"] < 0 : 
		AUX_CO01MOR049CC = 0 
	else: 
		AUX_CO01MOR049CC = data["CO01MOR049CC"] 
	
	if data["CO01MOR049HP"] < 0 : 
		AUX_CO01MOR049HP = 0 
	else: 
		AUX_CO01MOR049HP = data["CO01MOR049HP"]
	
	EVER06018P = AUX_CO01MOR049RO + AUX_CO01MOR049IN + AUX_CO01MOR049OT + AUX_CO01MOR049VE + AUX_CO01MOR049CC + AUX_CO01MOR049HP

#--------------------------------------------
# Calcular variable EVER09018P
#--------------------------------------------

	if data["CO01MOR050RO"] < 0 : 
		AUX_CO01MOR050RO = 0 
	else: 
		AUX_CO01MOR050RO = data["CO01MOR050RO"] 
	
	if data["CO01MOR050IN"] < 0 : 
		AUX_CO01MOR050IN = 0 
	else: 
		AUX_CO01MOR050IN = data["CO01MOR050IN"] 
	
	if data["CO01MOR050OT"] < 0 : 
		AUX_CO01MOR050OT = 0 
	else: 
		AUX_CO01MOR050OT = data["CO01MOR050OT"] 
	
	if data["CO01MOR050VE"] < 0 : 
		AUX_CO01MOR050VE = 0 
	else: 
		AUX_CO01MOR050VE = data["CO01MOR050VE"] 
	
	if data["CO01MOR050CC"] < 0 : 
		AUX_CO01MOR050CC = 0 
	else: 
		AUX_CO01MOR050CC = data["CO01MOR050CC"] 
	
	if data["CO01MOR050HP"] < 0 : 
		AUX_CO01MOR050HP = 0 
	else: 
		AUX_CO01MOR050HP = data["CO01MOR050HP"]
	
	EVER09018P = AUX_CO01MOR050RO + AUX_CO01MOR050IN + AUX_CO01MOR050OT + AUX_CO01MOR050VE + AUX_CO01MOR050CC + AUX_CO01MOR050HP

#--------------------------------------------
# Calcular variable EVER12018P
#--------------------------------------------

	if data["CO01MOR051RO"] < 0 : 
		AUX_CO01MOR051RO = 0 
	else: 
		AUX_CO01MOR051RO = data["CO01MOR051RO"] 
	
	if data["CO01MOR051IN"] < 0 : 
		AUX_CO01MOR051IN = 0 
	else: 
		AUX_CO01MOR051IN = data["CO01MOR051IN"]
	
	if data["CO01MOR051OT"] < 0 : 
		AUX_CO01MOR051OT = 0 
	else: 
		AUX_CO01MOR051OT = data["CO01MOR051OT"] 
	
	if data["CO01MOR051VE"] < 0 : 
		AUX_CO01MOR051VE = 0 
	else: 
		AUX_CO01MOR051VE = data["CO01MOR051VE"] 
	
	if data["CO01MOR051CC"] < 0 : 
		AUX_CO01MOR051CC = 0 
	else: 
		AUX_CO01MOR051CC = data["CO01MOR051CC"] 
	
	if data["CO01MOR051HP"] < 0 : 
		AUX_CO01MOR051HP = 0 
	else: 
		AUX_CO01MOR051HP = data["CO01MOR051HP"]
	
	EVER12018P = AUX_CO01MOR051RO + AUX_CO01MOR051IN + AUX_CO01MOR051OT + AUX_CO01MOR051VE + AUX_CO01MOR051CC + AUX_CO01MOR051HP

#--------------------------------------------
# Calcular variable EVERCC018P
#--------------------------------------------

	if data["CO01MOR052RO"] < 0 : 
		AUX_CO01MOR052RO = 0 
	else: 
		AUX_CO01MOR052RO = data["CO01MOR052RO"] 
	
	if data["CO01MOR052IN"] < 0 : 
		AUX_CO01MOR052IN = 0 
	else: 
		AUX_CO01MOR052IN = data["CO01MOR052IN"] 
	
	if data["CO01MOR052OT"] < 0 : 
		AUX_CO01MOR052OT = 0 
	else: 
		AUX_CO01MOR052OT = data["CO01MOR052OT"] 
	
	if data["CO01MOR052VE"] < 0 : 
		AUX_CO01MOR052VE = 0 
	else: 
		AUX_CO01MOR052VE = data["CO01MOR052VE"] 
	
	if data["CO01MOR052CC"] < 0 : 
		AUX_CO01MOR052CC = 0 
	else: 
		AUX_CO01MOR052CC = data["CO01MOR052CC"] 
	
	if data["CO01MOR052HP"] < 0 : 
		AUX_CO01MOR052HP = 0 
	else: 
		AUX_CO01MOR052HP = data["CO01MOR052HP"]
	
	EVERCC018P = AUX_CO01MOR052RO + AUX_CO01MOR052IN + AUX_CO01MOR052OT + AUX_CO01MOR052VE+ AUX_CO01MOR052CC+ AUX_CO01MOR052HP

#--------------------------------------------
# Calcular variable EVER03018E,EVER06018E
#                   EVER09018E,EVER12018E
#--------------------------------------------

	EVER03018E = EVER03018P - EVER06018P
	EVER06018E = EVER06018P - EVER09018P
	EVER09018E = EVER09018P - EVER12018P
	EVER12018E = EVER12018P - EVERCC018P

#--------------------------------------------
# Calcular variable EVER03024P
#--------------------------------------------

	if data["CO01MOR055RO"] < 0 : 
		AUX_CO01MOR055RO = 0 
	else: 
		AUX_CO01MOR055RO = data["CO01MOR055RO"] 
	
	if data["CO01MOR055IN"] < 0 : 
		AUX_CO01MOR055IN = 0 
	else: 
		AUX_CO01MOR055IN = data["CO01MOR055IN"] 
	
	if data["CO01MOR055OT"] < 0 : 
		AUX_CO01MOR055OT = 0 
	else: 
		AUX_CO01MOR055OT = data["CO01MOR055OT"] 
	
	if data["CO01MOR055VE"] < 0 : 
		AUX_CO01MOR055VE = 0 
	else: 
		AUX_CO01MOR055VE = data["CO01MOR055VE"] 
	
	if data["CO01MOR055CC"] < 0 : 
		AUX_CO01MOR055CC = 0 
	else: 
		AUX_CO01MOR055CC = data["CO01MOR055CC"] 
	
	if data["CO01MOR055HP"] < 0 : 
		AUX_CO01MOR055HP = 0 
	else: 
		AUX_CO01MOR055HP = data["CO01MOR055HP"]
	
	EVER03024P = AUX_CO01MOR055RO + AUX_CO01MOR055IN + AUX_CO01MOR055OT + AUX_CO01MOR055VE + AUX_CO01MOR055CC+ AUX_CO01MOR055HP

#--------------------------------------------
# Calcular variable EVER06024P
#--------------------------------------------

	if data["CO01MOR056RO"] < 0 : 
		AUX_CO01MOR056RO = 0 
	else: 
		AUX_CO01MOR056RO = data["CO01MOR056RO"] 
	
	if data["CO01MOR056IN"] < 0 : 
		AUX_CO01MOR056IN = 0 
	else: 
		AUX_CO01MOR056IN = data["CO01MOR056IN"] 
	
	if data["CO01MOR056OT"] < 0 : 
		AUX_CO01MOR056OT = 0 
	else: 
		AUX_CO01MOR056OT = data["CO01MOR056OT"] 
	
	if data["CO01MOR056VE"] < 0 : 
		AUX_CO01MOR056VE = 0 
	else: 
		AUX_CO01MOR056VE = data["CO01MOR056VE"] 
	
	if data["CO01MOR056CC"] < 0 : 
		AUX_CO01MOR056CC = 0 
	else: 
		AUX_CO01MOR056CC = data["CO01MOR056CC"] 
	
	if data["CO01MOR056HP"] < 0 : 
		AUX_CO01MOR056HP = 0 
	else: 
		AUX_CO01MOR056HP = data["CO01MOR056HP"]
	
	EVER06024P = AUX_CO01MOR056RO + AUX_CO01MOR056IN + AUX_CO01MOR056OT + AUX_CO01MOR056VE+ AUX_CO01MOR056CC+ AUX_CO01MOR056HP

#--------------------------------------------
# Calcular variable EVER09024P
#--------------------------------------------

	if data["CO01MOR057RO"] < 0 : 
		AUX_CO01MOR057RO = 0 
	else: 
		AUX_CO01MOR057RO = data["CO01MOR057RO"] 
	
	if data["CO01MOR057IN"] < 0 : 
		AUX_CO01MOR057IN = 0 
	else: 
		AUX_CO01MOR057IN = data["CO01MOR057IN"] 
	
	if data["CO01MOR057OT"] < 0 : 
		AUX_CO01MOR057OT = 0 
	else: 
		AUX_CO01MOR057OT = data["CO01MOR057OT"] 
	
	if data["CO01MOR057VE"] < 0 : 
		AUX_CO01MOR057VE = 0 
	else: 
		AUX_CO01MOR057VE = data["CO01MOR057VE"] 
	
	if data["CO01MOR057CC"] < 0 : 
		AUX_CO01MOR057CC = 0 
	else: 
		AUX_CO01MOR057CC = data["CO01MOR057CC"] 
	
	if data["CO01MOR057HP"] < 0 : 
		AUX_CO01MOR057HP = 0 
	else: 
		AUX_CO01MOR057HP = data["CO01MOR057HP"]
	
	EVER09024P = AUX_CO01MOR057RO + AUX_CO01MOR057IN + AUX_CO01MOR057OT + AUX_CO01MOR057VE + AUX_CO01MOR057CC + AUX_CO01MOR057HP

#--------------------------------------------
# Calcular variable EVER12024P
#--------------------------------------------

	if data["CO01MOR058RO"] < 0 : 
		AUX_CO01MOR058RO = 0 
	else: 
		AUX_CO01MOR058RO = data["CO01MOR058RO"] 
	
	if data["CO01MOR058IN"] < 0 : 
		AUX_CO01MOR058IN = 0 
	else: 
		AUX_CO01MOR058IN = data["CO01MOR058IN"] 
	
	if data["CO01MOR058OT"] < 0 : 
		AUX_CO01MOR058OT = 0 
	else: 
		AUX_CO01MOR058OT = data["CO01MOR058OT"] 
	
	if data["CO01MOR058VE"] < 0 : 
		AUX_CO01MOR058VE = 0 
	else: 
		AUX_CO01MOR058VE = data["CO01MOR058VE"] 
	
	if data["CO01MOR058CC"] < 0 : 
		AUX_CO01MOR058CC = 0 
	else: 
		AUX_CO01MOR058CC = data["CO01MOR058CC"] 
	
	if data["CO01MOR058HP"] < 0 : 
		AUX_CO01MOR058HP = 0 
	else: 
		AUX_CO01MOR058HP = data["CO01MOR058HP"]
	
	EVER12024P = AUX_CO01MOR058RO + AUX_CO01MOR058IN + AUX_CO01MOR058OT + AUX_CO01MOR058VE + AUX_CO01MOR058CC + AUX_CO01MOR058HP

#--------------------------------------------
# Calcular variable 
#--------------------------------------------

	if data["CO01MOR059RO"] < 0 : 
		AUX_CO01MOR059RO = 0 
	else: 
		AUX_CO01MOR059RO = data["CO01MOR059RO"] 
	
	if data["CO01MOR059IN"] < 0 : 
		AUX_CO01MOR059IN = 0 
	else: 
		AUX_CO01MOR059IN = data["CO01MOR059IN"] 
	
	if data["CO01MOR059OT"] < 0 : 
		AUX_CO01MOR059OT = 0 
	else: 
		AUX_CO01MOR059OT = data["CO01MOR059OT"]
	
	if data["CO01MOR059VE"] < 0 : 
		AUX_CO01MOR059VE = 0 
	else: 
		AUX_CO01MOR059VE = data["CO01MOR059VE"] 
	
	if data["CO01MOR059CC"] < 0 : 
		AUX_CO01MOR059CC = 0 
	else: 
		AUX_CO01MOR059CC = data["CO01MOR059CC"] 
	
	if data["CO01MOR059HP"] < 0 : 
		AUX_CO01MOR059HP = 0 
	else: 
		AUX_CO01MOR059HP = data["CO01MOR059HP"]
	
	EVERCC024P = AUX_CO01MOR059RO + AUX_CO01MOR059IN + AUX_CO01MOR059OT + AUX_CO01MOR059VE + AUX_CO01MOR059CC + AUX_CO01MOR059HP

#--------------------------------------------
# Calcular variable EVER03024E,EVER06024E
#                   EVER09024E,EVER12024E
#--------------------------------------------

	EVER03024E = EVER03024P - EVER06024P
	EVER06024E = EVER06024P - EVER09024P
	EVER09024E = EVER09024P - EVER12024P
	EVER12024E = EVER12024P - EVERCC024P

#--------------------------------------------
# Calcular variable 
#--------------------------------------------

	if data["CO01MOR062RO"] < 0 : 
		AUX_CO01MOR062RO = 0 
	else: 
		AUX_CO01MOR062RO = data["CO01MOR062RO"] 
	
	if data["CO01MOR062IN"] < 0 : 
		AUX_CO01MOR062IN = 0 
	else: 
		AUX_CO01MOR062IN = data["CO01MOR062IN"] 
	
	if data["CO01MOR062OT"] < 0 : 
		AUX_CO01MOR062OT = 0 
	else: 
		AUX_CO01MOR062OT = data["CO01MOR062OT"] 
	
	if data["CO01MOR062VE"] < 0 : 
		AUX_CO01MOR062VE = 0 
	else: 
		AUX_CO01MOR062VE = data["CO01MOR062VE"] 
	
	if data["CO01MOR062CC"] < 0 : 
		AUX_CO01MOR062CC = 0 
	else: 
		AUX_CO01MOR062CC = data["CO01MOR062CC"] 
	
	if data["CO01MOR062HP"] < 0 : 
		AUX_CO01MOR062HP = 0 
	else: 
		AUX_CO01MOR062HP = data["CO01MOR062HP"]
	
	EVER03036P = AUX_CO01MOR062RO + AUX_CO01MOR062IN + AUX_CO01MOR062OT + AUX_CO01MOR062VE + AUX_CO01MOR062CC + AUX_CO01MOR062HP

#--------------------------------------------
# Calcular variable 
#--------------------------------------------

	if data["CO01MOR063RO"] < 0 : 
		AUX_CO01MOR063RO = 0 
	else: 
		AUX_CO01MOR063RO = data["CO01MOR063RO"] 
	
	if data["CO01MOR063IN"] < 0 : 
		AUX_CO01MOR063IN = 0 
	else: 
		AUX_CO01MOR063IN = data["CO01MOR063IN"] 
	
	if data["CO01MOR063OT"] < 0 : 
		AUX_CO01MOR063OT = 0 
	else: 
		AUX_CO01MOR063OT = data["CO01MOR063OT"] 
	
	if data["CO01MOR063VE"] < 0 : 
		AUX_CO01MOR063VE = 0 
	else: 
		AUX_CO01MOR063VE = data["CO01MOR063VE"] 
	
	if data["CO01MOR063CC"] < 0 : 
		AUX_CO01MOR063CC = 0 
	else: 
		AUX_CO01MOR063CC = data["CO01MOR063CC"] 
	
	if data["CO01MOR063HP"] < 0 : 
		AUX_CO01MOR063HP = 0 
	else: 
		AUX_CO01MOR063HP = data["CO01MOR063HP"]
	
	EVER06036P = AUX_CO01MOR063RO + AUX_CO01MOR063IN + AUX_CO01MOR063OT + AUX_CO01MOR063VE + AUX_CO01MOR063CC + AUX_CO01MOR063HP

#--------------------------------------------
# Calcular variable 
#--------------------------------------------

	if data["CO01MOR064RO"] < 0 : 
		AUX_CO01MOR064RO = 0 
	else: 
		AUX_CO01MOR064RO = data["CO01MOR064RO"] 
	
	if data["CO01MOR064IN"] < 0 : 
		AUX_CO01MOR064IN = 0 
	else: 
		AUX_CO01MOR064IN = data["CO01MOR064IN"] 
	
	if data["CO01MOR064OT"] < 0 : 
		AUX_CO01MOR064OT = 0 
	else: 
		AUX_CO01MOR064OT = data["CO01MOR064OT"] 
	
	if data["CO01MOR064VE"] < 0 : 
		AUX_CO01MOR064VE = 0 
	else: 
		AUX_CO01MOR064VE = data["CO01MOR064VE"] 
	
	if data["CO01MOR064CC"] < 0 : 
		AUX_CO01MOR064CC = 0 
	else: 
		AUX_CO01MOR064CC = data["CO01MOR064CC"] 
	
	if data["CO01MOR064HP"] < 0 : 
		AUX_CO01MOR064HP = 0 
	else: 
		AUX_CO01MOR064HP = data["CO01MOR064HP"]
	
	EVER09036P = AUX_CO01MOR064RO + AUX_CO01MOR064IN + AUX_CO01MOR064OT + AUX_CO01MOR064VE + AUX_CO01MOR064CC + AUX_CO01MOR064HP

#--------------------------------------------
# Calcular variable 
#--------------------------------------------

	if data["CO01MOR065RO"] < 0 : 
		AUX_CO01MOR065RO = 0 
	else: 
		AUX_CO01MOR065RO = data["CO01MOR065RO"] 
	
	if data["CO01MOR065IN"] < 0 : 
		AUX_CO01MOR065IN = 0 
	else: 
		AUX_CO01MOR065IN = data["CO01MOR065IN"] 
	
	if data["CO01MOR065OT"] < 0 : 
		AUX_CO01MOR065OT = 0
	else: 
		AUX_CO01MOR065OT = data["CO01MOR065OT"] 
	
	if data["CO01MOR065VE"] < 0 : 
		AUX_CO01MOR065VE = 0 
	else: 
		AUX_CO01MOR065VE = data["CO01MOR065VE"] 
	
	if data["CO01MOR065CC"] < 0 : 
		AUX_CO01MOR065CC = 0 
	else: 
		AUX_CO01MOR065CC = data["CO01MOR065CC"] 
	
	if data["CO01MOR065HP"] < 0 : 
		AUX_CO01MOR065HP = 0
	else: 
		AUX_CO01MOR065HP = data["CO01MOR065HP"]
	
	EVER12036P = AUX_CO01MOR065RO + AUX_CO01MOR065IN + AUX_CO01MOR065OT + AUX_CO01MOR065VE + AUX_CO01MOR065CC + AUX_CO01MOR065HP

#--------------------------------------------
# Calcular variable 
#--------------------------------------------

	if data["CO01MOR066RO"] < 0 : 
		AUX_CO01MOR066RO = 0 
	else: 
		AUX_CO01MOR066RO = data["CO01MOR066RO"] 
	
	if data["CO01MOR066IN"] < 0 : 
		AUX_CO01MOR066IN = 0 
	else: 
		AUX_CO01MOR066IN = data["CO01MOR066IN"] 
	
	if data["CO01MOR066OT"] < 0 : 
		AUX_CO01MOR066OT = 0 
	else: 
		AUX_CO01MOR066OT = data["CO01MOR066OT"] 
	
	if data["CO01MOR066VE"] < 0 : 
		AUX_CO01MOR066VE = 0 
	else: 
		AUX_CO01MOR066VE = data["CO01MOR066VE"] 
	
	if data["CO01MOR066CC"] < 0 : 
		AUX_CO01MOR066CC = 0 
	else: 
		AUX_CO01MOR066CC = data["CO01MOR066CC"] 
	
	if data["CO01MOR066HP"] < 0 : 
		AUX_CO01MOR066HP = 0 
	else: 
		AUX_CO01MOR066HP = data["CO01MOR066HP"]
	
	EVERCC036P = AUX_CO01MOR066RO + AUX_CO01MOR066IN + AUX_CO01MOR066OT + AUX_CO01MOR066VE + AUX_CO01MOR066CC + AUX_CO01MOR066HP

#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	EVER03036E = EVER03036P - EVER06036P
	EVER06036E = EVER06036P - EVER09036P
	EVER09036E = EVER09036P - EVER12036P
	EVER12036E = EVER12036P - EVERCC036P

#--------------------------------------------
# Calcular variable 
#--------------------------------------------

	if data["CO01MOR069RO"] < 0 : 
		AUX_CO01MOR069RO = 0 
	else: 
		AUX_CO01MOR069RO = data["CO01MOR069RO"] 
	
	if data["CO01MOR069IN"] < 0 : 
		AUX_CO01MOR069IN = 0 
	else: 
		AUX_CO01MOR069IN = data["CO01MOR069IN"] 
	
	if data["CO01MOR069OT"] < 0 : 
		AUX_CO01MOR069OT = 0 
	else: 
		AUX_CO01MOR069OT = data["CO01MOR069OT"] 
	
	if data["CO01MOR069VE"] < 0 : 
		AUX_CO01MOR069VE = 0 
	else: 
		AUX_CO01MOR069VE = data["CO01MOR069VE"] 
	
	if data["CO01MOR069CC"] < 0 : 
		AUX_CO01MOR069CC = 0 
	else: 
		AUX_CO01MOR069CC = data["CO01MOR069CC"] 
	
	if data["CO01MOR069HP"] < 0 : 
		AUX_CO01MOR069HP = 0 
	else: 
		AUX_CO01MOR069HP = data["CO01MOR069HP"]
	
	EVER03048P = AUX_CO01MOR069RO + AUX_CO01MOR069IN + AUX_CO01MOR069OT + AUX_CO01MOR069VE + AUX_CO01MOR069CC + AUX_CO01MOR069HP

#--------------------------------------------
# Calcular variable 
#--------------------------------------------

	if data["CO01MOR070RO"] < 0 : 
		AUX_CO01MOR070RO = 0 
	else: 
		AUX_CO01MOR070RO = data["CO01MOR070RO"] 
	
	if data["CO01MOR070IN"] < 0 : 
		AUX_CO01MOR070IN = 0 
	else: 
		AUX_CO01MOR070IN = data["CO01MOR070IN"] 
	
	if data["CO01MOR070OT"] < 0 : 
		AUX_CO01MOR070OT = 0 
	else: 
		AUX_CO01MOR070OT = data["CO01MOR070OT"] 
	
	if data["CO01MOR070VE"] < 0 : 
		AUX_CO01MOR070VE = 0 
	else: 
		AUX_CO01MOR070VE = data["CO01MOR070VE"] 
	
	if data["CO01MOR070CC"] < 0 : 
		AUX_CO01MOR070CC = 0 
	else: 
		AUX_CO01MOR070CC = data["CO01MOR070CC"] 
	
	if data["CO01MOR070HP"] < 0 : 
		AUX_CO01MOR070HP = 0 
	else: 
		AUX_CO01MOR070HP = data["CO01MOR070HP"]
	
	EVER06048P = AUX_CO01MOR070RO + AUX_CO01MOR070IN + AUX_CO01MOR070OT + AUX_CO01MOR070VE + AUX_CO01MOR070CC + AUX_CO01MOR070HP

#--------------------------------------------
# Calcular variable 
#--------------------------------------------

	if data["CO01MOR071RO"] < 0 : 
		AUX_CO01MOR071RO = 0 
	else: 
		AUX_CO01MOR071RO = data["CO01MOR071RO"] 
	
	if data["CO01MOR071IN"] < 0 : 
		AUX_CO01MOR071IN = 0 
	else: 
		AUX_CO01MOR071IN = data["CO01MOR071IN"]
	
	if data["CO01MOR071OT"] < 0 : 
		AUX_CO01MOR071OT = 0 
	else: 
		AUX_CO01MOR071OT = data["CO01MOR071OT"] 
	
	if data["CO01MOR071VE"] < 0 : 
		AUX_CO01MOR071VE = 0 
	else: 
		AUX_CO01MOR071VE = data["CO01MOR071VE"] 
	
	if data["CO01MOR071CC"] < 0 : 
		AUX_CO01MOR071CC = 0 
	else: 
		AUX_CO01MOR071CC = data["CO01MOR071CC"] 
		
	if data["CO01MOR071HP"] < 0 : 
		AUX_CO01MOR071HP = 0 
	else: 
		AUX_CO01MOR071HP = data["CO01MOR071HP"]
	
	EVER09048P = AUX_CO01MOR071RO + AUX_CO01MOR071IN + AUX_CO01MOR071OT + AUX_CO01MOR071VE + AUX_CO01MOR071CC + AUX_CO01MOR071HP

#--------------------------------------------
# Calcular variable 
#--------------------------------------------

	if data["CO01MOR072RO"] < 0 : 
		AUX_CO01MOR072RO = 0 
	else: 
		AUX_CO01MOR072RO = data["CO01MOR072RO"] 
	
	if data["CO01MOR072IN"] < 0 : 
		AUX_CO01MOR072IN = 0 
	else: 
		AUX_CO01MOR072IN = data["CO01MOR072IN"] 
	
	if data["CO01MOR072OT"] < 0 : 
		AUX_CO01MOR072OT = 0 
	else: 
		AUX_CO01MOR072OT = data["CO01MOR072OT"] 
	
	if data["CO01MOR072VE"] < 0 : 
		AUX_CO01MOR072VE = 0 
	else: 
		AUX_CO01MOR072VE = data["CO01MOR072VE"] 
	
	if data["CO01MOR072CC"] < 0 : 
		AUX_CO01MOR072CC = 0 
	else: 
		AUX_CO01MOR072CC = data["CO01MOR072CC"] 
	
	if data["CO01MOR072HP"] < 0 : 
		AUX_CO01MOR072HP = 0 
	else: 
		AUX_CO01MOR072HP = data["CO01MOR072HP"]
	
	EVER12048P = AUX_CO01MOR072RO + AUX_CO01MOR072IN + AUX_CO01MOR072OT + AUX_CO01MOR072VE + AUX_CO01MOR072CC + AUX_CO01MOR072HP

#--------------------------------------------
# Calcular variable 
#--------------------------------------------

	if data["CO01MOR073RO"] < 0 : 
		AUX_CO01MOR073RO = 0 
	else: 
		AUX_CO01MOR073RO = data["CO01MOR073RO"] 
	
	if data["CO01MOR073IN"] < 0 : 
		AUX_CO01MOR073IN = 0 
	else: 
		AUX_CO01MOR073IN = data["CO01MOR073IN"] 
	
	if data["CO01MOR073OT"] < 0 : 
		AUX_CO01MOR073OT = 0 
	else: 
		AUX_CO01MOR073OT = data["CO01MOR073OT"] 
	
	if data["CO01MOR073VE"] < 0 : 
		AUX_CO01MOR073VE = 0 
	else: 
		AUX_CO01MOR073VE = data["CO01MOR073VE"] 
	
	if data["CO01MOR073CC"] < 0 : 
		AUX_CO01MOR073CC = 0 
	else: 
		AUX_CO01MOR073CC = data["CO01MOR073CC"] 
	
	if data["CO01MOR073HP"] < 0 : 
		AUX_CO01MOR073HP = 0 
	else: 
		AUX_CO01MOR073HP = data["CO01MOR073HP"]
	
	EVERCC048P = AUX_CO01MOR073RO + AUX_CO01MOR073IN + AUX_CO01MOR073OT + AUX_CO01MOR073VE + AUX_CO01MOR073CC + AUX_CO01MOR073HP

#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	EVER03048E = EVER03048P - EVER06048P
	EVER06048E = EVER06048P - EVER09048P
	EVER09048E = EVER09048P - EVER12048P
	EVER12048E = EVER12048P - EVERCC048P

#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01MOR001RO"] < 0 : 
		AUX_CO01MOR001RO = 0 
	else: 
		AUX_CO01MOR001RO = data["CO01MOR001RO"] 
	
	if data["CO01MOR001IN"] < 0 : 
		AUX_CO01MOR001IN = 0 
	else: 
		AUX_CO01MOR001IN = data["CO01MOR001IN"] 
	
	if data["CO01MOR001OT"] < 0 : 
		AUX_CO01MOR001OT = 0 
	else: 
		AUX_CO01MOR001OT = data["CO01MOR001OT"] 
	
	if data["CO01MOR001VE"] < 0 : 
		AUX_CO01MOR001VE = 0 
	else: 
		AUX_CO01MOR001VE = data["CO01MOR001VE"] 
	
	if data["CO01MOR001CC"] < 0 : 
		AUX_CO01MOR001CC = 0 
	else: 
		AUX_CO01MOR001CC = data["CO01MOR001CC"] 
	
	if data["CO01MOR001HP"] < 0 : 
		AUX_CO01MOR001HP = 0 
	else: 
		AUX_CO01MOR001HP = data["CO01MOR001HP"]
	
	QALDIA = AUX_CO01MOR001RO + AUX_CO01MOR001IN + AUX_CO01MOR001OT + AUX_CO01MOR001VE + AUX_CO01MOR001CC + AUX_CO01MOR001HP

#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01MOR002RO"] < 0 : 
		AUX_CO01MOR002RO = 0 
	else: 
		AUX_CO01MOR002RO = data["CO01MOR002RO"] 
	
	if data["CO01MOR002IN"] < 0 : 
		AUX_CO01MOR002IN = 0 
	else: 
		AUX_CO01MOR002IN = data["CO01MOR002IN"] 
	
	if data["CO01MOR002VE"] < 0 : 
		AUX_CO01MOR002VE = 0 
	else: 
		AUX_CO01MOR002VE = data["CO01MOR002VE"] 
	
	if data["CO01MOR002HP"] < 0 : 
		AUX_CO01MOR002HP = 0
	else: 
		AUX_CO01MOR002HP = data["CO01MOR002HP"] 
	
	if data["CO01MOR002CC"] < 0 : 
		AUX_CO01MOR002CC = 0 
	else: 
		AUX_CO01MOR002CC = data["CO01MOR002CC"] 
	
	if data["CO01MOR002OT"] < 0 : 
		AUX_CO01MOR002OT = 0
	else: 
		AUX_CO01MOR002OT = data["CO01MOR002OT"]
	
	QTOT030 = AUX_CO01MOR002RO + AUX_CO01MOR002IN + AUX_CO01MOR002VE + AUX_CO01MOR002HP + AUX_CO01MOR002CC + AUX_CO01MOR002OT

#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01MOR003RO"] < 0 : 
		AUX_CO01MOR003RO = 0 
	else: 
		AUX_CO01MOR003RO = data["CO01MOR003RO"] 
	
	if data["CO01MOR003IN"] < 0 : 
		AUX_CO01MOR003IN = 0 
	else: 
		AUX_CO01MOR003IN = data["CO01MOR003IN"] 
	
	if data["CO01MOR003VE"] < 0 : 
		AUX_CO01MOR003VE = 0 
	else: 
		AUX_CO01MOR003VE = data["CO01MOR003VE"]
	
	if data["CO01MOR003HP"] < 0 : 
		AUX_CO01MOR003HP = 0 
	else: 
		AUX_CO01MOR003HP = data["CO01MOR003HP"] 
	
	if data["CO01MOR003CC"] < 0 : 
		AUX_CO01MOR003CC = 0 
	else: 
		AUX_CO01MOR003CC = data["CO01MOR003CC"] 
	
	if data["CO01MOR003OT"] < 0 : 
		AUX_CO01MOR003OT = 0 
	else: 
		AUX_CO01MOR003OT = data["CO01MOR003OT"]
	
	QTOT060 = AUX_CO01MOR003RO + AUX_CO01MOR003IN + AUX_CO01MOR003VE + AUX_CO01MOR003HP + AUX_CO01MOR003CC + AUX_CO01MOR003OT

#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01MOR004RO"] < 0 : 
		AUX_CO01MOR004RO = 0 
	else: 
		AUX_CO01MOR004RO = data["CO01MOR004RO"] 
	
	if data["CO01MOR004IN"] < 0 : 
		AUX_CO01MOR004IN = 0 
	else: 
		AUX_CO01MOR004IN = data["CO01MOR004IN"] 
	
	if data["CO01MOR004VE"] < 0 : 
		AUX_CO01MOR004VE = 0 
	else: 
		AUX_CO01MOR004VE = data["CO01MOR004VE"] 
	
	if data["CO01MOR004HP"] < 0 : 
		AUX_CO01MOR004HP = 0 
	else: 
		AUX_CO01MOR004HP = data["CO01MOR004HP"] 
	
	if data["CO01MOR004CC"] < 0 : 
		AUX_CO01MOR004CC = 0 
	else: 
		AUX_CO01MOR004CC = data["CO01MOR004CC"] 
	
	if data["CO01MOR004OT"] < 0 : 
		AUX_CO01MOR004OT = 0 
	else: 
		AUX_CO01MOR004OT = data["CO01MOR004OT"]
	
	QTOT090 = AUX_CO01MOR004RO + AUX_CO01MOR004IN + AUX_CO01MOR004VE + AUX_CO01MOR004HP + AUX_CO01MOR004CC + AUX_CO01MOR004OT

#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01MOR005RO"] < 0 : 
		AUX_CO01MOR005RO = 0 
	else: 
		AUX_CO01MOR005RO = data["CO01MOR005RO"] 
	
	if data["CO01MOR005IN"] < 0 : 
		AUX_CO01MOR005IN = 0 
	else: 
		AUX_CO01MOR005IN = data["CO01MOR005IN"] 
	
	if data["CO01MOR005VE"] < 0 : 
		AUX_CO01MOR005VE = 0 
	else: 
		AUX_CO01MOR005VE = data["CO01MOR005VE"] 
	
	if data["CO01MOR005HP"] < 0 : 
		AUX_CO01MOR005HP = 0 
	else: 
		AUX_CO01MOR005HP = data["CO01MOR005HP"] 
	
	if data["CO01MOR005CC"] < 0 : 
		AUX_CO01MOR005CC = 0 
	else: 
		AUX_CO01MOR005CC = data["CO01MOR005CC"] 
	
	if data["CO01MOR005OT"] < 0 : 
		AUX_CO01MOR005OT = 0 
	else: 
		AUX_CO01MOR005OT = data["CO01MOR005OT"]
	
	QTOT120 = AUX_CO01MOR005RO + AUX_CO01MOR005IN + AUX_CO01MOR005VE + AUX_CO01MOR005HP + AUX_CO01MOR005CC + AUX_CO01MOR005OT

#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01MOR006RO"] < 0 : 
		AUX_CO01MOR006RO = 0 
	else: 
		AUX_CO01MOR006RO = data["CO01MOR006RO"] 
	
	if data["CO01MOR006IN"] < 0 : 
		AUX_CO01MOR006IN = 0 
	else: 
		AUX_CO01MOR006IN = data["CO01MOR006IN"] 
	
	if data["CO01MOR006VE"] < 0 : 
		AUX_CO01MOR006VE = 0 
	else: 
		AUX_CO01MOR006VE = data["CO01MOR006VE"] 
	
	if data["CO01MOR006HP"] < 0 : 
		AUX_CO01MOR006HP = 0 
	else: 
		AUX_CO01MOR006HP = data["CO01MOR006HP"] 
	
	if data["CO01MOR006CC"] < 0 : 
		AUX_CO01MOR006CC = 0 
	else: 
		AUX_CO01MOR006CC = data["CO01MOR006CC"] 
	
	if data["CO01MOR006OT"] < 0 : 
		AUX_CO01MOR006OT = 0 
	else: 
		AUX_CO01MOR006OT = data["CO01MOR006OT"]
	
	QTOTCC = AUX_CO01MOR006RO + AUX_CO01MOR006IN + AUX_CO01MOR006VE + AUX_CO01MOR006HP + AUX_CO01MOR006CC + AUX_CO01MOR006OT

#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01MOR007RO"] < 0 : 
		AUX_CO01MOR007RO = 0 
	else: 
		AUX_CO01MOR007RO = data["CO01MOR007RO"] 
	
	if data["CO01MOR007IN"] < 0 : 
		AUX_CO01MOR007IN = 0 
	else: 
		AUX_CO01MOR007IN = data["CO01MOR007IN"] 
	
	if data["CO01MOR007VE"] < 0 : 
		AUX_CO01MOR007VE = 0 
	else: 
		AUX_CO01MOR007VE = data["CO01MOR007VE"] 
	
	if data["CO01MOR007HP"] < 0 : 
		AUX_CO01MOR007HP = 0 
	else: 
		AUX_CO01MOR007HP = data["CO01MOR007HP"] 
	
	if data["CO01MOR007CC"] < 0 : 
		AUX_CO01MOR007CC = 0
	else: 
		AUX_CO01MOR007CC = data["CO01MOR007CC"] 
	
	if data["CO01MOR007OT"] < 0 : 
		AUX_CO01MOR007OT = 0 
	else: 
		AUX_CO01MOR007OT = data["CO01MOR007OT"]
	
	QTOTCR = AUX_CO01MOR007RO + AUX_CO01MOR007IN + AUX_CO01MOR007VE + AUX_CO01MOR007HP + AUX_CO01MOR007CC + AUX_CO01MOR007OT
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	QTOTMR = QALDIA + QTOT030 + QTOT060 + QTOT090 + QTOT120 + QTOTCC + QTOTCR
#--------------------------------------------
# Calcular variables 
#--------------------------------------------
	if QTOTMR != 0 : 
		PRQALDIA_C = QALDIA / QTOTMR 
		PRQALDIA = round(PRQALDIA_C,4) 
	else: 
		PRQALDIA = 0
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if QTOTMR != 0 : 
		PRQTOT030_C = QTOT030 / QTOTMR 
		PRQTOT030 = round(PRQTOT030_C,4) 
	else: 
		PRQTOT030 = 0
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if QTOTMR != 0 : 
		PRQTOT060_C = QTOT060 / QTOTMR 
		PRQTOT060 = round(PRQTOT060_C,4) 
	else: 
		PRQTOT060 = 0
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if QTOTMR != 0 : 
		PRQTOT090_C = QTOT090 / QTOTMR 
		PRQTOT090 = round(PRQTOT090_C,4) 
	else: 
		PRQTOT090 = 0
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if QTOTMR != 0 : 
		PRQTOT120_C = QTOT120 / QTOTMR
		PRQTOT120 = round(PRQTOT120_C,4) 
	else: 
		PRQTOT120 = 0
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if QTOTMR != 0 : 
		PRQTOTCC_C = QTOTCC / QTOTMR 
		PRQTOTCC = round(PRQTOTCC_C,4) 
	else: 
		PRQTOTCC = 0
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if QTOTMR != 0 : 
		PRQTOTCR_C = QTOTCR / QTOTMR 
		PRQTOTCR = round(PRQTOTCR_C,4) 
	else: 
		PRQTOTCR = 0
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01MOR008RO"] < 0 : 
		AUX_CO01MOR008RO = 0 
	else: 
		AUX_CO01MOR008RO = data["CO01MOR008RO"] 
	
	if data["CO01MOR008IN"] < 0 : 
		AUX_CO01MOR008IN = 0 
	else: 
		AUX_CO01MOR008IN = data["CO01MOR008IN"] 
	
	if data["CO01MOR008VE"] < 0 : 
		AUX_CO01MOR008VE = 0 
	else: 
		AUX_CO01MOR008VE = data["CO01MOR008VE"] 
	
	if data["CO01MOR008HP"] < 0 : 
		AUX_CO01MOR008HP = 0 
	else: 
		AUX_CO01MOR008HP = data["CO01MOR008HP"]
	
	if data["CO01MOR008CC"] < 0 : 
		AUX_CO01MOR008CC = 0 
	else: 
		AUX_CO01MOR008CC = data["CO01MOR008CC"] 
	
	if data["CO01MOR008OT"] < 0 : 
		AUX_CO01MOR008OT = 0 
	else: 
		AUX_CO01MOR008OT = data["CO01MOR008OT"]
	
	MMAXACT = max(AUX_CO01MOR008RO, AUX_CO01MOR008IN, AUX_CO01MOR008VE, AUX_CO01MOR008HP, AUX_CO01MOR008CC, AUX_CO01MOR008OT)
	MMAXACT_F = max(AUX_CO01MOR008RO, AUX_CO01MOR008IN, AUX_CO01MOR008VE, AUX_CO01MOR008HP)
#--------------------------------------------
# Calcular variables 
#--------------------------------------------
	if data["CO01MOR039CO"] < 0 : 
		AUX_CO01MOR039CO = 0 
	else: 
		AUX_CO01MOR039CO = data["CO01MOR039CO"] 
	
	if data["CO01MOR039RO"] < 0 : 
		AUX_CO01MOR039RO = 0 
	else: 
		AUX_CO01MOR039RO = data["CO01MOR039RO"] 
	
	if data["CO01MOR039IN"] < 0 : 
		AUX_CO01MOR039IN = 0 
	else: 
		AUX_CO01MOR039IN = data["CO01MOR039IN"]
	
	if data["CO01MOR039VE"] < 0 : 
		AUX_CO01MOR039VE = 0 
	else: 
		AUX_CO01MOR039VE = data["CO01MOR039VE"] 
	
	if data["CO01MOR039HP"] < 0 : 
		AUX_CO01MOR039HP = 0 
	else: 
		AUX_CO01MOR039HP = data["CO01MOR039HP"] 
	
	if data["CO01MOR039CC"] < 0 : 
		AUX_CO01MOR039CC = 0 
	else: 
		AUX_CO01MOR039CC = data["CO01MOR039CC"] 
	
	if data["CO01MOR039OT"] < 0 : 
		AUX_CO01MOR039OT = 0 
	else: 
		AUX_CO01MOR039OT = data["CO01MOR039OT"]
	
	MMAX06 = max(AUX_CO01MOR039RO, AUX_CO01MOR039IN, AUX_CO01MOR039VE, AUX_CO01MOR039HP, AUX_CO01MOR039CC, AUX_CO01MOR039OT)
	MMAX06_NF = max(AUX_CO01MOR039CO, AUX_CO01MOR039CC, AUX_CO01MOR039OT)
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01MOR046RO"] < 0 : 
		AUX_CO01MOR046RO = 0 
	else: 
		AUX_CO01MOR046RO = data["CO01MOR046RO"] 
	
	if data["CO01MOR046IN"] < 0 : 
		AUX_CO01MOR046IN = 0 
	else: 
		AUX_CO01MOR046IN = data["CO01MOR046IN"] 
	
	if data["CO01MOR046VE"] < 0 : 
		AUX_CO01MOR046VE = 0 
	else: 
		AUX_CO01MOR046VE = data["CO01MOR046VE"] 
	
	if data["CO01MOR046HP"] < 0 : 
		AUX_CO01MOR046HP = 0 
	else: 
		AUX_CO01MOR046HP = data["CO01MOR046HP"] 
	
	if data["CO01MOR046CC"] < 0 : 
		AUX_CO01MOR046CC = 0
	else: 
		AUX_CO01MOR046CC = data["CO01MOR046CC"] 
	
	if data["CO01MOR046OT"] < 0 : 
		AUX_CO01MOR046OT = 0 
	else: 
		AUX_CO01MOR046OT = data["CO01MOR046OT"]
	
	MMAX12 = max(AUX_CO01MOR046RO, AUX_CO01MOR046IN, AUX_CO01MOR046VE, AUX_CO01MOR046HP, AUX_CO01MOR046CC, AUX_CO01MOR046OT)
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01MOR053RO"] < 0 : 
		AUX_CO01MOR053RO = 0 
	else: 
		AUX_CO01MOR053RO = data["CO01MOR053RO"] 
	
	if data["CO01MOR053IN"] < 0 : 
		AUX_CO01MOR053IN = 0 
	else: 
		AUX_CO01MOR053IN = data["CO01MOR053IN"] 
	
	if data["CO01MOR053VE"] < 0 : 
		AUX_CO01MOR053VE = 0 
	else: 
		AUX_CO01MOR053VE = data["CO01MOR053VE"] 
	
	if data["CO01MOR053HP"] < 0 : 
		AUX_CO01MOR053HP = 0 
	else: 
		AUX_CO01MOR053HP = data["CO01MOR053HP"] 
	
	if data["CO01MOR053CC"] < 0 : 
		AUX_CO01MOR053CC = 0 
	else: 
		AUX_CO01MOR053CC = data["CO01MOR053CC"] 
	
	if data["CO01MOR053OT"] < 0 : 
		AUX_CO01MOR053OT = 0 
	else: 
		AUX_CO01MOR053OT = data["CO01MOR053OT"]
	
	MMAX18 = max(AUX_CO01MOR053RO, AUX_CO01MOR053IN, AUX_CO01MOR053VE, AUX_CO01MOR053HP, AUX_CO01MOR053CC, AUX_CO01MOR053OT)
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01MOR060RO"] < 0 : 
		AUX_CO01MOR060RO = 0 
	else: 
		AUX_CO01MOR060RO = data["CO01MOR060RO"] 
	
	if data["CO01MOR060IN"] < 0 : 
		AUX_CO01MOR060IN = 0 
	else: 
		AUX_CO01MOR060IN = data["CO01MOR060IN"] 
	
	if data["CO01MOR060VE"] < 0 : 
		AUX_CO01MOR060VE = 0 
	else: 
		AUX_CO01MOR060VE = data["CO01MOR060VE"] 
	
	if data["CO01MOR060HP"] < 0 : 
		AUX_CO01MOR060HP = 0 
	else: 
		AUX_CO01MOR060HP = data["CO01MOR060HP"] 
	
	if data["CO01MOR060CC"] < 0 : 
		AUX_CO01MOR060CC = 0 
	else: 
		AUX_CO01MOR060CC = data["CO01MOR060CC"] 
	
	if data["CO01MOR060OT"] < 0 : 
		AUX_CO01MOR060OT = 0 
	else: 
		AUX_CO01MOR060OT = data["CO01MOR060OT"]
	
	MMAX24 = max(AUX_CO01MOR060RO, AUX_CO01MOR060IN, AUX_CO01MOR060VE, AUX_CO01MOR060HP, AUX_CO01MOR060CC, AUX_CO01MOR060OT)
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01MOR067RO"] < 0 : 
		AUX_CO01MOR067RO = 0
	else: 
		AUX_CO01MOR067RO = data["CO01MOR067RO"] 
	
	if data["CO01MOR067IN"] < 0 : 
		AUX_CO01MOR067IN = 0 
	else: 
		AUX_CO01MOR067IN = data["CO01MOR067IN"] 
	
	if data["CO01MOR067VE"] < 0 : 
		AUX_CO01MOR067VE = 0 
	else: 
		AUX_CO01MOR067VE = data["CO01MOR067VE"] 
	
	if data["CO01MOR067HP"] < 0 : 
		AUX_CO01MOR067HP = 0 
	else: 
		AUX_CO01MOR067HP = data["CO01MOR067HP"] 
	
	if data["CO01MOR067CC"] < 0 : 
		AUX_CO01MOR067CC = 0 
	else: 
		AUX_CO01MOR067CC = data["CO01MOR067CC"] 
	
	if data["CO01MOR067OT"] < 0 : 
		AUX_CO01MOR067OT = 0 
	else: 
		AUX_CO01MOR067OT = data["CO01MOR067OT"]
	
	MMAX36 = max(AUX_CO01MOR067RO, AUX_CO01MOR067IN, AUX_CO01MOR067VE, AUX_CO01MOR067HP, AUX_CO01MOR067CC, AUX_CO01MOR067OT)
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01MOR074RO"] < 0 : 
		AUX_CO01MOR074RO = 0 
	else: 
		AUX_CO01MOR074RO = data["CO01MOR074RO"] 
	
	if data["CO01MOR074IN"] < 0 : 
		AUX_CO01MOR074IN = 0 
	else: 
		AUX_CO01MOR074IN = data["CO01MOR074IN"] 
	
	if data["CO01MOR074VE"] < 0 : 
		AUX_CO01MOR074VE = 0 
	else: 
		AUX_CO01MOR074VE = data["CO01MOR074VE"] 
	
	if data["CO01MOR074HP"] < 0 : 
		AUX_CO01MOR074HP = 0 
	else: 
		AUX_CO01MOR074HP = data["CO01MOR074HP"] 
	
	if data["CO01MOR074CC"] < 0 : 
		AUX_CO01MOR074CC = 0 
	else: 
		AUX_CO01MOR074CC = data["CO01MOR074CC"] 
	
	if data["CO01MOR074OT"] < 0 : 
		AUX_CO01MOR074OT = 0 
	else: 
		AUX_CO01MOR074OT = data["CO01MOR074OT"]
	
	MMAX48 = max(AUX_CO01MOR074RO, AUX_CO01MOR074IN, AUX_CO01MOR074VE, AUX_CO01MOR074HP, AUX_CO01MOR074CC, AUX_CO01MOR074OT)
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01MOR009RO"] < 0 : 
		AUX_CO01MOR009RO = 0 
	else: 
		AUX_CO01MOR009RO = data["CO01MOR009RO"] 
	
	if data["CO01MOR009IN"] < 0 : 
		AUX_CO01MOR009IN = 0 
	else: 
		AUX_CO01MOR009IN = data["CO01MOR009IN"] 
	
	if data["CO01MOR009VE"] < 0 : 
		AUX_CO01MOR009VE = 0 
	else: 
		AUX_CO01MOR009VE = data["CO01MOR009VE"] 
	
	if data["CO01MOR009HP"] < 0 : 
		AUX_CO01MOR009HP = 0 
	else: 
		AUX_CO01MOR009HP = data["CO01MOR009HP"] 
	
	if data["CO01MOR009CC"] < 0 : 
		AUX_CO01MOR009CC = 0 
	else: 
		AUX_CO01MOR009CC = data["CO01MOR009CC"] 
	
	if data["CO01MOR009OT"] < 0 : 
		AUX_CO01MOR009OT = 0 
	else: 
		AUX_CO01MOR009OT = data["CO01MOR009OT"]
	
	MMAXHIS = max(AUX_CO01MOR009RO, AUX_CO01MOR009IN, AUX_CO01MOR009VE, AUX_CO01MOR009HP, AUX_CO01MOR009CC, AUX_CO01MOR009OT)
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01EXP007RO"] < 0 : 
		AUX_CO01EXP007RO = 0 
	else: 
		AUX_CO01EXP007RO = data["CO01EXP007RO"] 
	
	if data["CO01EXP007IN"] < 0 : 
		AUX_CO01EXP007IN = 0 
	else: 
		AUX_CO01EXP007IN = data["CO01EXP007IN"] 
	
	if data["CO01EXP007OT"] < 0 : 
		AUX_CO01EXP007OT = 0 
	else: 
		AUX_CO01EXP007OT = data["CO01EXP007OT"] 
	
	if data["CO01EXP007VE"] < 0 : 
		AUX_CO01EXP007VE = 0 
	else: 
		AUX_CO01EXP007VE = data["CO01EXP007VE"] 
	
	if data["CO01EXP007CC"] < 0 : 
		AUX_CO01EXP007CC = 0 
	else: 
		AUX_CO01EXP007CC = data["CO01EXP007CC"] 
	
	if data["CO01EXP007HP"] < 0 : 
		AUX_CO01EXP007HP = 0 
	else: 
		AUX_CO01EXP007HP = data["CO01EXP007HP"]
	
	MOB06 = AUX_CO01EXP007RO + AUX_CO01EXP007IN + AUX_CO01EXP007OT + AUX_CO01EXP007VE + AUX_CO01EXP007CC + AUX_CO01EXP007HP
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01EXP008RO"]< 0 : 
		AUX_CO01EXP008RO = 0 
	else: 
		AUX_CO01EXP008RO = data["CO01EXP008RO"] 
	
	if data["CO01EXP008IN"] < 0 : 
		AUX_CO01EXP008IN = 0 
	else: 
		AUX_CO01EXP008IN = data["CO01EXP008IN"] 
	
	if data["CO01EXP008OT"] < 0 : 
		AUX_CO01EXP008OT = 0 
	else: 
		AUX_CO01EXP008OT = data["CO01EXP008OT"] 
	
	if data["CO01EXP008VE"] < 0 : 
		AUX_CO01EXP008VE = 0 
	else: 
		AUX_CO01EXP008VE = data["CO01EXP008VE"] 
	
	if data["CO01EXP008CC"] < 0 : 
		AUX_CO01EXP008CC = 0 
	else: 
		AUX_CO01EXP008CC = data["CO01EXP008CC"] 
	
	if data["CO01EXP008HP"] < 0 : 
		AUX_CO01EXP008HP = 0 
	else: 
		AUX_CO01EXP008HP = data["CO01EXP008HP"]
	
	MOB12 = AUX_CO01EXP008RO + AUX_CO01EXP008IN + AUX_CO01EXP008OT + AUX_CO01EXP008VE + AUX_CO01EXP008CC + AUX_CO01EXP008HP
#--------------------------------------------
# Calcular variables 
#--------------------------------------------
	if data["CO01EXP009RO"] < 0 : 
		AUX_CO01EXP009RO = 0 
	else: 
		AUX_CO01EXP009RO = data["CO01EXP009RO"] 
	
	if data["CO01EXP009IN"] < 0 : 
		AUX_CO01EXP009IN = 0 
	else: 
		AUX_CO01EXP009IN = data["CO01EXP009IN"] 
	
	if data["CO01EXP009OT"] < 0 : 
		AUX_CO01EXP009OT = 0 
	else: 
		AUX_CO01EXP009OT = data["CO01EXP009OT"] 
	
	if data["CO01EXP009VE"] < 0 : 
		AUX_CO01EXP009VE = 0 
	else: 
		AUX_CO01EXP009VE = data["CO01EXP009VE"] 
	
	if data["CO01EXP009CC"] < 0 : 
		AUX_CO01EXP009CC = 0 
	else: 
		AUX_CO01EXP009CC = data["CO01EXP009CC"] 
	
	if data["CO01EXP009HP"] < 0 : 
		AUX_CO01EXP009HP = 0 
	else: 
		AUX_CO01EXP009HP = data["CO01EXP009HP"]
	
	MOB24 = AUX_CO01EXP009RO + AUX_CO01EXP009IN + AUX_CO01EXP009OT + AUX_CO01EXP009VE + AUX_CO01EXP009CC + AUX_CO01EXP009HP
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01EXP010RO"] < 0 : 
		AUX_CO01EXP010RO = 0 
	else: 
		AUX_CO01EXP010RO = data["CO01EXP010RO"] 
	
	if data["CO01EXP010IN"] < 0 : 
		AUX_CO01EXP010IN = 0 
	else: 
		AUX_CO01EXP010IN = data["CO01EXP010IN"] 
	
	if data["CO01EXP010OT"] < 0 : 
		AUX_CO01EXP010OT = 0 
	else: 
		AUX_CO01EXP010OT = data["CO01EXP010OT"] 
	
	if data["CO01EXP010VE"] < 0 : 
		AUX_CO01EXP010VE = 0 
	else: 
		AUX_CO01EXP010VE = data["CO01EXP010VE"] 
	
	if data["CO01EXP010CC"] < 0 : 
		AUX_CO01EXP010CC = 0 
	else: 
		AUX_CO01EXP010CC = data["CO01EXP010CC"] 
	
	if data["CO01EXP010HP"] < 0 : 
		AUX_CO01EXP010HP = 0 
	else: 
		AUX_CO01EXP010HP = data["CO01EXP010HP"]
	
	MOB36 = AUX_CO01EXP010RO + AUX_CO01EXP010IN + AUX_CO01EXP010OT + AUX_CO01EXP010VE + AUX_CO01EXP010CC + AUX_CO01EXP010HP
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01EXP011RO"] < 0 : 
		AUX_CO01EXP011RO = 0 
	else: 
		AUX_CO01EXP011RO = data["CO01EXP011RO"] 
	
	if data["CO01EXP011IN"] < 0 : 
		AUX_CO01EXP011IN = 0 
	else: 
		AUX_CO01EXP011IN = data["CO01EXP011IN"] 
	
	if data["CO01EXP011OT"] < 0 : 
		AUX_CO01EXP011OT = 0 
	else: 
		AUX_CO01EXP011OT = data["CO01EXP011OT"] 
	
	if data["CO01EXP011VE"] < 0 : 
		AUX_CO01EXP011VE = 0 
	else: 
		AUX_CO01EXP011VE = data["CO01EXP011VE"] 
	
	if data["CO01EXP011CC"] < 0 : 
		AUX_CO01EXP011CC = 0 
	else: 
		AUX_CO01EXP011CC = data["CO01EXP011CC"] 
	
	if data["CO01EXP011HP"] < 0 : 
		AUX_CO01EXP011HP = 0 
	else: 
		AUX_CO01EXP011HP = data["CO01EXP011HP"]
	
	MOB48 = AUX_CO01EXP011RO + AUX_CO01EXP011IN + AUX_CO01EXP011OT + AUX_CO01EXP011VE + AUX_CO01EXP011CC + AUX_CO01EXP011HP
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01EXP012RO"] < 0 : 
		AUX_CO01EXP012RO = 0 
	else: 
		AUX_CO01EXP012RO = data["CO01EXP012RO"] 
	
	if data["CO01EXP012IN"] < 0 : 
		AUX_CO01EXP012IN = 0 
	else: 
		AUX_CO01EXP012IN = data["CO01EXP012IN"] 
	
	if data["CO01EXP012OT"] < 0 : 
		AUX_CO01EXP012OT = 0 
	else: 
		AUX_CO01EXP012OT = data["CO01EXP012OT"] 
	
	if data["CO01EXP012VE"] < 0 : 
		AUX_CO01EXP012VE = 0 
	else: 
		AUX_CO01EXP012VE = data["CO01EXP012VE"] 
	
	if data["CO01EXP012CC"] < 0 : 
		AUX_CO01EXP012CC = 0 
	else: 
		AUX_CO01EXP012CC = data["CO01EXP012CC"] 
	
	if data["CO01EXP012HP"] < 0 : 
		AUX_CO01EXP012HP = 0 
	else: 
		AUX_CO01EXP012HP = data["CO01EXP012HP"]
	
	MOB60 = AUX_CO01EXP012RO + AUX_CO01EXP012IN + AUX_CO01EXP012OT + AUX_CO01EXP012VE + AUX_CO01EXP012CC + AUX_CO01EXP012HP
#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01EXP013RO"] < 0 : 
		AUX_CO01EXP013RO = 0 
	else: 
		AUX_CO01EXP013RO = data["CO01EXP013RO"] 
	
	if data["CO01EXP013IN"] < 0 : 
		AUX_CO01EXP013IN = 0 
	else: 
		AUX_CO01EXP013IN = data["CO01EXP013IN"] 
	
	if data["CO01EXP013OT"] < 0 : 
		AUX_CO01EXP013OT = 0 
	else: 
		AUX_CO01EXP013OT = data["CO01EXP013OT"] 
	
	if data["CO01EXP013VE"] < 0 : 
		AUX_CO01EXP013VE = 0 
	else: 
		AUX_CO01EXP013VE = data["CO01EXP013VE"] 
	
	if data["CO01EXP013CC"] < 0 : 
		AUX_CO01EXP013CC = 0 
	else: 
		AUX_CO01EXP013CC = data["CO01EXP013CC"] 
	
	if data["CO01EXP013HP"] < 0 : 
		AUX_CO01EXP013HP = 0 
	else: 
		AUX_CO01EXP013HP = data["CO01EXP013HP"]
	
	MOB60M = AUX_CO01EXP013RO + AUX_CO01EXP013IN + AUX_CO01EXP013OT + AUX_CO01EXP013VE + AUX_CO01EXP013CC + AUX_CO01EXP013HP

	if RECMORA030 == 999:
		RECMORA030 = -1
	if RECMORA060 == 999:
		RECMORA060 = -1
	if RECMORA090 == 999:
		RECMORA090 = -1
	if RECMORA120 == 999:
		RECMORA120 = -1
	if RECMORACC == 999:
		RECMORACC = -1
	if RECMORA001 == 999:
		RECMORA001 = -1
	if RECMORA002 == 999:
		RECMORA002 = -1
	if RECMORA001VSA == 999:
		RECMORA001VSA = -1
	if RECMORA002VSA ==999:
		RECMORA002VSA = -1

#--------------------------------------------
# Calcular variables 
#--------------------------------------------

	if data["CO01EXP001RO"] < 0 : 
		AUX_CO01EXP001RO = 0
	else: 
		AUX_CO01EXP001RO = data["CO01EXP001RO"]

	if data["CO01EXP001IN"] < 0 : 
		AUX_CO01EXP001IN = 0
	else: 
		AUX_CO01EXP001IN = data["CO01EXP001IN"]

	if data["CO01EXP001VE"] < 0 : 
		AUX_CO01EXP001VE = 0
	else: 
		AUX_CO01EXP001VE = data["CO01EXP001VE"]

	if data["CO01EXP001HP"] < 0 : 
		AUX_CO01EXP001HP = 0
	else: 
		AUX_CO01EXP001HP = data["CO01EXP001HP"]

	if data["CO01EXP001CC"] < 0 : 
		AUX_CO01EXP001CC = 0
	else: 
		AUX_CO01EXP001CC = data["CO01EXP001CC"]

	if data["CO01EXP001OT"] < 0 : 
		AUX_CO01EXP001OT = 0
	else: 
		AUX_CO01EXP001OT = data["CO01EXP001OT"]

	APERTURA_ANT=max(AUX_CO01EXP001RO,AUX_CO01EXP001IN,AUX_CO01EXP001VE,AUX_CO01EXP001HP,AUX_CO01EXP001CC,AUX_CO01EXP001OT)
	APERTURA_ANT_F=max(AUX_CO01EXP001RO,AUX_CO01EXP001IN,AUX_CO01EXP001VE,AUX_CO01EXP001HP)

#--------------------------------------------
#Calcular variables  DMOR , EMOR
#--------------------------------------------
	DMOR=0
	EMOR=0
#--------------------------------------------
# SEGMENTO 
#--------------------------------------------
	if INPUT_SEG == 1 or INPUT_SEG == 2:
		#DMOR = MOR120
		DMOR = QTOT120
		#EMOR = MOR00 + MOR30 + MOR60 + MOR90
		EMOR = QALDIA + QTOT030 + QTOT060 + QTOT090
#--------------------------------------------
# SEGMENTO 
#--------------------------------------------
	if INPUT_SEG == 3 or INPUT_SEG == 4 :
		#DMOR = MOR120
		DMOR = QTOT090+QTOT120
		#EMOR = MOR00 + MOR30 + MOR60 + MOR90
		EMOR = QALDIA+QTOT030+QTOT060
#--------------------------------------------
# SEGMENTO 
#--------------------------------------------
	if INPUT_SEG == 5: #or INPUT_SEG == 6:
		#DMOR = MOR90 + MOR120
		DMOR = QTOT120
		#EMOR = MOR00 + MOR30 + MOR60
		EMOR = QALDIA+QTOT030+QTOT060+QTOT090

	if INPUT_SEG == 6: #or INPUT_SEG == 6:
		#DMOR = MOR90 + MOR120
		DMOR = QTOT090+QTOT120
		#EMOR = MOR00 + MOR30 + MOR60
		EMOR = QALDIA+QTOT030+QTOT060
#--------------------------------------------
# SEGMENTO 
#--------------------------------------------
	if INPUT_SEG == 7 or INPUT_SEG==8:
		#DMOR = MOR90 + MOR120
		DMOR = QTOT090+QTOT120
		#EMOR = MOR00 + MOR30 + MOR60
		EMOR = QALDIA+QTOT030+QTOT060
#--------------------------------------------
# SEGMENTO 
#--------------------------------------------
	#if INPUT_SEG == 8 :
		#DMOR = MOR90 + MOR120

		#EMOR = MOR00 + MOR30 + MOR60

#--------------------------------------------
# Retorno variables
#--------------------------------------------

	return EMOR,DMOR,QTOTAB,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,QTOTABHD,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA

#--------------------------------------------------------------------------------------------------------------#
#  FUNCION EXCLUCIONES : REALIZA LAS EXCLUSIONES 
#                        --> CLIENTES DIFERENTES A PERSONA NATURAL : 70 , score 0   
#                        --> CLIENTES TIPO 5  : 71 , score 0
#                        --> CLIENTES TIPO 1 SIN DESEMPENO : 72 , score 0
#                        --> CLIENTES FALLECIDOS : 73 , score 3
#                        --> CLIENTES QUE SOLO SON CODEUDorES : 74 , score 4
#                        --> CLIENTES CON TODAS SUS CUENTAS EN DEFAULT : 75 , score 1 
#                        --> CLIENTES CON EXPERIENCIA MENor O IGUAL A 6 MESES SOLO REAL : 76 , score 7                       
#--------------------------------------------------------------------------------------------------------------#

def exclusiones(data,QTOTAB,QTOTABHD,DMOR,EMOR):
	EXCLUSION = 0
	SCORE_FINAL = 0
	#EXCLUSION CLIENTES DIFERENTES A PERSONAS NATURALES
	if data.get('TIPOID') in [2,3]:
		EXCLUSION=70
		SCORE_FINAL=0
	else:
		if data["CO01NUM001RO"] == -1  and data["CO01NUM001IN"] == -1 and data["CO01NUM001VE"] == -1 and data["CO01NUM001HP"] == -1 and data["CO01NUM001CC"] == -1 and data["CO01NUM001OT"] == -1 and data["CO01NUM001CO"] == -1 and data["CO01NUM001AH"] == -1 and data["CO01NUM001CT"] == -1 :
			EXCLUSION = 71
			SCORE_FINAL = 0
		else:
			if ( data["CO01NUM001AH"] > 0 or data["CO01NUM001CT"] > 0 ) and data["CO01NUM001RO"] == -1 and data["CO01NUM001IN"] == -1 and data["CO01NUM001VE"] == -1 and data["CO01NUM001HP"] == -1 and data["CO01NUM001CC"] == -1 and data["CO01NUM001OT"] == -1 and data["CO01NUM001CO"] == -1 :
				EXCLUSION = 72
				SCORE_FINAL = 0
			else:
				if data["CO00DEM001"] == 1 or data["CO00DEM002"] == 1 :
					EXCLUSION = 73
					SCORE_FINAL = 3
				else:
					if data["CO01NUM001RO"] == -1 and data["CO01NUM001IN"] == -1 and data["CO01NUM001VE"] == -1 and data["CO01NUM001HP"] == -1 and data["CO01NUM001CC"] == -1 and data["CO01NUM001OT"] == -1 and data["CO01NUM001CO"] != -1 :
						EXCLUSION = 74
						SCORE_FINAL = 4
					else:
						if ( DMOR > 0 and EMOR == 0) or ( QTOTABHD > 0 and ( data["CO02NUM018TO"] + data["CO02NUM020TO"] == QTOTABHD )):
							EXCLUSION = 75
							SCORE_FINAL = 1
						else:
								EXCLUSION = 99
	#reporte={}
	#reporte['TIPOID']=int(data['TIPOID'])
	#reporte['CONUMIDE']=int(data['CONUMIDE'])
	#reporte['scoreSegment']=0
	#reporte['SCORE_FINAL']=SCORE_FINAL
	#reporte['exclusionCode']=EXCLUSION
	#reporte['QTOTAB']=QTOTAB
	#reporte['DMOR']=DMOR
	#reporte['EMOR']=EMOR
	return EXCLUSION,SCORE_FINAL#,reporte
#--------------------------------------------------------------------------------------------------------------#
#  FUNCION scorecard : ESCOGE A QUE SEGMENTO DE LA POBLACION PERTENECE EL CONSULTADO PARA APLICAR   
#                      LA ForMULA DEL score
#--------------------------------------------------------------------------------------------------------------#
def scorecard(data,INPUT_SEG,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA):
	scoreR={}
	if INPUT_SEG == 1:
		scoreR=segmento1(data,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION)
		scoreR['scoreValue']=segmentar_DCOM(scoreR['scoreValue'],MMAXACT)
		
	if INPUT_SEG == 2:
		scoreR=segmento2(data,PRQALDIA,RECMORA001VSA,MMAXHIS,MMAX24,RECMORA120,TIPORELD04)
		scoreR['scoreValue']=segmentar_DCOM(scoreR['scoreValue'],MMAXACT)

	if INPUT_SEG == 3:
		scoreR=segmento3(data,PROQTOTAB,PRQALDIA,RECMORA001VSA,MMAXHIS)

	if INPUT_SEG == 4:
		scoreR=segmento4(data,PRQALDIA,PREXPOSICIONIN,RECMORA001VSA,MMAXHIS)

	if INPUT_SEG == 5:
		scoreR=segmento5(data,MOB12,PRQALDIA,RECMORA030,MMAXHIS,RECMORA001)

	if INPUT_SEG == 6:
		scoreR=segmento6(data,PRQALDIA,RECMORA001VSA,RECMORA030,MMAXHIS)

	if INPUT_SEG == 7:
		scoreR=segmento7(data,RECMORA001VSA,MMAXHIS,PROQTOTAB)

	if INPUT_SEG == 8:
		scoreR=segmento8(data,PRQALDIA,EVER06036P,EVER03024P,EVER12036E,RECMORA001)

	if INPUT_SEG == 9:
		scoreR,CO02EXP006TO_DPU=segmento9(data,PRQALDIA,MOB60M,MOB12,RECMORA001VSA,MMAXHIS)
		scoreR['scoreValue']=segmentar_DFGE(data,scoreR['scoreValue'],CO02EXP006TO_DPU,MMAXACT,RECMORA001VSA,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,TIPORELD01,RECMORA002VSA)

	return scoreR

#--------------------------------------------------------------------------------------------------------------#
#  FUNCION segmento1 : REALIZA EL CALCULO DEL score PARA POBLACION DEL SEGMENTO 1   
#--------------------------------------------------------------------------------------------------------------#
def segmento1(data,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION):
	if data["CO02EXP008TO"] < 0 : 
		CO02EXP008TO_DCCN = 60 
	else: 
		CO02EXP008TO_DCCN = data["CO02EXP008TO"]
	
	if data["CO02EXP001TO"] < 0 : 
		CO02EXP001TO_DCCN = 0 
	else: 
		CO02EXP001TO_DCCN = data["CO02EXP001TO"]
	
	PRQALDIA_DCCN = PRQALDIA
	
	if data["CO02NUM029TO"] < 0 : 
		CO02NUM029TO_DCCN = 0 
	else: 
		CO02NUM029TO_DCCN = data["CO02NUM029TO"]
	
	if data["CO02EXP006TO"] < 0 : 
		CO02EXP006TO_DCCN = 0 
	else: 
		CO02EXP006TO_DCCN = data["CO02EXP006TO"]
	
	if CO02EXP008TO_DCCN > 100 : 
		CO02EXP008TO_DCCN = 100
	
	if CO02EXP001TO_DCCN > 267 : 
		CO02EXP001TO_DCCN = 267
	
	if PRQALDIA_DCCN > 1 : 
		PRQALDIA_DCCN = 1
	
	if CO02NUM029TO_DCCN > 17 : 
		CO02NUM029TO_DCCN = 17
	
	if CO02EXP006TO_DCCN > 115 : 
		CO02EXP006TO_DCCN = 115
	
	TIPORELD01_DCCN = TIPORELD01 
	TIPORELD04_DCCN = TIPORELD04
	
	if 0 <= MMAXHIS < 2 : 
		MMAXHIS_DCCND01 = 1
	else: 
		MMAXHIS_DCCND01 = 0
	
	if 2 <= MMAXHIS : 
		MMAXHIS_DCCND02 = 1 
	else: 
		MMAXHIS_DCCND02 = 0
	
	if 0 <= data["CO02END015CB"] < 0.65 : 
		CO02END015CB_DCCND01 = 1 
	else: 
		CO02END015CB_DCCND01 = 0
	
	if data["CO02END015CB"]<0:
		CO02END015CB_DCCND02 = 0
	elif 0.65 <= data["CO02END015CB"] : 
		CO02END015CB_DCCND02 = 1 
	else: 
		CO02END015CB_DCCND02 = 0
	
	if 0 <= RECMORA001VSA < 3 : 
		RECMORA001VSA_DCCND01 = 1 
	else: 
		RECMORA001VSA_DCCND01 = 0
	
	if 3 <= RECMORA001VSA < 10.9 : 
		RECMORA001VSA_DCCND02 = 1 
	else: 
		RECMORA001VSA_DCCND02 = 0
	
	if 10.9 <= RECMORA001VSA : 
		RECMORA001VSA_DCCND03 = 1 
	else: 
		RECMORA001VSA_DCCND03 = 0
	
	if 0 <= data["CO01END089RO"] < 32.07 : 
		CO01END089RO_DCCND01 = 1 
	else: 
		CO01END089RO_DCCND01 = 0
	
	if 32.07 <= data["CO01END089RO"] < 63.18 : 
		CO01END089RO_DCCND02 = 1 
	else: 
		CO01END089RO_DCCND02 = 0
	
	if 63.18 <= data["CO01END089RO"] < 86.16 : 
		CO01END089RO_DCCND03 = 1 
	else: 
		CO01END089RO_DCCND03 = 0
	
	if 86.16 <= data["CO01END089RO"] : 
		CO01END089RO_DCCND04 = 1 
	else: 
		CO01END089RO_DCCND04 = 0
	
	if data["CO01END088RO"]<0:
		CO01END088RO_DCCND01 = 0
	elif 0 <= data["CO01END088RO"] < 32.57 : 
		CO01END088RO_DCCND01 = 1 
	else: 
		CO01END088RO_DCCND01 = 0
	
	if 32.57 <= data["CO01END088RO"] < 63.74 : 
		CO01END088RO_DCCND02 = 1 
	else: 
		CO01END088RO_DCCND02 = 0
	
	if 63.74 <= data["CO01END088RO"] < 86.53 : 
		CO01END088RO_DCCND03 = 1 
	else: 
		CO01END088RO_DCCND03 = 0
	
	if 86.53 <= data["CO01END088RO"] : 
		CO01END088RO_DCCND04 = 1 
	else: 
		CO01END088RO_DCCND04 = 0
	
	if data["CO01EXP001RO"] < 0 : 
		CO01EXP001RO_DCCND00 = 1 
	else: 
		CO01EXP001RO_DCCND00 = 0
	
	if 0 <= data["CO01EXP001RO"] < 20.15 : 
		CO01EXP001RO_DCCND01 = 1 
	else: 
		CO01EXP001RO_DCCND01 = 0
	
	if 20.15 <= data["CO01EXP001RO"] < 44.83 : 
		CO01EXP001RO_DCCND02 = 1 
	else: 
		CO01EXP001RO_DCCND02 = 0
	
	if 44.83 <= data["CO01EXP001RO"] < 118.14 : 
		CO01EXP001RO_DCCND03 = 1 
	else: 
		CO01EXP001RO_DCCND03 = 0
	
	if data["CO01EXP001RO"]<0:
		CO01EXP001RO_DCCND04 = 0
	if 118.14 <= data["CO01EXP001RO"] : 
		CO01EXP001RO_DCCND04 = 1 
	else: 
		CO01EXP001RO_DCCND04 = 0
	
	if data["CO01EXP001AH"] < 0 : 
		CO01EXP001AH_DCCND00 = 1 
	else: 
		CO01EXP001AH_DCCND00 = 0
	
	if 0 <= data["CO01EXP001AH"] < 36.44 : 
		CO01EXP001AH_DCCND01 = 1 
	else: 
		CO01EXP001AH_DCCND01 = 0
	
	if 36.44 <= data["CO01EXP001AH"] < 70.57 : 
		CO01EXP001AH_DCCND02 = 1 
	else: 
		CO01EXP001AH_DCCND02 = 0
	
	if 70.57 <= data["CO01EXP001AH"] < 123.61 : 
		CO01EXP001AH_DCCND03 = 1 
	else: 
		CO01EXP001AH_DCCND03 = 0
	
	if 123.61 <= data["CO01EXP001AH"] : 
		CO01EXP001AH_DCCND04 = 1 
	else: 
		CO01EXP001AH_DCCND04 = 0
	
	if 0 <= data["CO01MOR040RO"] < 1 : 
		CO01MOR040RO_DCCND01 = 1 
	else: 
		CO01MOR040RO_DCCND01 = 0
	
	if 1 <= data["CO01MOR040RO"] < 2 : 
		CO01MOR040RO_DCCND02 = 1 
	else: 
		CO01MOR040RO_DCCND02 = 0
	
	if 2 <= data["CO01MOR040RO"] : 
		CO01MOR040RO_DCCND03 = 1 
	else: 
		CO01MOR040RO_DCCND03 = 0
	
	if 0 <= EVER03006P < 0.25 : 
		EVER03006P_DCCND01 = 1 
	else: 
		EVER03006P_DCCND01 = 0
	
	if 0.25 <= EVER03006P : 
		EVER03006P_DCCND02 = 1 
	else: 
		EVER03006P_DCCND02 = 0
	
	if 0 <= data["CO01END030RO"] < 0.37 : 
		CO01END030RO_DCCND01 = 1 
	else: 
		CO01END030RO_DCCND01 = 0
	
	if 0.37 <= data["CO01END030RO"] < 1.2 : 
		CO01END030RO_DCCND02 = 1 
	else: 
		CO01END030RO_DCCND02 = 0
	
	if 1.2 <= data["CO01END030RO"] < 3.08 : 
		CO01END030RO_DCCND03 = 1 
	else: 
		CO01END030RO_DCCND03 = 0
	
	if 3.08 <= data["CO01END030RO"] : 
		CO01END030RO_DCCND04 = 1 
	else: 
		CO01END030RO_DCCND04 = 0
	
	if 0 <= data["CO01MOR062RO"] < 1 : 
		CO01MOR062RO_DCCND01 = 1 
	else: 
		CO01MOR062RO_DCCND01 = 0
	
	if 1 <= data["CO01MOR062RO"] : 
		CO01MOR062RO_DCCND02 = 1 
	else: 
		CO01MOR062RO_DCCND02 = 0
	
	if EXPOSICION < 2.47 : 
		EXPOSICION_DCCND01 = 1 
	else: 
		EXPOSICION_DCCND01 = 0
	
	if 2.47 <= EXPOSICION < 7.87: 
		EXPOSICION_DCCND02 = 1 
	else: 
		EXPOSICION_DCCND02 = 0
	
	if 7.87 <= EXPOSICION < 27.13 : 
		EXPOSICION_DCCND03 = 1 
	else: 
		EXPOSICION_DCCND03 = 0
	
	if 27.13 <= EXPOSICION : 
		EXPOSICION_DCCND04 = 1 
	else: 
		EXPOSICION_DCCND04 = 0
	
	if 0 <= data["CO01END022RO"] < 0.01 : 
		CO01END022RO_DCCND01 = 1 
	else: 
		CO01END022RO_DCCND01 = 0
	
	if 0.01 <= data["CO01END022RO"] : 
		CO01END022RO_DCCND02 = 1 
	else: 
		CO01END022RO_DCCND02 = 0
	
	if 0 <= data["CO01MOR055CC"] < 1 : 
		CO01MOR055CC_DCCND01 = 1 
	else: 
		CO01MOR055CC_DCCND01 = 0
	
	if 1 <= data["CO01MOR055CC"] : 
		CO01MOR055CC_DCCND02 = 1 
	else: 
		CO01MOR055CC_DCCND02 = 0
	
	if 0 <= data["CO01NUM050RO"] < 0.94 : 
		CO01NUM050RO_DCCND01 = 1 
	else: 
		CO01NUM050RO_DCCND01 = 0
	
	if 0.94 <= data["CO01NUM050RO"] < 2 : 
		CO01NUM050RO_DCCND02 = 1 
	else: 
		CO01NUM050RO_DCCND02 = 0
	
	if 2 <= data["CO01NUM050RO"] : 
		CO01NUM050RO_DCCND03 = 1 
	else: 
		CO01NUM050RO_DCCND03 = 0
	
	suma = + 0.756507907349518\
	+(CO02EXP008TO_DCCN * -0.00344032622123293)\
	+(CO02EXP001TO_DCCN  * 0.00204345104836843)\
	+(PRQALDIA_DCCN      * 0.193466311383486)\
	+(CO02NUM029TO_DCCN  * 0.0185970530036857)\
	+(CO02EXP006TO_DCCN  * 0.00209661609206721)\
	+(MMAXHIS_DCCND02    * -0.429539126501729)\
	+(CO02END015CB_DCCND02  * -0.304805348684901)\
	+(RECMORA001VSA_DCCND01 * -0.406942204478714)\
	+(CO01END089RO_DCCND04 * -0.292770028900652)\
	+(TIPORELD01_DCCN      * 0.201335816376428)\
	+(CO01END088RO_DCCND01 * 0.365151513984611)\
	+(CO01EXP001RO_DCCND04 * 0.247223329612578)\
	+(CO01EXP001AH_DCCND00 * -0.11829228496699)\
	+(CO01MOR040RO_DCCND03 * 0.165952304511341)\
	+(TIPORELD04_DCCN      * 0.147503034238019)\
	+(EVER03006P_DCCND02   * -0.179211222196262)\
	+(CO01END030RO_DCCND04 * 0.235168533414298)\
	+(CO01MOR062RO_DCCND01 * 0.206107107865234)\
	+(CO01END088RO_DCCND02 * 0.185999913749878)\
	+(EXPOSICION_DCCND01   * -0.0872351805359107)\
	+(CO01END030RO_DCCND03 * 0.150857328602515)\
	+(CO01END022RO_DCCND02 * -0.0819867759662279)\
	+(CO01MOR055CC_DCCND01 * 0.257998143028414)\
	+(CO01NUM050RO_DCCND03 * 0.0319328452568861)
	AciertaA = int (1000 / (1 + np.exp(-suma)))
	AciertaADef = int (400.000000000000 + 110.321693765613 * suma)

	if AciertaADef <= 150:
		AciertaADef=150
	if AciertaADef >= 999:
		AciertaADef=999

	reporte={}
	#reporte['TIPOID']=int(data['TIPOID'])
	#reporte['CONUMIDE']=int(data['CONUMIDE'])
	reporte['scoreSegment']=1
	#reporte['AciertaA']=AciertaA
	reporte['scoreValue']=AciertaADef
	#reporte["PRQALDIA"]=PRQALDIA
	#reporte["TIPORELD01"]=TIPORELD01
	#reporte["TIPORELD04"]=TIPORELD04
	#reporte["MMAXHIS"]=MMAXHIS
	#reporte["RECMORA001VSA"]=RECMORA001VSA
	#reporte["EVER03006P"]=EVER03006P
	#reporte["EXPOSICION"]=EXPOSICION
	#reporte["CO02EXP008TO_DCCN"]=int(CO02EXP008TO_DCCN)
	#reporte["CO02EXP001TO_DCCN"]=int(CO02EXP001TO_DCCN)
	#reporte["PRQALDIA_DCCN"]=int(PRQALDIA_DCCN)
	#reporte["CO02NUM029TO_DCCN"]=int(CO02NUM029TO_DCCN)
	#reporte["CO02EXP006TO_DCCN"]=int(CO02EXP006TO_DCCN)
	#reporte["MMAXHIS_DCCND02"]=int(MMAXHIS_DCCND02)
	#reporte["CO02END015CB_DCCND02"]=int(CO02END015CB_DCCND02)
	#reporte["RECMORA001VSA_DCCND01"]=int(RECMORA001VSA_DCCND01)
	#reporte["CO01END089RO_DCCND04"]=int(CO01END089RO_DCCND04)
	#reporte["TIPORELD01_DCCN"]=int(TIPORELD01_DCCN)
	#reporte["CO01END088RO_DCCND01"]=int(CO01END088RO_DCCND01)
	#reporte["CO01EXP001RO_DCCND04"]=int(CO01EXP001RO_DCCND04)
	#reporte["CO01EXP001AH_DCCND00"]=int(CO01EXP001AH_DCCND00)
	#reporte["CO01MOR040RO_DCCND03"]=int(CO01MOR040RO_DCCND03)
	#reporte["TIPORELD04_DCCN"]=int(TIPORELD04_DCCN)
	#reporte["EVER03006P_DCCND02"]=int(EVER03006P_DCCND02)
	#reporte["CO01END030RO_DCCND04"]=int(CO01END030RO_DCCND04)
	#reporte["CO01MOR062RO_DCCND01"]=int(CO01MOR062RO_DCCND01)
	#reporte["CO01END088RO_DCCND02"]=int(CO01END088RO_DCCND02)
	#reporte["EXPOSICION_DCCND01"]=int(EXPOSICION_DCCND01)
	#reporte["CO01END030RO_DCCND03"]=int(CO01END030RO_DCCND03)
	#reporte["CO01END022RO_DCCND02"]=int(CO01END022RO_DCCND02)
	#reporte["CO01MOR055CC_DCCND01"]=int(CO01MOR055CC_DCCND01)
	#reporte["CO01NUM050RO_DCCND03"]=int(CO01NUM050RO_DCCND03)
	return reporte
#--------------------------------------------------------------------------------------------------------------#
#  FUNCION segmento2 : REALIZA EL CALCULO DEL score PARA POBLACION DEL SEGMENTO 2   
#--------------------------------------------------------------------------------------------------------------#
def segmento2(data,PRQALDIA,RECMORA001VSA,MMAXHIS,MMAX24,RECMORA120,TIPORELD04):
	PRQALDIA_DCCE = PRQALDIA
	if data["CO02EXP001TO"] < 0 : 
		CO02EXP001TO_DCCE = 0 
	else: 
		CO02EXP001TO_DCCE = data["CO02EXP001TO"]
	
	if data["CO01EXP001CC"] < 0 : 
		CO01EXP001CC_DCCE = 0 
	else: 
		CO01EXP001CC_DCCE = data["CO01EXP001CC"]
	
	if data["CO02NUM042CB"] < 0 : 
		CO02NUM042CB_DCCE = 0 
	else: 
		CO02NUM042CB_DCCE = data["CO02NUM042CB"]
	
	if data["CO02EXP006TO"] < 0 : 
		CO02EXP006TO_DCCE = 0 
	else: 
		CO02EXP006TO_DCCE = data["CO02EXP006TO"]
	
	if data["CO01NUM050CC"] < 0 : 
		CO01NUM050CC_DCCE = 0 
	else: 
		CO01NUM050CC_DCCE = data["CO01NUM050CC"]
	
	if PRQALDIA_DCCE > 1 : 
		PRQALDIA_DCCE = 1
	
	if CO02EXP001TO_DCCE > 287 : 
		CO02EXP001TO_DCCE = 287
	
	if CO01EXP001CC_DCCE > 145 : 
		CO01EXP001CC_DCCE = 145
	
	if CO02NUM042CB_DCCE > 100 : 
		CO02NUM042CB_DCCE = 100
	
	if CO02EXP006TO_DCCE > 104 : 
		CO02EXP006TO_DCCE = 104
	
	if CO01NUM050CC_DCCE > 5 : 
		CO01NUM050CC_DCCE = 5
	
	TIPORELD04_DCCE = TIPORELD04
	
	if 0 <= RECMORA001VSA < 3.12 : 
		RECMORA001VSA_DCCED01 = 1 
	else: 
		RECMORA001VSA_DCCED01 = 0
	
	if 3.12 <= RECMORA001VSA < 12.54 : 
		RECMORA001VSA_DCCED02 = 1 
	else: 
		RECMORA001VSA_DCCED02 = 0
	
	if 12.54 <= RECMORA001VSA : 
		RECMORA001VSA_DCCED03 = 1 
	else: 
		RECMORA001VSA_DCCED03 = 0
	
	if 0 <= MMAXHIS < 1 : 
		MMAXHIS_DCCED01 = 1 
	else: 
		MMAXHIS_DCCED01 = 0
	
	if 1 <= MMAXHIS < 3 : 
		MMAXHIS_DCCED02 = 1 
	else: 
		MMAXHIS_DCCED02 = 0
	
	if 3 <= MMAXHIS : 
		MMAXHIS_DCCED03 = 1 
	else: 
		MMAXHIS_DCCED03 = 0
	
	if 0 <= data["CO01END027CC"] < 0.02 : 
		CO01END027CC_DCCED01 = 1 
	else: 
		CO01END027CC_DCCED01 = 0
	
	if 0.02 <= data["CO01END027CC"] : 
		CO01END027CC_DCCED02 = 1 
	else: 
		CO01END027CC_DCCED02 = 0
	
	if 0 <= data["CO01END027RO"] < 0.01 : 
		CO01END027RO_DCCED01 = 1 
	else: 
		CO01END027RO_DCCED01 = 0
	
	if 0.01 <= data["CO01END027RO"] : 
		CO01END027RO_DCCED02 = 1 
	else: 
		CO01END027RO_DCCED02 = 0
	
	if data["CO01MOR033RO"] < 0 : 
		CO01MOR033RO_DCCED00 = 1
	else: 
		CO01MOR033RO_DCCED00 = 0
	
	if 0 <= data["CO01MOR033RO"] < 2 : 
		CO01MOR033RO_DCCED01 = 1 
	else: 
		CO01MOR033RO_DCCED01 = 0
	
	if 2 <= data["CO01MOR033RO"] < 3 : 
		CO01MOR033RO_DCCED02 = 1 
	else: 
		CO01MOR033RO_DCCED02 = 0
	
	if 3 <= data["CO01MOR033RO"] : 
		CO01MOR033RO_DCCED03 = 1 
	else: 
		CO01MOR033RO_DCCED03 = 0
	
	if 0 <= data["CO01END030RO"] < 0.62 : 
		CO01END030RO_DCCED01 = 1 
	else: 
		CO01END030RO_DCCED01 = 0
	
	if 0.62 <= data["CO01END030RO"] < 1.78 : 
		CO01END030RO_DCCED02 = 1 
	else: 
		CO01END030RO_DCCED02 = 0
	
	if 1.78 <= data["CO01END030RO"] < 4.4 : 
		CO01END030RO_DCCED03 = 1 
	else: 
		CO01END030RO_DCCED03 = 0
	
	if 4.4 <= data["CO01END030RO"] : 
		CO01END030RO_DCCED04 = 1 
	else: 
		CO01END030RO_DCCED04 = 0
	
	if 0 <= data["CO02END015CB"] < 0.41 : 
		CO02END015CB_DCCED01 = 1 
	else: 
		CO02END015CB_DCCED01 = 0
	
	if 0.41 <= data["CO02END015CB"] : 
		CO02END015CB_DCCED02 = 1 
	else: 
		CO02END015CB_DCCED02 = 0
	
	if 0 <= data["CO01END092RO"] < 10.35 : 
		CO01END092RO_DCCED01 = 1 
	else: 
		CO01END092RO_DCCED01 = 0
	
	if 10.35 <= data["CO01END092RO"] < 24.2 : 
		CO01END092RO_DCCED02 = 1 
	else: 
		CO01END092RO_DCCED02 = 0
	
	if 24.2 <= data["CO01END092RO"] < 47.63 : 
		CO01END092RO_DCCED03 = 1 
	else: 
		CO01END092RO_DCCED03 = 0
	
	if 47.63 <= data["CO01END092RO"] : 
		CO01END092RO_DCCED04 = 1 
	else: 
		CO01END092RO_DCCED04 = 0
	
	if data["CO01EXP001AH"] < 0 : 
		CO01EXP001AH_DCCED00 = 1 
	else: 
		CO01EXP001AH_DCCED00 = 0
	
	if 0 <= data["CO01EXP001AH"] < 45.89 : 
		CO01EXP001AH_DCCED01 = 1 
	else: 
		CO01EXP001AH_DCCED01 = 0
	
	if 45.89 <= data["CO01EXP001AH"] < 82.61 : 
		CO01EXP001AH_DCCED02 = 1 
	else: 
		CO01EXP001AH_DCCED02 = 0
	
	if 82.61 <= data["CO01EXP001AH"] < 135.01 : 
		CO01EXP001AH_DCCED03 = 1 
	else: 
		CO01EXP001AH_DCCED03 = 0
	
	if 135.01<= data["CO01EXP001AH"] : 
		CO01EXP001AH_DCCED04 = 1 
	else: 
		CO01EXP001AH_DCCED04 = 0
	
	if 0 <= data["CO01MOR009CC"] < 1 : 
		CO01MOR009CC_DCCED01 = 1 
	else: 
		CO01MOR009CC_DCCED01 = 0
	
	if 1 <= data["CO01MOR009CC"] : 
		CO01MOR009CC_DCCED02 = 1 
	else: 
		CO01MOR009CC_DCCED02 = 0
	
	if data["CO01NUM050AH"] < 0 : 
		CO01NUM050AH_DCCED00 = 1 
	else: 
		CO01NUM050AH_DCCED00 = 0
	
	if 0 <= data["CO01NUM050AH"] < 1 : 
		CO01NUM050AH_DCCED01 = 1 
	else: 
		CO01NUM050AH_DCCED01 = 0
	
	if 1 <= data["CO01NUM050AH"] < 2 : 
		CO01NUM050AH_DCCED02 = 1 
	else: 
		CO01NUM050AH_DCCED02 = 0
	
	if 2 <= data["CO01NUM050AH"] : 
		CO01NUM050AH_DCCED03 = 1 
	else: 
		CO01NUM050AH_DCCED03 = 0
	
	if 0 <= MMAX24 < 2 : 
		MMAX24_DCCED01 = 1 
	else: 
		MMAX24_DCCED01 = 0
	
	if 2 <= MMAX24 : 
		MMAX24_DCCED02 = 1 
	else: 
		MMAX24_DCCED02 = 0
	
	if 0 <= RECMORA120 < 2 : 
		RECMORA120_DCCED01 = 1 
	else: 
		RECMORA120_DCCED01 = 0
	
	if 2 <= RECMORA120 : 
		RECMORA120_DCCED02 = 1 
	else: 
		RECMORA120_DCCED02 = 0
	
	if 0 <= data["CO01END071RO"] < 25.47 : 
		CO01END071RO_DCCED01 = 1 
	else: 
		CO01END071RO_DCCED01 = 0
	
	if 25.47 <= data["CO01END071RO"] < 55.45 : 
		CO01END071RO_DCCED02 = 1 
	else: 
		CO01END071RO_DCCED02 = 0
	
	if 55.45 <= data["CO01END071RO"] < 83.35 : 
		CO01END071RO_DCCED03 = 1 
	else: 
		CO01END071RO_DCCED03 = 0
	
	if 83.35 <= data["CO01END071RO"] : 
		CO01END071RO_DCCED04 = 1 
	else: 
		CO01END071RO_DCCED04 = 0
	
	suma =  + 0.540029201961117 \
			+ (PRQALDIA_DCCE     * 0.330937592599727)     \
			+ (CO02EXP001TO_DCCE * 0.000960423347683772) \
			+ (CO01EXP001CC_DCCE * 0.00421741288326723) \
			+ (CO02NUM042CB_DCCE * -0.00475588941910042) \
			+ (CO02EXP006TO_DCCE * 0.00935515942758703) \
			+ (CO01NUM050CC_DCCE * 0.052228354649971) \
			+ (RECMORA001VSA_DCCED01 * -0.420674002235437)\
			+ (MMAXHIS_DCCED01      * 0.498396782997891) \
			+ (MMAXHIS_DCCED02      * 0.325203260449194) \
			+ (CO01END027CC_DCCED01 * 0.506090752275124) \
			+ (CO01END027RO_DCCED01 * 0.197910488406771) \
			+ (CO01MOR033RO_DCCED00 * -0.104744086096822) \
			+ (CO01MOR033RO_DCCED02 * 0.183794847829539) \
			+ (CO01MOR033RO_DCCED03 * 0.284519725845049) \
			+ (CO01END030RO_DCCED01 * -0.186365878978875) \
			+ (CO01END030RO_DCCED03 * 0.136233576280088) \
			+ (CO01END030RO_DCCED04 * 0.205640162476688) \
			+ (CO02END015CB_DCCED01 * 0.107728472859104) \
			+ (CO02END015CB_DCCED02 * -0.165721926380589) \
			+ (CO01END092RO_DCCED01 * -0.153129971716385) \
			+ (CO01END092RO_DCCED04 * 0.175657497650932) \
			+ (CO01EXP001AH_DCCED00 * -0.142156941746533) \
			+ (CO01MOR009CC_DCCED02 * -0.339490788274381) \
			+ (CO01NUM050AH_DCCED01 * -0.198408569882946) \
			+ (CO01NUM050AH_DCCED03 * 0.134711827731912) \
			+ (MMAX24_DCCED02       * -0.143171574014672) \
			+ (RECMORA120_DCCED01   * -0.223653711596704) \
			+ (CO01END071RO_DCCED01 * 0.199175648390095) \
			+ (CO01END071RO_DCCED04 * -0.24608674579614) \
			+ (TIPORELD04_DCCE      * 0.113175284048051)
	AciertaA = int (1000 / (1 + np.exp(-suma)))
	AciertaADef = int (400.000000000000 + 110.321693765613 * suma)

	if AciertaADef <= 150:
		AciertaADef=150
	if AciertaADef >= 999:
		AciertaADef=999

	reporte={}
	#reporte['TIPOID']=int(data['TIPOID'])
	#reporte['CONUMIDE']=int(data['CONUMIDE'])
	reporte['scoreSegment']=2
	#reporte['AciertaA']=AciertaA
	reporte['scoreValue']=AciertaADef
	#reporte["PRQALDIA"]=PRQALDIA
	#reporte["RECMORA001VSA"]=RECMORA001VSA
	#reporte["MMAXHIS"]=MMAXHIS
	#reporte["MMAX24"]=MMAX24
	#reporte["RECMORA120"]=RECMORA120
	#reporte["TIPORELD04"]=TIPORELD04
	#reporte["PRQALDIA_DCCE"]=PRQALDIA_DCCE
	#reporte["CO02EXP001TO_DCCE"]=int(CO02EXP001TO_DCCE)
	#reporte["CO01EXP001CC_DCCE"]=int(CO01EXP001CC_DCCE)
	#reporte["CO02NUM042CB_DCCE"]=int(CO02NUM042CB_DCCE)
	#reporte["CO02EXP006TO_DCCE"]=int(CO02EXP006TO_DCCE)
	#reporte["CO01NUM050CC_DCCE"]=int(CO01NUM050CC_DCCE)
	#reporte["RECMORA001VSA_DCCED01"]=int(RECMORA001VSA_DCCED01)
	#reporte["MMAXHIS_DCCED01"]=int(MMAXHIS_DCCED01)
	#reporte["MMAXHIS_DCCED02"]=int(MMAXHIS_DCCED02)
	#reporte["CO01END027CC_DCCED01"]=int(CO01END027CC_DCCED01)
	#reporte["CO01END027RO_DCCED01"]=int(CO01END027RO_DCCED01)
	#reporte["CO01MOR033RO_DCCED00"]=int(CO01MOR033RO_DCCED00)
	#reporte["CO01MOR033RO_DCCED02"]=int(CO01MOR033RO_DCCED02)
	#reporte["CO01MOR033RO_DCCED03"]=int(CO01MOR033RO_DCCED03)
	#reporte["CO01END030RO_DCCED01"]=int(CO01END030RO_DCCED01)
	#reporte["CO01END030RO_DCCED03"]=int(CO01END030RO_DCCED03)
	#reporte["CO01END030RO_DCCED04"]=int(CO01END030RO_DCCED04)
	#reporte["CO02END015CB_DCCED01"]=int(CO02END015CB_DCCED01)
	#reporte["CO02END015CB_DCCED02"]=int(CO02END015CB_DCCED02)
	#reporte["CO01END092RO_DCCED01"]=int(CO01END092RO_DCCED01)
	#reporte["CO01END092RO_DCCED04"]=int(CO01END092RO_DCCED04)
	#reporte["CO01EXP001AH_DCCED00"]=int(CO01EXP001AH_DCCED00)
	#reporte["CO01MOR009CC_DCCED02"]=int(CO01MOR009CC_DCCED02)
	#reporte["CO01NUM050AH_DCCED01"]=int(CO01NUM050AH_DCCED01)
	#reporte["CO01NUM050AH_DCCED03"]=int(CO01NUM050AH_DCCED03)
	#reporte["MMAX24_DCCED02"]=int(MMAX24_DCCED02)
	#reporte["RECMORA120_DCCED01"]=int(RECMORA120_DCCED01)
	#reporte["CO01END071RO_DCCED01"]=int(CO01END071RO_DCCED01)
	#reporte["CO01END071RO_DCCED04"]=int(CO01END071RO_DCCED04)
	#reporte["TIPORELD04_DCCE"]=int(TIPORELD04_DCCE)
	#print("segmento2")
	return reporte

#--------------------------------------------------------------------------------------------------------------#
#  FUNCION segmento3 : REALIZA EL CALCULO DEL score PARA POBLACION DEL SEGMENTO 3   
#--------------------------------------------------------------------------------------------------------------#

def segmento3(data,PROQTOTAB,PRQALDIA,RECMORA001VSA,MMAXHIS):
	#/* Continuas: Valores especiales (imputa) */ 
	if data['CO02EXP001TO'] < 0:
		CO02EXP001TO_DTRN = 0
	else:
		CO02EXP001TO_DTRN = data['CO02EXP001TO']
	if data['CO02EXP006TO'] < 0:
		CO02EXP006TO_DTRN = 0
	else:
		CO02EXP006TO_DTRN = data['CO02EXP006TO']
	if data['CO02EXP008TO'] < 0:
		CO02EXP008TO_DTRN = 0
	else:
		CO02EXP008TO_DTRN = data['CO02EXP008TO']
	if PROQTOTAB < 0:
		PROQTOTAB_DTRN = 0
	else:
		PROQTOTAB_DTRN = PROQTOTAB
	if PRQALDIA < 0:
		PRQALDIA_DTRN = 0
	else:
		PRQALDIA_DTRN = PRQALDIA
	#continuas
	if CO02EXP001TO_DTRN > 277:
		CO02EXP001TO_DTRN = 277
	if CO02EXP006TO_DTRN > 103:
		CO02EXP006TO_DTRN = 103
	if CO02EXP008TO_DTRN > 100:
		CO02EXP008TO_DTRN = 100
	if PROQTOTAB_DTRN > 1:
		PROQTOTAB_DTRN = 1
	if PRQALDIA_DTRN > 1:
		PRQALDIA_DTRN = 1
	if 0.43 <= data['CO01END030RO'] < 1.25:
		CO01END030RO_DTRND02 = 1
	else:
		CO01END030RO_DTRND02 = 0
	if 1.25 <= data['CO01END030RO'] < 3.16:
		CO01END030RO_DTRND03 = 1
	else:
		CO01END030RO_DTRND03 = 0
	if 3.16 <= data['CO01END030RO']:
		CO01END030RO_DTRND04 = 1
	else:
		CO01END030RO_DTRND04 = 0
	if 0 <= data['CO01END089RO']< 30.12:
		CO01END089RO_DTRND01 = 1
	else:
		CO01END089RO_DTRND01 = 0
	if 83.94 <= data['CO01END089RO']:
		CO01END089RO_DTRND04 = 1
	else:
		CO01END089RO_DTRND04 = 0
	if 0 <= data['CO01EXP001RO']< 21:
		CO01EXP001RO_DTRND01 = 1
	else:
		CO01EXP001RO_DTRND01 = 0
	if 122.82 <= data['CO01EXP001RO']:
		CO01EXP001RO_DTRND04 = 1
	else:
		CO01EXP001RO_DTRND04 = 0
	if 1 <= data['CO01MOR068RO']:
		CO01MOR068RO_DTRND02 = 1
	else:
		CO01MOR068RO_DTRND02 = 0
	if 0 <= data['CO01END092RO']< 9.66:
		CO01END092RO_DTRND01 = 1
	else:
		CO01END092RO_DTRND01 = 0
	if 45.52 <= data['CO01END092RO']:
		CO01END092RO_DTRND04 = 1
	else:
		CO01END092RO_DTRND04 = 0
	if 0 <= data['CO01MOR074CC']< 1:
		CO01MOR074CC_DTRND01 = 1
	else:
		CO01MOR074CC_DTRND01 = 0
	if 2 <= data['CO01MOR047RO']:
		CO01MOR047RO_DTRND03 = 1
	else:
		CO01MOR047RO_DTRND03 = 0
	if 0 <= RECMORA001VSA< 8:
		RECMORA001VSA_DTRND01 = 1
	else:
		RECMORA001VSA_DTRND01 = 0
	if 16.88 <= RECMORA001VSA:
		RECMORA001VSA_DTRND03 = 1
	else:
		RECMORA001VSA_DTRND03 = 0
	if 1 <= MMAXHIS:
		MMAXHIS_DTRND02 = 1
	else:
		MMAXHIS_DTRND02 = 0
	if 2 <= data['CO01INQ016TO']:
		CO01INQ016_DTRND02 = 1
	else:
		CO01INQ016_DTRND02 = 0

	suma = 2.16002832244677 \
	+ (CO02EXP001TO_DTRN * 0.00104734005877538) \
	+ (CO02EXP006TO_DTRN * 0.00637891733046571) \
	+ (CO02EXP008TO_DTRN * -0.00673963285986247) \
	+ (PROQTOTAB_DTRN * -0.409008100719587) \
	+ (PRQALDIA_DTRN * 0.537443167022554) \
	+ (CO01END030RO_DTRND02 * 0.244762124780151) \
	+ (CO01END030RO_DTRND03 * 0.445652630009138) \
	+ (CO01END030RO_DTRND04 * 0.67860276731568) \
	+ (CO01END089RO_DTRND01 * 0.319166729465078) \
	+ (CO01END089RO_DTRND04 * -0.318520738959837) \
	+ (CO01EXP001RO_DTRND01 * -0.1477963373389) \
	+ (CO01EXP001RO_DTRND04 * 0.218030967614173) \
	+ (CO01MOR068RO_DTRND02 * 0.458592460897973) \
	+ (CO01END092RO_DTRND01 * -0.207397524080302) \
	+ (CO01END092RO_DTRND04 * 0.269981123195007) \
	+ (CO01MOR074CC_DTRND01 * 0.25157562727694) \
	+ (CO01MOR047RO_DTRND03 * 0.0941085824347264) \
	+ (RECMORA001VSA_DTRND01 * -0.426773779602227) \
	+ (RECMORA001VSA_DTRND03 * 0.118557919952929) \
	+ (MMAXHIS_DTRND02 * -0.456702340824274) \
	+ (CO01INQ016_DTRND02 * -0.394327459472137)
	AciertaA = int (1000 / (1 + np.exp(-suma)))
	AciertaADef = int (400.000000000000 + 110.321693765613 * suma)

	if AciertaADef <= 150:
		AciertaADef=150
	if AciertaADef >= 999:
		AciertaADef=999

	reporte={}
	#reporte['TIPOID']=int(data['TIPOID'])
	#reporte['CONUMIDE']=int(data['CONUMIDE'])
	reporte['scoreSegment']=3
	#reporte['AciertaA']=AciertaA
	reporte['scoreValue']=AciertaADef
	#reporte["PROQTOTAB"]=PROQTOTAB
	#reporte["PRQALDIA"]=PRQALDIA
	#reporte["RECMORA001VSA"]=RECMORA001VSA
	#reporte["MMAXHIS"]=MMAXHIS
	#reporte['PROQTOTAB']=PROQTOTAB
	#reporte['PRQALDIA']=PRQALDIA
	#reporte['RECMORA001VSA']=RECMORA001VSA
	#reporte['MMAXHIS']=MMAXHIS
	#reporte['CO02EXP001TO_DTRN']=int(CO02EXP001TO_DTRN)
	#reporte['CO02EXP006TO_DTRN']=int(CO02EXP006TO_DTRN)
	#reporte['CO02EXP008TO_DTRN']=int(CO02EXP008TO_DTRN)
	#reporte['PROQTOTAB_DTRN']=int(PROQTOTAB_DTRN)
	#reporte['PRQALDIA_DTRN']=int(PRQALDIA_DTRN)
	#reporte['CO01END030RO_DTRND02']=int(CO01END030RO_DTRND02)
	#reporte['CO01END030RO_DTRND03']=int(CO01END030RO_DTRND03)
	#reporte['CO01END030RO_DTRND04']=int(CO01END030RO_DTRND04)
	#reporte['CO01END089RO_DTRND01']=int(CO01END089RO_DTRND01)
	#reporte['CO01END089RO_DTRND04']=int(CO01END089RO_DTRND04)
	#reporte['CO01EXP001RO_DTRND01']=int(CO01EXP001RO_DTRND01)
	#reporte['CO01EXP001RO_DTRND04']=int(CO01EXP001RO_DTRND04)
	#reporte['CO01MOR068RO_DTRND02']=int(CO01MOR068RO_DTRND02)
	#reporte['CO01END092RO_DTRND01']=int(CO01END092RO_DTRND01)
	#reporte['CO01END092RO_DTRND04']=int(CO01END092RO_DTRND04)
	#reporte['CO01MOR074CC_DTRND01']=int(CO01MOR074CC_DTRND01)
	#reporte['CO01MOR047RO_DTRND03']=int(CO01MOR047RO_DTRND03)
	#reporte['RECMORA001VSA_DTRND01']=int(RECMORA001VSA_DTRND01)
	#reporte['RECMORA001VSA_DTRND03']=int(RECMORA001VSA_DTRND03)
	#reporte['MMAXHIS_DTRND02']=int(MMAXHIS_DTRND02)
	#reporte['CO01INQ016_DTRND02']=int(CO01INQ016_DTRND02)
	#print("segmento3")
	return reporte

#--------------------------------------------------------------------------------------------------------------#
#  FUNCION segmento4 : REALIZA EL CALCULO DEL score PARA POBLACION DEL SEGMENTO 4   
#--------------------------------------------------------------------------------------------------------------#

def segmento4(data,PRQALDIA,PREXPOSICIONIN,RECMORA001VSA,MMAXHIS):
	#/* Continuas: Valores especiales (imputa) */ 
	PRQALDIA_DTRE = PRQALDIA
	if data['CO02EXP006TO'] < 0:
		CO02EXP006TO_DTRE = 60
	else:
		CO02EXP006TO_DTRE = data['CO02EXP006TO']
	if data['CO01NUM050RO'] < 0:
		CO01NUM050RO_DTRE = 0
	else:
		CO01NUM050RO_DTRE = data['CO01NUM050RO']
	if data['CO02NUM042CB'] < 0:
		CO02NUM042CB_DTRE = 0
	else:
		CO02NUM042CB_DTRE = data['CO02NUM042CB']
	if data['CO01ACP004RO'] < 0:
		CO01ACP004RO_DTRE = 2
	else:
		CO01ACP004RO_DTRE = data['CO01ACP004RO']
	if PREXPOSICIONIN < 0:
		PREXPOSICIONIN_DTRE = 0
	else:
		PREXPOSICIONIN_DTRE = PREXPOSICIONIN
	if data['CO02EXP008TO'] < 0:
		CO02EXP008TO_DTRE = 0
	else:
		CO02EXP008TO_DTRE = data['CO02EXP008TO']
	#continuas
	if CO02EXP006TO_DTRE > 109:
		CO02EXP006TO_DTRE = 109
	if CO01NUM050RO_DTRE > 9:
		CO01NUM050RO_DTRE = 9
	if PRQALDIA_DTRE > 1:
		PRQALDIA_DTRE = 1
	if CO02NUM042CB_DTRE > 100:
		CO02NUM042CB_DTRE = 100
	if CO01ACP004RO_DTRE > 6:
		CO01ACP004RO_DTRE = 6
	if PREXPOSICIONIN_DTRE > 1:
		PREXPOSICIONIN_DTRE = 1
	if CO02EXP008TO_DTRE > 75:
		CO02EXP008TO_DTRE = 75
	#categoricas
	if 26.45 <= data['CO01END092RO'] < 49.48:
		CO01END092RO_DTRED03 = 1
	else:
		CO01END092RO_DTRED03 = 0
	if 49.48 <= data['CO01END092RO']:
		CO01END092RO_DTRED04 = 1
	else:
		CO01END092RO_DTRED04 = 0
	if 0 <= data['CO01END071RO'] < 27.35:
		CO01END071RO_DTRED01 = 1
	else:
		CO01END071RO_DTRED01 = 0
	if 27.35 <= data['CO01END071RO'] < 56.14:
		CO01END071RO_DTRED02 = 1
	else:
		CO01END071RO_DTRED02 = 0
	if 82.01 <= data['CO01END071RO']:
		CO01END071RO_DTRED04 = 1
	else:
		CO01END071RO_DTRED04 = 0
	if 0 <= data['CO01END089RO'] < 28.5:
		CO01END089RO_DTRED01 = 1
	else:
		CO01END089RO_DTRED01 = 0
	if 28.5 <= data['CO01END089RO'] < 56.65:
		CO01END089RO_DTRED02 = 1
	else:
		CO01END089RO_DTRED02 = 0
	if 79.05 <= data['CO01END089RO']:
		CO01END089RO_DTRED04 = 1
	else:
		CO01END089RO_DTRED04 = 0
	if 2.16 <= data['CO01END010RO'] < 5.22:
		CO01END010RO_DTRED03 = 1
	else:
		CO01END010RO_DTRED03 = 0
	if 5.22 <= data['CO01END010RO']:
		CO01END010RO_DTRED04 = 1
	else:
		CO01END010RO_DTRED04 = 0
	if data['CO01INQ017TO'] < 0:
		CO01INQ017_DTRED00 = 1
	else:
		CO01INQ017_DTRED00 = 0
	if 2 <= data['CO01INQ017TO']< 3:
		CO01INQ017_DTRED02 = 1
	else:
		CO01INQ017_DTRED02 = 0
	if 3 <= data['CO01INQ017TO']:
		CO01INQ017_DTRED03 = 1
	else:
		CO01INQ017_DTRED03 = 0
	if 0 <= RECMORA001VSA < 6:
		RECMORA001VSA_DTRED01 = 1
	else:
		RECMORA001VSA_DTRED01 = 0
	if 6 <= RECMORA001VSA < 15:
		RECMORA001VSA_DTRED02 = 1
	else:
		RECMORA001VSA_DTRED02 = 0
	if 2 <= MMAXHIS:
		MMAXHIS_DTRED02 = 1
	else:
		MMAXHIS_DTRED02 = 0

	suma = 2.50650260609909 \
	+ (CO02EXP006TO_DTRE * 0.0099816308358122) \
	+ (CO01NUM050RO_DTRE * 0.0836297107093468) \
	+ (PRQALDIA_DTRE * 0.953950873392059) \
	+ (CO02NUM042CB_DTRE * -0.00679276532905383) \
	+ (CO01ACP004RO_DTRE * -0.0995983512223878) \
	+ (PREXPOSICIONIN_DTRE * -0.244996730346691) \
	+ (CO02EXP008TO_DTRE * -0.007507425254573) \
	+ (CO01END092RO_DTRED03 * 0.147935467727473) \
	+ (CO01END092RO_DTRED04 * 0.253028540378739) \
	+ (CO01END071RO_DTRED01 * 0.369083173273486) \
	+ (CO01END071RO_DTRED02 * 0.301081045292067) \
	+ (CO01END071RO_DTRED04 * -0.338159935896673) \
	+ (CO01END089RO_DTRED01 * 0.229209748986827) \
	+ (CO01END089RO_DTRED02 * 0.177023743513138) \
	+ (CO01END089RO_DTRED04 * -0.188951513767361) \
	+ (CO01END010RO_DTRED03 * 0.104057785366257) \
	+ (CO01END010RO_DTRED04 * 0.277373734138514) \
	+ (CO01INQ017_DTRED00 * 0.257417987210384) \
	+ (CO01INQ017_DTRED02 * -0.224282520125901) \
	+ (CO01INQ017_DTRED03 * -0.571253870563982) \
	+ (RECMORA001VSA_DTRED01 * -0.555548462857749) \
	+ (RECMORA001VSA_DTRED02 * -0.258145138338064) \
	+ (MMAXHIS_DTRED02 * -0.399364291783047)
	AciertaA = int (1000 / (1 + np.exp(-suma)))
	AciertaADef = int (400.000000000000 + 110.321693765613 * suma)

	if AciertaADef <= 150:
		AciertaADef=150
	if AciertaADef >= 999:
		AciertaADef=999

	reporte={}
	#reporte['TIPOID']=int(data['TIPOID'])
	#reporte['CONUMIDE']=int(data['CONUMIDE'])
	reporte['scoreSegment']=4
	#reporte['AciertaA']=AciertaA
	reporte['scoreValue']=AciertaADef
	#reporte["PRQALDIA"]=PRQALDIA
	#reporte["PREXPOSICIONIN"]=PREXPOSICIONIN
	#reporte["RECMORA001VSA"]=RECMORA001VSA
	#reporte["MMAXHIS"]=MMAXHIS
	#reporte['PRQALDIA']=PRQALDIA
	#reporte['MMAXHIS']=MMAXHIS
	#reporte['CO02EXP006TO_DTRE']=int(CO02EXP006TO_DTRE)
	#reporte['CO01NUM050RO_DTRE']=int(CO01NUM050RO_DTRE)
	#reporte['PRQALDIA_DTRE']=int(PRQALDIA_DTRE)
	#reporte['CO02NUM042CB_DTRE']=int(CO02NUM042CB_DTRE)
	#reporte['CO01ACP004RO_DTRE']=int(CO01ACP004RO_DTRE)
	#reporte['PREXPOSICIONIN_DTRE']=int(PREXPOSICIONIN_DTRE)
	#reporte['CO02EXP008TO_DTRE']=int(CO02EXP008TO_DTRE)
	#reporte['CO01END092RO_DTRED03']=int(CO01END092RO_DTRED03)
	#reporte['CO01END092RO_DTRED04']=int(CO01END092RO_DTRED04)
	#reporte['CO01END071RO_DTRED01']=int(CO01END071RO_DTRED01)
	#reporte['CO01END071RO_DTRED02']=int(CO01END071RO_DTRED02)
	#reporte['CO01END071RO_DTRED04']=int(CO01END071RO_DTRED04)
	#reporte['CO01END089RO_DTRED01']=int(CO01END089RO_DTRED01)
	#reporte['CO01END089RO_DTRED02']=int(CO01END089RO_DTRED02)
	#reporte['CO01END089RO_DTRED04']=int(CO01END089RO_DTRED04)
	#reporte['CO01END010RO_DTRED03']=int(CO01END010RO_DTRED03)
	#reporte['CO01END010RO_DTRED04']=int(CO01END010RO_DTRED04)
	#reporte['CO01INQ017_DTRED00']=int(CO01INQ017_DTRED00)
	#reporte['CO01INQ017_DTRED02']=int(CO01INQ017_DTRED02)
	#reporte['CO01INQ017_DTRED03']=int(CO01INQ017_DTRED03)
	#reporte['RECMORA001VSA_DTRED01']=int(RECMORA001VSA_DTRED01)
	#reporte['RECMORA001VSA_DTRED02']=int(RECMORA001VSA_DTRED02)
	#reporte['MMAXHIS_DTRED02']=int(MMAXHIS_DTRED02)
	#print("segmento4")
	return reporte

#--------------------------------------------------------------------------------------------------------------#
#  FUNCION segmento5 : REALIZA EL CALCULO DEL score PARA POBLACION DEL SEGMENTO 4   
#--------------------------------------------------------------------------------------------------------------#

def segmento5(data,MOB12,PRQALDIA,RECMORA030,MMAXHIS,RECMORA001):
	#/* Continuas: Valores especiales (imputa) */ 
	AA_S5_PRQALDIA_DINT = PRQALDIA
	if AA_S5_PRQALDIA_DINT > 1 :
		AA_S5_PRQALDIA_DINT = 1

	AA_S5_CO02NUM042CB_DINT = data['CO02NUM042CB']
	if AA_S5_CO02NUM042CB_DINT > 100 :
		AA_S5_CO02NUM042CB_DINT = 100

	AA_S5_CO02EXP001TO_DINT = data['CO02EXP001TO']
	if AA_S5_CO02EXP001TO_DINT > 313 :
		AA_S5_CO02EXP001TO_DINT = 313

	AA_S5_CO02NUM005TO_DINT = data['CO02NUM005TO']
	if AA_S5_CO02NUM005TO_DINT > 42 :
		AA_S5_CO02NUM005TO_DINT = 42

	if 0 <= RECMORA001 < 3.63 :
		AA_S5_RECMORA001_DINTD01 = 1
	else:
		AA_S5_RECMORA001_DINTD01 = 0

	#if data['CO02END015CB'] < 0 :
	#	AUX_CO02END015CB = 0
	#else :
	#	AUX_CO02END015CB = CO02END015CB

	if 0.31 <= data['CO02END015CB'] :
		AA_S5_CO02END015CB_DINTD02 = 1
	else:
		AA_S5_CO02END015CB_DINTD02 = 0

	if 0 <= RECMORA030 < 5:
		AA_S5_RECMORA030_DINTD01 = 1
	else:
		AA_S5_RECMORA030_DINTD01 = 0

	#if data['CO01END089RO'] < 0 :
	#	AUX_CO01END089RO = 0
	#else :
	#	AUX_CO01END089RO = data['CO01END089RO']

	if 0 <= data['CO01END089RO'] < 36.76 :
		AA_S5_CO01END089RO_DINTD01 = 1 
	else:
		AA_S5_CO01END089RO_DINTD01 = 0

	if 36.76 <= data['CO01END089RO'] < 63.97 :
		AA_S5_CO01END089RO_DINTD02 = 1
	else :
		AA_S5_CO01END089RO_DINTD02 = 0


	if 84.47 <= data['CO01END089RO']:
		AA_S5_CO01END089RO_DINTD04 = 1
	else :
		AA_S5_CO01END089RO_DINTD04 = 0

	#if data['CO01MOR046RO'] < 0 :
	#	AUX_CO01MOR046RO = 0
	#else :
	#	AUX_CO01MOR046RO = data['CO01MOR046RO']

	if 0 <= data['CO01MOR046RO'] < 1 :
		AA_S5_CO01MOR046RO_DINTD01 = 1
	else :
		AA_S5_CO01MOR046RO_DINTD01 = 0

	if 2 <= MMAXHIS :
		AA_S5_MMAXHIS_DINTD03 = 1
	else :
		AA_S5_MMAXHIS_DINTD03 = 0

	#if data['CO01END017RO'] < 0 :
	#	AUX_CO01END017RO = 0
	#else :
	#	AUX_CO01END017RO = data['CO01END017RO']

	if 0.01 <= data['CO01END017RO'] :
		AA_S5_CO01END017RO_DINTD02 = 1
	else :
		AA_S5_CO01END017RO_DINTD02 = 0

	#if data['CO01END071RO'] < 0 :
	#	AUX_CO01END071RO = 0
	#else :
	#	AUX_CO01END071RO = data['CO01END071RO']

	if 0 <= data['CO01END071RO'] < 34.96 :
		AA_S5_CO01END071RO_DINTD01 = 1
	else : 
		AA_S5_CO01END071RO_DINTD01 = 0

	if 34.96 <= data['CO01END071RO'] < 63.27 :
		AA_S5_CO01END071RO_DINTD02 = 1
	else :
		AA_S5_CO01END071RO_DINTD02 = 0


	if 86.95 <= data['CO01END071RO'] : 
		AA_S5_CO01END071RO_DINTD04 = 1
	else :
		AA_S5_CO01END071RO_DINTD04 = 0

	#if data['CO01EXP001RO'] < 0 :
	#	AUX_CO01EXP001RO = 0
	#else :
	#	AUX_CO01EXP001RO = data['CO01EXP001RO']

	if 0 <= data['CO01EXP001RO'] < 30.38 :
		AA_S5_CO01EXP001RO_DINTD01 = 1
	else : 
		AA_S5_CO01EXP001RO_DINTD01 = 0 

	#if data['CO01END070RO'] < 0 :
	#	AUX_CO01END070RO = 0
	#else :
	#	AUX_CO01END070RO = data['CO01END070RO']

	if 0 <= data['CO01END070RO'] <0.34 :
		AA_S5_CO01END070RO_DINTD01 = 1 
	else : 
		AA_S5_CO01END070RO_DINTD01 = 0 

	if 1.72 <= data['CO01END070RO'] <5.05:
		AA_S5_CO01END070RO_DINTD03 = 1
	else :
		AA_S5_CO01END070RO_DINTD03 = 0

	if 5.05 <= data['CO01END070RO']:
		AA_S5_CO01END070RO_DINTD04 = 1
	else :
		AA_S5_CO01END070RO_DINTD04 = 0

	#if data['CO01EXP001AH'] < 0 :
	#	AUX_CO01EXP001AH = 0
	#else :
	#	AUX_CO01EXP001AH = data['CO01EXP001AH']

	if 141.68 <= data['CO01EXP001AH'] : 
		AA_S5_CO01EXP001AH_DINTD04 = 1
	else :
		AA_S5_CO01EXP001AH_DINTD04 = 0

	#if data['CO01ACP007CT'] < 0 :
	#	AUX_CO01ACP007CT = 0
	#else :
	#	AUX_CO01ACP007CT = data['CO01ACP007CT']

	if 1 <= data['CO01ACP007CT']:
		AA_S5_CO01ACP007CT_DINTD02 = 1
	else :
		AA_S5_CO01ACP007CT_DINTD02 = 0

	#if data['CO01MOR009CC'] < 0 :
	#	AUX_CO01MOR009CC = 0
	#else :
	#	AUX_CO01MOR009CC = data['CO01MOR009CC']

	if 0 <= data['CO01MOR009CC'] < 1:
		AA_S5_CO01MOR009CC_DINTD01 = 1
	else: 
		AA_S5_CO01MOR009CC_DINTD01 = 0

	#if data['CO01MOR054IN'] < 0 :
	#	AUX_CO01MOR054IN = 0
	#else :
	#	AUX_CO01MOR054IN = data['CO01MOR054IN']

	if 0 <= data['CO01MOR054IN'] < 1 :
		AA_S5_CO01MOR054IN_DINTD01 = 1
	else :
		AA_S5_CO01MOR054IN_DINTD01 = 0
 
	if 1 <=data['CO01MOR054IN'] : 
		AA_S5_CO01MOR054IN_DINTD02 = 1
	else:
		AA_S5_CO01MOR054IN_DINTD02 = 0

	#if data['CO01INQ025'] < 0 :
	#	AUX_CO01INQ025 = 0
	#else :
	#	AUX_CO01INQ025 = data['CO01INQ025']

	if 2 <= data['CO01INQ025'] :
		AA_S5_CO01INQ025_DINTD03 = 1
	else :
		AA_S5_CO01INQ025_DINTD03 = 0

	suma = 2.01479519671931 +    \
          (AA_S5_PRQALDIA_DINT        * 0.893191407686053) +    \
          (AA_S5_CO02NUM042CB_DINT    * -0.00758477829861706) + \
          (AA_S5_CO02EXP001TO_DINT    * 0.00221497883005786) +  \
          (AA_S5_CO02NUM005TO_DINT    * 0.0067766308467504) +   \
          (AA_S5_RECMORA001_DINTD01   * -0.115744838307031) +   \
          (AA_S5_CO02END015CB_DINTD02 * -0.732429617190354) +   \
          (AA_S5_RECMORA030_DINTD01   * -0.278658181610554) +   \
          (AA_S5_CO01END089RO_DINTD01 * 0.366446340578242) +    \
          (AA_S5_CO01END089RO_DINTD02 * 0.214380069956298) +    \
          (AA_S5_CO01END089RO_DINTD04 * -0.184556464505395) +   \
          (AA_S5_CO01MOR046RO_DINTD01 * 0.304925995566543) +    \
          (AA_S5_MMAXHIS_DINTD03      * -0.469416677316358) +   \
          (AA_S5_CO01END017RO_DINTD02 * -0.373306734974282) +   \
          (AA_S5_CO01END071RO_DINTD01 * 0.384801414983065) +    \
          (AA_S5_CO01END071RO_DINTD02 * 0.21805071915204) +     \
          (AA_S5_CO01END071RO_DINTD04 * -0.255969322795542) +   \
          (AA_S5_CO01EXP001RO_DINTD01 * -0.421112288800988) +   \
          (AA_S5_CO01END070RO_DINTD01 * -0.0736922281823448) +  \
          (AA_S5_CO01END070RO_DINTD03 * 0.156574172531047) +    \
          (AA_S5_CO01END070RO_DINTD04 * 0.278252320499173) +    \
          (AA_S5_CO01EXP001AH_DINTD04 * 0.103284773118345) +    \
          (AA_S5_CO01ACP007CT_DINTD02 * -0.565198914412701) +   \
          (AA_S5_CO01MOR009CC_DINTD01 * 0.0750417753252263) +   \
          (AA_S5_CO01MOR054IN_DINTD01 * -0.142288835466278) +   \
          (AA_S5_CO01MOR054IN_DINTD02 * 0.185335058688169) +    \
          (AA_S5_CO01INQ025_DINTD03   * -0.469938039519278)

	AciertaA = int (1000 / (1 + np.exp(-suma)))
	AciertaADef = int (400.000000000000 + 110.321693765613 * suma)

	if AciertaADef <= 150:
		AciertaADef=150
	if AciertaADef >= 999:
		AciertaADef=999

	reporte={}
	#reporte['TIPOID']=int(data['TIPOID'])
	#reporte['CONUMIDE']=int(data['CONUMIDE'])
	reporte['scoreSegment']=5
	#reporte['AciertaA']=AciertaA
	reporte['scoreValue']=AciertaADef
	#reporte['PRQALDIA']=PRQALDIA
	#reporte['RECMORA030']=RECMORA030
	#reporte['MMAXHIS']=MMAXHIS
	#reporte['RECMORA001']=RECMORA001
	#reporte['AA_S5_PRQALDIA_DINT']=int(AA_S5_PRQALDIA_DINT)
	#reporte['AA_S5_CO02NUM042CB_DINT']=int(AA_S5_CO02NUM042CB_DINT)
	#reporte['AA_S5_CO02EXP001TO_DINT']=int(AA_S5_CO02EXP001TO_DINT)
	#reporte['AA_S5_CO02NUM005TO_DINT']=int(AA_S5_CO02NUM005TO_DINT)
	#reporte['AA_S5_RECMORA001_DINTD01']=int(AA_S5_RECMORA001_DINTD01)
	#reporte['AA_S5_CO02END015CB_DINTD02']=int(AA_S5_CO02END015CB_DINTD02)
	#reporte['AA_S5_RECMORA030_DINTD01']=int(AA_S5_RECMORA030_DINTD01)
	#reporte['AA_S5_CO01END089RO_DINTD01']=int(AA_S5_CO01END089RO_DINTD01)
	#reporte['AA_S5_CO01END089RO_DINTD02']=int(AA_S5_CO01END089RO_DINTD02)
	#reporte['AA_S5_CO01END089RO_DINTD04']=int(AA_S5_CO01END089RO_DINTD04)
	#reporte['AA_S5_CO01MOR046RO_DINTD01']=int(AA_S5_CO01MOR046RO_DINTD01)
	#reporte['AA_S5_MMAXHIS_DINTD03']=int(AA_S5_MMAXHIS_DINTD03)
	#reporte['AA_S5_CO01END017RO_DINTD02']=int(AA_S5_CO01END017RO_DINTD02)
	#reporte['AA_S5_CO01END071RO_DINTD01']=int(AA_S5_CO01END071RO_DINTD01)
	#reporte['AA_S5_CO01END071RO_DINTD02']=int(AA_S5_CO01END071RO_DINTD02)
	#reporte['AA_S5_CO01END071RO_DINTD04']=int(AA_S5_CO01END071RO_DINTD04)
	#reporte['AA_S5_CO01EXP001RO_DINTD01']=int(AA_S5_CO01EXP001RO_DINTD01)
	#reporte['AA_S5_CO01END070RO_DINTD01']=int(AA_S5_CO01END070RO_DINTD01)
	#reporte['AA_S5_CO01END070RO_DINTD03']=int(AA_S5_CO01END070RO_DINTD03)
	#reporte['AA_S5_CO01END070RO_DINTD04']=int(AA_S5_CO01END070RO_DINTD04)
	#reporte['AA_S5_CO01EXP001AH_DINTD04']=int(AA_S5_CO01EXP001AH_DINTD04)
	#reporte['AA_S5_CO01ACP007CT_DINTD02']=int(AA_S5_CO01ACP007CT_DINTD02)
	#reporte['AA_S5_CO01MOR009CC_DINTD01']=int(AA_S5_CO01MOR009CC_DINTD01)
	#reporte['AA_S5_CO01MOR054IN_DINTD01']=int(AA_S5_CO01MOR054IN_DINTD01)
	#reporte['AA_S5_CO01MOR054IN_DINTD02']=int(AA_S5_CO01MOR054IN_DINTD02)
	#reporte['AA_S5_CO01INQ025_DINTD03']=int(AA_S5_CO01INQ025_DINTD03)
	#print("segmento5")
	return reporte

#--------------------------------------------------------------------------------------------------------------#
#  FUNCION segmento6 : REALIZA EL CALCULO DEL score PARA POBLACION DEL SEGMENTO 6   
#--------------------------------------------------------------------------------------------------------------#

def segmento6(data,PRQALDIA,RECMORA001VSA,RECMORA030,MMAXHIS):
	#/* Continuas: Valores especiales (imputa) */ 
	AA_S6_CO02NUM042CB_DHVT=data['CO02NUM042CB']
	if AA_S6_CO02NUM042CB_DHVT > 100:
		AA_S6_CO02NUM042CB_DHVT=100

	AA_S6_PRQALDIA_DHVT=PRQALDIA
	if AA_S6_PRQALDIA_DHVT > 1:
		AA_S6_PRQALDIA_DHVT=1
                               
	AA_S6_CO02EXP009TO_DHVT=data['CO02EXP009TO']
	if AA_S6_CO02EXP009TO_DHVT > 100:
		AA_S6_CO02EXP009TO_DHVT=100
	elif data['CO02EXP009TO']<0:
		AA_S6_CO02EXP009TO_DHVT=0

	if 0 <= RECMORA001VSA < 6:
		AA_S6_RECMORA001VSA_DHVTD01=1
	else:
		AA_S6_RECMORA001VSA_DHVTD01=0
               
	if 0 <= data['CO01END071RO'] < 18.86:
		AA_S6_CO01END071RO_DHVTD01=1
	else:
		AA_S6_CO01END071RO_DHVTD01=0

	if 18.86 <= data['CO01END071RO'] < 46.6:
		AA_S6_CO01END071RO_DHVTD02=1
	else:
		AA_S6_CO01END071RO_DHVTD02=0

	if 76.49 <= data['CO01END071RO']:
		AA_S6_CO01END071RO_DHVTD04=1
	else:
		AA_S6_CO01END071RO_DHVTD04=0

	if 0 <= data['CO01END089RO'] < 21.45:
		AA_S6_CO01END089RO_DHVTD01=1
	else:
		AA_S6_CO01END089RO_DHVTD01=0
                       
	if 21.45 <= data['CO01END089RO'] < 48.61:
		AA_S6_CO01END089RO_DHVTD02=1
	else:
		AA_S6_CO01END089RO_DHVTD02=0

	if 0 <= RECMORA030 < 7:
		AA_S6_RECMORA030_DHVTD01=1
	else:
		AA_S6_RECMORA030_DHVTD01=0

	if 7 <= RECMORA030 < 16:
		AA_S6_RECMORA030_DHVTD02=1
	else:
		AA_S6_RECMORA030_DHVTD02=0     

	if 0 <= MMAXHIS < 2:
		AA_S6_MMAXHIS_DHVTD01=1
	else:
		AA_S6_MMAXHIS_DHVTD01=0

	if 2.61 <= data['CO01END015RO'] < 6.21:
		AA_S6_CO01END015RO_DHVTD03=1
	else:
		AA_S6_CO01END015RO_DHVTD03=0

	if 6.21 <= data['CO01END015RO']:
		AA_S6_CO01END015RO_DHVTD04=1
	else:
		AA_S6_CO01END015RO_DHVTD04=0

	if 3 <= data['CO01INQ017TO']:
		AA_S6_CO01INQ017_DHVTD02=1
	else:
		AA_S6_CO01INQ017_DHVTD02=0

	if 0 <= data['CO01MOR009CC'] < 1:
		AA_S6_CO01MOR009CC_DHVTD01=1
	else:
		AA_S6_CO01MOR009CC_DHVTD01=0

	if 0 <= data['CO01MOR067RO'] < 1:
		AA_S6_CO01MOR067RO_DHVTD01=1
	else:
		AA_S6_CO01MOR067RO_DHVTD01=0

	suma = 2.87262241140757 + \
          (AA_S6_CO02NUM042CB_DHVT     * -0.0100532998584682) + \
          (AA_S6_PRQALDIA_DHVT         * 1.04053795499282) +    \
          (AA_S6_CO02EXP009TO_DHVT     * -0.00920851495874948) +\
          (AA_S6_RECMORA001VSA_DHVTD01 * -0.278925633871566) +  \
          (AA_S6_CO01END071RO_DHVTD01  * 0.432200195477845) +   \
          (AA_S6_CO01END071RO_DHVTD02  * 0.326071715561251) +   \
          (AA_S6_CO01END071RO_DHVTD04  * -0.561449436152477) +  \
          (AA_S6_CO01END089RO_DHVTD01  * 0.433444395820514) +   \
          (AA_S6_CO01END089RO_DHVTD02  * 0.340613200216082) +   \
          (AA_S6_RECMORA030_DHVTD01    * -0.567695118779128) +  \
          (AA_S6_RECMORA030_DHVTD02    * -0.331022905167224) +  \
          (AA_S6_MMAXHIS_DHVTD01       * 0.777428452533831) +   \
          (AA_S6_CO01END015RO_DHVTD03  * 0.24277708011573) +    \
          (AA_S6_CO01END015RO_DHVTD04  * 0.477252369773504) +   \
          (AA_S6_CO01INQ017_DHVTD02    * -0.32993658699919) +   \
          (AA_S6_CO01MOR009CC_DHVTD01  * 0.0750461559435727) +  \
          (AA_S6_CO01MOR067RO_DHVTD01  * 0.164475831866231)

	AciertaA = int (1000 / (1 + np.exp(-suma)))
	AciertaADef = int (400.000000000000 + 110.321693765613 * suma)

	if AciertaADef <= 150:
		AciertaADef=150
	if AciertaADef >= 999:
		AciertaADef=999

	reporte={}
	#reporte['TIPOID']=int(data['TIPOID'])
	#reporte['CONUMIDE']=int(data['CONUMIDE'])
	reporte['scoreSegment']=6
	#reporte['AciertaA']=AciertaA
	reporte['scoreValue']=AciertaADef
	#reporte['PRQALDIA']=PRQALDIA
	#reporte['RECMORA001VSA']=RECMORA001VSA
	#reporte['RECMORA030']=RECMORA030
	#reporte['MMAXHIS']=MMAXHIS
	#reporte['AA_S6_CO02NUM042CB_DHVT']=AA_S6_CO02NUM042CB_DHVT    
	#reporte['AA_S6_PRQALDIA_DHVT']=AA_S6_PRQALDIA_DHVT        
	#reporte['AA_S6_CO02EXP009TO_DHVT']=AA_S6_CO02EXP009TO_DHVT    
	#reporte['AA_S6_RECMORA001VSA_DHVTD01']=AA_S6_RECMORA001VSA_DHVTD01
	#reporte['AA_S6_CO01END071RO_DHVTD01']=AA_S6_CO01END071RO_DHVTD01 
	#reporte['AA_S6_CO01END071RO_DHVTD02']=AA_S6_CO01END071RO_DHVTD02 
	#reporte['AA_S6_CO01END071RO_DHVTD04']=AA_S6_CO01END071RO_DHVTD04 
	#reporte['AA_S6_CO01END089RO_DHVTD01']=AA_S6_CO01END089RO_DHVTD01 
	#reporte['AA_S6_CO01END089RO_DHVTD02']=AA_S6_CO01END089RO_DHVTD02 
	#reporte['AA_S6_RECMORA030_DHVTD01']=AA_S6_RECMORA030_DHVTD01   
	#reporte['AA_S6_RECMORA030_DHVTD02']=AA_S6_RECMORA030_DHVTD02   
	#reporte['AA_S6_MMAXHIS_DHVTD01']=AA_S6_MMAXHIS_DHVTD01      
	#reporte['AA_S6_CO01END015RO_DHVTD03']=AA_S6_CO01END015RO_DHVTD03 
	#reporte['AA_S6_CO01END015RO_DHVTD04']=AA_S6_CO01END015RO_DHVTD04 
	#reporte['AA_S6_CO01INQ017_DHVTD02']=AA_S6_CO01INQ017_DHVTD02   
	#reporte['AA_S6_CO01MOR009CC_DHVTD01']=AA_S6_CO01MOR009CC_DHVTD01 
	#reporte['AA_S6_CO01MOR067RO_DHVTD01']=AA_S6_CO01MOR067RO_DHVTD01 
	#print("segmento6")
	return reporte

#--------------------------------------------------------------------------------------------------------------#
#  FUNCION segmento7 : REALIZA EL CALCULO DEL score PARA POBLACION DEL SEGMENTO 7   
#--------------------------------------------------------------------------------------------------------------#

def segmento7(data,RECMORA001VSA,MMAXHIS,PROQTOTAB):
	#/* Continuas: Valores especiales (imputa) */
	if data['CO00DEM003']<0:
		AA_S7_CO00DEM003_DCPN=-1  
	else:
		AA_S7_CO00DEM003_DCPN=data['CO00DEM003']
                                                   
	if AA_S7_CO00DEM003_DCPN < 18 or AA_S7_CO00DEM003_DCPN == -1:
		AA_S7_CO00DEM003_DCPN=18

	if AA_S7_CO00DEM003_DCPN > 66:
		AA_S7_CO00DEM003_DCPN=66

	if 0 <= RECMORA001VSA and RECMORA001VSA < 3:
		AA_S7_RECMORA001VSA_DCPND02=1
	else:
		AA_S7_RECMORA001VSA_DCPND02=0

	if 4 <= MMAXHIS:
		AA_S7_MMAXHIS_DCPND04=1
	else:
		AA_S7_MMAXHIS_DCPND04=0

	if 0 <= MMAXHIS and MMAXHIS < 1:
		AA_S7_MMAXHIS_DCPND02=1
	else:
		AA_S7_MMAXHIS_DCPND02=0

	if data['CO01MOR071RO']<0:
		AA_S7_CO01MOR071RO_DCPND02=0 
	elif 0 <= data['CO01MOR071RO'] and data['CO01MOR071RO'] < 1:
		AA_S7_CO01MOR071RO_DCPND02=1
	else:
		AA_S7_CO01MOR071RO_DCPND02=0

	if data['CO02END015CB']<0:
		AA_S7_CO02END015CB_DCPND03=0
	elif 0.87 <= data['CO02END015CB']:
		AA_S7_CO02END015CB_DCPND03=1
	else:
		AA_S7_CO02END015CB_DCPND03=0

	if data['CO01MOR065CC']<0:
		AA_S7_CO01MOR065CC_DCPND02=0
	elif 0 <= data['CO01MOR065CC'] and data['CO01MOR065CC'] < 1:
		AA_S7_CO01MOR065CC_DCPND02=1
	else:
		AA_S7_CO01MOR065CC_DCPND02=0

	if data['CO02END016CB']<0:
		AA_S7_CO02END016CB_DCPND02=0
	elif 0 <= data['CO02END016CB'] and data['CO02END016CB'] < 0.88:
		AA_S7_CO02END016CB_DCPND02=1
	else:
		AA_S7_CO02END016CB_DCPND02=0

	if data['CO01MOR086RO']<0:
		AA_S7_CO01MOR086RO_DCPND03=0
	elif 100 <= data['CO01MOR086RO']:
		AA_S7_CO01MOR086RO_DCPND03=1
	else: 
		AA_S7_CO01MOR086RO_DCPND03=0

	if data['CO01MOR009IN']<0:
		AA_S7_CO01MOR009IN_DCPND03=0
	elif 1 <= data['CO01MOR009IN']:
		AA_S7_CO01MOR009IN_DCPND03=1
	else:
		AA_S7_CO01MOR009IN_DCPND03=0

	if data['CO01MOR054RO']<0:
		AA_S7_CO01MOR054RO_DCPND03=0
	elif 1 <= data['CO01MOR054RO']:
		AA_S7_CO01MOR054RO_DCPND03=1
	else:
		AA_S7_CO01MOR054RO_DCPND03=0

	if data['CO01MOR075CC']<0:
		AA_S7_CO01MOR075CC_DCPND03=0
	elif 999 <= data['CO01MOR075CC']:
		AA_S7_CO01MOR075CC_DCPND03=1
	else:
		AA_S7_CO01MOR075CC_DCPND03=0

	if data['CO01END022CC']<0:
		AA_S7_CO01END022CC_DCPND02=0
	elif 0 <= data['CO01END022CC'] and data['CO01END022CC'] < 0.05:
		AA_S7_CO01END022CC_DCPND02=1
	else: 
		AA_S7_CO01END022CC_DCPND02=0

	if data['CO01MOR033CC']<0:
		AA_S7_CO01MOR033CC_DCPND02=0
	elif 0 <= data['CO01MOR033CC'] and data['CO01MOR033CC'] < 1:
		AA_S7_CO01MOR033CC_DCPND02=1
	else:
		AA_S7_CO01MOR033CC_DCPND02=0

	if data['CO01INQ017TO']<0:
		AA_S7_CO01INQ017_DCPND04=0
	elif 3 <= data['CO01INQ017TO']:
		AA_S7_CO01INQ017_DCPND04=1
	else:
		AA_S7_CO01INQ017_DCPND04=0

	if 0.63 <= PROQTOTAB:
		AA_S7_PROQTOTAB_DCPND04=1
	else:
		AA_S7_PROQTOTAB_DCPND04=0

	if data['CO01END076RO']<0:
		AA_S7_CO01END076RO_DCPND04=0
	elif 92.95 <= data['CO01END076RO']:  
		AA_S7_CO01END076RO_DCPND04=1
	else:
		AA_S7_CO01END076RO_DCPND04=0

	if data['CO01END093RO'] < 11.87:
		AA_S7_CO01END093RO_DCPND01=1
	else:
		AA_S7_CO01END093RO_DCPND01=0

	if data['CO01MOR009OT']<0:
		AA_S7_CO01MOR009OT_DCPND03=0
	elif 3 <= data['CO01MOR009OT']:
		AA_S7_CO01MOR009OT_DCPND03=1
	else:
		AA_S7_CO01MOR009OT_DCPND03=0

	if data['CO01INQ026CC']<0:
		AA_S7_CO01INQ026_DCPND03=0
	elif 1 <= data['CO01INQ026CC']:
		AA_S7_CO01INQ026_DCPND03=1
	else:
		AA_S7_CO01INQ026_DCPND03=0

	if data['CO01MOR092IN']<0:
		AA_S7_CO01MOR092IN_DCPND04=0
	elif 100 <= data['CO01MOR092IN']:
		AA_S7_CO01MOR092IN_DCPND04=1
	else:
		AA_S7_CO01MOR092IN_DCPND04=0

	if data['CO02NUM043CB']<0:
		AA_S7_CO02NUM043CB_DCPND04=0
	elif 71.43 <= data['CO02NUM043CB']:  
		AA_S7_CO02NUM043CB_DCPND04=1
	else:
		AA_S7_CO02NUM043CB_DCPND04=0

	if data['CO02NUM041TO']<0:
		AA_S7_CO02NUM041TO_DCPND03=0
	elif 1 <= data['CO02NUM041TO']:
		AA_S7_CO02NUM041TO_DCPND03=1
	else:
		AA_S7_CO02NUM041TO_DCPND03=0

	if data['CO01MOR058OT']<0:
		AA_S7_CO01MOR058OT_DCPND02=0
	elif 0 <= data['CO01MOR058OT'] and data['CO01MOR058OT'] < 1:
		AA_S7_CO01MOR058OT_DCPND02=1
	else:
		AA_S7_CO01MOR058OT_DCPND02=0

	#-----------------------------------------------------------------
	suma = 2.468070525737 + \
		(0.0159666291997757 *  AA_S7_CO00DEM003_DCPN ) +\
		(-0.370170716546081 *  AA_S7_RECMORA001VSA_DCPND02 ) +\
		(-0.21159215046405  *  AA_S7_MMAXHIS_DCPND04 ) +\
		(0.254747117912453  *  AA_S7_MMAXHIS_DCPND02 ) +\
		(0.189482278170605  *  AA_S7_CO01MOR071RO_DCPND02  ) +\
		(-0.210572395661856 *  AA_S7_CO02END015CB_DCPND03  ) +\
		(0.181709408698641  *  AA_S7_CO01MOR065CC_DCPND02  ) +\
		(0.10890145875865*  AA_S7_CO02END016CB_DCPND02  ) +\
		(0.203707650772108  *  AA_S7_CO01MOR086RO_DCPND03  ) +\
		(-0.216853347568927 *  AA_S7_CO01MOR009IN_DCPND03  ) +\
		(0.164397815449642  *  AA_S7_CO01MOR054RO_DCPND03  ) +\
		(0.146244572739024  *  AA_S7_CO01MOR075CC_DCPND03  ) +\
		(0.150648397704208  *  AA_S7_CO01END022CC_DCPND02  ) +\
		(-0.18194367613691  *  AA_S7_CO01MOR033CC_DCPND02  ) +\
		(-0.428350015900003 *  AA_S7_CO01INQ017_DCPND04) +\
		(-0.252345801276706 *  AA_S7_PROQTOTAB_DCPND04 ) +\
		(-0.343556651423649 *  AA_S7_CO01END076RO_DCPND04  ) +\
		(-0.147736420508853 *  AA_S7_CO01END093RO_DCPND01  ) +\
		(-0.134936242409943 *  AA_S7_CO01MOR009OT_DCPND03  ) +\
		(-0.177185743082333 *  AA_S7_CO01INQ026_DCPND03) +\
		(0.237580988250664  *  AA_S7_CO01MOR092IN_DCPND04  ) +\
		(0.155216843761023  *  AA_S7_CO02NUM043CB_DCPND04  ) +\
		(-0.0781482889509479 * AA_S7_CO02NUM041TO_DCPND03 ) + \
		(0.0860439512553454 *  AA_S7_CO01MOR058OT_DCPND02  )
	AciertaA = int (1000 / (1 + np.exp(-suma)))
	AciertaADef = int (400.000000000000 + 110.321693765613 * suma)

	if AciertaADef <= 150:
		AciertaADef=150
	if AciertaADef >= 999:
		AciertaADef=999

	reporte={}
	#reporte['TIPOID']=int(data['TIPOID'])
	#reporte['CONUMIDE']=int(data['CONUMIDE'])
	reporte['scoreSegment']=7
	#reporte['AciertaA']=AciertaA
	reporte['scoreValue']=AciertaADef
	#reporte['RECMORA001VSA']=RECMORA001VSA
	#reporte['MMAXHIS']=MMAXHIS
	#reporte['PROQTOTAB']=PROQTOTAB
	#reporte['AA_S7_CO00DEM003_DCPN']=int(AA_S7_CO00DEM003_DCPN)
	#reporte['AA_S7_RECMORA001VSA_DCPND02']=int(AA_S7_RECMORA001VSA_DCPND02)
	#reporte['AA_S7_MMAXHIS_DCPND04']=int(AA_S7_MMAXHIS_DCPND04)
	#reporte['AA_S7_MMAXHIS_DCPND02']=int(AA_S7_MMAXHIS_DCPND02)
	#reporte['AA_S7_CO01MOR071RO_DCPND02']=int(AA_S7_CO01MOR071RO_DCPND02)
	#reporte['AA_S7_CO02END015CB_DCPND03']=int(AA_S7_CO02END015CB_DCPND03)
	#reporte['AA_S7_CO01MOR065CC_DCPND02']=int(AA_S7_CO01MOR065CC_DCPND02)
	#reporte['AA_S7_CO02END016CB_DCPND02']=int(AA_S7_CO02END016CB_DCPND02)
	#reporte['AA_S7_CO01MOR086RO_DCPND03']=int(AA_S7_CO01MOR086RO_DCPND03)
	#reporte['AA_S7_CO01MOR009IN_DCPND03']=int(AA_S7_CO01MOR009IN_DCPND03)
	#reporte['AA_S7_CO01MOR054RO_DCPND03']=int(AA_S7_CO01MOR054RO_DCPND03)
	#reporte['AA_S7_CO01MOR075CC_DCPND03']=int(AA_S7_CO01MOR075CC_DCPND03)
	#reporte['AA_S7_CO01END022CC_DCPND02']=int(AA_S7_CO01END022CC_DCPND02)
	#reporte['AA_S7_CO01MOR033CC_DCPND02']=int(AA_S7_CO01MOR033CC_DCPND02)
	#reporte['AA_S7_CO01INQ017_DCPND04']=int(AA_S7_CO01INQ017_DCPND04)
	#reporte['AA_S7_PROQTOTAB_DCPND04']=int(AA_S7_PROQTOTAB_DCPND04)
	#reporte['AA_S7_CO01END076RO_DCPND04']=int(AA_S7_CO01END076RO_DCPND04)
	#reporte['AA_S7_CO01END093RO_DCPND01']=int(AA_S7_CO01END093RO_DCPND01)
	#reporte['AA_S7_CO01MOR009OT_DCPND03']=int(AA_S7_CO01MOR009OT_DCPND03)
	#reporte['AA_S7_CO01INQ026_DCPND03']=int(AA_S7_CO01INQ026_DCPND03)
	#reporte['AA_S7_CO01MOR092IN_DCPND04']=int(AA_S7_CO01MOR092IN_DCPND04)
	#reporte['AA_S7_CO02NUM043CB_DCPND04']=int(AA_S7_CO02NUM043CB_DCPND04)
	#reporte['AA_S7_CO02NUM041TO_DCPND03']=int(AA_S7_CO02NUM041TO_DCPND03)
	#reporte['AA_S7_CO01MOR058OT_DCPND02']=int(AA_S7_CO01MOR058OT_DCPND02)
	#print("segmento7")
	return reporte

#--------------------------------------------------------------------------------------------------------------#
#  FUNCION segmento8 : REALIZA EL CALCULO DEL score PARA POBLACION DEL SEGMENTO 8   
#--------------------------------------------------------------------------------------------------------------#

def segmento8(data,PRQALDIA,EVER06036P,EVER03024P,EVER12036E,RECMORA001):
	#/* Continuas: Valores especiales (imputa) */ 
	#*--------------------------CLARA---------------------*
	AA_S8_PRQALDIA_DCPE = PRQALDIA
	if AA_S8_PRQALDIA_DCPE > 1:              
		AA_S8_PRQALDIA_DCPE = 1

	AA_S8_CO02NUM042CB_DCPE=data['CO02NUM042CB']
	if AA_S8_CO02NUM042CB_DCPE > 75:             
		AA_S8_CO02NUM042CB_DCPE=75

	AA_S8_CO02EXP006TO_DCPE=data['CO02EXP006TO']
	if data['CO02EXP006TO']<0:
		AA_S8_CO02EXP006TO_DCPE=0
	elif AA_S8_CO02EXP006TO_DCPE > 91:
		AA_S8_CO02EXP006TO_DCPE=91

	if 0 <= RECMORA001 and RECMORA001 < 4.87:
		AA_S8_RECMORA001_DCPED02=1        
	else:
		AA_S8_RECMORA001_DCPED02=0

	if 0 <= data['CO01MOR069IN'] < 0.97:
		AA_S8_CO01MOR069IN_DCPED02=1      
	else:
		AA_S8_CO01MOR069IN_DCPED02=0     

	if 0 <= EVER06036P and EVER06036P < 1:
		AA_S8_EVER06036P_DCPED02=1  
	else:
		AA_S8_EVER06036P_DCPED02=0

	if data['CO02END015CB']<0:
		AA_S8_CO02END015CB_DCPED02=0
	elif 0 <= data['CO02END015CB'] and data['CO02END015CB'] < 0.38:
		AA_S8_CO02END015CB_DCPED02=1
	else:
		AA_S8_CO02END015CB_DCPED02=0

	if data['CO01MOR009IN']<0:
		AA_S8_CO01MOR009IN_DCPED03=0
	elif 0.87 <= data['CO01MOR009IN']:
		AA_S8_CO01MOR009IN_DCPED03=1
	else:
		AA_S8_CO01MOR009IN_DCPED03=0                               

	if 0 <= EVER03024P and EVER03024P < 1.9:
		AA_S8_EVER03024P_DCPED02=1
	else:
		AA_S8_EVER03024P_DCPED02=0

	if 0 <= EVER12036E and EVER12036E < 0.28:
		AA_S8_EVER12036P_DCPED02=1
	else:
		AA_S8_EVER12036P_DCPED02=0

	if data['CO01MOR086RO']<0:
		AA_S8_CO01MOR086RO_DCPED03=0
	elif 100 <= data['CO01MOR086RO']:
		AA_S8_CO01MOR086RO_DCPED03=1
	else:
		AA_S8_CO01MOR086RO_DCPED03=0                              

	if 0 <= data['CO01MOR069CC'] < 1:
		AA_S8_CO01MOR069CC_DCPED02=1
	else:
		AA_S8_CO01MOR069CC_DCPED02=0
 
	if data['CO01MOR061IN']<0:
		AA_S8_CO01MOR061IN_DCPED03=0
	elif 1 <= data['CO01MOR061IN']:
		AA_S8_CO01MOR061IN_DCPED03=1
	else:
		AA_S8_CO01MOR061IN_DCPED03=0  

	if data['CO01MOR040VE']<0:
		AA_S8_CO01MOR040VE_DCPED02=0          
	elif 0 <= data['CO01MOR040VE'] and data['CO01MOR040VE'] < 1:
		AA_S8_CO01MOR040VE_DCPED02=1
	else:
		AA_S8_CO01MOR040VE_DCPED02=0

	if data['CO01MOR033IN']<0:
		AA_S8_CO01MOR033IN_DCPED01=0
	elif 0 <= data['CO01MOR033IN'] and data['CO01MOR033IN'] < 1:
		AA_S8_CO01MOR033IN_DCPED01=1
	else:
		AA_S8_CO01MOR033IN_DCPED01=0

	if data['CO01END071RO']<0:
		AA_S8_CO01END071RO_DCPED01=0 
	elif 0 <= data['CO01END071RO'] and data['CO01END071RO'] < 29.86:
		AA_S8_CO01END071RO_DCPED01=1
	else:
		AA_S8_CO01END071RO_DCPED01=0         

	if data['CO01MOR080VE']<0:
		AA_S8_CO01MOR080VE_DCPED01=0
	elif 100 <= data['CO01MOR080VE']:
		AA_S8_CO01MOR080VE_DCPED01=1
	else:
		AA_S8_CO01MOR080VE_DCPED01=0

	if data['CO01MOR021IN']<0:
		AA_S8_CO01MOR021IN_DCPED01=0
	elif 0 <= data['CO01MOR021IN'] and data['CO01MOR021IN'] < 1:
		AA_S8_CO01MOR021IN_DCPED01=1
	else:
		AA_S8_CO01MOR021IN_DCPED01=0

	if data['CO01NUM005RO']<0:
		AA_S8_CO01NUM005RO_DCPED01=0
	elif 0 <= data['CO01NUM005RO'] and data['CO01NUM005RO'] < 1:
		AA_S8_CO01NUM005RO_DCPED01=1
	else:
		AA_S8_CO01NUM005RO_DCPED01=0

	if data['CO01END060RO'] < 0.47:
		AA_S8_CO01END060RO_DCPED01=1
	else:
		AA_S8_CO01END060RO_DCPED01=0

	suma =            3.279928225 + \
	   (AA_S8_PRQALDIA_DCPE        * 0.619968819336058) + \
	   (AA_S8_CO02NUM042CB_DCPE    * -0.0127841273060512) + \
	   (AA_S8_CO02EXP006TO_DCPE    * 0.0132739108864092) + \
	   (AA_S8_RECMORA001_DCPED02   * -0.585438455785895) + \
	   (AA_S8_CO01MOR069IN_DCPED02 * 0.340602407267763) +  \
	   (AA_S8_EVER06036P_DCPED02   * 0.24884293819532) +   \
	   (AA_S8_CO02END015CB_DCPED02 * 0.314286700986998) +  \
	   (AA_S8_CO01MOR009IN_DCPED03 * -0.394899834049106) + \
	   (AA_S8_EVER03024P_DCPED02   * 0.125092880989948) +  \
	   (AA_S8_EVER12036P_DCPED02   * 0.174052008622815) +  \
	   (AA_S8_CO01MOR086RO_DCPED03 * 0.214112986442259) +  \
	   (AA_S8_CO01MOR069CC_DCPED02 * 0.217934788686414) +  \
	   (AA_S8_CO01MOR061IN_DCPED03 * 0.281380152976834) +  \
	   (AA_S8_CO01MOR040VE_DCPED02 * -0.718221748903653) + \
	   (AA_S8_CO01MOR033IN_DCPED01 * -0.178898862690356) + \
	   (AA_S8_CO01END071RO_DCPED01 * 0.405903407976085) +  \
	   (AA_S8_CO01MOR080VE_DCPED01 * 0.68897624287928) +   \
	   (AA_S8_CO01MOR021IN_DCPED01 * -0.145416808617441) + \
	   (AA_S8_CO01NUM005RO_DCPED01 * -0.272296494469846) + \
	   (AA_S8_CO01END060RO_DCPED01 * -0.215343477621003)

	AciertaA = int (1000 / (1 + np.exp(-suma)))
	AciertaADef = int (400.000000000000 + 110.321693765613 * suma)

	if AciertaADef <= 150:
		AciertaADef=150
	if AciertaADef >= 999:
		AciertaADef=999

	reporte={}
	#reporte['TIPOID']=int(data['TIPOID'])
	#reporte['CONUMIDE']=int(data['CONUMIDE'])
	reporte['scoreSegment']=8
	#reporte['AciertaA']=AciertaA
	reporte['scoreValue']=AciertaADef
	#reporte['PRQALDIA']=PRQALDIA
	#reporte['EVER06036P']=EVER06036P
	#reporte['EVER03024P']=EVER03024P
	#reporte['EVER12036E']=EVER12036E
	#reporte['RECMORA001']=RECMORA001
	#reporte['AA_S8_PRQALDIA_DCPE']=int(AA_S8_PRQALDIA_DCPE)
	#reporte['AA_S8_CO02NUM042CB_DCPE']=int(AA_S8_CO02NUM042CB_DCPE)
	#reporte['AA_S8_CO02EXP006TO_DCPE']=int(AA_S8_CO02EXP006TO_DCPE)
	#reporte['AA_S8_RECMORA001_DCPED02']=int(AA_S8_RECMORA001_DCPED02)
	#reporte['AA_S8_CO01MOR069IN_DCPED02']=int(AA_S8_CO01MOR069IN_DCPED02)
	#reporte['AA_S8_EVER06036P_DCPED02']=int(AA_S8_EVER06036P_DCPED02)
	#reporte['AA_S8_CO02END015CB_DCPED02']=int(AA_S8_CO02END015CB_DCPED02)
	#reporte['AA_S8_CO01MOR009IN_DCPED03']=int(AA_S8_CO01MOR009IN_DCPED03)
	#reporte['AA_S8_EVER03024P_DCPED02']=int(AA_S8_EVER03024P_DCPED02)
	#reporte['AA_S8_EVER12036P_DCPED02']=int(AA_S8_EVER12036P_DCPED02)
	#reporte['AA_S8_CO01MOR086RO_DCPED03']=int(AA_S8_CO01MOR086RO_DCPED03)
	#reporte['AA_S8_CO01MOR069CC_DCPED02']=int(AA_S8_CO01MOR069CC_DCPED02)
	#reporte['AA_S8_CO01MOR061IN_DCPED03']=int(AA_S8_CO01MOR061IN_DCPED03)
	#reporte['AA_S8_CO01MOR040VE_DCPED02']=int(AA_S8_CO01MOR040VE_DCPED02)
	#reporte['AA_S8_CO01MOR033IN_DCPED01']=int(AA_S8_CO01MOR033IN_DCPED01)
	#reporte['AA_S8_CO01END071RO_DCPED01']=int(AA_S8_CO01END071RO_DCPED01)
	#reporte['AA_S8_CO01MOR080VE_DCPED01']=int(AA_S8_CO01MOR080VE_DCPED01)
	#reporte['AA_S8_CO01MOR021IN_DCPED01']=int(AA_S8_CO01MOR021IN_DCPED01)
	#reporte['AA_S8_CO01NUM005RO_DCPED01']=int(AA_S8_CO01NUM005RO_DCPED01)
	#reporte['AA_S8_CO01END060RO_DCPED01']=int(AA_S8_CO01END060RO_DCPED01)
#*--------------------------CLARA---------------------*
	#print("segmento8")
	return reporte

def segmento9(data,PRQALDIA,MOB60M,MOB12,RECMORA001VSA,MMAXHIS):
	
	if data['CO02EXP006TO'] < 0:
		CO02EXP006TO_DPU = 21
	else:
		CO02EXP006TO_DPU = data['CO02EXP006TO']

	PRQALDIA_DPU = PRQALDIA

	MOB60M_DPU = MOB60M

	if data['CO02NUM042CB'] < 0:
		CO02NUM042CB_DPU = 0
	else:
		CO02NUM042CB_DPU = data['CO02NUM042CB']

	if data['CO02EXP007TO'] < 0:
		CO02EXP007TO_DPU = 0
	else:
		CO02EXP007TO_DPU = data['CO02EXP007TO']

	MOB12_DPU = MOB12

	#/* Continuas: Acota */ 
	if CO02EXP006TO_DPU > 105:
		CO02EXP006TO_DPU = 105

	if PRQALDIA_DPU > 1:
		PRQALDIA_DPU = 1

	if MOB60M_DPU > 10:
		MOB60M_DPU = 10

	if CO02NUM042CB_DPU > 100:
		CO02NUM042CB_DPU = 100

	if CO02EXP007TO_DPU > 66.67:
		CO02EXP007TO_DPU = 66.67

	if MOB12_DPU > 7:
		MOB12_DPU = 7

	
	if 48 <= data['CO00DEM003']:
		CO00DEM003_DPUD04 = 1
	else:
		CO00DEM003_DPUD04 = 0

	if 59.58 <= data['CO01END089RO'] < 82.17:
		CO01END089RO_DPUD03 = 1
	else:
		CO01END089RO_DPUD03 = 0

	if 82.17 <= data['CO01END089RO']:
		CO01END089RO_DPUD04 = 1
	else:
		CO01END089RO_DPUD04 = 0

	if RECMORA001VSA < 5:
		RECMORA001VSA_DPUD01 = 1
	else:
		RECMORA001VSA_DPUD01 = 0

	if 0 <= data['CO01MOR060RO'] < 1:
		CO01MOR060RO_DPUD01 = 1
	else:
		CO01MOR060RO_DPUD01 = 0

	if 1 <= data['CO01MOR060RO']:
		CO01MOR060RO_DPUD02 = 1
	else:
		CO01MOR060RO_DPUD02 = 0

	if 2 <= MMAXHIS:
		MMAXHIS_DPUD02 = 1
	else:
		MMAXHIS_DPUD02 = 0

	if 1 <= data['CO01NUM050RO'] < 3:
		CO01NUM050RO_DPUD02 = 1
	else:
		CO01NUM050RO_DPUD02 = 0

	if 3 <= data['CO01NUM050RO']:
		CO01NUM050RO_DPUD03 = 1
	else:
		CO01NUM050RO_DPUD03 = 0

	if data['CO01INQ017TO'] < 2:
		CO01INQ017_DPUD01 = 1
	else:
		CO01INQ017_DPUD01 = 0

	if 3 <= data['CO01INQ017TO']:
		CO01INQ017_DPUD03 = 1
	else:
		CO01INQ017_DPUD03 = 0

	if data['CO01END020RO'] < 0.63:
		CO01END020RO_DPUD01 = 1
	else:
		CO01END020RO_DPUD01 = 0

	if 0.63 <= data['CO01END020RO'] < 1.77:
		CO01END020RO_DPUD02 = 1
	else:
		CO01END020RO_DPUD02 = 0

	if 4.49 <= data['CO01END020RO']:
		CO01END020RO_DPUD04 = 1
	else:
		CO01END020RO_DPUD04 = 0

	if 0 <= data['CO01MOR060CC']< 1:
		CO01MOR060CC_DPUD01 = 1
	else:
		CO01MOR060CC_DPUD01 = 0

	if 1 <= data['CO01MOR060CC']:
		CO01MOR060CC_DPUD02 = 1
	else:
		CO01MOR060CC_DPUD02 = 0

	if 0.01 <= data['CO01END017IN']:
		CO01END017IN_DPUD02 = 1
	else:
		CO01END017IN_DPUD02 = 0

	suma = 2.49390371193464 + \
			(CO02EXP006TO_DPU * 0.00962565053255312) + \
			(PRQALDIA_DPU * 1.01797600542744) + \
			(MOB60M_DPU * 0.0737146155290281) + \
			(CO02NUM042CB_DPU * -0.00820333727312719) + \
			(CO02EXP007TO_DPU * -0.00567824081776764) + \
			(MOB12_DPU * -0.0596035005866085) + \
			(CO00DEM003_DPUD04 * 0.0857474420683266) + \
			(CO01END089RO_DPUD03 * -0.410110970960899) + \
			(CO01END089RO_DPUD04 * -0.70056004503504) + \
			(RECMORA001VSA_DPUD01 * -0.372311661418595) + \
			(CO01MOR060RO_DPUD01 * 0.297821931378993) + \
			(CO01MOR060RO_DPUD02 * -0.351455278275151) + \
			(MMAXHIS_DPUD02 * -0.72876826897054) + \
			(CO01NUM050RO_DPUD02 * 0.22232583163106) + \
			(CO01NUM050RO_DPUD03 * 0.249236778230884) + \
			(CO01INQ017_DPUD01 * 0.131076953923632) + \
			(CO01INQ017_DPUD03 * -0.301130515733036) + \
			(CO01END020RO_DPUD01 * -0.317231902203161) + \
			(CO01END020RO_DPUD02 * -0.120742410717848) + \
			(CO01END020RO_DPUD04 * 0.161629996851654) + \
			(CO01MOR060CC_DPUD01 * 0.149784885489206) + \
			(CO01MOR060CC_DPUD02 * -0.0590958504020993) + \
			(CO01END017IN_DPUD02 * -0.462215502284069)

	AciertaA = int (1000 / (1 + np.exp(-suma)))

	AciertaADef = int (400.000000000000 + 110.321693765613 * suma)

	SCORE = AciertaADef

	if AciertaADef <= 150:
		SCORE=150
	if AciertaADef >= 999:
		SCORE=999

	reporte={}
	#reporte['COIDE']=int(data['COIDE'])
	#reporte['CONUMIDE']=int(data['CONUMIDE'])
	#reporte['SEGMENTO']=9
	#reporte['AciertaA']=AciertaA
	#reporte['AciertaADef']=SCORE
	#reporte['PRQALDIA']=PRQALDIA
	#reporte['MOB60M']=MOB60M
	#reporte['MOB12']=MOB12
	#reporte['RECMORA001VSA']=RECMORA001VSA
	#reporte['MMAXHIS']=MMAXHIS
	#reporte['CO02EXP006TO_DPU']=int(CO02EXP006TO_DPU)
	#reporte['PRQALDIA_DPU']=PRQALDIA_DPU
	#reporte['MOB60M_DPU']=int(MOB60M_DPU)
	#reporte['CO02NUM042CB_DPU']=int(CO02NUM042CB_DPU)
	#reporte['CO02EXP007TO_DPU']=int(CO02EXP007TO_DPU)
	#reporte['MOB12_DPU']=int(MOB12_DPU)
	#reporte['CO00DEM003_DPUD04']=int(CO00DEM003_DPUD04)
	#reporte['CO01END089RO_DPUD03']=int(CO01END089RO_DPUD03)
	#reporte['CO01END089RO_DPUD04']=int(CO01END089RO_DPUD04)
	#reporte['RECMORA001VSA_DPUD01']=int(RECMORA001VSA_DPUD01)
	#reporte['CO01MOR060RO_DPUD01']=int(CO01MOR060RO_DPUD01)
	#reporte['CO01MOR060RO_DPUD02']=int(CO01MOR060RO_DPUD02)
	#reporte['MMAXHIS_DPUD02']=int(MMAXHIS_DPUD02)
	#reporte['CO01NUM050RO_DPUD02']=int(CO01NUM050RO_DPUD02)
	#reporte['CO01NUM050RO_DPUD03']=int(CO01NUM050RO_DPUD03)
	#reporte['CO01INQ017_DPUD01']=int(CO01INQ017_DPUD01)
	#reporte['CO01INQ017_DPUD03']=int(CO01INQ017_DPUD03)
	#reporte['CO01END020RO_DPUD01']=int(CO01END020RO_DPUD01)
	#reporte['CO01END020RO_DPUD02']=int(CO01END020RO_DPUD02)
	#reporte['CO01END020RO_DPUD04']=int(CO01END020RO_DPUD04)
	#reporte['CO01MOR060CC_DPUD01']=int(CO01MOR060CC_DPUD01)
	#reporte['CO01MOR060CC_DPUD02']=int(CO01MOR060CC_DPUD02)
	#reporte['CO01END017IN_DPUD02']=int(CO01END017IN_DPUD02)

	reporte['scoreSegment']=9
	reporte['scoreValue']=SCORE

	return reporte,CO02EXP006TO_DPU

def segmentar_DCOM(SCORE,MMAXACT):#SEGMENTO 1 y 2

	if 4 <= MMAXACT and 400 <= SCORE:
		SCORE_ORI = (-2975.894 + 519.3702 * np.log(SCORE))
		if SCORE_ORI > 400:
			SCORE_ORI = 400
		if SCORE_ORI < 150:
			SCORE_ORI = 150
	else:
		SCORE_ORI=SCORE
	return SCORE_ORI

def segmentar_DFGE(data,SCORE,CO02EXP006TO_DPU,MMAXACT,RECMORA001VSA,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,TIPORELD01,RECMORA002VSA):#SEGMENTO 9
	
	NODO=0
	#APERTURA_ANT,APERTURA_ANT_F=apertura(data)
	if APERTURA_ANT >= 0 and APERTURA_ANT <= 35:
		RANGO_ANT=0

	if APERTURA_ANT >= 36 and APERTURA_ANT <= 70:
		RANGO_ANT=1

	if APERTURA_ANT >= 71 and APERTURA_ANT <= 122:
		RANGO_ANT=2

	if APERTURA_ANT >= 123 and APERTURA_ANT <= 168:
		RANGO_ANT=3

	if APERTURA_ANT >= 169:
		RANGO_ANT=4
	
	if 1 <= data['CO01EXP011RO']:
		M9_CO01EXP011RO_DPUD02=1
	else:
		M9_CO01EXP011RO_DPUD02=0

	if MMAXACT_F >= 4:
		M9_MMAXACT_F_120MAS=1	
	else:
		M9_MMAXACT_F_120MAS=0

	if MMAX06_NF >=4:
		M9_MMAX06_NF_120MAS=1
	else:
		M9_MMAX06_NF_120MAS=0

	if data['CO01END015RO'] < 0.58:
		M9_CO01END015RO_DPUD01=1
	else:
		M9_CO01END015RO_DPUD01=0

	if data['CO01END059RO'] < 0.99:
		M9_CO01END059RO_DPUD01=1
	else:
		M9_CO01END059RO_DPUD01=0

	if 62.1 <= data['CO01END090RO']:
		M9_CO01END090RO_DPUD04=1
	else:
		M9_CO01END090RO_DPUD04=0

	if 0 <= data['CO01ACP008AH'] < 1:
		M9_CO01ACP008AH_DPUD01=1
	else:
		M9_CO01ACP008AH_DPUD01=0

	if data['CO01INQ016TO'] < 2:
		M9_CO01INQ016_DPUD01=1
	else:
		M9_CO01INQ016_DPUD01=0

	if 13 <= data['CO01EXP004RO'] < 26:
		M9_CO01EXP004RO_DPUD03=1
	else:
		M9_CO01EXP004RO_DPUD03=0

	if 39 <= data['CO00DEM003'] < 48:
		M9_CO00DEM003_DPUD03=1
	else:
		M9_CO00DEM003_DPUD03=0

	if 1  <= data['CO01MOR033CC'] < 2:
		M9_CO01MOR033CC_DPUD02=1
	else:
		M9_CO01MOR033CC_DPUD02=0

	if 85.22 <= data['CO01END086RO']:
		M9_CO01END086RO_DPUD04=1
	else:
		M9_CO01END086RO_DPUD04=0

	if 101 <= data['CO01EXP006AH']:
		M9_CO01EXP006AH_DPUD04=1
	else:
		M9_CO01EXP006AH_DPUD04=0

	if data['CO01MOR080IN'] < 100:
		M9_CO01MOR080IN_DPUD01=1
	else:
		M9_CO01MOR080IN_DPUD01=0

	if data['CO01EXP004AH'] <0:
		M9_CO01EXP004AH_DPUD00=1
	else:
		M9_CO01EXP004AH_DPUD00=0

	if 72.22 <= data['CO02NUM042IN']:
		M9_CO02NUM042IN_DPUD04=1
	else:
		M9_CO02NUM042IN_DPUD04=0

	if EVER03048P < 1:
		M9_EVER03048P_DPUD01=1
	else:
		M9_EVER03048P_DPUD01=0

	if data['CO01END029RO'] < 2.32:
		M9_CO01END029RO_DPUD01=1
	else:
		M9_CO01END029RO_DPUD01=0

	if 86.81 <= data['CO01END077RO']:
		M9_CO01END077RO_DPUD04=1
	else:
		M9_CO01END077RO_DPUD04=0

	if 0 <= data['CO01ACP008RO'] < 1:
		M9_CO01ACP008RO_DPUD01=1
	else:
		M9_CO01ACP008RO_DPUD01=0

	if 85.12 <= data['CO01END071RO']:
		M9_CO01END071RO_DPUD04=1
	else:
		M9_CO01END071RO_DPUD04=0

	if data['CO01END092RO'] < 10.71:
		M9_CO01END092RO_DPUD01=1
	else:
		M9_CO01END092RO_DPUD01=0

	if MMAX18 >= 4:
		M9_MMAX18_120MAS=1
	else:
		M9_MMAX18_120MAS=0

	if 60.88 <= data['CO01END078RO'] < 86.63:
		M9_CO01END078RO_DPUD03=1
	else:
		M9_CO01END078RO_DPUD03=0

	if 0 <= data['CO02EXP013AH'] < 50:
		M9_CO02EXP013AH_DPUD01=1
	else:
		M9_CO02EXP013AH_DPUD01=0

	if data['CO01END025RO'] < 0.66:
		M9_CO01END025RO_DPUD01=1
	else:
		M9_CO01END025RO_DPUD01=0

	if 2 <= data['CO01INQ017TO'] < 3:
		M9_CO01INQ017_DPUD02=1
	else:
		M9_CO01INQ017_DPUD02=0

	if 5 <= RECMORA002VSA < 15:
		RECMORA002VSA_DPUD02=1
	else:
		RECMORA002VSA_DPUD02=0

	if 0.01 < data['CO01END022IN']:
		M9_CO01END022IN_DPUD02=1
	else:
		M9_CO01END022IN_DPUD02=0
	
	if 1 <= data['CO01ACP005CT']:
		M9_CO01ACP005CT_DPUD02=1
	else:
		M9_CO01ACP005CT_DPUD02=0

	if RECMORA001VSA  < 5:
		RECMORA001VSA_DPUD01=1
	else:
		RECMORA001VSA_DPUD01=0

	if 2 <= data['CO01MOR001RO'] < 4:
		M9_CO01MOR001RO_DPUD02=1
	else:
		M9_CO01MOR001RO_DPUD02=0

	if 3.48 <= data['CO01END059RO'] < 11.91:
		M9_CO01END059RO_DPUD03=1
	else:
		M9_CO01END059RO_DPUD03=0

	if data['CO01END060RO'] < 0.73:
		M9_CO01END060RO_DPUD01=1
	else:
		M9_CO01END060RO_DPUD01=0

	if 26 <= data['CO01EXP002IN']:
		M9_CO01EXP002IN_DPUD04=1
	else:
		M9_CO01EXP002IN_DPUD04=0

	if data['CO01MOR009CC']>=0:
		CO01MOR009CC=data['CO01MOR009CC']
	else:
		CO01MOR009CC=0

	#arbol de segmentacion
	if 0.5 <= M9_MMAXACT_F_120MAS:
		if 0.5 <= M9_CO01EXP011RO_DPUD02:
			if 0.5 <= M9_CO01END059RO_DPUD03:
				NODO=582
			else:
				NODO=581
		else:
			if 0.5 <= M9_MMAX06_NF_120MAS:
				NODO=301
			else:
				NODO=300
	else:
		#RAMAIZQ1
		if 0.5 <= MMAXACT:
			if APERTURA_ANT_F < 20.5:
				NODO=520
			else:
				if SCORE<515:
					NODO=522
				else:
					if 0.5 <= M9_CO01END015RO_DPUD01:
						if M9_CO01END059RO_DPUD01 < 0.5:
							NODO=526
						else:
							NODO=527
					else:
						if 0.5 <= M9_CO01END090RO_DPUD04:
							NODO=531
						else:
							if 0.5 <= M9_CO01ACP008AH_DPUD01:
								NODO=539
							else:
								if 100 <= data['CO01EXP001CO']:
									NODO=544
								else:
									NODO=543
		else:
			#RAMAIZQ2
			if RANGO_ANT < 1.5:
				if SCORE < 592.5:
					if 0.5 <= M9_CO01INQ016_DPUD01:
						if 0.5 <= M9_CO01EXP004RO_DPUD03:
							NODO=313
						else:
							if 0.5 <= M9_CO00DEM003_DPUD03:
								NODO=315
							else:
								if 0.5 <= M9_CO01MOR033CC_DPUD02:
									NODO=320
								else:
									NODO=319
					else:
						if 0.5 <= M9_CO01END086RO_DPUD04:
							NODO=305
						else:
							NODO=304
				else:
					if 700 <= SCORE:
						if 0.5 <= M9_CO01EXP006AH_DPUD04:
							if M9_CO01MOR080IN_DPUD01 < 0.5:
								NODO=528
							else:
								NODO=529
						else:
							if 0.5 <= M9_CO01EXP004AH_DPUD00:
								if 0.5 <= CO01MOR009CC:
									NODO=519
								else:
									NODO=518
							else:
								if 0.5 <= M9_CO02NUM042IN_DPUD04:
									NODO=370
								else:
									NODO=369
					else:
						if M9_EVER03048P_DPUD01 < 0.5:
							if M9_CO01END060RO_DPUD01 < 0.5:
								NODO=564
							else:
								if 0.5 <= M9_CO01EXP002IN_DPUD04:
									NODO=567
								else:
									NODO=566
						else:
							if CO02EXP006TO_DPU < 6:
								NODO=336
							else:
								if 0.5 <= M9_CO01END077RO_DPUD04:
									NODO=339
								else:
									if APERTURA_ANT < 8.5:
										NODO=340
									else:
										if 63.5 <= APERTURA_ANT:
											NODO=343
										else:
											NODO=342
			else:
				#RAMAIZQ3
				if SCORE < 600:
					if 0.5 <= M9_CO01ACP008RO_DPUD01:
						NODO=381
					else:
						NODO=380
				else:
					if 688.5 <= SCORE < 780:
						if 0.5 <= M9_CO01END071RO_DPUD04:
							NODO=398
						else:
							if 0.5 <= M9_CO01ACP008RO_DPUD01:
								NODO=412
							else:
								if M9_CO01END092RO_DPUD01 < 0.5:
									NODO=422
								else:
									if 0.5 <= M9_MMAX18_120MAS:
										NODO=506
									else:
										NODO=505
					else:
						if 780 <= SCORE:
							if 0.5 <= M9_CO01END078RO_DPUD03:
								if 0.5 <= M9_CO02EXP013AH_DPUD01:
									NODO=546
								else:
									NODO=545
							else:
								if 0.5 <= M9_CO01END025RO_DPUD01:
									if 0.5 <= M9_CO01INQ017_DPUD02:
										NODO=469
									else:
										if 0.5 <= RECMORA002VSA_DPUD02:
											NODO=489
										else:
											NODO=488
								else:
									if 0.5 <= TIPORELD01:
										NODO=462
									else:
										if 0.5 <= M9_CO01END022IN_DPUD02:
											NODO=464
										else:
											NODO=463
						else:
							if 0.5 <= M9_CO01ACP005CT_DPUD02:
								NODO=383
							else:
								if RECMORA001VSA_DPUD01 < 0.5:
									if 0.5 <= M9_CO01MOR001RO_DPUD02:
										NODO=390
									else:
										if data['CO01EXP001IN'] < 53.5:
											NODO=510
										else:
											NODO=511
								else:
									NODO=385
	#APLICAR NODO
	if SCORE >= 653 and NODO == 564:
		SCORE=653
	if SCORE >= 650 and NODO == 531:
		SCORE=650
	if SCORE >= 645 and NODO == 519:
		SCORE=645
	if SCORE >= 647 and NODO == 510:
		SCORE=647
	if SCORE >= 642 and NODO == 543:
		SCORE=642
	if SCORE >= 634 and NODO == 383:
		SCORE=634
	if SCORE >= 628 and NODO == 340:
		SCORE=628
	if SCORE >= 621 and NODO == 339:
		SCORE=621
	if SCORE >= 618 and NODO == 567:
		SCORE=618
	if SCORE >= 610 and NODO == 566:
		SCORE=610
	if SCORE >= 607 and NODO == 539:
		SCORE=607
	if SCORE >= 599 and NODO == 336:
		SCORE=599
	if SCORE >= 595 and NODO == 380:
		SCORE=595
	if SCORE >= 595 and NODO == 527:
		SCORE=595
	if SCORE >= 591 and NODO == 315:
		SCORE=591
	if SCORE >= 584 and NODO == 320:
		SCORE=584
	if SCORE >= 579 and NODO == 526:
		SCORE=579
	if SCORE >= 579 and NODO == 319:
		SCORE=579
	if SCORE >= 563 and NODO == 313:
		SCORE=563
	if SCORE >= 544 and NODO == 381:
		SCORE=544
	if SCORE >= 529 and NODO == 304:
		SCORE=529
	if SCORE >= 509 and NODO == 305:
		SCORE=509
	if SCORE >= 495 and NODO == 520:
		SCORE=495
	if SCORE >= 479 and NODO == 522:
		SCORE=479
	if SCORE >= 457 and NODO == 581:
		SCORE=457
	if SCORE >= 457 and NODO == 582:
		SCORE=457
	if SCORE >= 421 and NODO == 300:
		SCORE=421
	if SCORE >= 421 and NODO == 301:
		SCORE=421

	return SCORE


class aciertaA_AAE_1(object):

	@staticmethod
	def __call__(data):
		INPUT_SEG = 1
		data_mod = deepcopy(data)
		x = {}
		try:
			EMOR,DMOR,QTOTAB,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,QTOTABHD,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA=hibridas(data_mod,INPUT_SEG)
		except Exception, error:
			tb = traceback.format_exc()
			assert False, "!!! Error: {}, {}".format(error, tb)
		a,b=exclusiones(data_mod,QTOTAB,QTOTABHD,DMOR,EMOR)
		if a == 99 :
			try:
				x=scorecard(data_mod,INPUT_SEG,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA)
				x['exclusionCode']=[a]
			except Exception, error:
				tb = traceback.format_exc()
				assert False, "!!! Error: {}, {}".format(error, tb)
		else:
			x['scoreValue']=b
			x['scoreSegment']=0
			x['exclusionCode']=[a]
		x['TIPOID'] = data.get('TIPOID')
		x['scoreCode'] = '49'
		x['scoreName'] = 'AAE'
		x['scoreDate'] = int(round(time.time() * 1000))
		x['relation'] = '0'
		x['tradeHolderIndicator'] = '0'
		return x


class aciertaA_AAE_2(object):

	@staticmethod
	def __call__(data):
		INPUT_SEG = 2
		data_mod = deepcopy(data)
		x = {}
		try:
			EMOR,DMOR,QTOTAB,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,QTOTABHD,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA=hibridas(data_mod,INPUT_SEG)
		except Exception, error:
			tb = traceback.format_exc()
			assert False, "!!! Error: {}, {}".format(error, tb)
		a,b=exclusiones(data_mod,QTOTAB,QTOTABHD,DMOR,EMOR)
		if a == 99 :
			try:
				x=scorecard(data_mod,INPUT_SEG,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA)
				x['exclusionCode']=[a]
			except Exception, error:
				tb = traceback.format_exc()
				assert False, "!!! Error: {}, {}".format(error, tb)
		else:
			x['scoreValue']=b
			x['scoreSegment']=0
			x['exclusionCode']=[a]
		x['TIPOID'] = data.get('TIPOID')
		x['scoreCode'] = '49'
		x['scoreName'] = 'AAE'
		x['scoreDate'] = int(round(time.time() * 1000))
		x['relation'] = '1'
		x['tradeHolderIndicator'] = '0'
		return x


class aciertaA_AAD_3(object):

	@staticmethod
	def __call__(data):
		INPUT_SEG = 3
		data_mod = deepcopy(data)
		x = {}
		try:
			EMOR,DMOR,QTOTAB,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,QTOTABHD,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA=hibridas(data_mod,INPUT_SEG)
		except Exception, error:
			tb = traceback.format_exc()
			assert False, "!!! Error: {}, {}".format(error, tb)
		a,b=exclusiones(data_mod,QTOTAB,QTOTABHD,DMOR,EMOR)
		if a == 99 :
			try:
				x=scorecard(data_mod,INPUT_SEG,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA)
				x['exclusionCode']=[a]
			except Exception, error:
				tb = traceback.format_exc()
				assert False, "!!! Error: {}, {}".format(error, tb)
		else:
			x['scoreValue']=b
			x['scoreSegment']=0
			x['exclusionCode']=[a]
		x['TIPOID'] = data.get('TIPOID')
		x['scoreCode'] = '48'
		x['scoreName'] = 'AAD'
		x['scoreDate'] = int(round(time.time() * 1000))
		x['relation'] = '0'
		x['tradeHolderIndicator'] = '0'
		return x


class aciertaA_AAD_4(object):

	@staticmethod
	def __call__(data):
		INPUT_SEG = 4
		data_mod = deepcopy(data)
		x = {}
		try:
			EMOR,DMOR,QTOTAB,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,QTOTABHD,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA=hibridas(data_mod,INPUT_SEG)
		except Exception, error:
			tb = traceback.format_exc()
			assert False, "!!! Error: {}, {}".format(error, tb)
		a,b=exclusiones(data_mod,QTOTAB,QTOTABHD,DMOR,EMOR)
		if a == 99 :
			try:
				x=scorecard(data_mod,INPUT_SEG,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA)
				x['exclusionCode']=[a]
			except Exception, error:
				tb = traceback.format_exc()
				assert False, "!!! Error: {}, {}".format(error, tb)
		else:
			x['scoreValue']=b
			x['scoreSegment']=0
			x['exclusionCode']=[a]
		x['TIPOID'] = data.get('TIPOID')
		x['scoreCode'] = '48'
		x['scoreName'] = 'AAD'
		x['scoreDate'] = int(round(time.time() * 1000))
		x['relation'] = '1'
		x['tradeHolderIndicator'] = '0'
		return x


class aciertaA_AAB_5(object):

	@staticmethod
	def __call__(data):
		INPUT_SEG = 5
		data_mod = deepcopy(data)
		x = {}
		try:
			EMOR,DMOR,QTOTAB,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,QTOTABHD,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA=hibridas(data_mod,INPUT_SEG)
		except Exception, error:
			tb = traceback.format_exc()
			assert False, "!!! Error: {}, {}".format(error, tb)
		a,b=exclusiones(data_mod,QTOTAB,QTOTABHD,DMOR,EMOR)
		if a == 99 :
			try:
				x=scorecard(data_mod,INPUT_SEG,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA)
				x['exclusionCode']=[a]
			except Exception, error:
				tb = traceback.format_exc()
				assert False, "!!! Error: {}, {}".format(error, tb)
		else:
			x['scoreValue']=b
			x['scoreSegment']=0
			x['exclusionCode']=[a]
		x['TIPOID'] = data.get('TIPOID')
		x['scoreCode'] = '45'
		x['scoreName'] = 'AAB'
		x['scoreDate'] = int(round(time.time() * 1000))
		x['relation'] = '0'
		x['tradeHolderIndicator'] = '0'
		return x


class aciertaA_AAB_6(object):

	@staticmethod
	def __call__(data):
		INPUT_SEG = 6
		data_mod = deepcopy(data)
		x = {}
		try:
			EMOR,DMOR,QTOTAB,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,QTOTABHD,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA=hibridas(data_mod,INPUT_SEG)
		except Exception, error:
			tb = traceback.format_exc()
			assert False, "!!! Error: {}, {}".format(error, tb)
		a,b=exclusiones(data_mod,QTOTAB,QTOTABHD,DMOR,EMOR)
		if a == 99 :
			try:
				x=scorecard(data_mod,INPUT_SEG,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA)
				x['exclusionCode']=[a]
			except Exception, error:
				tb = traceback.format_exc()
				assert False, "!!! Error: {}, {}".format(error, tb)
		else:
			x['scoreValue']=b
			x['scoreSegment']=0
			x['exclusionCode']=[a]
		x['TIPOID'] = data.get('TIPOID')
		x['scoreCode'] = '45'
		x['scoreName'] = 'AAB'
		x['scoreDate'] = int(round(time.time() * 1000))
		x['relation'] = '1'
		x['tradeHolderIndicator'] = '0'
		return x


class aciertaA_AAF_7(object):

	@staticmethod
	def __call__(data):
		INPUT_SEG = 7
		data_mod = deepcopy(data)
		x = {}
		try:
			EMOR,DMOR,QTOTAB,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,QTOTABHD,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA=hibridas(data_mod,INPUT_SEG)
		except Exception, error:
			tb = traceback.format_exc()
			assert False, "!!! Error: {}, {}".format(error, tb)
		a,b=exclusiones(data_mod,QTOTAB,QTOTABHD,DMOR,EMOR)
		if a == 99 :
			try:
				x=scorecard(data_mod,INPUT_SEG,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA)
				x['exclusionCode']=[a]
			except Exception, error:
				tb = traceback.format_exc()
				assert False, "!!! Error: {}, {}".format(error, tb)
		else:
			x['scoreValue']=b
			x['scoreSegment']=0
			x['exclusionCode']=[a]
		x['TIPOID'] = data.get('TIPOID')
		x['scoreCode'] = '95'
		x['scoreName'] = 'AAF'
		x['scoreDate'] = int(round(time.time() * 1000))
		x['relation'] = '0'
		x['tradeHolderIndicator'] = '0'
		return x


class aciertaA_AAA_8(object):

	@staticmethod
	def __call__(data):
		INPUT_SEG = 8
		data_mod = deepcopy(data)
		x = {}
		try:
			EMOR,DMOR,QTOTAB,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,QTOTABHD,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA=hibridas(data_mod,INPUT_SEG)
		except Exception, error:
			tb = traceback.format_exc()
			assert False, "!!! Error: {}, {}".format(error, tb)
		a,b=exclusiones(data_mod,QTOTAB,QTOTABHD,DMOR,EMOR)
		if a == 99 :
			try:
				x=scorecard(data_mod,INPUT_SEG,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA)
				x['exclusionCode']=[a]
			except Exception, error:
				tb = traceback.format_exc()
				assert False, "!!! Error: {}, {}".format(error, tb)
		else:
			x['scoreValue']=b
			x['scoreSegment']=0
			x['exclusionCode']=[a]
		x['TIPOID'] = data.get('TIPOID')
		x['scoreCode'] = '41'
		x['scoreName'] = 'AAA'
		x['scoreDate'] = int(round(time.time() * 1000))
		x['relation'] = '0'
		x['tradeHolderIndicator'] = '0'
		return x


class aciertaA_AAC_9(object):

	@staticmethod
	def __call__(data):
		INPUT_SEG = 9
		data_mod = deepcopy(data)
		x = {}
		try:
			EMOR,DMOR,QTOTAB,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,QTOTABHD,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA=hibridas(data_mod,INPUT_SEG)
		except Exception, error:
			tb = traceback.format_exc()
			assert False, "!!! Error: {}, {}".format(error, tb)
		a,b=exclusiones(data_mod,QTOTAB,QTOTABHD,DMOR,EMOR)
		if a == 99 :
			try:
				x=scorecard(data_mod,INPUT_SEG,PRQALDIA,TIPORELD01,TIPORELD04,MMAXHIS,RECMORA001VSA,EVER03006P,EXPOSICION,MMAX24,RECMORA120,PROQTOTAB,PREXPOSICIONIN,MOB12,RECMORA001,MMAX48,RECMORA030,EVER06036P,EVER03024P,EVER12036E,MOB60M,MMAXACT_F,MMAX06_NF,EVER03048P,MMAX18,APERTURA_ANT,APERTURA_ANT_F,MMAXACT,RECMORA002VSA)
				x['exclusionCode']=[a]
			except Exception, error:
				tb = traceback.format_exc()
				assert False, "!!! Error: {}, {}".format(error, tb)
		else:
			x['scoreValue']=b
			x['scoreSegment']=0
			x['exclusionCode']=[a]
		x['TIPOID'] = data.get('TIPOID')
		x['scoreCode'] = '47'
		x['scoreName'] = 'AAC'
		x['scoreDate'] = int(round(time.time() * 1000))
		x['relation'] = '0'
		x['tradeHolderIndicator'] = '0'
		return x
