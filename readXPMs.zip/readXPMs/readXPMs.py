#!/usr/bin/env python
# -*- coding: utf-8 -*-
""" Engines Differ Tool

Differ engine application, computes attributes and scores in order to certificate Omnia is data and components.
"""
from ConfigParser import ConfigParser

import pyspark
from pyspark import SparkContext, SparkConf
import traceback
import json
import ConfigParser
import argparse
import sys
import os
from oxygenScoresEngine.orchestrator import Orchestrator
import logging
from logging import Logger
import pandas as pd
from copy import deepcopy
import os

# Logging configuration
log = logging.getLogger('scoresEngine')  # type: Logger
_handler = logging.StreamHandler(sys.stdout)
# Logging format e.g. 2020-02-07 10:43:31,749 - scoresEngine - INFO: ...
_handler.setFormatter(logging.Formatter("%(asctime)s - %(name)s - %(levelname)s : %(message)s"))
log.addHandler(_handler)
log.setLevel("DEBUG")

# Initialize sparkSession and gets sparkContext
sc = SparkContext()  # type: SparkContext
sparkSession = pyspark.sql.SparkSession \
    .builder \
    .appName("scoresEngine") \
    .getOrCreate()

# Import Attributes Engine Java Packages
jvm = getattr(sc, "_gateway").jvm
# Load Attributes Engine Class
oxygenAttributesEngine = getattr(jvm, "co.com.experian.omnia.motorcrts.orquestador.OxygenAttributesEngine").\
    getAttributesEngine()
readCobolFile = getattr(jvm, "co.com.experian.omnia.motorcrts.entrada.cobol.LectorRutinaCobol")()

rawAttributesKeys = []
attributesKeys = []
with open("attributesKeys.txt", "r") as attributesKeysFile:
    rawAttributesKeys.append("TIPOID")
    rawAttributesKeys.append("NUMID")
    rawAttributesKeys.append("CO01NUM003RO")
    for attributeName in attributesKeysFile:
        rawAttributesKeys.append(attributeName.replace("\n", ""))
    for attributeName in rawAttributesKeys:
        if attributeName not in attributesKeys:
            attributesKeys.append(attributeName)


def loadConfig(attributes_bundle_file, scores_bundle_file, app_config_file):
    """ Loads configuration files and return them in the required format.

    :param attributes_bundle_file: Attributes Bundle json file.
    :param scores_bundle_file: Scores bundle json file.
    :param app_config_file: Application .conf file.
    :return: configuration objects.
    """
    with open(attributes_bundle_file, "r") as attributesBundleFile:
        attributesBundleObject = attributesBundleFile.read()
        if attributesBundleObject:
            log.debug("Attributes Bundle Loaded.")
        else:
            raise Exception("!!! Error: Missing or corrupted Attributes bundle.")
    with open(scores_bundle_file, "r") as scoresBundleFile:
        try:
            scoresBundleObject = json.load(scoresBundleFile)
            log.debug("Scores Bundle Loaded.")
        except Exception, error:
            raise Exception("!!! Error: Missing or corrupted Scores bundle. {}".format(error))
    appConfigObject = ConfigParser.ConfigParser()  # type: ConfigParser
    appConfigObject.read(app_config_file)
    if appConfigObject.sections():
        log.debug("Application Configuration loaded.")
    else:
        raise Exception("!!! Error: Missing or corrupted Scores bundle.")
    return attributesBundleObject, scoresBundleObject, appConfigObject


def loadDataPaths(app_config):
    # type: (ConfigParser) -> (str, str, str, str)
    """ Load application data paths.

    :param app_config: Application configuration parser
    :return: Data Paths.
    """
    sourceXpm = sourceSal = targetXpm = targetSal = None
    if app_config.has_section("application"):
        if app_config.has_option("application", "sourceXpm"):
            sourceXpm = app_config.get("application", "sourceXpm")
        if app_config.has_option("application", "sourceSal"):
            sourceSal = app_config.get("application", "sourceSal")
        if app_config.has_option("application", "targetXpm"):
            targetXpm = app_config.get("application", "targetXpm")
        if app_config.has_option("application", "targetSal"):
            targetSal = app_config.get("application", "targetSal")
        if sourceXpm and sourceSal and targetXpm and targetSal:
            return sourceXpm, sourceSal, targetXpm, targetSal
        else:
            raise Exception("!!! Error: Missing application data paths or corrupted application configuration file")


def readSmlmv(smlmv_path):
    smlmvData = pd.read_csv(smlmv_path, sep=";")
    smlmvRawDict = eval(smlmvData.to_json())  # type: dict
    if len(smlmvRawDict.get("value").items()) == len(smlmvRawDict.get("year").items()):
        values = smlmvRawDict.get("value")
        years = smlmvRawDict.get("year")
        smlmvDict = {years[str(key)]: str(values[key]) for key in values.keys()}
        return smlmvDict
    else:
        raise Exception("Error loading smlmv csv file !!!")


def flatter1(xpm):
    xpmJson = deepcopy(xpm)
    flat = {}
    info = {
        "TIPOID": xpmJson["bureauAttributes"]["personIdType"],
        "NUMID": xpmJson["bureauAttributes"]["personIdNumber"]
    }
    attributes = {
        x["name"]: x.get('errorValue') or x.get('value')
        for x in xpmJson['bureauAttributes']['attributes']
    }
    scores = {
        x["modelName"]: x.get("scoreValue") or x.get("incomeSMLMV")
        for x in xpmJson["bureauModels"][0]["scores"]
    }
    flat.update(info)
    flat.update(attributes)
    flat.update(scores)
    return flat


def flatter2(jsonObject):
    resultJson = deepcopy(jsonObject)
    flat = {}
    info = {
        "TIPOID": resultJson["TIPOID"],
        "NUMID": resultJson["NUMID"]
    }
    attributes = {
        key: value
        for key, value in resultJson["LLAVE"].items()
    }
    flat.update(info)
    flat.update(attributes)
    flat.update(scores)
    return flat


def generateFromPureCobol(source_sal, target_sal):
    # Read XPMs
    results = []
    files = []
    for i in os.listdir(source_sal):
        if i.endswith('.json'):
            with open("xpms/"+i, "r") as jsonFile:
                for person_cobol in jsonFile:
                    results.append(flatter2(json.loads(person_cobol)))
    with open(target_sal, "w") as targetFile:
        targetFile.write(";".join(attributesKeys)+";\n")
        for result in results:
            for name in attributesKeys:
                gettedValue = result.get(name, -1)
                value = float(gettedValue) if gettedValue else -1.0
                targetFile.write("{};".format(value))
            targetFile.write("\n")


def generateFromCobol(source_sal, target_sal, oxygen_scores_engine):
    # Generate Person Object for each Person
    listOfPersons = readCobolFile.leerArchivo(source_sal)
    results = []
    for person in listOfPersons:
        personAttributes = json.dumps({"bureauAttributes": json.loads(oxygenAttributesEngine.executeCobol(person))})
        results.append(flatter1(json.loads(oxygen_scores_engine.computeScores(personAttributes))))
    with open(target_sal, "w") as targetFile:
        targetFile.write(";".join(attributesKeys)+";\n")
        for result in results:
            for name in attributesKeys:
                gettedValue = result.get(name, -1)
                value = float(gettedValue) if gettedValue else -1.0
                targetFile.write("{};".format(value))
            targetFile.write("\n")


def generateFromXpm(source_xpm, target_xpm, oxygen_scores_engine):
    # Read XPMs
    results = []
    files = []
    for i in os.listdir(source_xpm):
        if i.endswith('.json'):
            with open("xpms/"+i, "r") as jsonFile:
                for personXpm in jsonFile:
                    person = json.loads(personXpm)
                    bureauAttributes = oxygenAttributesEngine.execute(json.dumps(person))
                    personAttributes = {"bureauAttributes": json.loads(bureauAttributes)}
                    results.append(flatter1(json.loads(oxygen_scores_engine.computeScores(json.dumps(personAttributes)))))
    with open(target_xpm, "w") as targetFile:
        targetFile.write(";".join(attributesKeys)+";\n")
        for result in results:
            for name in attributesKeys:
                gettedValue = result.get(name, -1)
                value = float(gettedValue) if gettedValue else -1.0
                targetFile.write("{};".format(value))
            targetFile.write("\n")


if __name__ == "__main__":
    # Application Arguments Parsing
    parser = argparse.ArgumentParser(description='Run Scores Engine PySpark job')
    parser.add_argument('--appConfig', type=str, required=True, dest='appConfigFile',
                        help="App configuration file name.")
    parser.add_argument('--scoresBundle', type=str, required=True, dest='scoresBundleFile',
                        help="Scores bundle file path.")
    parser.add_argument('--attributesBundle', type=str, required=True, dest='attributesBundle',
                        help="Attributes bundle file path.")
    args = parser.parse_args()

    # Load Application Configuration
    attributesBundle, scoresBundle, appConfig = loadConfig(
        args.attributesBundle, args.scoresBundleFile, args.appConfigFile)
    # Get data paths
    sourceXpm, sourceSal, targetXpm, targetSal = loadDataPaths(appConfig)
    # Load scores App Configuration
    appScoresConfig = ConfigParser.ConfigParser()
    appScoresConfig.read("conf/appScores.conf")

    if appConfig.has_option("application", "smlmvPath"):
        smlmvPath = appConfig.get("application", "smlmvPath")
    else:
        raise Exception("Application configuration has not a valid SMLMV file path !!!")

    try:
        smlmv = readSmlmv(smlmvPath)
        # Configure Attributes Engine
        oxygenAttributesEngine.configure(attributesBundle, {str(key): str(value) for key, value in smlmv.items()})
        # Configure Scores Engines
        oxygenScoresEngine = Orchestrator(scoresBundle, appScoresConfig)
        oxygenScoresEngine.createScoresModelsInstances()
        # Execute Cobol routine
        generateFromCobol(sourceSal, targetSal, oxygenScoresEngine)
        # generateFromPureCobol(source_sal, target_sal)
        # Execute XPM routine
        generateFromXpm(sourceXpm, targetXpm, oxygenScoresEngine)
    except Exception as error:
        tb = traceback.format_exc()
        log.error("!!! Error: {}, {}".format(error, tb))
