
import glob
Files = glob.glob("*.pkl")

for File in Files:
  a = open(File, "rb").readlines()
  a = map(lambda x: x.replace("\r\n", "\n"), a)
  with open("".join(["NEW_MODELS/", File]),"wb") as j:
    for i in a:
      j.write(i)

exit()
