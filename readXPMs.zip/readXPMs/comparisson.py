import pandas as pd
import numpy as np


if __name__ == "__main__":
    icgmotCsvPath = "icgmotOut/icgmot.csv"  # type: str
    xpmsCsvPath = "xpmsOut/xpm.csv"  # type: str

    icgmotCsv = pd.read_csv(icgmotCsvPath, sep=";")
    xpmsCsv = pd.read_csv(xpmsCsvPath, sep=";")

    mergedFiles = pd.merge(icgmotCsv, xpmsCsv, on=['NUMID', 'TIPOID'])
    mergedFiles.to_csv('mergeAttributes&Scores.csv', sep=';', float_format='%11.4f', index=False)

    Comparison = []
    for key, values in mergedFiles.to_dict().items():
        mean = np.mean(values.values())
        var = np.var(values.values())
        maxE = np.max(values.values())
        Comparison.append(
            {
                "Attribute": key.split('_')[0],
                "Mean Error": mean,
                "Error Variance": var,
                "Max Error": maxE
            }
        )
    errors = pd.DataFrame(Comparisson)
    errors.to_csv('attributes&scores_errors.csv', sep=';', float_format='%11.4f', index=False)