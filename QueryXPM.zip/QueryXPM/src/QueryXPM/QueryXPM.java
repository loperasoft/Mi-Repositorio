package QueryXPM;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class QueryXPM {

	private static SparkSession spark = null;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		spark = SparkSession			  
				  .builder()
				  .master("local[3]")
			      .appName("Query XPM idNumber")			      
			      .getOrCreate(); 
		
		//SearchXPM("file:///test-ids/*", "618015,715736,899106,9102392,11389969,51764226,71695652,79143381,79462597,79753890,80061057,80312668,91275600" +
		//",900422614,1014184450,1016000684,1016014814,1020715947,1024490885,1108452899,1130613592");//"71940798"
		SearchXPM("file:///test-ids_47/*", "66774314");//args[1]
		
		spark.stop();
	}
	
	private static void SearchXPM(String strFile, String idNumber)
	{
		try
		{	
			System.out.println("Ruta: " + strFile);
			System.out.println("IdNumber: " + idNumber);
			
			Dataset<Row> dsXPM = spark.read().json(strFile).repartition(10);
			
			dsXPM.filter("validatedRecordJsonTest.idNumber in( " + idNumber + ")")
			.repartition(1)
			.write()
			.format("json")
			.mode("overwrite")			
			//.save("hdfs://nameservice1/user/c66357a/Xpm/" + idNumber);
			.save("C:/Users/c66357a/Documents/QueryXPM/" + idNumber);//XPMs");
			//.foreach(row -> System.out.println("Registro: " + row));
			
			/*dsXPM.createOrReplaceTempView("XPM");
			
			Dataset<Row> dsPerson = spark.sql(
					"Select * From XPM"
					+ " Where validatedRecordJsonTest.idNumber == " + idNumber);
			
			dsPerson.show(false);*/
		}
		
		catch (Exception e) {
		      e.printStackTrace();
		      System.out.println(e);
	   }
	}
}
